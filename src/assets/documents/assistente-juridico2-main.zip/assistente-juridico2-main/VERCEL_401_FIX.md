# Correção do Erro 401 Unauthorized na Vercel

## 🔍 Diagnóstico do Problema

Você está recebendo erros **401 Unauthorized** ao acessar seu deployment na Vercel. Os logs mostram:

```
GET / → 401 Unauthorized
GET /assets/icon-LBgKhUI_.svg → 401 Unauthorized  
GET /assets/manifest-C8wLVLY-.json → 401 Unauthorized
```

### Causa Raiz

A presença dos parâmetros `_vercel_jwt` e `_vercel_jwe` nas requisições indica que a **Proteção de Deployment da Vercel** está ativada no seu projeto. Isso significa que a Vercel está exigindo autenticação antes de servir qualquer conteúdo (incluindo assets estáticos).

## ✅ Solução: Desabilitar a Proteção de Deployment

### Opção 1: Desabilitar Completamente (Recomendado para Apps Públicos)

Se sua aplicação deve ser acessível publicamente, siga estes passos:

1. **Acesse o Dashboard da Vercel:**
   - Vá para: https://vercel.com/dashboard
   - Selecione seu projeto `assistente-juridico`

2. **Navegue até as Configurações:**
   - Clique em **Settings** (Configurações)
   - No menu lateral, clique em **Deployment Protection** (Proteção de Deployment)

3. **Desabilite a Proteção:**
   - Você verá uma ou mais das seguintes opções ativadas:
     - **Vercel Authentication** (Autenticação Vercel)
     - **Password Protection** (Proteção por Senha)
     - **Trusted IPs** (IPs Confiáveis)
   - **Desative todas** as proteções marcadas
   - Clique em **Save** (Salvar)

4. **Aguarde a Propagação:**
   - As mudanças são aplicadas imediatamente
   - Teste acessar seu site novamente
   - Pode levar 1-2 minutos para propagar completamente

### Opção 2: Configurar Proteção Apenas para Preview Deployments

Se você deseja manter a proteção apenas para deployments de preview (branches), mas deixar o production público:

1. **Vá para Settings → Deployment Protection**

2. **Configure conforme necessário:**
   - Em **Production Deployments**: Desative todas as proteções
   - Em **Preview Deployments**: Mantenha as proteções ativas (opcional)

3. **Salve as configurações**

### Opção 3: Adicionar Usuários Autorizados (Para Apps Privados)

Se sua aplicação deve ser privada e você quer manter a proteção:

1. **Mantenha a Proteção Ativada**

2. **Adicione usuários autorizados:**
   - Em **Deployment Protection**
   - Role até **Vercel Authentication** ou **Password Protection**
   - Adicione os emails dos usuários que devem ter acesso
   - Ou configure uma senha compartilhada

3. **Os usuários precisarão:**
   - Fazer login com conta Vercel (se usar Vercel Authentication)
   - OU digitar a senha (se usar Password Protection)

## 🔧 Passos Adicionais de Troubleshooting

### Verificar Environment Variables

Certifique-se de que estas variáveis estão configuradas corretamente na Vercel:

```
VITE_BACKEND_URL=https://assistente-juridico-rs1e.onrender.com
VITE_GOOGLE_CLIENT_ID=<sua-chave>
VITE_VAPID_PUBLIC_KEY=<sua-chave>
```

**Como verificar:**
1. Settings → Environment Variables
2. Confirme que as variáveis estão presentes
3. Se fizer alterações, faça um **Redeploy**

### Testar o Deployment

Após desabilitar a proteção, teste:

1. **Acesse sua URL de produção:**
   ```
   https://seu-projeto.vercel.app
   ```

2. **Você deve ver a tela de login** (não um erro 401)

3. **Teste o login:**
   - Usuário: `admin`
   - Senha: `admin123`

4. **Verifique os assets no DevTools:**
   - Abra DevTools (F12)
   - Vá para a aba **Network**
   - Recarregue a página
   - Todos os requests devem retornar **200 OK** (não 401)

### Se Ainda Houver Erros 401

Se após desabilitar a Proteção de Deployment você ainda vê 401:

1. **Limpe o cache:**
   ```bash
   # No navegador
   - Ctrl + Shift + Delete
   - Limpe cookies e cache
   # Ou use aba anônima/incógnito
   ```

2. **Verifique se há múltiplos projetos Vercel:**
   - Você pode ter deployments em diferentes projetos
   - Certifique-se de estar configurando o projeto correto

3. **Faça um Hard Refresh:**
   - Ctrl + F5 (Windows/Linux)
   - Cmd + Shift + R (Mac)

4. **Verifique o Custom Domain (se configurado):**
   - Se você tem um domínio customizado, verifique suas configurações DNS
   - Acesse pela URL `.vercel.app` primeiro para isolar o problema

## 📊 Comparação: Antes vs Depois

### ❌ Antes (Com Proteção Ativada)
```
Request: GET https://seu-projeto.vercel.app/
Response: 401 Unauthorized

Request: GET https://seu-projeto.vercel.app/assets/icon-xxx.svg  
Response: 401 Unauthorized

Usuário vê: Página em branco ou erro de autenticação
```

### ✅ Depois (Com Proteção Desativada)
```
Request: GET https://seu-projeto.vercel.app/
Response: 200 OK

Request: GET https://seu-projeto.vercel.app/assets/icon-xxx.svg
Response: 200 OK

Usuário vê: Tela de login da aplicação funcionando
```

## 🎯 Quando Usar Cada Tipo de Proteção

### Sem Proteção (Público)
**Use quando:**
- App é público e qualquer pessoa pode acessar
- Você implementa autenticação no próprio app (como este projeto faz)
- É um site institucional, blog, portfolio

**Benefícios:**
- Acesso imediato sem fricção
- Melhor para SEO
- Mais fácil de compartilhar

### Com Proteção (Privado)
**Use quando:**
- App está em desenvolvimento e não deve ser público ainda
- Apenas equipe interna deve acessar
- Dados sensíveis antes de autenticação estar completa
- Apps corporativos internos

**Desvantagens:**
- Usuários precisam de conta Vercel ou senha
- Adiciona fricção no acesso
- Pode confundir usuários que esperam ver o login do app

## 🔐 Sobre Segurança

### Este projeto já tem autenticação própria! 

A aplicação possui seu próprio sistema de login (`/pages/Login.tsx`) que:
- ✅ Requer usuário e senha
- ✅ Usa JWT tokens
- ✅ Protege rotas do backend
- ✅ Gerencia sessões de usuário

Por isso, **você não precisa** da Proteção de Deployment da Vercel para este projeto. A proteção deve ser feita pela aplicação, não pela infraestrutura.

### Proteção em Camadas

**Camada de Infraestrutura (Vercel):**
- Use apenas durante desenvolvimento
- Desative para production

**Camada de Aplicação (Este Projeto):**
- ✅ Login com credenciais
- ✅ JWT authentication
- ✅ Rotas protegidas
- ✅ CORS configurado

## 📞 Precisa de Ajuda?

Se após seguir este guia você ainda tiver problemas:

1. **Capture screenshots:**
   - Dashboard Vercel → Settings → Deployment Protection
   - DevTools → Network tab com os erros 401
   - Console do navegador (F12)

2. **Verifique:**
   - Qual URL você está acessando?
   - É a URL correta do projeto?
   - Você está logado na Vercel?
   - Há algum ad-blocker ou firewall corporativo?

3. **Informações úteis para debug:**
   - URL do deployment
   - Screenshot das configurações de Deployment Protection
   - Logs do Network tab (DevTools)
   - Mensagem de erro exata

## 🎓 Recursos Adicionais

- [Documentação Vercel - Deployment Protection](https://vercel.com/docs/security/deployment-protection)
- [Documentação Vercel - Environment Variables](https://vercel.com/docs/projects/environment-variables)
- [Guia de Troubleshooting - Vercel](https://vercel.com/support)

---

## ✅ Checklist Final

Use esta checklist para resolver o problema:

- [ ] 1. Acessar Dashboard Vercel
- [ ] 2. Ir em Settings → Deployment Protection
- [ ] 3. Desabilitar todas as proteções (ou configurar corretamente)
- [ ] 4. Salvar alterações
- [ ] 5. Aguardar 1-2 minutos
- [ ] 6. Limpar cache do navegador
- [ ] 7. Testar acesso ao site
- [ ] 8. Verificar Network tab (DevTools) - todos 200 OK
- [ ] 9. Testar login na aplicação
- [ ] 10. Confirmar que tudo funciona ✓

---

**Última atualização:** Novembro 2024

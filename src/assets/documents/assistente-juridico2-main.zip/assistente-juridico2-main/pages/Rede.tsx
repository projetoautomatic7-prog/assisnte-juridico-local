import React, { useState, useMemo, useEffect } from 'react';

import { GlobeAltIcon, MagnifyingGlassIcon } from '../components/icons/Icons';
import LoadingSpinner from '../components/LoadingSpinner';
import PageTitle from '../components/PageTitle';
import { authenticatedFetch, BACKEND_URL } from '../services/api';
import { Contact } from '../types';

const ContactCard: React.FC<{ contact: Contact }> = ({ contact }) => (
    <div className="bg-gray-800/50 rounded-lg p-5 border border-gray-700/50 flex flex-col text-center items-center">
        <div className="w-20 h-20 rounded-full bg-gray-700 mb-4 flex items-center justify-center text-blue-400 text-3xl font-bold">
            {contact.avatarUrl ? <img src={contact.avatarUrl} alt={contact.name} className="rounded-full w-full h-full object-cover" /> : contact.name.charAt(0)}
        </div>
        <h3 className="font-bold text-lg text-gray-100">{contact.name}</h3>
        <p className="text-sm text-blue-300">{contact.role}</p>
        <p className="text-xs text-gray-500 mt-1">{contact.location}</p>
        <div className="flex flex-wrap justify-center gap-2 mt-4 pt-4 border-t border-gray-700/50 w-full">
            {contact.expertise.map(exp => (
                <span key={exp} className="text-xs bg-gray-700 text-gray-300 px-2 py-1 rounded-full">{exp}</span>
            ))}
        </div>
         <button className="mt-4 w-full bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2 px-4 rounded-lg transition">
            Ver Perfil
        </button>
    </div>
);


const Rede: React.FC = () => {
    const [contacts, setContacts] = useState<Contact[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState('');
    const [searchTerm, setSearchTerm] = useState('');
    const [expertiseFilter, setExpertiseFilter] = useState('all');

    useEffect(() => {
        const fetchContacts = async () => {
            setIsLoading(true);
            setError('');
            try {
                const response = await authenticatedFetch(`${BACKEND_URL}/api/data/rede`);
                if (!response.ok) throw new Error('Falha ao buscar contatos.');
                const data = await response.json();
                setContacts(data);
            } catch (err) {
                setError((err as Error).message);
            } finally {
                setIsLoading(false);
            }
        };
        fetchContacts();
    }, []);

    const allExpertise = useMemo(() => {
        const set = new Set<string>();
        contacts.forEach(c => c.expertise.forEach(e => set.add(e)));
        return Array.from(set).sort();
    }, [contacts]);

    const filteredContacts = useMemo(() => {
        return contacts.filter(contact => {
            const matchesSearch = contact.name.toLowerCase().includes(searchTerm.toLowerCase()) || contact.role.toLowerCase().includes(searchTerm.toLowerCase());
            const matchesFilter = expertiseFilter === 'all' || contact.expertise.includes(expertiseFilter);
            return matchesSearch && matchesFilter;
        });
    }, [contacts, searchTerm, expertiseFilter]);


  return (
    <div>
      <PageTitle
        title="Rede de Contatos"
        description="Gerencie suas conexões e colabore com outros profissionais."
      />
      <div className="bg-gray-800/50 rounded-lg p-4 mb-6">
        <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-grow">
                 <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <MagnifyingGlassIcon className="h-5 w-5 text-gray-400" />
                </div>
                <input
                    type="text"
                    placeholder="Buscar por nome ou cargo..."
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    className="w-full bg-gray-900/50 border border-gray-700 text-gray-200 rounded-lg pl-10 p-2.5"
                />
            </div>
            <select
                value={expertiseFilter}
                onChange={e => setExpertiseFilter(e.target.value)}
                className="bg-gray-900/50 border border-gray-700 text-gray-200 rounded-lg p-2.5"
            >
                <option value="all">Todas as Especialidades</option>
                {allExpertise.map(exp => <option key={exp} value={exp}>{exp}</option>)}
            </select>
        </div>
      </div>
      
       {isLoading ? <div className="flex justify-center p-16"><LoadingSpinner size="12"/></div> :
        error ? <div className="text-center text-red-400 p-16 bg-gray-800/50 rounded-lg">{error}</div> :
        filteredContacts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredContacts.map(contact => (
                    <ContactCard key={contact.id} contact={contact} />
                ))}
            </div>
        ) : (
            <div className="text-center text-gray-500 p-16 bg-gray-800/50 rounded-lg">
                <GlobeAltIcon className="h-16 w-16 mx-auto mb-4" />
                <h3 className="font-semibold text-gray-300">Nenhum Contato Encontrado</h3>
                <p className="text-sm mt-2">Tente ajustar seus filtros de busca ou adicione novos contatos.</p>
            </div>
        )}

    </div>
  );
};

export default Rede;
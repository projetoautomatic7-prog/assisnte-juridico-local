import React, { useState, useMemo, useEffect } from 'react';

import { CRMCard } from '../components/CRM/KanbanBoard';
import { BriefcaseIcon, CheckCircleIcon, ClockIcon, CurrencyDollarIcon, PlusIcon, XMarkIcon } from '../components/icons/Icons';
import PageTitle from '../components/PageTitle';
import ProcessoDetalheDrawer from '../components/ProcessoDetalheDrawer';
import ProcessoSkeleton from '../components/skeletons/ProcessoSkeleton';
import { useAcervoStore } from '../stores/acervoStore';
import { Processo, ProcessPhase } from '../types';

const PHASES: { id: ProcessPhase; label: string }[] = [
    { id: 'Marketing', label: 'Marketing' },
    { id: 'Negociação', label: 'Negociação' },
    { id: 'Consultoria', label: 'Consultoria' },
    { id: 'Administrativo', label: 'Administrativo' },
    { id: 'Judicial', label: 'Judicial' },
    { id: 'Recursal', label: 'Recursal' },
    { id: 'Execução', label: 'Execução' },
    { id: 'Financeiro', label: 'Financeiro' },
    { id: 'Arquivamento', label: 'Arquivamento' },
];

const STAGES: Record<ProcessPhase, string[]> = {
    Marketing: ['Lead Contato Inicial', 'Validação'],
    Negociação: ['Análise de Caso', 'Aguardando Revisão', 'Parecer Enviado', 'Agendar Reunião', 'Contrato de Honorários'],
    Consultoria: ['Solicitação de Documentos', 'Contrato em Produção', 'Contrato Finalizado', 'Elaborar Petição', 'Análise de Documentos'],
    Administrativo: ['Aguardando Decisão do Orgão', 'Aguardando Decisão do INSS', 'Cobrança', 'Aguardando Documentação'],
    Judicial: ['Aguardando Protocolo', 'Aguarda Manifestação', 'Produção de Provas', 'Aguardando Sentença'],
    Recursal: ['Análise de Recurso', 'Preparo de Recurso', 'Aguardando Julgamento'],
    Execução: ['Cálculos de Execução', 'Aguardando Homologação', 'Rpv Expedido', 'Cobrar Expedição'],
    Financeiro: ['Aguardando Pagamento', 'Pagamento Realizado'],
    Arquivamento: ['Arquivado Provisoriamente', 'Arquivado Definitivamente'],
};

const KanbanColumn: React.FC<{ 
    stage: string; 
    processes: Processo[];
    isDragOver: boolean;
    onDragStart: (e: React.DragEvent<HTMLDivElement>, processoId: string) => void;
    onDrop: (e: React.DragEvent<HTMLDivElement>, stage: string) => void;
    onDragEnd: (e: React.DragEvent<HTMLDivElement>) => void;
    onCardClick: (processo: Processo) => void;
    onDragEnter: (e: React.DragEvent<HTMLDivElement>, stage: string) => void;
}> = ({ stage, processes, isDragOver, onDragStart, onDrop, onDragEnd, onCardClick, onDragEnter }) => (
    <div 
        className={`w-80 flex-shrink-0 bg-gray-900/50 rounded-xl p-3 transition-colors duration-200 ${isDragOver ? 'bg-blue-900/40' : ''}`}
        onDragOver={(e) => e.preventDefault()}
        onDragEnter={(e) => onDragEnter(e, stage)}
        onDrop={(e) => onDrop(e, stage)}
    >
        <div className="flex justify-between items-center mb-4 px-2">
            <h3 className="font-semibold text-gray-200">{stage}</h3>
            <span className="text-sm font-bold text-gray-400 bg-gray-800/50 px-2.5 py-1 rounded-full">{processes.length}</span>
        </div>
        <div className={`h-full overflow-y-auto space-y-3 p-1 rounded-lg border-2 border-dashed transition-colors duration-200 ${isDragOver ? 'border-blue-500' : 'border-transparent'}`}>
            {processes.map(p => (
                <CRMCard
                    key={p.id}
                    id={p.id}
                    cnj={p.numero_cnj}
                    titulo={p.titulo || `Processo ${p.numero_cnj}`}
                    partes={p.partes}
                    estagio={stage}
                    prazos={{ fatal: p.prazo_processual || null, resposta: null }}
                    status={p.is_overdue ? 'em_progresso' : 'novo'}
                    valor={p.value}
                    onDragStart={onDragStart}
                    onDragEnd={onDragEnd}
                    onClick={() => onCardClick(p)}
                />
            ))}
            {processes.length === 0 && (
                <div className="flex items-center justify-center h-24 text-sm text-gray-600">
                    Arraste um card aqui
                </div>
            )}
        </div>
    </div>
);

const Acervo: React.FC = () => {
    const { processos, isLoading, error, fetchProcessos, updateProcessoStage, archiveProcesso, setError } = useAcervoStore();
    const [activePhase, setActivePhase] = useState<ProcessPhase>('Consultoria');
    const [isDragging, setIsDragging] = useState(false);
    const [isOverCompleteZone, setIsOverCompleteZone] = useState(false);
    const [dragOverStage, setDragOverStage] = useState<string | null>(null);
    const [selectedProcesso, setSelectedProcesso] = useState<Processo | null>(null);
    
    useEffect(() => {
        fetchProcessos();
    }, [fetchProcessos]);

    const handleCardClick = (processo: Processo) => {
        setSelectedProcesso(processo);
    };

    const handleCloseDrawer = () => {
        setSelectedProcesso(null);
    };

    const handleDragStart = (e: React.DragEvent<HTMLDivElement>, processoId: string) => {
        e.dataTransfer.setData("processoId", processoId);
        setIsDragging(true);
    };
    
    const handleDragEnd = () => {
        setIsDragging(false);
        setIsOverCompleteZone(false);
        setDragOverStage(null);
    };

    const handleDropOnStage = (e: React.DragEvent<HTMLDivElement>, targetStage: string) => {
        e.preventDefault();
        const processoId = e.dataTransfer.getData("processoId");
        
        const currentProcess = processos.find(p => p.id === processoId);
        if (currentProcess && currentProcess.stage === targetStage) {
            setDragOverStage(null);
            return;
        }
        
        updateProcessoStage(processoId, targetStage, activePhase);
        setDragOverStage(null);
    };
    
    const handleDropOnComplete = (e: React.DragEvent<HTMLDivElement>) => {
        const processoId = e.dataTransfer.getData("processoId");
        
        const droppedCard = document.querySelector(`[data-processo-id='${processoId}']`);
        if (droppedCard) {
            droppedCard.classList.add('processo-card--completed');
        }

        setTimeout(() => {
            archiveProcesso(processoId);
        }, 300); // Match CSS animation duration
        
        handleDragEnd();
    };
    
    const handleDragEnter = (e: React.DragEvent<HTMLDivElement>, stage: string) => {
        e.preventDefault();
        setDragOverStage(stage);
    };

    const counters = useMemo(() => {
        const filtered = processos.filter(p => p.phase === activePhase);
        return {
            total: filtered.length,
            newThisMonth: 0, // Mocked
            value: filtered.reduce((acc, p) => acc + (p.value || 0), 0),
            stagnated: filtered.filter(p => p.isOverdue).length,
        }
    }, [processos, activePhase]);

    const currentStages = STAGES[activePhase];
    
    const renderKanbanContent = () => {
        if (isLoading) {
            return (
                <div className="flex h-full gap-4">
                    {Array.from({ length: 4 }).map((_, i) => <ProcessoSkeleton key={i} />)}
                </div>
            );
        }

        return (
            <div className="flex h-full gap-4">
                {currentStages.map(stage => (
                    <KanbanColumn
                        key={stage}
                        stage={stage}
                        processes={processos.filter(p => p.phase === activePhase && p.stage === stage)}
                        isDragOver={dragOverStage === stage}
                        onDragStart={handleDragStart}
                        onDrop={handleDropOnStage}
                        onDragEnd={handleDragEnd}
                        onCardClick={handleCardClick}
                        onDragEnter={handleDragEnter}
                    />
                ))}
                 <div className="w-80 flex-shrink-0">
                    <button className="w-full text-gray-400 hover:text-white border-2 border-dashed border-gray-700/50 hover:border-gray-600 rounded-xl p-4 h-20 flex items-center justify-center transition-colors">
                        <PlusIcon className="h-5 w-5 mr-2" /> Adicionar outra etapa
                    </button>
                </div>
            </div>
        );
    };

    return (
        <div className="flex flex-col h-full">
            {error && !isLoading && (
                 <div className="bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-lg flex items-center justify-between gap-4 mb-4" role="alert">
                    <span>{error}</span>
                    <button onClick={() => setError(null)} className="p-1 rounded-full hover:bg-red-800/50">
                        <XMarkIcon className="h-5 w-5"/>
                    </button>
                </div>
            )}
            <PageTitle
                title="CRM de Processos"
                description="Gerencie o fluxo de trabalho do seu escritório com o painel Kanban."
            />
            
            <div className="border-b border-gray-700/50 mb-4">
                <div className="flex items-center overflow-x-auto">
                    {PHASES.map(phase => (
                        <button
                            key={phase.id}
                            onClick={() => setActivePhase(phase.id)}
                            className={`whitespace-nowrap py-3 px-4 text-sm font-medium transition-colors ${
                                activePhase === phase.id 
                                ? 'border-b-2 border-blue-400 text-blue-300' 
                                : 'text-gray-400 hover:text-white'
                            }`}
                        >
                            {phase.label}
                        </button>
                    ))}
                </div>
            </div>
            
            <div className="flex-shrink-0 mb-4">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                     <div className="flex items-center gap-4 text-sm text-gray-300">
                        <div className="flex items-center gap-2"><BriefcaseIcon className="h-5 w-5 text-gray-400"/> {counters.total} Processos</div>
                        <div className="flex items-center gap-2"><CheckCircleIcon className="h-5 w-5 text-green-400"/> {counters.newThisMonth} Recebido este mês</div>
                        <div className="flex items-center gap-2"><CurrencyDollarIcon className="h-5 w-5 text-yellow-400"/> {counters.value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</div>
                        <div className="flex items-center gap-2"><ClockIcon className="h-5 w-5 text-red-400"/> {counters.stagnated} Estagnado</div>
                    </div>
                    <div className="flex items-center gap-2">
                        <input
                            type="text"
                            placeholder="Pesquisar..."
                            className="bg-gray-800/50 border border-gray-700 text-gray-200 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                        />
                        <button className="bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2.5 px-4 rounded-lg">Filtrar</button>
                    </div>
                </div>
            </div>

            <div className="flex-1 overflow-x-auto pb-4">
                {renderKanbanContent()}
            </div>
            
            <div 
                className={`fixed top-0 bottom-0 right-0 w-64 bg-green-900/50 backdrop-blur-sm border-l-2 border-dashed border-green-500/50 flex flex-col items-center justify-center text-green-300 transition-transform duration-300 ease-in-out z-10 ${isDragging ? 'translate-x-0' : 'translate-x-full'}`}
                onDragOver={(e) => { e.preventDefault(); e.dataTransfer.dropEffect = "move"; }}
                onDragEnter={() => setIsOverCompleteZone(true)}
                onDragLeave={() => setIsOverCompleteZone(false)}
                onDrop={handleDropOnComplete}
            >
                <div className={`p-4 rounded-full transition-all duration-300 ${isOverCompleteZone ? 'bg-green-500/20 scale-110' : ''}`}>
                    <CheckCircleIcon className="h-16 w-16" />
                </div>
                <h3 className="text-xl font-semibold mt-4">Finalizar Processo</h3>
                <p className="text-sm text-green-400 mt-1">Arraste aqui para concluir.</p>
            </div>

            <ProcessoDetalheDrawer processo={selectedProcesso} onClose={handleCloseDrawer} />
        </div>
    );
};

export default Acervo;

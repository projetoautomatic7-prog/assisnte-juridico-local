import React, { useMemo, useState, useEffect } from 'react';

import BarChartOrigins from '../components/charts/BarChartOrigins';
import DonutChart from '../components/charts/DonutChart';
import { UserPlusIcon, MagnifyingGlassIcon, UserCircleIcon, EllipsisVerticalIcon, UserGroupIcon, BriefcaseIcon } from '../components/icons/Icons';
import LoadingSpinner from '../components/LoadingSpinner';
import PageTitle from '../components/PageTitle';
import StatCard from '../components/StatCard';
import { BACKEND_URL, authenticatedFetch } from '../services/api';
import { Pessoa, OriginData } from '../types';

interface ChartData {
    percentage: number;
    label: string;
}
interface PessoasData {
    list: Pessoa[];
    stats: {
        total: number;
        withProcess: number;
        withoutProcess: number;
    };
    charts: {
        origins: OriginData[];
        age: ChartData;
        professions: ChartData;
    };
}

const Pessoas: React.FC = () => {
    const [searchQuery, setSearchQuery] = useState('');
    const [data, setData] = useState<PessoasData | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState('');

     useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            setError('');
            try {
                const response = await authenticatedFetch(`${BACKEND_URL}/api/data/pessoas`);
                if (!response.ok) {
                    throw new Error('Falha ao buscar dados de pessoas.');
                }
                const fetchedData: PessoasData = await response.json();
                setData(fetchedData);
            } catch (err) {
                setError((err as Error).message);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, []);

    const filteredPessoas = useMemo(() => {
        if (!data) return [];
        if (!searchQuery.trim()) {
            return data.list;
        }
        return data.list.filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()));
    }, [data, searchQuery]);
    
    if (isLoading) {
        return <div className="flex justify-center items-center h-full"><LoadingSpinner size="12" /></div>;
    }

    if (error) {
        return <div className="text-center text-red-400 p-8">{error}</div>;
    }
    
    if (!data) {
        return <div className="text-center text-gray-500 p-8">Nenhum dado encontrado.</div>;
    }

    return (
        <div>
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
                <PageTitle
                    title="Pessoas"
                    description="Gerencie clientes, advogados e outros contatos do seu escritório."
                />
                <button className="bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-blue-700 transition flex items-center gap-2 w-full sm:w-auto justify-center">
                    <UserPlusIcon className="h-5 w-5" />
                    Adicionar Pessoa
                </button>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
                <StatCard title="Cadastrados" value={data.stats.total} icon={UserGroupIcon} />
                <StatCard title="Com Processo" value={data.stats.withProcess} icon={BriefcaseIcon} />
                <StatCard title="Sem Processo" value={data.stats.withoutProcess} icon={UserCircleIcon} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                <div className="bg-gray-800/50 p-4 rounded-lg h-64 flex flex-col">
                    <h3 className="text-base font-semibold text-gray-200 mb-2">Top Origens</h3>
                    <BarChartOrigins data={data.charts.origins} />
                </div>
                <div className="bg-gray-800/50 p-4 rounded-lg h-64 flex flex-col items-center">
                    <h3 className="text-base font-semibold text-gray-200 mb-2">Faixa Etária</h3>
                    <div className="flex-grow flex items-center">
                        <DonutChart percentage={data.charts.age.percentage} color="#3b82f6" size={150} strokeWidth={15} label={data.charts.age.label} />
                    </div>
                </div>
                <div className="bg-gray-800/50 p-4 rounded-lg h-64 flex flex-col items-center">
                    <h3 className="text-base font-semibold text-gray-200 mb-2">Top Profissões</h3>
                     <div className="flex-grow flex items-center">
                        <DonutChart percentage={data.charts.professions.percentage} color="#8b5cf6" size={150} strokeWidth={15} label={data.charts.professions.label} />
                    </div>
                </div>
            </div>

            <div className="bg-gray-800/50 rounded-lg">
                <div className="p-4 border-b border-gray-700/50">
                    <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                           <MagnifyingGlassIcon className="h-5 w-5 text-gray-400" />
                        </div>
                        <input
                            type="text"
                            value={searchQuery}
                            onChange={e => setSearchQuery(e.target.value)}
                            className="bg-gray-900/50 border border-gray-700 text-gray-200 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-2.5"
                            placeholder="Pesquisar por nome do cliente..."
                        />
                    </div>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-300">
                        <thead className="text-xs text-gray-400 uppercase bg-gray-900/50">
                            <tr>
                                <th className="px-6 py-3">Nome do Cliente</th>
                                <th className="px-6 py-3">Contato</th>
                                <th className="px-6 py-3">Cidade/UF</th>
                                <th className="px-6 py-3">Data Cadastro</th>
                                <th className="px-6 py-3"><span className="sr-only">Ações</span></th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredPessoas.map(p => (
                                <tr key={p.id} className="border-b border-gray-700/50 hover:bg-gray-800">
                                    <td className="px-6 py-4 font-semibold text-white">{p.name}</td>
                                    <td className="px-6 py-4">{p.contact}</td>
                                    <td className="px-6 py-4">{p.location}</td>
                                    <td className="px-6 py-4">{new Date(p.registrationDate).toLocaleDateString('pt-BR')}</td>
                                    <td className="px-6 py-4 text-right">
                                        <button className="p-1.5 text-gray-400 hover:text-white rounded-full hover:bg-gray-700">
                                            <EllipsisVerticalIcon className="h-5 w-5"/>
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    );
};

export default Pessoas;
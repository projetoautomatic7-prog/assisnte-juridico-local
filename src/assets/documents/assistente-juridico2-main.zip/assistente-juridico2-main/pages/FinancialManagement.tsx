import React, { useState, useMemo, useRef, useEffect } from 'react';

import FinancialBarChart from '../components/charts/FinancialBarChart';
import { XMarkIcon, PaperClipIcon, PlusIcon, ArrowUpIcon, ArrowDownIcon, TrashIcon } from '../components/icons/Icons';
import LoadingSpinner from '../components/LoadingSpinner';
import PageTitle from '../components/PageTitle';
import StatCard from '../components/StatCard';
import { BACKEND_URL, fileToBase64, authenticatedFetch } from '../services/api';
import { useFinancialStore } from '../stores/financialStore';
import { Transaction } from '../types';

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
};

const AddTransactionPanel: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onSave: (transaction: Omit<Transaction, 'id'>, id?: string) => Promise<void>;
  transactionToEdit: Transaction | null;
}> = ({ isOpen, onClose, onSave, transactionToEdit }) => {
  const [formState, setFormState] = useState({
    date: new Date().toISOString().split('T')[0],
    processo_cnj: '',
    description: '',
    amount: 0,
    type: 'credit' as 'credit' | 'debit',
    status: 'paid' as 'paid' | 'pending',
  });
  const [attachment, setAttachment] = useState<{ name: string; data: string; mimeType: string; } | null>(null);
  const [isExtracting, setIsExtracting] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [fileError, setFileError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  React.useEffect(() => {
    if (transactionToEdit) {
      setFormState({
        ...transactionToEdit,
        date: new Date(transactionToEdit.date).toISOString().split('T')[0],
        amount: transactionToEdit.amount || 0,
      });
      setAttachment(transactionToEdit.attachment || null);
    } else {
      setFormState({
        date: new Date().toISOString().split('T')[0],
        processo_cnj: '',
        description: '',
        amount: 0,
        type: 'credit',
        status: 'paid',
      });
      setAttachment(null);
    }
    setIsSaving(false);
  }, [transactionToEdit, isOpen]);


  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormState(prev => ({ ...prev, [name]: name === 'amount' ? parseFloat(value) || 0 : value }));
  };
  
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
        const file = e.target.files[0];
        setFileError('');
        setIsExtracting(true);
        try {
            const fileData = await fileToBase64(file);
            setAttachment(fileData);
            
            const response = await authenticatedFetch(`${BACKEND_URL}/api/ai/extract-financial`, {
                method: 'POST',
                body: JSON.stringify({ file: fileData }),
            });

            if (!response.ok) throw new Error('Falha ao extrair dados da IA.');
            
            const extracted = await response.json();
            setFormState(prev => ({
                ...prev,
                description: extracted.description || prev.description,
                amount: extracted.amount || prev.amount,
                processo_cnj: extracted.processo_cnj || prev.processo_cnj,
            }));

        } catch (err) {
            setFileError('Erro ao processar o arquivo.');
            console.error(err);
        } finally {
            setIsExtracting(false);
        }
    }
  };

  const handleRemoveAttachment = () => {
    setAttachment(null);
    if(fileInputRef.current) fileInputRef.current.value = '';
  };


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (formState.description && formState.amount > 0) {
      setIsSaving(true);
      await onSave({ ...formState, attachment: attachment || undefined }, transactionToEdit?.id);
      setIsSaving(false);
      onClose();
    } else {
      alert('Descrição e Valor (maior que zero) são obrigatórios.');
    }
  };

  return (
    <>
      <div className={`fixed inset-0 bg-black/60 z-40 transition-opacity ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={onClose}></div>
      <div className={`fixed inset-y-0 right-0 w-full max-w-lg bg-gray-800 shadow-xl z-50 transform transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
          <form onSubmit={handleSubmit} id="transaction-form" className="flex flex-col h-full">
              <div className="flex justify-between items-center p-4 border-b border-gray-700">
                  <h2 className="text-xl font-semibold text-gray-100">{transactionToEdit ? 'Editar Lançamento' : 'Novo Lançamento'}</h2>
                  <button type="button" onClick={onClose} className="text-gray-500 hover:text-gray-200">
                      <XMarkIcon className="h-6 w-6" />
                  </button>
              </div>
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                 <div>
                    <label className="block text-sm font-medium text-gray-300">Anexar Documento (Opcional)</label>
                    <div className="mt-1 flex items-center justify-center px-6 pt-5 pb-6 border-2 border-gray-600 border-dashed rounded-md">
                        <div className="space-y-1 text-center">
                            <PaperClipIcon className="mx-auto h-12 w-12 text-gray-500"/>
                            <div className="flex text-sm text-gray-400">
                                <label htmlFor="file-upload" className="relative cursor-pointer bg-gray-700 rounded-md font-medium text-blue-400 hover:text-blue-300 px-2 py-1">
                                    <span>Carregar um arquivo</span>
                                    <input id="file-upload" name="file-upload" type="file" className="sr-only" onChange={handleFileChange} ref={fileInputRef} />
                                </label>
                                <p className="pl-1">ou arraste e solte</p>
                            </div>
                            <p className="text-xs text-gray-500">PNG, JPG, PDF até 10MB</p>
                        </div>
                    </div>
                     {isExtracting && <div className="text-sm text-blue-300 flex items-center mt-2"><LoadingSpinner size="4"/> <span className="ml-2">Analisando documento...</span></div>}
                     {fileError && <p className="text-red-400 text-sm mt-2">{fileError}</p>}
                     {attachment && !isExtracting && (
                        <div className="mt-2 flex items-center justify-between bg-gray-700/50 p-2 rounded-md">
                            <span className="text-sm text-gray-300 truncate">{attachment.name}</span>
                            <button onClick={handleRemoveAttachment} type="button" className="text-gray-400 hover:text-red-400"><XMarkIcon className="h-4 w-4"/></button>
                        </div>
                     )}
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300">Data</label>
                      <input type="date" name="date" value={formState.date} onChange={handleChange} className="mt-1 w-full bg-gray-900/50 border-gray-700 rounded-md p-2 text-gray-200" required />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300">Nº do Processo (CNJ)</label>
                      <input type="text" name="processo_cnj" value={formState.processo_cnj} onChange={handleChange} className="mt-1 w-full bg-gray-900/50 border-gray-700 rounded-md p-2 text-gray-200" placeholder="Preenchido pela IA" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300">Descrição</label>
                    <textarea name="description" value={formState.description} onChange={handleChange} rows={3} className="mt-1 w-full bg-gray-900/50 border-gray-700 rounded-md p-2 text-gray-200" required placeholder="Preenchido pela IA" />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300">Valor (R$)</label>
                      <input type="number" name="amount" value={formState.amount} onChange={handleChange} className="mt-1 w-full bg-gray-900/50 border-gray-700 rounded-md p-2 text-gray-200" step="0.01" required placeholder="Preenchido pela IA" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300">Tipo</label>
                      <select name="type" value={formState.type} onChange={handleChange} className="mt-1 w-full bg-gray-900/50 border-gray-700 rounded-md p-2 text-gray-200">
                        <option value="credit">Receita</option>
                        <option value="debit">Despesa</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300">Status</label>
                      <select name="status" value={formState.status} onChange={handleChange} className="mt-1 w-full bg-gray-900/50 border-gray-700 rounded-md p-2 text-gray-200">
                        <option value="paid">Pago</option>
                        <option value="pending">Pendente</option>
                      </select>
                    </div>
                  </div>
              </div>
              <div className="p-4 border-t border-gray-700 flex justify-end gap-4">
                  <button type="button" onClick={onClose} className="bg-gray-600 hover:bg-gray-700 text-white font-semibold py-2 px-4 rounded-lg">Cancelar</button>
                  <button type="submit" form="transaction-form" disabled={isSaving} className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg flex justify-center items-center w-24">
                    {isSaving ? <LoadingSpinner size="5" /> : 'Salvar'}
                  </button>
              </div>
          </form>
      </div>
    </>
  );
};

const FinancialManagement: React.FC = () => {
  const { 
    transactions, isLoading, error, sortConfig, summary,
    fetchTransactions, saveTransaction, deleteTransaction, requestSort 
  } = useFinancialStore();
  
  const [isPanelOpen, setIsPanelOpen] = useState(false);
  const [transactionToEdit, setTransactionToEdit] = useState<Transaction | null>(null);

  useEffect(() => {
    fetchTransactions();
  }, [fetchTransactions]);
  
  const sortedTransactions = useMemo(() => {
    const sortableItems = [...transactions];
    if (sortConfig !== null) {
      sortableItems.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableItems;
  }, [transactions, sortConfig]);


  const getSortIcon = (key: keyof Transaction) => {
    if (!sortConfig || sortConfig.key !== key) return null;
    return sortConfig.direction === 'asc' 
      ? <ArrowUpIcon className="h-3 w-3 ml-1" /> 
      : <ArrowDownIcon className="h-3 w-3 ml-1" />;
  };

  const handleOpenPanel = (transaction?: Transaction) => {
    setTransactionToEdit(transaction || null);
    setIsPanelOpen(true);
  };
  
  const handleClosePanel = () => {
    setIsPanelOpen(false);
    setTransactionToEdit(null);
  };

  return (
    <div>
      <PageTitle
        title="Gestão Financeira"
        description="Controle honorários, despesas e o fluxo de caixa dos seus processos."
      />
      {error && <p className="text-red-400 mb-4 text-center">{error}</p>}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard title="Receita Total (Bruto)" value={summary.revenue} colorClass="text-green-400" formatAsCurrency />
        <StatCard title="Despesas Totais" value={summary.expenses} colorClass="text-red-400" formatAsCurrency />
        <StatCard title="Saldo Líquido" value={summary.netBalance} colorClass={summary.netBalance >= 0 ? 'text-green-400' : 'text-red-400'} formatAsCurrency />
        <StatCard title="A Receber" value={summary.receivable} colorClass="text-yellow-400" formatAsCurrency />
      </div>
      
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 mb-8">
        <div className="xl:col-span-3 bg-gray-800/50 p-6 rounded-lg">
            <h3 className="text-lg font-semibold text-gray-200 mb-4">Receitas x Despesas (Mensal)</h3>
            <div className="h-64">
                <FinancialBarChart />
            </div>
        </div>
      </div>
      
      <div className="bg-gray-800/50 rounded-lg p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold text-gray-100">Histórico de Transações</h3>
          <button onClick={() => handleOpenPanel()} className="bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-blue-700 transition flex items-center gap-2">
            <PlusIcon className="h-5 w-5" />
            Adicionar Lançamento
          </button>
        </div>

        <div className="overflow-x-auto">
          {isLoading ? <div className="flex justify-center p-8"><LoadingSpinner/></div> : (
          <table className="w-full text-sm text-left text-gray-300">
            <thead className="text-xs text-gray-400 uppercase bg-gray-900/50">
              <tr>
                <th className="px-6 py-3">
                   <button onClick={() => requestSort('date')} className="flex items-center gap-1 hover:text-white">Data {getSortIcon('date')}</button>
                </th>
                <th className="px-6 py-3">Processo (CNJ)</th>
                <th className="px-6 py-3">
                  <button onClick={() => requestSort('description')} className="flex items-center gap-1 hover:text-white">Descrição {getSortIcon('description')}</button>
                </th>
                <th className="px-6 py-3">Tipo</th>
                <th className="px-6 py-3">Status</th>
                <th className="px-6 py-3 text-right">
                  <button onClick={() => requestSort('amount')} className="flex items-center gap-1 hover:text-white w-full justify-end">Valor {getSortIcon('amount')}</button>
                </th>
                <th className="px-6 py-3">Anexo</th>
                <th className="px-6 py-3">Ações</th>
              </tr>
            </thead>
            <tbody>
              {sortedTransactions.map(t => (
                <tr key={t.id} className="border-b border-gray-700 hover:bg-gray-800">
                  <td className="px-6 py-4">{new Date(t.date).toLocaleDateString('pt-BR', { timeZone: 'UTC' })}</td>
                  <td className="px-6 py-4 font-mono">{t.processo_cnj}</td>
                  <td className="px-6 py-4">{t.description}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                      t.type === 'credit' ? 'bg-green-600/30 text-green-300' : 'bg-orange-600/30 text-orange-300'
                    }`}>
                      {t.type === 'credit' ? 'Receita' : 'Despesa'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                     <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                      t.status === 'paid' ? 'bg-green-600/30 text-green-300' : 'bg-yellow-600/30 text-yellow-300'
                    }`}>
                      {t.status === 'paid' ? 'Pago' : 'Pendente'}
                    </span>
                  </td>
                  <td className={`px-6 py-4 text-right font-semibold ${t.type === 'credit' ? 'text-green-400' : 'text-red-400'}`}>
                    {formatCurrency(t.amount)}
                  </td>
                   <td className="px-6 py-4">
                    {t.attachment ? (
                      <a href={`data:${t.attachment.mimeType};base64,${t.attachment.data}`} target="_blank" rel="noopener noreferrer" title={t.attachment.name} className="flex justify-center">
                        <PaperClipIcon className="h-5 w-5 text-blue-400 hover:text-blue-300" />
                      </a>
                    ) : null}
                  </td>
                  <td className="px-6 py-4 text-right">
                     <div className="flex items-center justify-end gap-2">
                        <button onClick={() => handleOpenPanel(t)} className="text-blue-400 hover:underline text-xs">Editar</button>
                        <button onClick={() => deleteTransaction(t.id)} className="text-gray-400 hover:text-red-400">
                            <TrashIcon className="h-4 w-4" />
                        </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          )}
        </div>
      </div>

      <AddTransactionPanel 
        isOpen={isPanelOpen}
        onClose={handleClosePanel}
        onSave={saveTransaction}
        transactionToEdit={transactionToEdit}
      />
    </div>
  );
};

export default FinancialManagement;

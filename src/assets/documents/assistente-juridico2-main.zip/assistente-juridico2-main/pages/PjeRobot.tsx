import React, { useState, useCallback, useEffect, useMemo, useRef } from 'react';

import { InformationCircleIcon, CpuChipIcon, WrenchScrewdriverIcon, CheckCircleIcon, XCircleIcon, StopCircleIcon, XMarkIcon, CircleOutlineIcon, ArrowPathIcon, ArrowRightOnRectangleIcon } from '../components/icons/Icons';
import LoadingSpinner from '../components/LoadingSpinner';
import PageTitle from '../components/PageTitle';
import { BACKEND_URL, WEBSOCKET_URL } from '../services/api';
import { useRobotStore } from '../stores/robotStore';
import { PjeRobotLog, NotificationStatus } from '../types';

type DiagnosticStep = 'backend' | 'gemini' | 'puppeteer' | 'google';
type DiagnosticStatus = 'pending' | 'running' | 'success' | 'error';
interface DiagnosticResult {
    step: DiagnosticStep;
    status: DiagnosticStatus;
    message: string;
}

// Função auxiliar para formatar o tempo de atividade
const formatUptime = (totalSeconds: number) => {
    const hours = Math.floor(totalSeconds / 3600).toString().padStart(2, '0');
    const minutes = Math.floor((totalSeconds % 3600) / 60).toString().padStart(2, '0');
    const seconds = (totalSeconds % 60).toString().padStart(2, '0');
    return `${hours}:${minutes}:${seconds}`;
};


const StatusIndicator: React.FC<{ status: 'inactive' | 'running' | 'connecting' | 'error' | 'paused' | 'disconnected' | 'active' | 'reconnecting'; label: string }> = ({ status, label }) => {
    const styles: { [key: string]: { t: string, c: string } } = {
        inactive: { t: 'Inativo', c: 'bg-gray-500' },
        connecting: { t: 'Conectando', c: 'bg-blue-500 animate-pulse' },
        running: { t: 'Ativo', c: 'bg-green-500 animate-pulse' },
        paused: { t: 'Pausado', c: 'bg-orange-500' },
        error: { t: 'Erro Crítico', c: 'bg-red-500' },
        disconnected: { t: 'Desconectada', c: 'bg-gray-500' },
        active: { t: 'Ativa', c: 'bg-green-500' },
        reconnecting: { t: 'Reconectando', c: 'bg-yellow-500 animate-pulse' }
    };
    const style = styles[status] || { t: 'Desconhecido', c: 'bg-gray-500' };
    return (
        <div className="flex items-center gap-3 bg-gray-800/50 p-3 rounded-lg">
            <span className={`h-3 w-3 rounded-full ${style.c}`}></span>
            <div>
                <div className="text-sm text-gray-400">{label}</div>
                <div className="font-semibold text-gray-200">{style.t}</div>
            </div>
        </div>
    );
};

const NotificationStatusBadge: React.FC<{ status: NotificationStatus }> = ({ status }) => {
    const styles: Record<NotificationStatus, { text: string; className: string }> = {
        pending: { text: 'Pendente', className: 'bg-gray-600 text-gray-200' },
        analyzing: { text: 'Analisando', className: 'bg-blue-600 text-white animate-pulse' },
        drafting: { text: 'Gerando Minuta', className: 'bg-indigo-600 text-white animate-pulse' },
        review: { text: 'Revisão Necessária', className: 'bg-yellow-500 text-gray-900 font-bold' },
        protocoling: { text: 'Protocolando', className: 'bg-purple-600 text-white' },
        success: { text: 'Sucesso', className: 'bg-green-600 text-white' },
        error: { text: 'Erro', className: 'bg-red-600 text-white' },
        awaiting_documents: { text: 'Aguardando Docs', className: 'bg-orange-500 text-white' },
    };
    const style = styles[status] || styles.pending;
    return <span className={`px-2 py-1 text-xs font-semibold rounded-full ${style.className}`}>{style.text}</span>;
};


const ReadyStatePanel: React.FC<{ onStart: () => void }> = ({ onStart }) => (
    <div className="bg-gray-800/50 rounded-lg p-8 my-6 text-center border border-dashed border-green-500/50">
        <div className="flex justify-center mb-4">
            <CheckCircleIcon className="h-12 w-12 text-green-400"/>
        </div>
        <h3 className="text-xl font-semibold text-gray-100">Sessão PJe Ativa</h3>
        <p className="text-gray-400 mt-2 mb-6">O robô está conectado ao PJe e pronto para iniciar o monitoramento de novos expedientes.</p>
        <button 
            onClick={onStart} 
            className="bg-green-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-green-700 transition transform hover:scale-105"
        >
            Iniciar Monitoramento 24/7
        </button>
    </div>
);


const RobotDashboard: React.FC<{
    onStart: () => void;
    onStop: () => void;
    onDisconnect: () => void;
}> = ({ onStart, onStop, onDisconnect }) => {
    const { robotStatus, sessionStatus, logs, results, history, uptime } = useRobotStore();
    const [selectedAudit, setSelectedAudit] = useState<any | null>(null); // Use 'any' for ProcessedNotification
    const [activeTab, setActiveTab] = useState<'live' | 'history'>('live');
    const [dateFilter, setDateFilter] = useState('');
    const [statusFilter, setStatusFilter] = useState<NotificationStatus | 'all'>('all');
    
    const logsEndRef = React.useRef<HTMLDivElement>(null);

    useEffect(() => {
        logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [logs]);

    const filteredHistory = useMemo(() => {
        return history.filter(item => {
            const statusMatch = statusFilter === 'all' || item.status === statusFilter;
            const dateMatch = !dateFilter || (item.processedAt && new Date(item.processedAt).toISOString().split('T')[0] === dateFilter);
            return statusMatch && dateMatch;
        });
    }, [history, dateFilter, statusFilter]);
    
    const isReadyToStart = robotStatus === 'inactive' && sessionStatus === 'active';

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <StatusIndicator status={robotStatus} label="Status do Robô" />
                <StatusIndicator status={sessionStatus} label="Sessão PJe" />
                 <div className="flex items-center gap-3 bg-gray-800/50 p-3 rounded-lg">
                    <div className="text-sm text-gray-400">Duração do Monitoramento</div>
                    <div className="font-semibold text-gray-200 text-lg">{formatUptime(uptime)}</div>
                </div>
                <div className="flex items-center gap-2">
                    <button onClick={onStart} disabled={robotStatus !== 'inactive' || sessionStatus !== 'active'} className="flex-1 bg-green-600 text-white h-full rounded-lg hover:bg-green-700 disabled:bg-gray-600 disabled:cursor-not-allowed">Iniciar</button>
                    <button onClick={onStop} disabled={!['running', 'paused'].includes(robotStatus)} className="flex-1 bg-yellow-500 text-black h-full rounded-lg hover:bg-yellow-600 disabled:bg-gray-600 disabled:cursor-not-allowed">Parar</button>
                    <button onClick={onDisconnect} className="flex-1 bg-red-600 text-white h-full rounded-lg hover:bg-red-700">Desconectar</button>
                </div>
            </div>

            {isReadyToStart && <ReadyStatePanel onStart={onStart} />}

            {/* Main Content */}
            {robotStatus === 'running' && (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Logs */}
                    <div className="lg:col-span-1 bg-gray-800/50 rounded-lg flex flex-col h-[60vh]">
                        <h3 className="text-lg font-semibold p-4 border-b border-gray-700 text-gray-200">Console de Logs</h3>
                        <div className="overflow-y-auto flex-1 p-4 text-sm font-mono space-y-2">
                            {logs.map((log, i) => (
                                <div key={i} className="flex gap-2">
                                    <span className="text-gray-500 flex-shrink-0">{log.timestamp}</span>
                                    <span className={`${
                                        log.level === 'success' ? 'text-green-400' : 
                                        log.level === 'error' ? 'text-yellow-400' : 
                                        log.level === 'fatal' ? 'text-red-400 font-bold' : 
                                        log.level === 'warn' ? 'text-orange-400' : 'text-gray-300'
                                    }`}>{log.message}</span>
                                </div>
                            ))}
                            <div ref={logsEndRef} />
                        </div>
                    </div>
                    
                    {/* Results */}
                    <div className="lg:col-span-2 bg-gray-800/50 rounded-lg h-[60vh] flex flex-col">
                         <div className="flex border-b border-gray-700">
                            <button onClick={() => setActiveTab('live')} className={`py-3 px-4 font-medium ${activeTab === 'live' ? 'border-b-2 border-blue-400 text-blue-300' : 'text-gray-400'}`}>Em Processamento ({results.length})</button>
                            <button onClick={() => setActiveTab('history')} className={`py-3 px-4 font-medium ${activeTab === 'history' ? 'border-b-2 border-blue-400 text-blue-300' : 'text-gray-400'}`}>Histórico ({history.length})</button>
                        </div>

                        {activeTab === 'live' && (
                            <div className="overflow-y-auto flex-1">
                               <table className="w-full text-sm text-left">
                                   <thead className="text-xs text-gray-400 uppercase bg-gray-900/50">
                                       <tr>
                                           <th className="px-6 py-3">CNJ</th>
                                           <th className="px-6 py-3">Cliente</th>
                                           <th className="px-6 py-3">Status</th>
                                           <th className="px-6 py-3">Ação</th>
                                       </tr>
                                   </thead>
                                   <tbody>
                                       {results.map(r => (
                                           <tr key={r.id} className="border-b border-gray-700 hover:bg-gray-800">
                                               <td className="px-6 py-4 font-medium text-gray-200">{r.cnj}</td>
                                               <td className="px-6 py-4">{r.client}</td>
                                               <td className="px-6 py-4"><NotificationStatusBadge status={r.status} /></td>
                                               <td className="px-6 py-4"><button onClick={() => setSelectedAudit(r)} className="text-blue-400 hover:underline">Ver Detalhes</button></td>
                                           </tr>
                                       ))}
                                   </tbody>
                               </table>
                               {results.length === 0 && <p className="text-gray-500 text-center p-8">Aguardando novos expedientes...</p>}
                            </div>
                        )}
                         {activeTab === 'history' && (
                             <div className="flex-1 flex flex-col">
                                 <div className="p-4 flex gap-4 bg-gray-900/50">
                                     <input type="date" value={dateFilter} onChange={e => setDateFilter(e.target.value)} className="bg-gray-800 border-gray-700 rounded-md p-2 text-sm text-gray-200"/>
                                     <select value={statusFilter} onChange={e => setStatusFilter(e.target.value as any)} className="bg-gray-800 border-gray-700 rounded-md p-2 text-sm text-gray-200">
                                         <option value="all">Todos os Status</option>
                                         <option value="success">Sucesso</option>
                                         <option value="error">Erro</option>
                                         <option value="review">Revisão</option>
                                         <option value="awaiting_documents">Aguardando Docs</option>
                                     </select>
                                 </div>
                                  <div className="overflow-y-auto flex-1">
                                   <table className="w-full text-sm text-left">
                                       <thead className="text-xs text-gray-400 uppercase bg-gray-900/50">
                                           <tr>
                                               <th className="px-6 py-3">CNJ</th>
                                               <th className="px-6 py-3">Finalizado Em</th>
                                               <th className="px-6 py-3">Status Final</th>
                                               <th className="px-6 py-3">Ação</th>
                                           </tr>
                                       </thead>
                                       <tbody>
                                           {filteredHistory.map(r => (
                                               <tr key={r.id} className="border-b border-gray-700 hover:bg-gray-800">
                                                   <td className="px-6 py-4 font-medium text-gray-200">{r.cnj}</td>
                                                   <td className="px-6 py-4">{r.processedAt}</td>
                                                   <td className="px-6 py-4"><NotificationStatusBadge status={r.status} /></td>
                                                   <td className="px-6 py-4"><button onClick={() => setSelectedAudit(r)} className="text-blue-400 hover:underline">Ver Auditoria</button></td>
                                               </tr>
                                           ))}
                                       </tbody>
                                   </table>
                                    {filteredHistory.length === 0 && <p className="text-gray-500 text-center p-8">Nenhum registro encontrado para os filtros selecionados.</p>}
                                </div>
                             </div>
                        )}
                    </div>
                </div>
            )}
            
            {selectedAudit && (
                 <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50" onClick={() => setSelectedAudit(null)}>
                    <div className="bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl p-6" onClick={e => e.stopPropagation()}>
                         <h3 className="text-lg font-semibold text-blue-300 mb-4">Trilha de Auditoria - {selectedAudit.cnj}</h3>
                         <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-4">
                            <div>
                                <h4 className="font-semibold text-gray-300">Resumo da IA</h4>
                                <p className="text-sm text-gray-400 bg-gray-900/50 p-3 rounded-md mt-1">{selectedAudit.summary}</p>
                            </div>
                            {selectedAudit.draftContent && (
                                <div>
                                    <h4 className="font-semibold text-gray-300">Minuta Gerada</h4>
                                    <p className="text-sm text-gray-400 bg-gray-900/50 p-3 rounded-md mt-1 whitespace-pre-wrap">{selectedAudit.draftContent}</p>
                                </div>
                            )}
                             <div>
                                <h4 className="font-semibold text-gray-300">Linha do Tempo</h4>
                                <ul className="mt-2 border-l-2 border-gray-700 ml-2">
                                    {selectedAudit.auditTrail.map((entry: any, index: number) => (
                                        <li key={index} className="mb-4 ml-6">
                                            <span className="absolute flex items-center justify-center w-6 h-6 bg-blue-900 rounded-full -left-3 ring-8 ring-gray-800">
                                                <CheckCircleIcon className="w-3 h-3 text-blue-300"/>
                                            </span>
                                            <p className="text-sm font-semibold text-gray-200">{entry.action}</p>
                                            <time className="block text-xs font-normal leading-none text-gray-500">{entry.timestamp}</time>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                         </div>
                         <button onClick={() => setSelectedAudit(null)} className="mt-6 bg-blue-600 text-white w-full py-2 rounded-lg hover:bg-blue-700">Fechar</button>
                    </div>
                 </div>
            )}
        </div>
    );
};

const ConnectionStatusBanner: React.FC<{ status: 'connected' | 'reconnecting' | 'disconnected' | 'connecting' }> = ({ status }) => {
    const config = {
        connected: {
            Icon: CheckCircleIcon,
            color: 'green',
            message: 'Conectado ao servidor do robô em tempo real.'
        },
        connecting: {
            Icon: InformationCircleIcon,
            color: 'blue',
            message: 'Conectando ao servidor do robô...'
        },
        reconnecting: {
            Icon: InformationCircleIcon,
            color: 'yellow',
            message: 'Conexão perdida. Tentando reconectar automaticamente...'
        },
        disconnected: {
            Icon: XCircleIcon,
            color: 'red',
            message: 'Desconectado do servidor do robô. Verifique se o backend está em execução.'
        }
    }[status];

    const colors = {
        green: 'bg-green-900/50 border-green-700 text-green-300',
        blue: 'bg-blue-900/50 border-blue-700 text-blue-300',
        yellow: 'bg-yellow-900/50 border-yellow-700 text-yellow-300',
        red: 'bg-red-900/50 border-red-700 text-red-300',
    }

    if (!config) return null;

    return (
        <div className={`border ${colors[config.color as keyof typeof colors]} px-4 py-3 rounded-lg flex items-center gap-4 mb-6`} role="alert">
            <config.Icon className="h-6 w-6 flex-shrink-0"/>
            <span className="text-sm">{config.message}</span>
            {(status === 'reconnecting' || status === 'connecting') && <LoadingSpinner size="5"/>}
        </div>
    )
}

const ConnectionProgress: React.FC<{ onRetry: () => void }> = ({ onRetry }) => {
    const step = useRobotStore(state => state.connectionStep);
    const steps: { key: 'idle' | 'launching' | 'navigating' | 'filling' | 'submitting' | 'waiting' | 'success' | 'failed', label: string }[] = [
        { key: 'launching', label: 'Iniciando navegador seguro' },
        { key: 'navigating', label: 'Navegando para o portal PJe' },
        { key: 'filling', label: 'Preenchendo credenciais' },
        { key: 'submitting', label: 'Enviando formulário de login' },
        { key: 'waiting', label: 'Aguardando resposta do PJe' },
    ];
    const currentStepIndex = steps.findIndex(s => s.key === step);

    if (step === 'idle' || step === 'success') {
        return null;
    }

    const getStatusIcon = (index: number) => {
        if (step === 'failed') return <XCircleIcon className="h-5 w-5 text-red-400" />;
        if (index < currentStepIndex) return <CheckCircleIcon className="h-5 w-5 text-green-400" />;
        if (index === currentStepIndex) return <LoadingSpinner size="5" />;
        return <CircleOutlineIcon className="h-5 w-5 text-gray-500" />;
    };

    return (
        <div className="mt-6 bg-gray-900/50 border border-gray-700 rounded-lg p-4">
            <h4 className="font-semibold text-gray-300 mb-3 text-sm">Progresso da Conexão:</h4>
            <ul className="space-y-2">
                {steps.map((s, index) => (
                    <li key={s.key} className="flex items-center gap-3 text-sm">
                        {getStatusIcon(index)}
                        <span className={`${index <= currentStepIndex ? 'text-gray-200' : 'text-gray-500'}`}>
                            {s.label}
                        </span>
                    </li>
                ))}
            </ul>
             {step === 'failed' && (
                <div className="mt-4 text-center">
                    <p className="text-red-400 text-xs mb-3">A conexão falhou. Verifique o log de erro e suas credenciais.</p>
                    <button onClick={onRetry} className="bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold py-2 px-4 rounded-lg">
                        Tentar Novamente
                    </button>
                </div>
             )}
        </div>
    );
};


const PjeRobot: React.FC = () => {
    // --- STATE REFACTOR: Get all state and actions from the Zustand store ---
    const {
        isAuthenticated, wsConnectionStatus, robotStatus, appError, is2faRequired, isSessionExpiredModalOpen, connectionStep, loginError, twoFactorError, isSubmitting2fa,
        setIsAuthenticated, setWsConnectionStatus, addLog, setRobotStatus, setSessionStatus, setConnectionStep, setAppError, setIs2faRequired, setResults, setHistory,
        setIsSessionExpiredModalOpen, resetOnDisconnect, resetConnectionState, setLoginError, setTwoFactorError, setIsSubmitting2fa, setLogs
    } = useRobotStore();
    
    // --- Local state for form inputs and UI-specific modals ---
    const [login, setLogin] = useState<string>('');
    const [password, setPassword] = useState<string>('');
    const [twoFactorCode, setTwoFactorCode] = useState<string>('');
    const [isDiagnosticModalOpen, setIsDiagnosticModalOpen] = useState(false);
    const [diagnosticResults, setDiagnosticResults] = useState<DiagnosticResult[]>([]);
    
    // --- Refs for managing side effects ---
    const uptimeIntervalRef = useRef<number | null>(null);
    const wsRef = useRef<WebSocket | null>(null);
    const reconnectTimeoutRef = useRef<number | null>(null);

    const addLogWithTimestamp = useCallback((message: string, level: PjeRobotLog['level'], code?: string) => {
        const timestamp = new Date().toLocaleTimeString();
        addLog({ timestamp, message, level, code });
    }, [addLog]);


    useEffect(() => {
        const connectWebSocket = () => {
            if (wsRef.current && (wsRef.current.readyState === WebSocket.OPEN || wsRef.current.readyState === WebSocket.CONNECTING)) {
                return;
            }

            const ws = new WebSocket(WEBSOCKET_URL);
            wsRef.current = ws;

            ws.onopen = () => {
                console.log('Conectado ao WebSocket do backend');
                addLogWithTimestamp('Painel de controle conectado ao robô.', 'info');
                setWsConnectionStatus('connected');
            };

            ws.onmessage = (event) => {
                try {
                    const { type, payload } = JSON.parse(event.data);
                    
                    if (type === 'log') {
                        addLogWithTimestamp(payload.message, payload.level, payload.code);
                        if (payload.level === 'fatal') {
                            setAppError(payload.message);
                            setConnectionStep('failed');
                        }
                        if (payload.code) {
                            const stepMap: Record<string, 'launching' | 'navigating' | 'filling' | 'submitting' | 'waiting' | 'success'> = {
                                'LAUNCHING_BROWSER': 'launching', 'NAVIGATING_TO_PJE': 'navigating',
                                'FILLING_CREDENTIALS': 'filling', 'SUBMITTING_LOGIN': 'submitting',
                                'WAITING_FOR_RESULT': 'waiting', 'LOGIN_SUCCESS': 'success',
                            };
                            if (stepMap[payload.code]) setConnectionStep(stepMap[payload.code]);
                        }
                    }

                    switch (type) {
                        case 'status':
                            if (payload.robotStatus) setRobotStatus(payload.robotStatus);
                            if (payload.sessionStatus) setSessionStatus(payload.sessionStatus);
                            break;
                        case '2fa_required':
                            addLogWithTimestamp('Autenticação de dois fatores necessária.', 'warn');
                            setIs2faRequired(true);
                            setRobotStatus('connecting');
                            break;
                        case 'auth_success':
                            setIsAuthenticated(true);
                            setIs2faRequired(false);
                            setLoginError(null);
                            setTwoFactorError(null);
                            setAppError(null);
                            resetConnectionState();
                            break;
                        case 'new_result':
                            setResults(prev => [payload, ...prev]);
                            break;
                        case 'update_result':
                            const isTerminalStatus = ['success', 'error', 'review', 'awaiting_documents'].includes(payload.status);
                            if (isTerminalStatus) {
                                setResults(prev => {
                                    const itemToMove = prev.find(r => r.id === payload.id);
                                    if (itemToMove) setHistory(prevHistory => [{ ...itemToMove, ...payload }, ...prevHistory]);
                                    return prev.filter(r => r.id !== payload.id);
                                });
                            } else {
                                setResults(prev => prev.map(r => r.id === payload.id ? { ...r, ...payload } : r));
                            }
                            break;
                        case 'pje_session_expired':
                            setIsSessionExpiredModalOpen(true);
                            break;
                    }
                } catch(e) { console.error("Failed to parse websocket message", e); }
            };

            ws.onclose = () => {
                setWsConnectionStatus('reconnecting');
                if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
                reconnectTimeoutRef.current = window.setTimeout(connectWebSocket, 5000);
            };

            ws.onerror = () => {
                setWsConnectionStatus('disconnected');
                ws.close();
            };
        };

        connectWebSocket();

        return () => {
            if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
            if (uptimeIntervalRef.current) clearInterval(uptimeIntervalRef.current);
            wsRef.current?.close();
            wsRef.current = null;
        };
    }, [addLogWithTimestamp, setAppError, setConnectionStep, setHistory, setIs2faRequired, setIsAuthenticated, setIsSessionExpiredModalOpen, setResults, setRobotStatus, setSessionStatus, setWsConnectionStatus, resetConnectionState, setLoginError, setTwoFactorError]);

    const handleConnect = async (e?: React.FormEvent) => {
        if (e) e.preventDefault();
        setLoginError(null);
        if (!login || !password) {
            setLoginError('Login e senha são obrigatórios.');
            return;
        }
        setRobotStatus('connecting');
        setConnectionStep('launching');
        setLogs([]); // Clear logs on new attempt
        addLogWithTimestamp('Credenciais enviadas. O robô irá preencher o formulário do PJe automaticamente.', 'info');
        
        try {
            const token = localStorage.getItem('jwt');
            const response = await fetch(`${BACKEND_URL}/api/robot/connect`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
                body: JSON.stringify({ login, password }),
            });
             if (!response.ok) throw new Error((await response.json()).message);
        } catch (error) {
            const message = (error instanceof Error && error.message.includes('fetch'))
                ? 'Não foi possível conectar ao servidor do robô. O serviço pode estar offline.'
                : (error as Error).message;
            addLogWithTimestamp(message, 'fatal');
            setLoginError(message);
            setConnectionStep('failed');
        }
    };
    
    const handleSubmit2FA = async (e: React.FormEvent) => {
        e.preventDefault();
        setTwoFactorError(null);
        if (!twoFactorCode.trim() || twoFactorCode.length !== 6) {
            setTwoFactorError('O código de autenticação deve ter 6 dígitos.');
            return;
        }
        setIsSubmitting2fa(true);
        addLogWithTimestamp('Enviando código de autenticação...', 'info');
        try {
            const token = localStorage.getItem('jwt');
            const response = await fetch(`${BACKEND_URL}/api/robot/submit-2fa`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
                body: JSON.stringify({ code: twoFactorCode }),
            });
            if (!response.ok) throw new Error((await response.json()).message);
            setTwoFactorCode('');
        } catch (error) {
            addLogWithTimestamp(`Erro 2FA: ${(error as Error).message}`, 'fatal');
            setTwoFactorError((error as Error).message);
            setTwoFactorCode('');
        } finally {
            setIsSubmitting2fa(false);
        }
    };


    const handleStart = async () => {
        useRobotStore.getState().setUptime(0);
        const token = localStorage.getItem('jwt');
        await fetch(`${BACKEND_URL}/api/robot/start`, { method: 'POST', headers: { 'Authorization': `Bearer ${token}` } });
        if (uptimeIntervalRef.current) clearInterval(uptimeIntervalRef.current);
        uptimeIntervalRef.current = window.setInterval(() => useRobotStore.getState().setUptime(useRobotStore.getState().uptime + 1), 1000);
    };
    
    const handleStop = async () => {
        const token = localStorage.getItem('jwt');
        await fetch(`${BACKEND_URL}/api/robot/stop`, { method: 'POST', headers: { 'Authorization': `Bearer ${token}` } });
        if (uptimeIntervalRef.current) clearInterval(uptimeIntervalRef.current);
    };

    const handleDisconnect = async () => {
        const token = localStorage.getItem('jwt');
        await fetch(`${BACKEND_URL}/api/robot/disconnect`, { method: 'POST', headers: { 'Authorization': `Bearer ${token}` } });
        resetOnDisconnect();
        setLogin('');
        setPassword('');
        if (uptimeIntervalRef.current) clearInterval(uptimeIntervalRef.current);
    }

    const handleReconnect = () => {
        setIsSessionExpiredModalOpen(false);
        handleDisconnect();
    };
    
    const runDiagnostics = async () => {
        setIsDiagnosticModalOpen(true);
        const steps: DiagnosticStep[] = ['backend', 'gemini', 'puppeteer', 'google'];
        const initialResults: DiagnosticResult[] = steps.map(step => ({ step, status: 'pending', message: '' }));
        setDiagnosticResults(initialResults);
        const token = localStorage.getItem('jwt');

        for (let i = 0; i < steps.length; i++) {
            const step = steps[i];
            setDiagnosticResults(prev => prev.map(r => r.step === step ? { ...r, status: 'running' } : r));
            try {
                const response = await fetch(`${BACKEND_URL}/api/robot/diagnostics`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
                    body: JSON.stringify({ step }),
                });
                const data = await response.json();
                setDiagnosticResults(prev => prev.map(r => r.step === step ? { step, status: data.success ? 'success' : 'error', message: data.message } : r));
                if (!data.success) break;
            } catch (err) {
                setDiagnosticResults(prev => prev.map(r => r.step === step ? { step, status: 'error', message: 'Falha ao conectar ao backend.' } : r));
                break;
            }
        }
    };

    const renderLoginForm = () => (
        <div className="flex items-center justify-center h-full">
            <div className="w-full max-w-md">
                <div className="bg-gray-800/50 shadow-md rounded-lg p-8">
                    <div className="flex justify-center mb-6"><CpuChipIcon className="h-16 w-16 text-blue-400" /></div>
                    <h2 className="text-2xl font-bold text-center text-gray-100 mb-2">Acesso ao Robô PJe</h2>
                    <p className="text-center text-gray-400 text-sm mb-8">Utilize suas credenciais do PJe para conectar.</p>
                    
                    {robotStatus !== 'connecting' ? (
                        <form onSubmit={handleConnect}>
                            <div className="mb-4">
                                <label className="block text-gray-300 text-sm font-bold mb-2" htmlFor="login">Login (CPF/OAB)</label>
                                <input className="w-full bg-gray-900/50 border border-gray-700 rounded-md p-3 text-gray-200 focus:ring-2 focus:ring-blue-500" id="login" type="text" placeholder="Seu login do PJe" value={login} onChange={e => setLogin(e.target.value)} />
                            </div>
                            <div className="mb-6">
                                <label className="block text-gray-300 text-sm font-bold mb-2" htmlFor="password">Senha</label>
                                <input className="w-full bg-gray-900/50 border border-gray-700 rounded-md p-3 text-gray-200 focus:ring-2 focus:ring-blue-500" id="password" type="password" placeholder="******************" value={password} onChange={e => setPassword(e.target.value)} />
                            </div>
                            {loginError && (
                                <div className="bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-lg relative mb-4 text-sm" role="alert">
                                    <strong className="font-bold">Erro de Conexão: </strong>
                                    <span className="block sm:inline">{loginError}</span>
                                </div>
                            )}
                            <div className="flex flex-col gap-4">
                                <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg focus:outline-none focus:shadow-outline disabled:bg-gray-600 flex items-center justify-center gap-2" type="submit">
                                    <ArrowRightOnRectangleIcon className="h-5 w-5" />
                                    Conectar ao PJe
                                </button>
                            </div>
                        </form>
                    ) : (
                         <ConnectionProgress onRetry={handleConnect} />
                    )}
                </div>

                <div className="mt-6 bg-gray-800/50 border border-gray-700/50 rounded-lg p-6">
                    <div className="flex items-start gap-4">
                        <InformationCircleIcon className="h-8 w-8 text-blue-400 flex-shrink-0 mt-1" />
                        <div>
                            <h3 className="font-semibold text-gray-200 text-base">Primeiros Passos</h3>
                            <ol className="list-decimal list-inside space-y-1.5 text-gray-400 mt-2 text-sm">
                                <li><span className="font-semibold text-gray-300">Conecte-se</span> para estabelecer uma sessão segura e automatizada.</li>
                                <li><span className="font-semibold text-gray-300">Inicie o Monitoramento</span> para que o robô comece a trabalhar 24/7.</li>
                                <li><span className="font-semibold text-gray-300">Receba Insights</span> e minutas na página "Expedientes".</li>
                            </ol>
                        </div>
                    </div>
                </div>

                <div className="mt-4">
                    <button type="button" onClick={runDiagnostics} className="w-full bg-gray-700 hover:bg-gray-600 text-gray-200 font-bold py-2 px-4 rounded-lg flex items-center justify-center gap-2" disabled={robotStatus === 'connecting'}>
                        <WrenchScrewdriverIcon className="h-5 w-5"/>
                        Verificar Conexão e Diagnóstico
                    </button>
                </div>
            </div>
        </div>
    );
    
    return (
        <div className="relative">
            <PageTitle title="Robô PJe Autônomo" description="Monitore e controle o agente autônomo que opera no PJe 24/7." />

            {isAuthenticated ? (
                <>
                    <ConnectionStatusBanner status={wsConnectionStatus} />
                    {appError && (
                        <div className="bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-lg flex items-center justify-between gap-4 mb-6" role="alert">
                            <div className="flex items-center gap-4">
                                <XCircleIcon className="h-6 w-6 flex-shrink-0"/>
                                <div>
                                    <strong className="font-bold">Alerta Crítico do Robô: </strong>
                                    <span className="block sm:inline">{appError}</span>
                                </div>
                            </div>
                            <button onClick={() => setAppError(null)} className="p-1 rounded-full hover:bg-red-800/50">
                                <XMarkIcon className="h-5 w-5"/>
                            </button>
                        </div>
                    )}
                     <RobotDashboard 
                        onStart={handleStart}
                        onStop={handleStop}
                        onDisconnect={handleDisconnect}
                     />
                </>
            ) : (
                <>
                 <ConnectionStatusBanner status={wsConnectionStatus} />
                 {renderLoginForm()}
                </>
            )}

            {is2faRequired && (
                 <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
                    <div className="bg-gray-800 rounded-lg shadow-xl w-full max-w-sm p-8">
                         <h3 className="text-xl font-semibold text-center text-blue-300 mb-2">Verificação de Dois Fatores</h3>
                         <p className="text-center text-gray-400 text-sm mb-6">Abra seu aplicativo de autenticação e insira o código de 6 dígitos.</p>
                         <form onSubmit={handleSubmit2FA}>
                            <input
                                type="text"
                                value={twoFactorCode}
                                onChange={e => setTwoFactorCode(e.target.value.replace(/\D/g, ''))}
                                maxLength={6}
                                placeholder="_ _ _ _ _ _"
                                className="w-full text-center text-3xl tracking-[0.5em] bg-gray-900/50 border-gray-700 rounded-md p-4 text-gray-100 focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
                                disabled={isSubmitting2fa}
                            />
                            {twoFactorError && (
                                <p className="text-red-400 text-sm text-center mt-3">{twoFactorError}</p>
                            )}
                            <div className="flex gap-4 mt-6">
                                <button type="button" onClick={handleDisconnect} className="w-full bg-gray-600 hover:bg-gray-700 text-white font-bold py-3 rounded-lg" disabled={isSubmitting2fa}>Cancelar</button>
                                <button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg flex justify-center items-center disabled:bg-blue-800" disabled={isSubmitting2fa}>
                                     {isSubmitting2fa ? <LoadingSpinner size="5" /> : 'Verificar'}
                                </button>
                            </div>
                         </form>
                    </div>
                 </div>
            )}

            {isDiagnosticModalOpen && (
                 <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50" onClick={() => setIsDiagnosticModalOpen(false)}>
                    <div className="bg-gray-800 rounded-lg shadow-xl w-full max-w-lg p-6" onClick={e => e.stopPropagation()}>
                         <h3 className="text-lg font-semibold text-blue-300 mb-4">Diagnóstico do Sistema</h3>
                         <div className="space-y-3">
                            {diagnosticResults.map(({step, status, message}) => {
                                const stepLabels: Record<DiagnosticStep, string> = {
                                    backend: 'Conexão com Servidor',
                                    gemini: 'API do Gemini',
                                    puppeteer: 'Navegador de Automação',
                                    google: 'API do Google Workspace'
                                };
                                return (
                                    <div key={step} className="bg-gray-900/50 p-3 rounded-lg">
                                        <div className="flex items-center justify-between">
                                            <span className="font-semibold text-gray-300">{stepLabels[step]}</span>
                                            {status === 'running' && <LoadingSpinner size="5"/>}
                                            {status === 'success' && <CheckCircleIcon className="h-6 w-6 text-green-400"/>}
                                            {status === 'error' && <XCircleIcon className="h-6 w-6 text-red-400"/>}
                                        </div>
                                        {status === 'error' && <p className="text-xs text-red-300 mt-2"><b>Ação Recomendada:</b> {message}</p>}
                                        {status === 'success' && <p className="text-xs text-green-300 mt-2">{message}</p>}
                                    </div>
                                );
                            })}
                         </div>
                         <button onClick={() => setIsDiagnosticModalOpen(false)} className="mt-6 bg-blue-600 text-white w-full py-2 rounded-lg hover:bg-blue-700">Fechar</button>
                    </div>
                 </div>
            )}

            {isSessionExpiredModalOpen && (
                <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
                    <div className="bg-gray-800 rounded-lg shadow-xl w-full max-w-md p-8 text-center">
                        <XCircleIcon className="h-12 w-12 text-red-400 mx-auto mb-4" />
                        <h3 className="text-xl font-semibold text-gray-100">Sessão Expirada</h3>
                        <p className="text-gray-400 mt-2 mb-6">Sua sessão de automação no PJe expirou. Para continuar, por favor, reconecte-se.</p>
                        <button
                            onClick={handleReconnect}
                            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg flex items-center justify-center gap-2"
                        >
                            <ArrowPathIcon className="h-5 w-5" />
                            Reconectar
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default PjeRobot;
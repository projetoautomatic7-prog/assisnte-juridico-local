import React, { useState, useEffect } from 'react';

import PageTitle from '../components/PageTitle';
import '../styles/AgentDashboard.css';
import { BACKEND_URL, authenticatedFetch } from '../services/api';
import { Agent, AgentGoal, AgentStatus } from '../types';
import LoadingSpinner from '../components/LoadingSpinner';
import { XMarkIcon } from '../components/icons/Icons';

// --- Placeholder Components (since they were missing) ---
const AgentCard: React.FC<{
  agent: Agent;
  onPause: () => void;
  onDetails: () => void;
  onClose: () => void;
}> = ({ agent, onDetails }) => {
  const statusConfig: Record<AgentStatus, { text: string; color: string }> = {
    RUNNING: { text: 'Ativo', color: 'bg-green-500' },
    IDLE: { text: 'Ocioso', color: 'bg-gray-500' },
    ERROR: { text: 'Erro', color: 'bg-red-500' },
    PAUSED: { text: 'Pausado', color: 'bg-yellow-500' },
    SUCCESS: { text: 'Concluído', color: 'bg-blue-500' },
  };

  const currentStatus = statusConfig[agent.status] || statusConfig.IDLE;

  return (
    <div className="agent-card">
      <div className="agent-card__header">
        <h3 className="agent-card__title">{agent.name}</h3>
        <span className={`agent-card__status ${currentStatus.color}`}>{currentStatus.text}</span>
      </div>
      <p className="agent-card__description">{agent.description}</p>
      {agent.status === 'ERROR' && (
        <div className="agent-card__error">
          <strong>Detalhes do Erro:</strong> {agent.errorDetails}
        </div>
      )}
      <div className="agent-card__footer">
        <button onClick={onDetails} className="agent-card__button">
          Detalhes & Config
        </button>
      </div>
    </div>
  );
};

const AgentConfigModal: React.FC<{
  agent: any;
  isOpen: boolean;
  onClose: () => void;
  onSave: (config: any) => void;
}> = ({ agent, isOpen, onClose, onSave }) => {
    if(!isOpen) return null;

    return (
        <div className="modal-overlay" onClick={onClose}>
            <div className="modal-content" onClick={e => e.stopPropagation()}>
                <div className="modal-header">
                    <h3>Configurações: {agent.name}</h3>
                    <button onClick={onClose}><XMarkIcon className="h-6 w-6" /></button>
                </div>
                <div className="modal-body">
                    <p>Funcionalidade de configuração detalhada do agente a ser implementada.</p>
                </div>
                 <div className="modal-footer">
                    <button onClick={onClose}>Fechar</button>
                 </div>
            </div>
        </div>
    );
};
// --- End of Placeholder Components ---

const AgentDashboard: React.FC = () => {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedAgent, setSelectedAgent] = useState<Agent | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [filter, setFilter] = useState<'all' | AgentStatus>('all');

   useEffect(() => {
        const fetchGoals = async () => {
            setIsLoading(true);
            setError('');
            try {
                const response = await authenticatedFetch(`${BACKEND_URL}/api/agent/goals`);
                if (!response.ok) throw new Error('Falha ao buscar objetivos dos agentes.');
                const goals: AgentGoal[] = await response.json();
                
                // Map AgentGoal[] to Agent[]
                const mappedAgents: Agent[] = goals.map(goal => {
                    let status: AgentStatus = 'IDLE';
                    if (goal.status === 'RUNNING') status = 'RUNNING';
                    else if (goal.status === 'FAILED') status = 'ERROR';
                    else if (goal.status === 'PAUSED') status = 'PAUSED';
                    else if (goal.status === 'DONE') status = 'SUCCESS';

                    return {
                        id: goal.id,
                        name: goal.title,
                        type: 'Objetivo de IA',
                        status: status,
                        description: `Criado em: ${new Date(goal.created_at).toLocaleDateString()}`,
                        errorDetails: goal.status === 'FAILED' ? 'A execução falhou. Verifique os logs.' : undefined,
                    };
                });
                setAgents(mappedAgents);

            } catch (err) {
                setError((err as Error).message);
            } finally {
                setIsLoading(false);
            }
        };
        fetchGoals();
    }, []);


  const filteredAgents = agents.filter((agent) => {
    if (filter === 'all') return true;
    return agent.status === filter;
  });

  const stats = {
    total: agents.length,
    active: agents.filter((a) => a.status === 'RUNNING').length,
    errors: agents.filter((a) => a.status === 'ERROR').length,
    success: agents.filter((a) => a.status === 'SUCCESS').length,
    uptime: '99.8%', // Mocked for now
  };

  const handleSaveConfig = (config: any) => {
    console.log('Saved config:', config);
    setShowModal(false);
  };

  return (
    <div className="agent-dashboard">
      <PageTitle
        title="Dashboard dos Agentes IA"
        description="Monitore a atividade, performance e objetivos dos seus agentes autônomos."
      />

      <div className="dashboard-metrics">
        <div className="metric-box">
          <div className="metric-number">{stats.total}</div>
          <div className="metric-label">Objetivos Ativos</div>
        </div>
        <div className="metric-box">
          <div className="metric-number">{stats.active}</div>
          <div className="metric-label">Em Execução</div>
        </div>
        <div className="metric-box">
          <div className="metric-number">{stats.errors}</div>
          <div className="metric-label">Com Falha (Atenção)</div>
        </div>
        <div className="metric-box">
          <div className="metric-number">{stats.success}</div>
          <div className="metric-label">Concluídos</div>
        </div>
      </div>

      <div className="dashboard-filters">
        <div className="filter-group">
          <label>Filtro:</label>
          <button
            className={`filter-btn ${filter === 'all' ? 'active' : ''}`}
            onClick={() => setFilter('all')}
          >
            Todos ({agents.length})
          </button>
          <button
            className={`filter-btn ${filter === 'RUNNING' ? 'active' : ''}`}
            onClick={() => setFilter('RUNNING')}
          >
            Em Execução ({stats.active})
          </button>
           <button
            className={`filter-btn ${filter === 'SUCCESS' ? 'active' : ''}`}
            onClick={() => setFilter('SUCCESS')}
          >
            Concluídos ({stats.success})
          </button>
          <button
            className={`filter-btn ${filter === 'ERROR' ? 'active' : ''}`}
            onClick={() => setFilter('ERROR')}
          >
            Com Falha ({stats.errors})
          </button>
        </div>

        <input
          type="text"
          className="search-input"
          placeholder="Pesquisar objetivos..."
        />
      </div>

      {isLoading ? <div className="flex justify-center p-10"><LoadingSpinner size="12"/></div> : error ? <p className="text-red-400 text-center">{error}</p> : (
        <div className="agents-grid">
            {filteredAgents.map((agent) => (
            <AgentCard
                key={agent.id}
                agent={agent}
                onPause={() => console.log('Pause', agent.id)}
                onDetails={() => {
                setSelectedAgent(agent);
                setShowModal(true);
                }}
                onClose={() => console.log('Close', agent.id)}
            />
            ))}
        </div>
      )}

      {selectedAgent && (
        <AgentConfigModal
          agent={selectedAgent}
          isOpen={showModal}
          onClose={() => setShowModal(false)}
          onSave={handleSaveConfig}
        />
      )}
    </div>
  );
};

export default AgentDashboard;
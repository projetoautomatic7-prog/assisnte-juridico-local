import React, { useState, useEffect, useMemo, ChangeEvent, useRef, useCallback } from 'react';

import DonutChart from '../components/charts/DonutChart';
import { BriefcaseIcon, ChevronDownIcon, DocumentDuplicateIcon, ArrowUpTrayIcon, TrashIcon, LightBulbIcon, ArrowTopRightOnSquareIcon, CheckCircleIcon } from '../components/icons/Icons';
import LoadingSpinner from '../components/LoadingSpinner';
import PageTitle from '../components/PageTitle';
import PremonicaoModal from '../components/PremonicaoModal';
import ExpedienteSkeleton from '../components/skeletons/ExpedienteSkeleton';
import { BACKEND_URL, authenticatedFetch } from '../services/api';
import { useExpedientesStore } from '../stores/expedientesStore';
import { Expediente, ExpedienteStatus } from '../types';

// Hook de debounce
const useDebounce = (callback: (...args: any[]) => void, delay: number) => {
    const timeoutRef = useRef<number | null>(null);

    return useCallback((...args: any[]) => {
        if (timeoutRef.current) {
            clearTimeout(timeoutRef.current);
        }
        timeoutRef.current = window.setTimeout(() => {
            callback(...args);
        }, delay);
    }, [callback, delay]);
};


const ManagementPanel: React.FC<{ 
    expediente: Expediente; 
    onSaveDraft: (expedienteId: string, newContent: string) => void; 
    onToggleGoogleDocsEdit: (expedienteId: string, status: Expediente['google_docs_editing_status']) => void;
}> = ({ expediente, onSaveDraft, onToggleGoogleDocsEdit }) => {
    const [activeTab, setActiveTab] = useState<'draft' | 'pending'>('draft');
    const [editedContent, setEditedContent] = useState(expediente.ai_drafted_document?.content || '');
    const [uploadedFiles, setUploadedFiles] = useState<{ [key: string]: File }>({});
    const [isSaved, setIsSaved] = useState(false);
    const isEditingRef = useRef(false);

    const lockTask = useCallback(async () => {
        if (!expediente.agentTaskId || isEditingRef.current) return;
        isEditingRef.current = true;
        console.log(`Locking task ${expediente.agentTaskId}`);
        try {
            await authenticatedFetch(`${BACKEND_URL}/api/agent/tasks/${expediente.agentTaskId}/lock`, { method: 'POST' });
        } catch (e) { console.error("Failed to lock task", e); }
    }, [expediente.agentTaskId]);

    const unlockTask = useCallback(async () => {
        if (!expediente.agentTaskId || !isEditingRef.current) return;
        isEditingRef.current = false;
        console.log(`Unlocking task ${expediente.agentTaskId}`);
        try {
            await authenticatedFetch(`${BACKEND_URL}/api/agent/tasks/${expediente.agentTaskId}/unlock`, { method: 'POST' });
        } catch (e) { console.error("Failed to unlock task", e); }
    }, [expediente.agentTaskId]);
    
    const debouncedUnlock = useDebounce(unlockTask, 5000); // Unlock after 5s of inactivity

    useEffect(() => {
        // Avoid calling setState directly in effect to prevent cascading renders.
        // Instead, schedule the update asynchronously so it runs after paint.
        const scheduleActiveTab = () => {
            if (expediente.ai_drafted_document) {
                setActiveTab('draft');
            } else if (expediente.required_documents.length > 0) {
                setActiveTab('pending');
            }
        };
        const id = window.setTimeout(scheduleActiveTab, 0);
        // Cleanup function to unlock task if component unmounts while editing
        return () => {
            clearTimeout(id);
            if (isEditingRef.current) {
                unlockTask();
            }
        };
    }, [expediente, unlockTask]);

    const handleFileChange = (e: ChangeEvent<HTMLInputElement>, requirement: string) => {
        if (e.target.files && e.target.files[0]) {
            setUploadedFiles(prev => ({ ...prev, [requirement]: e.target.files![0] }));
        }
    };

    const handleFileRemove = (requirement: string) => {
        setUploadedFiles(prev => {
            const newState = { ...prev };
            delete newState[requirement];
            return newState;
        });
    };
    
    const handleSaveClick = async () => {
        onSaveDraft(expediente.id, editedContent);
        setIsSaved(true);
        // Also update the payload on the backend task
        if (expediente.agentTaskId) {
             try {
                const currentPayload = { notification: expediente, human_draft: editedContent };
                await authenticatedFetch(`${BACKEND_URL}/api/agent/tasks/${expediente.agentTaskId}/payload`, {
                    method: 'PATCH',
                    body: JSON.stringify(currentPayload),
                });
            } catch (e) { console.error("Failed to update task payload", e); }
        }
        // Unlock after saving
        await unlockTask();
        setTimeout(() => setIsSaved(false), 2000);
    };

     const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        lockTask(); // Lock on first change
        setEditedContent(e.target.value);
        debouncedUnlock(); // Schedule unlock
    };
    
    const handleSyncFromGoogle = () => {
        const updatedContent = `${editedContent}\n\n//-- CONTEÚDO SINCRONIZADO DO GOOGLE DOCS EM ${new Date().toLocaleString()} --//`;
        setEditedContent(updatedContent);
        onSaveDraft(expediente.id, updatedContent);
        onToggleGoogleDocsEdit(expediente.id, 'idle');
    };

    const isEditingInGoogle = expediente.google_docs_editing_status === 'editing_google_docs';

    return (
        <div className="bg-gray-900/50 p-5 border-t-2 border-blue-800/50">
            <div className="flex border-b border-gray-700 mb-4">
                {expediente.ai_drafted_document && (
                    <button onClick={() => setActiveTab('draft')} className={`flex items-center gap-2 py-2 px-4 text-sm font-medium ${activeTab === 'draft' ? 'border-b-2 border-blue-400 text-blue-300' : 'text-gray-400'}`}>
                        <DocumentDuplicateIcon className="h-5 w-5" /> Documento Gerado
                    </button>
                )}
                {expediente.required_documents.length > 0 && (
                    <button onClick={() => setActiveTab('pending')} className={`flex items-center gap-2 py-2 px-4 text-sm font-medium ${activeTab === 'pending' ? 'border-b-2 border-blue-400 text-blue-300' : 'text-gray-400'}`}>
                        <ArrowUpTrayIcon className="h-5 w-5" /> Documentos Pendentes
                    </button>
                )}
            </div>
            
            {activeTab === 'draft' && expediente.ai_drafted_document && (
                <div>
                    <div className="flex justify-between items-center mb-2 flex-wrap gap-2">
                        <h4 className="font-semibold text-gray-300">{expediente.ai_drafted_document.name}</h4>
                        <div className="flex gap-2">
                           {expediente.google_doc_link && !isEditingInGoogle && (
                                <button onClick={() => onToggleGoogleDocsEdit(expediente.id, 'editing_google_docs')} className="bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold py-1 px-3 rounded flex items-center gap-1.5">
                                    <ArrowTopRightOnSquareIcon className="h-4 w-4"/> Editar no Google Docs
                                </button>
                           )}
                           {isEditingInGoogle && (
                                <button onClick={handleSyncFromGoogle} className="bg-green-600 hover:bg-green-700 text-white text-xs font-bold py-1 px-3 rounded animate-pulse">
                                    Sincronizar do Google Docs
                                </button>
                           )}
                            <button onClick={handleSaveClick} disabled={isSaved || isEditingInGoogle} className={`text-white text-xs font-bold py-1 px-3 rounded transition-colors duration-200 ${isSaved ? 'bg-green-600' : 'bg-blue-600 hover:bg-blue-700'} disabled:bg-gray-600 disabled:cursor-not-allowed`}>
                                {isSaved ? 'Salvo!' : 'Salvar Alterações'}
                            </button>
                        </div>
                    </div>
                     {isEditingInGoogle && (
                        <div className="bg-sky-900/50 border border-sky-700 text-sky-300 text-xs text-center p-2 rounded-md mb-2">
                            Edição bloqueada. O documento está sendo editado no Google Docs. Clique em "Sincronizar" para buscar as alterações.
                        </div>
                    )}
                    <textarea 
                        value={editedContent}
                        onFocus={lockTask}
                        onChange={handleContentChange}
                        onBlur={unlockTask}
                        rows={12}
                        className="w-full bg-gray-800 border border-gray-700 rounded-md p-3 text-gray-300 font-mono text-xs focus:ring-1 focus:ring-blue-500 disabled:opacity-50"
                        disabled={isEditingInGoogle}
                    />
                </div>
            )}

            {activeTab === 'pending' && expediente.required_documents.length > 0 && (
                <div className="space-y-3">
                    {expediente.required_documents.map(req => (
                        <div key={req} className="bg-gray-800 p-3 rounded-md flex items-center justify-between">
                            <p className="text-sm text-gray-300">{req}</p>
                            {uploadedFiles[req] ? (
                                <div className="flex items-center gap-2">
                                    <DocumentDuplicateIcon className="h-4 w-4 text-green-400 flex-shrink-0" />
                                    <span className="text-sm text-green-400 truncate max-w-xs">{uploadedFiles[req].name}</span>
                                    <button onClick={() => handleFileRemove(req)} className="text-gray-500 hover:text-red-400">
                                        <TrashIcon className="h-4 w-4" />
                                    </button>
                                </div>
                            ) : (
                                <label className="bg-gray-700 hover:bg-gray-600 text-gray-300 text-xs font-bold py-1 px-3 rounded cursor-pointer">
                                    Anexar Arquivo
                                    <input type="file" className="hidden" onChange={(e) => handleFileChange(e, req)} />
                                </label>
                            )}
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

const TaskDetails: React.FC<{ expediente: Expediente, onToggle: () => void }> = ({ expediente, onToggle }) => (
    <div className="bg-gray-900/30 p-4 border-t border-gray-700/50">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <div>
                <h4 className="font-semibold text-gray-300 text-sm mb-2">Tarefas Concluídas pela IA ({expediente.tasks_completed_by_ai})</h4>
                <ul className="space-y-1.5">
                    {expediente.ai_completed_tasks_list.map((task, index) => (
                      <li key={index} className="flex items-center text-xs text-gray-400">
                         <CheckCircleIcon className="w-4 h-4 mr-2 text-green-400 flex-shrink-0"/>
                        {task}
                      </li>
                    ))}
                  </ul>
            </div>
             <div>
                <h4 className="font-semibold text-gray-300 text-sm mb-2">Diligências Humanas ({expediente.tasks_pending_human})</h4>
                 {expediente.human_tasks_list?.length > 0 ? (
                    <ul className="space-y-1.5">
                        {expediente.human_tasks_list.map((task, index) => 
                        <li key={index} className="flex items-center text-xs text-yellow-300">
                            <BriefcaseIcon className="w-4 h-4 mr-2 text-yellow-400 flex-shrink-0"/>
                            {task}
                        </li>)}
                    </ul>
                ) : <p className="text-xs text-gray-500 mt-1">Nenhuma ação pendente.</p>}
            </div>
        </div>
        <button onClick={onToggle} className="text-xs text-gray-500 hover:text-gray-300 mt-3 w-full text-center">Ocultar Detalhes</button>
    </div>
);

const ExpedienteCard: React.FC<{ 
    expediente: Expediente; 
    onSaveDraft: (id: string, content: string) => void;
    onToggleGoogleDocsEdit: (id: string, status: Expediente['google_docs_editing_status']) => void;
    onPremonicaoClick: (cnj: string) => void;
}> = ({ expediente, onSaveDraft, onToggleGoogleDocsEdit, onPremonicaoClick }) => {
    const [isDocsExpanded, setIsDocsExpanded] = useState(false);
    const [isTasksExpanded, setIsTasksExpanded] = useState(false);

    const statusConfig: Record<ExpedienteStatus, { text: string; className: string; color: string }> = {
        human_review: { text: 'Revisão Humana', className: 'bg-yellow-500/20 text-yellow-300', color: '#facc15' },
        awaiting_documents: { text: 'Aguardando Documentos', className: 'bg-orange-500/20 text-orange-300', color: '#fb923c' },
        drafting: { text: 'Gerando Minuta', className: 'bg-blue-500/20 text-blue-300 animate-pulse', color: '#60a5fa' },
        completed: { text: 'Cumprido', className: 'bg-green-500/20 text-green-300', color: '#4ade80' },
        no_action_needed: { text: 'Ciência (Sem Ação)', className: 'bg-gray-500/20 text-gray-400', color: '#9ca3af' },
    };

    const percentage = expediente.tasks_total > 0 ? (expediente.tasks_completed_by_ai / expediente.tasks_total) * 100 : 100;
    const currentStatus = statusConfig[expediente.status];

    return (
        <div className="bg-gray-800/50 rounded-lg border border-gray-700/50 overflow-hidden transition-all duration-300">
            <div className="flex flex-col md:flex-row">
                <div className="p-5 flex-grow md:w-3/5">
                    <div className="flex justify-between items-start mb-3">
                        <div>
                            <p className="font-bold text-gray-200 text-lg">{expediente.destinatario}</p>
                            <p className="text-sm text-gray-400">{expediente.tipo} ({expediente.id}) via {expediente.fonte}</p>
                        </div>
                        <div className="text-right flex-shrink-0 ml-4">
                            <p className="text-sm font-semibold text-amber-400">{expediente.prazo_dias}</p>
                            <p className="text-xs text-gray-500">Publicado: {expediente.data_publicacao}</p>
                        </div>
                    </div>
                    <div className="bg-gray-900/40 p-3 rounded-md text-sm mb-4">
                        <p className="text-gray-300">{expediente.data_ciencia}</p>
                        <p className="font-semibold text-gray-100">Data limite: {expediente.data_limite}</p>
                    </div>
                    <div className="text-sm space-y-1">
                        <p><strong className="font-semibold text-gray-400">Processo:</strong> <span className="text-gray-300">{expediente.processo_classe} {expediente.processo_cnj}</span></p>
                        <p><strong className="font-semibold text-gray-400">Partes:</strong> <span className="text-gray-300">{expediente.partes}</span></p>
                    </div>
                </div>
                <div className="bg-gray-900/50 p-5 md:w-2/5 md:border-l border-gray-700/50 flex flex-col justify-between">
                    <div>
                        <div className="flex justify-between items-start">
                           <h3 className="text-lg font-semibold text-blue-300 mb-3">Status da Automação</h3>
                           <button onClick={() => onPremonicaoClick(expediente.processo_cnj)} className="text-yellow-400 hover:text-yellow-300" title="Premonição Jurídica">
                               <LightBulbIcon className="h-6 w-6"/>
                           </button>
                        </div>
                        <div className="flex items-center gap-4">
                            <DonutChart percentage={percentage} color={currentStatus.color} size={80} strokeWidth={8} />
                            <div>
                                <span className={`px-2.5 py-1 text-sm font-semibold rounded-full ${currentStatus.className}`}>
                                    {currentStatus.text}
                                </span>
                                <p className="text-sm text-gray-400 mt-2">{expediente.ai_summary}</p>
                            </div>
                        </div>
                    </div>
                     <div className="flex gap-2 mt-4">
                        <button onClick={() => setIsTasksExpanded(!isTasksExpanded)} className="w-full bg-gray-700/50 hover:bg-gray-700 text-gray-300 font-semibold py-2 px-4 rounded-lg flex items-center justify-center gap-2 transition-colors text-xs">
                            Detalhes das Tarefas <ChevronDownIcon className={`h-4 w-4 transition-transform ${isTasksExpanded ? 'rotate-180' : ''}`} />
                        </button>
                        <button onClick={() => setIsDocsExpanded(!isDocsExpanded)} className="w-full bg-gray-700/50 hover:bg-gray-700 text-gray-300 font-semibold py-2 px-4 rounded-lg flex items-center justify-center gap-2 transition-colors text-xs">
                            Gerenciar Documentos <ChevronDownIcon className={`h-4 w-4 transition-transform ${isDocsExpanded ? 'rotate-180' : ''}`} />
                        </button>
                    </div>
                </div>
            </div>
            {isTasksExpanded && <TaskDetails expediente={expediente} onToggle={() => setIsTasksExpanded(false)} />}
            {isDocsExpanded && <ManagementPanel expediente={expediente} onSaveDraft={onSaveDraft} onToggleGoogleDocsEdit={onToggleGoogleDocsEdit} />}
        </div>
    );
};


const Expedientes: React.FC = () => {
    const { 
        expedientes, isLoading, error, isModalOpen, isModalLoading, premonicaoData, modalError,
        fetchExpedientes, fetchPremonicao, closeModal, saveDraft, toggleGoogleDocsEdit
    } = useExpedientesStore();

    useEffect(() => {
        fetchExpedientes();
    }, [fetchExpedientes]);
    
    const summary = useMemo(() => {
        return expedientes.reduce((acc, curr) => {
            acc[curr.status] = (acc[curr.status] || 0) + 1;
            acc.total++;
            return acc;
        }, { total: 0 } as Record<ExpedienteStatus | 'total', number>);
    }, [expedientes]);

    const renderContent = () => {
        if (isLoading) {
            return (
                <div className="space-y-6">
                    <ExpedienteSkeleton />
                    <ExpedienteSkeleton />
                </div>
            );
        }

        if (error) {
            return (
                <div className="text-center text-red-400 bg-red-900/50 p-6 rounded-lg">
                    <h3 className="font-semibold">Não foi possível carregar os expedientes</h3>
                    <p className="text-sm mt-2">{error}</p>
                    <p className="text-sm mt-2">Certifique-se de que o robô está conectado ao PJe na página 'Robô PJe'.</p>
                </div>
            );
        }
        
        if (expedientes.length === 0) {
            return (
                 <div className="text-center text-gray-500 p-10 bg-gray-800/50 rounded-lg">
                    <BriefcaseIcon className="h-12 w-12 mx-auto mb-4" />
                    <h3 className="font-semibold text-gray-300">Caixa de entrada vazia.</h3>
                    <p className="text-sm mt-2">O robô não encontrou nenhum expediente pendente no PJe.</p>
                </div>
            );
        }

        return (
            <div className="space-y-6">
                {expedientes.map(exp => <ExpedienteCard 
                    key={exp.id} 
                    expediente={exp} 
                    onSaveDraft={saveDraft} 
                    onToggleGoogleDocsEdit={toggleGoogleDocsEdit}
                    onPremonicaoClick={fetchPremonicao}
                    />
                )}
            </div>
        );
    }

    return (
        <div>
            <PageTitle
                title="Painel de Expedientes"
                description="Visualize suas intimações do PJe com status de cumprimento e automação da IA."
            />
            
            {!isLoading && !error && expedientes.length > 0 && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                    <div className="bg-blue-900/50 p-4 rounded-lg text-center"><div className="text-2xl font-bold text-white">{summary.total || 0}</div><div className="text-sm text-blue-300">Total</div></div>
                    <div className="bg-yellow-900/50 p-4 rounded-lg text-center"><div className="text-2xl font-bold text-white">{summary.human_review || 0}</div><div className="text-sm text-yellow-300">Revisão Humana</div></div>
                    <div className="bg-orange-900/50 p-4 rounded-lg text-center"><div className="text-2xl font-bold text-white">{summary.awaiting_documents || 0}</div><div className="text-sm text-orange-300">Aguardando Docs</div></div>
                    <div className="bg-green-900/50 p-4 rounded-lg text-center"><div className="text-2xl font-bold text-white">{summary.completed || 0}</div><div className="text-sm text-green-300">Cumpridos</div></div>
                </div>
            )}

            {renderContent()}

            <PremonicaoModal 
              isOpen={isModalOpen}
              onClose={closeModal}
              isLoading={isModalLoading}
              data={premonicaoData}
              error={modalError}
            />
        </div>
    );
};

export default Expedientes;

import React, { useState, useEffect, useMemo } from 'react';

import { StarIcon, ExclamationTriangleIcon, MagnifyingGlassIcon, ChevronLeftIcon, ChevronRightIcon } from '../components/icons/Icons';
import LoadingSpinner from '../components/LoadingSpinner';
import PageTitle from '../components/PageTitle';
import { BACKEND_URL, authenticatedFetch } from '../services/api';
import { Atividade } from '../types';

// Mock Data for chart (will be replaced with real data from API)
let barChartData = [
  { label: 'Pendentes', value: 0, color: 'bg-yellow-500' },
  { label: 'Atrasadas', value: 0, color: 'bg-red-500' },
  { label: 'Resolvidas no mês', value: 0, color: 'bg-green-500' },
];


const AtividadeItem: React.FC<{ item: Atividade }> = ({ item }) => (
    <tr className="border-b border-gray-700/50 hover:bg-gray-800">
        <td className="px-4 py-3">
            <div className="flex items-center gap-3">
                <input type="checkbox" aria-label="Marcar atividade como concluída" className="h-4 w-4 rounded bg-gray-700 border-gray-600 text-blue-500 focus:ring-blue-600" />
                <button aria-label="Marcar como favorito">
                    <StarIcon className="h-5 w-5 text-gray-600 hover:text-yellow-400 cursor-pointer" />
                </button>
                {item.isUrgent && <ExclamationTriangleIcon className="h-5 w-5 text-red-500"><title>Prazo fatal</title></ExclamationTriangleIcon>}
            </div>
        </td>
        <td className="px-4 py-3">
            <p className="font-medium text-gray-200">{item.tarefa}</p>
        </td>
        <td className="px-4 py-3 text-gray-400">{item.partes}</td>
        <td className="px-4 py-3 text-gray-400">{new Date(item.dataCompromisso).toLocaleDateString('pt-BR', { timeZone: 'UTC' })}</td>
        <td className="px-4 py-3 font-semibold text-red-400">{item.prazoFatal ? new Date(item.prazoFatal).toLocaleDateString('pt-BR', { timeZone: 'UTC' }) : '-'}</td>
    </tr>
);


const Atividades: React.FC = () => {
    const [atividades, setAtividades] = useState<Atividade[]>([]);
    const [stats, setStats] = useState({ atividades: 0, pendentes: 0, atrasadas: 0, resolvidasNoMes: 0, produtividade: 0, publicacoesPendentes: 0 });
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState('');
    const [searchQuery, setSearchQuery] = useState('');
    const [personFilter, setPersonFilter] = useState('todos');
    const [currentDate, setCurrentDate] = useState(new Date());
    const [selectedDate, setSelectedDate] = useState<Date | null>(null);

    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            setError('');
            try {
                const response = await authenticatedFetch(`${BACKEND_URL}/api/data/atividades`);
                if (!response.ok) throw new Error('Falha ao buscar atividades.');
                const data = await response.json();
                setAtividades(data);

                // Buscar estatísticas
                const statsResponse = await authenticatedFetch(`${BACKEND_URL}/api/data/atividades/stats`);
                if (statsResponse.ok) {
                    const statsData = await statsResponse.json();
                    setStats(statsData);
                    // Atualizar barChartData com dados reais
                    barChartData = [
                        { label: 'Pendentes', value: statsData.pendentes, color: 'bg-yellow-500' },
                        { label: 'Atrasadas', value: statsData.atrasadas, color: 'bg-red-500' },
                        { label: 'Resolvidas no mês', value: statsData.resolvidasNoMes, color: 'bg-green-500' },
                    ];
                }
            } catch (err) {
                setError((err as Error).message);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, []);

    const activityDates = useMemo(() => {
        if (!atividades) return new Set();
        return new Set(atividades.map(a => {
            const dt = new Date(a.dataCompromisso);
            return new Date(dt.getUTCFullYear(), dt.getUTCMonth(), dt.getUTCDate()).toDateString();
        }));
    }, [atividades]);

    const filteredAtividades = useMemo(() => {
        return atividades
            .filter(a => {
                const searchMatch = a.tarefa.toLowerCase().includes(searchQuery.toLowerCase()) || a.partes.toLowerCase().includes(searchQuery.toLowerCase());
                return searchMatch;
            })
            .filter(a => {
                if (!selectedDate) return true;
                const activityDate = new Date(a.dataCompromisso);
                const normalizedActivityDate = new Date(activityDate.getUTCFullYear(), activityDate.getUTCMonth(), activityDate.getUTCDate());
                return normalizedActivityDate.toDateString() === selectedDate.toDateString();
            });
    }, [atividades, searchQuery, selectedDate]);
    
    // Simple bar chart component
    const ActivitiesBarChart: React.FC = () => {
        const maxValue = Math.max(...barChartData.map(d => d.value));
        return (
            <div className="flex items-end h-32 gap-4">
                {barChartData.map(item => (
                    <div key={item.label} className="flex-1 flex flex-col items-center text-center">
                        <div className="text-lg font-bold text-white">{item.value}</div>
                        <div 
                            className={`w-full rounded-md ${item.color}`}
                            style={{ height: `${(item.value / maxValue) * 100}%` }}
                        ></div>
                        <div className="text-xs text-gray-400 mt-1">{item.label}</div>
                    </div>
                ))}
            </div>
        );
    };
    
    // Calendar Component Logic
    const Calendar = () => {
        const daysOfWeek = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
        const monthNames = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];

        const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
        const lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
        const daysInMonth = lastDayOfMonth.getDate();
        const startingDay = firstDayOfMonth.getDay();

        const changeMonth = (offset: number) => {
            setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + offset, 1));
            setSelectedDate(null);
        };

        const handleDayClick = (day: number) => {
            const clickedDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
            if(selectedDate?.toDateString() === clickedDate.toDateString()){
                setSelectedDate(null); // Deselect if clicked again
            } else {
                setSelectedDate(clickedDate);
            }
        };

        const today = new Date();

        return (
            <div className="p-4 h-full flex flex-col">
                <div className="flex justify-between items-center mb-4">
                    <button onClick={() => changeMonth(-1)} className="p-2 rounded-full hover:bg-gray-700"><ChevronLeftIcon className="h-5 w-5"/></button>
                    <h4 className="font-semibold text-gray-200">{monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}</h4>
                    <button onClick={() => changeMonth(1)} className="p-2 rounded-full hover:bg-gray-700"><ChevronRightIcon className="h-5 w-5"/></button>
                </div>
                <div className="grid grid-cols-7 gap-1 text-center text-xs text-gray-400 mb-2">
                    {daysOfWeek.map(day => <div key={day}>{day}</div>)}
                </div>
                <div className="grid grid-cols-7 gap-1 flex-grow">
                    {Array.from({ length: startingDay }).map((_, i) => <div key={`empty-${i}`}></div>)}
                    {Array.from({ length: daysInMonth }).map((_, i) => {
                        const day = i + 1;
                        const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
                        const dateString = date.toDateString();
                        const isToday = dateString === today.toDateString();
                        const hasActivity = activityDates.has(dateString);
                        const isSelected = selectedDate?.toDateString() === dateString;

                        return (
                            <button 
                                key={day} 
                                onClick={() => handleDayClick(day)}
                                className={`relative w-full h-10 flex items-center justify-center rounded-lg transition-colors ${
                                    isSelected ? 'bg-blue-600 text-white font-semibold' : 
                                    isToday ? 'bg-gray-700/50 text-blue-300 font-semibold' : 'hover:bg-gray-700/50'
                                }`}
                            >
                                {day}
                                {hasActivity && <div className={`absolute bottom-1.5 w-1.5 h-1.5 rounded-full ${isSelected ? 'bg-white' : 'bg-blue-400'}`}></div>}
                            </button>
                        );
                    })}
                </div>
            </div>
        );
    };

    return (
        <div>
            <PageTitle
                title="Atividades"
                description="Acompanhe suas tarefas, produtividade e prazos."
            />
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                <div className="lg:col-span-1 bg-gray-800/50 p-6 rounded-lg">
                    <h3 className="text-lg font-semibold text-gray-200 mb-4">Atividades</h3>
                    <ActivitiesBarChart />
                </div>
                <div className="lg:col-span-1 bg-gray-800/50 p-6 rounded-lg space-y-4">
                    <h3 className="text-lg font-semibold text-gray-200">Produtividade</h3>
                    <div className="bg-gray-900/50 p-4 rounded-lg text-center">
                        <p className="text-4xl font-bold text-white">{stats.produtividade}</p>
                        <p className="text-gray-400">Tarefas Pendentes</p>
                    </div>
                    <div className="bg-gray-900/50 p-4 rounded-lg text-center">
                        <p className="text-4xl font-bold text-white">{stats.publicacoesPendentes}</p>
                        <p className="text-gray-400">Publicações Pendentes</p>
                    </div>
                </div>
                <div className="lg:col-span-1 bg-gray-800/50 rounded-lg flex items-center justify-center">
                     <Calendar />
                </div>
            </div>

            <div className="bg-gray-800/50 rounded-lg">
                <div className="p-4 border-b border-gray-700/50 flex flex-col sm:flex-row gap-4 justify-between items-center">
                    <div className="flex items-center gap-4">
                        <h3 className="text-lg font-semibold text-gray-200">
                            {selectedDate ? `Atividades para ${selectedDate.toLocaleDateString('pt-BR')}` : 'Todas as Atividades'}
                        </h3>
                        {selectedDate && (
                            <button onClick={() => setSelectedDate(null)} className="text-xs text-blue-400 hover:underline">Mostrar todas</button>
                        )}
                    </div>
                    <div className="flex gap-2 w-full sm:w-auto">
                        <div className="relative flex-grow">
                             <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                               <MagnifyingGlassIcon className="h-5 w-5 text-gray-400" />
                            </div>
                            <input 
                                type="text" 
                                placeholder="Pesquisar Tarefa..."
                                value={searchQuery}
                                onChange={e => setSearchQuery(e.target.value)}
                                className="bg-gray-900/50 border border-gray-700 text-gray-200 text-sm rounded-lg block w-full pl-10 p-2.5"
                            />
                        </div>
                         <select 
                            value={personFilter}
                            onChange={e => setPersonFilter(e.target.value)}
                            className="bg-gray-900/50 border border-gray-700 text-gray-200 text-sm rounded-lg p-2.5"
                        >
                            <option value="todos">Todos</option>
                            <option value="carmina">Carmina Remones</option>
                        </select>
                    </div>
                </div>
                 <div className="overflow-x-auto">
                    {isLoading ? <div className="flex justify-center p-8"><LoadingSpinner /></div> : error ? <div className="p-4 text-center text-red-400">{error}</div> : (
                    <table className="w-full text-sm">
                        <thead className="text-xs text-gray-400 uppercase bg-gray-900/50">
                            <tr>
                                <th className="px-4 py-3 w-20"></th>
                                <th className="px-4 py-3 text-left">Tarefa</th>
                                <th className="px-4 py-3 text-left">Partes</th>
                                <th className="px-4 py-3 text-left">Data Compromisso</th>
                                <th className="px-4 py-3 text-left">Prazo Fatal</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredAtividades.length > 0 ? filteredAtividades.map(item => <AtividadeItem key={item.id} item={item} />) : (
                                <tr>
                                    <td colSpan={5} className="text-center text-gray-500 py-8">
                                        Nenhuma atividade encontrada para os filtros selecionados.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                    )}
                </div>
            </div>

        </div>
    );
};

export default Atividades;
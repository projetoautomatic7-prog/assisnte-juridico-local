import React, { useState } from 'react';

import { ChevronDownIcon } from '../components/icons/Icons';
import LoadingSpinner from '../components/LoadingSpinner';
import PageTitle from '../components/PageTitle';
import { BACKEND_URL, authenticatedFetch } from '../services/api';

interface DeadlineResult {
    data_final_prazo: string;
    dias_corridos: number;
    dias_uteis: number;
    raciocinio_passo_a_passo: string;
}

const DeadlineCalculator: React.FC = () => {
  const [startDate, setStartDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [days, setDays] = useState<string>('15');
  const [deadlineType, setDeadlineType] = useState<'CPC' | 'CLT'>('CPC');
  const [context, setContext] = useState<string>('');
  const [useDeepReasoning, setUseDeepReasoning] = useState<boolean>(true);
  const [result, setResult] = useState<DeadlineResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [isReasoningExpanded, setIsReasoningExpanded] = useState<boolean>(false);

  const calculateDeadline = async () => {
    setIsLoading(true);
    setError(null);
    setResult(null);
    setIsReasoningExpanded(false); // Reset on new calculation

    try {
        const prompt = `Atue como um especialista em contagem de prazos processuais no Brasil. Calcule a data final do prazo com base nas seguintes informações. Forneça uma explicação passo a passo auditável, considerando as regras do ${deadlineType}, a contagem em dias úteis, e possíveis feriados nacionais (considere o ano corrente da data de início).
        - Data de início da contagem (primeiro dia do prazo): ${startDate}
        - Duração do prazo: ${days} dias
        - Tipo de prazo: ${deadlineType} (Considerar contagem em dias úteis para CPC)
        - Contexto adicional (feriados locais, suspensões, etc.): ${context || "Nenhum contexto adicional fornecido."}
        `;

        const schema = {
            type: 'OBJECT',
            properties: {
                data_final_prazo: { type: 'STRING', description: "A data final no formato DD/MM/AAAA." },
                dias_corridos: { type: 'INTEGER', description: "Número total de dias corridos." },
                dias_uteis: { type: 'INTEGER', description: "Número total de dias úteis contados." },
                raciocinio_passo_a_passo: { type: 'STRING', description: "Explicação detalhada de como o cálculo foi feito." }
            },
            required: ["data_final_prazo", "dias_corridos", "dias_uteis", "raciocinio_passo_a_passo"]
        };
        
        const response = await authenticatedFetch(`${BACKEND_URL}/api/ai/text`, {
            method: 'POST',
            body: JSON.stringify({ prompt, schema, model: 'gemini-2.5-pro' }), // Assuming thinkingBudget is handled by model choice
        });

        if (!response.ok) {
            const err = await response.json();
            throw new Error(err.message || 'Erro do servidor');
        }

        const backendResult = await response.json();
        const parsedResult = JSON.parse(backendResult.text) as DeadlineResult;
        setResult(parsedResult);
        
    } catch (err) {
      console.error(err);
      setError('Ocorreu um erro ao calcular o prazo. A resposta do modelo pode não estar no formato esperado.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div>
      <PageTitle
        title="Calculadora de Prazos com Raciocínio Profundo"
        description="Calcule prazos processuais complexos com uma análise passo a passo auditável fornecida pela IA."
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-gray-800/50 rounded-lg p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300">Data de Início do Prazo</label>
            <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="mt-1 w-full bg-gray-900/50 border-gray-700 rounded-md p-2 text-gray-200" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300">Duração (dias)</label>
            <input type="number" value={days} onChange={e => setDays(e.target.value)} className="mt-1 w-full bg-gray-900/50 border-gray-700 rounded-md p-2 text-gray-200" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300">Legislação</label>
            <select value={deadlineType} onChange={e => setDeadlineType(e.target.value as 'CPC' | 'CLT')} className="mt-1 w-full bg-gray-900/50 border-gray-700 rounded-md p-2 text-gray-200">
              <option value="CPC">CPC (dias úteis)</option>
              <option value="CLT">CLT (dias corridos)</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300">Contexto Adicional</label>
            <textarea value={context} onChange={e => setContext(e.target.value)} rows={3} className="mt-1 w-full bg-gray-900/50 border-gray-700 rounded-md p-2 text-gray-200" placeholder="Ex: Feriado municipal em 15/08, suspensão de prazos entre 20/12 e 20/01..."></textarea>
          </div>
          <div className="flex items-center justify-between">
              <label htmlFor="deep-reasoning" className="flex items-center text-sm text-gray-300">
                  <input
                      type="checkbox"
                      id="deep-reasoning"
                      checked={useDeepReasoning}
                      onChange={(e) => setUseDeepReasoning(e.target.checked)}
                      className="h-4 w-4 rounded border-gray-600 bg-gray-700 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2">Ativar Modo de Raciocínio Profundo (Usa Gemini 2.5 Pro)</span>
              </label>
          </div>
          <button onClick={calculateDeadline} disabled={isLoading} className="w-full bg-blue-600 text-white font-semibold py-3 px-4 rounded-lg hover:bg-blue-700 transition disabled:bg-gray-600 flex justify-center">
            {isLoading ? <LoadingSpinner /> : 'Calcular Prazo'}
          </button>
          {error && <p className="text-red-400 text-center">{error}</p>}
        </div>

        <div className="bg-gray-800/50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-blue-300 mb-4">Resultado do Cálculo</h3>
          {result && !isLoading && (
            <div className="space-y-4">
              <div className="text-center bg-blue-900/50 border border-blue-700 p-4 rounded-lg">
                <p className="text-sm text-blue-300">Data Final do Prazo</p>
                <p className="text-4xl font-bold text-white">{result.data_final_prazo}</p>
                <p className="text-sm text-gray-400 mt-1">{result.dias_uteis} dias úteis / {result.dias_corridos} dias corridos</p>
              </div>
              <div>
                <button 
                  onClick={() => setIsReasoningExpanded(!isReasoningExpanded)}
                  className="w-full flex justify-between items-center text-left font-semibold text-gray-300 py-2 hover:bg-gray-900/20 rounded-md px-2"
                  aria-expanded={isReasoningExpanded}
                >
                  <span>Raciocínio Passo a Passo:</span>
                  <ChevronDownIcon className={`h-5 w-5 transition-transform duration-300 ${isReasoningExpanded ? 'rotate-180' : ''}`} />
                </button>
                <div 
                  className={`transition-all duration-500 ease-in-out overflow-hidden ${isReasoningExpanded ? 'max-h-[500px] opacity-100' : 'max-h-0 opacity-0'}`}
                >
                  <div className="mt-2 p-4 bg-gray-900/50 rounded text-sm text-gray-400 whitespace-pre-wrap overflow-y-auto max-h-[450px]">
                    {result.raciocinio_passo_a_passo}
                  </div>
                </div>
              </div>
            </div>
          )}
          {isLoading && <div className="flex justify-center items-center h-full"><LoadingSpinner size="12" /></div>}
          {!result && !isLoading && <div className="flex justify-center items-center h-full text-gray-500">O resultado aparecerá aqui.</div>}
        </div>
      </div>
    </div>
  );
};

export default DeadlineCalculator;
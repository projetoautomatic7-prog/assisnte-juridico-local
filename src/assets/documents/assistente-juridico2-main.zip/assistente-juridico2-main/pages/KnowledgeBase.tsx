import React, { useState, useEffect } from 'react';

import { BookOpenIcon, PaperAirplaneIcon } from '../components/icons/Icons';
import LoadingSpinner from '../components/LoadingSpinner';
import PageTitle from '../components/PageTitle';
import { useKnowledgeBaseStore } from '../stores/knowledgeBaseStore';

const KnowledgeBase: React.FC = () => {
    const [indexText, setIndexText] = useState('');
    const [searchQuery, setSearchQuery] = useState('');
    
    // Supondo que o contexto do processo ainda seja definido externamente,
    // mas a lógica de busca e indexação está no store.
    const [processContext, setProcessContext] = useState<string | null>(null);

    const {
        isIndexing, indexSuccess, indexError, isSearching, searchResult, searchError,
        indexText: indexTextAction, searchText: searchTextAction, resetSearch
    } = useKnowledgeBaseStore();

    useEffect(() => {
        resetSearch();
    }, [processContext, resetSearch]);

    const handleIndexSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!indexText.trim()) return;
        await indexTextAction(indexText);
        setIndexText('');
    };

    const handleSearchSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!searchQuery.trim()) return;
        await searchTextAction(searchQuery, processContext);
    };

    return (
        <div>
            <PageTitle
                title="Base de Conhecimento do Agente"
                description="Alimente a memória do seu agente com documentos e converse com ele para obter respostas baseadas no seu acervo."
            />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-gray-800/50 p-6 rounded-lg border border-gray-700">
                    <h3 className="text-xl font-semibold text-blue-300 mb-4">1. Indexar Novo Conhecimento</h3>
                    <form onSubmit={handleIndexSubmit}>
                        <textarea value={indexText} onChange={(e) => setIndexText(e.target.value)} rows={10} className="w-full bg-gray-900/50 border border-gray-700 rounded-md p-3 text-gray-200" placeholder="Cole o texto de uma petição, artigo, etc..." />
                        <button type="submit" disabled={isIndexing} className="mt-4 w-full bg-blue-600 text-white font-semibold py-3 px-4 rounded-lg hover:bg-blue-700 disabled:bg-gray-600 flex justify-center items-center">
                            {isIndexing ? <LoadingSpinner /> : 'Indexar Texto'}
                        </button>
                        {indexSuccess && <p className="text-green-400 text-sm mt-2">{indexSuccess}</p>}
                        {indexError && <p className="text-red-400 text-sm mt-2">{indexError}</p>}
                    </form>
                </div>
                <div className="bg-gray-800/50 rounded-lg flex flex-col h-[60vh] border border-gray-700">
                    <h3 className="text-xl font-semibold text-blue-300 p-4 border-b border-gray-700">2. Conversar com a Base de Conhecimento</h3>
                    <div className="flex-1 overflow-y-auto p-4 space-y-4">
                        {!isSearching && !searchResult && !searchError && (
                            <div className="flex flex-col items-center justify-center h-full text-center text-gray-500">
                                <BookOpenIcon className="h-16 w-16 mb-4" />
                                <p>As respostas baseadas nos seus documentos aparecerão aqui.</p>
                            </div>
                        )}
                        {isSearching && <div className="flex justify-center items-center h-full"><LoadingSpinner size="10" /></div>}
                        {searchError && <p className="text-red-400">{searchError}</p>}
                        {searchResult && (
                            <div className="bg-gray-900/50 p-4 rounded-lg">
                                <p className="text-gray-200 whitespace-pre-wrap">{searchResult.answer}</p>
                                {searchResult.sources?.length > 0 && (
                                     <div className="mt-4 pt-2 border-t border-gray-700"><p className="text-xs text-gray-500">Fontes:</p></div>
                                )}
                            </div>
                        )}
                    </div>
                    <form onSubmit={handleSearchSubmit} className="p-4 border-t border-gray-700">
                        <div className="flex items-center bg-gray-900/50 rounded-lg">
                            <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Faça uma pergunta sobre seus documentos..." className="flex-1 bg-transparent p-3 text-gray-200 focus:outline-none" disabled={isSearching} />
                            <button type="submit" className="p-3 text-blue-400 hover:text-blue-300 disabled:text-gray-500" disabled={isSearching || !searchQuery.trim()}><PaperAirplaneIcon className="h-6 w-6" /></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default KnowledgeBase;
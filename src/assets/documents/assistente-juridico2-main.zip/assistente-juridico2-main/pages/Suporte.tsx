import React, { useState } from 'react';

import { QuestionMarkCircleIcon, ChevronDownIcon } from '../components/icons/Icons';
import LoadingSpinner from '../components/LoadingSpinner';
import PageTitle from '../components/PageTitle';

const faqItems = [
    { q: 'Como conecto o Robô PJe pela primeira vez?', a: 'Na página "Robô PJe", insira seu login e senha do PJe e clique em "Conectar". Se seu acesso exigir autenticação de dois fatores (2FA), um campo aparecerá para você inserir o código do seu aplicativo autenticador.' },
    { q: 'Os dados dos meus processos ficam armazenados?', a: 'O sistema processa as informações sob demanda e retém o mínimo de dados possível para garantir a funcionalidade. As informações sensíveis, como suas credenciais, são gerenciadas de forma segura e nunca são expostas.' },
    { q: 'Como funciona a "Premonição Jurídica"?', a: 'Esta ferramenta utiliza o modelo Gemini Pro para analisar o contexto do seu processo, buscar em uma base de dados jurídica e comparar com jurisprudências e casos similares, fornecendo uma estimativa de probabilidade de êxito e sugerindo estratégias.' },
    { q: 'Posso usar o sistema em múltiplos computadores?', a: 'Sim, por ser uma aplicação web, você pode acessá-la de qualquer dispositivo com um navegador moderno. Suas configurações e dados são associados à sua conta.' },
];

const FaqItem: React.FC<{ item: { q: string, a: string } }> = ({ item }) => {
    const [isOpen, setIsOpen] = useState(false);
    return (
        <div className="border-b border-gray-700/50">
            <button onClick={() => setIsOpen(!isOpen)} className="w-full flex justify-between items-center text-left py-4 px-2">
                <span className="font-semibold text-gray-200">{item.q}</span>
                <ChevronDownIcon className={`h-5 w-5 text-gray-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
            </button>
            <div className={`overflow-hidden transition-all duration-300 ease-in-out ${isOpen ? 'max-h-96' : 'max-h-0'}`}>
                <div className="pb-4 px-2 text-gray-400 text-sm">
                    {item.a}
                </div>
            </div>
        </div>
    );
}

const Suporte: React.FC = () => {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isSent, setIsSent] = useState(false);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);
        setTimeout(() => {
            setIsSubmitting(false);
            setIsSent(true);
        }, 1500); // Simulate network request
    }

  return (
    <div>
      <PageTitle
        title="Suporte e Ajuda"
        description="Encontre respostas para suas perguntas e entre em contato com nossa equipe."
      />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-gray-800/50 rounded-lg p-6">
            <h3 className="text-xl font-semibold text-gray-100 mb-4">Perguntas Frequentes</h3>
            <div className="space-y-2">
                {faqItems.map((item, index) => <FaqItem key={index} item={item} />)}
            </div>
        </div>

         <div className="bg-gray-800/50 rounded-lg p-6 h-fit">
            <h3 className="text-xl font-semibold text-gray-100 mb-4">Entrar em Contato</h3>
            {isSent ? (
                <div className="text-center p-8 bg-green-900/50 rounded-lg">
                    <p className="text-green-300 font-semibold">Sua mensagem foi enviada!</p>
                    <p className="text-sm text-gray-400 mt-2">Nossa equipe responderá em breve.</p>
                </div>
            ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label htmlFor="name" className="block text-sm font-medium text-gray-300">Seu Nome</label>
                        <input type="text" id="name" required className="mt-1 w-full bg-gray-900/50 border-gray-700 rounded-md p-2 text-gray-200" />
                    </div>
                     <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-300">Seu Email</label>
                        <input type="email" id="email" required className="mt-1 w-full bg-gray-900/50 border-gray-700 rounded-md p-2 text-gray-200" />
                    </div>
                     <div>
                        <label htmlFor="subject" className="block text-sm font-medium text-gray-300">Assunto</label>
                        <input type="text" id="subject" required className="mt-1 w-full bg-gray-900/50 border-gray-700 rounded-md p-2 text-gray-200" />
                    </div>
                     <div>
                        <label htmlFor="message" className="block text-sm font-medium text-gray-300">Mensagem</label>
                        <textarea id="message" rows={5} required className="mt-1 w-full bg-gray-900/50 border-gray-700 rounded-md p-2 text-gray-200"></textarea>
                    </div>
                    <button type="submit" disabled={isSubmitting} className="w-full bg-blue-600 text-white font-semibold py-3 px-4 rounded-lg hover:bg-blue-700 transition disabled:bg-gray-600 flex justify-center items-center">
                        {isSubmitting ? <LoadingSpinner /> : 'Enviar Mensagem'}
                    </button>
                </form>
            )}
        </div>
      </div>
    </div>
  );
};

export default Suporte;

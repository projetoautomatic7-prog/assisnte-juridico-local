import React, { useState, useEffect } from 'react';

import LineChartBI from '../components/charts/LineChartBI';
import { CheckCircleIcon, ClockIcon, StarIcon, ExclamationTriangleIcon, CalendarDaysIcon, ChevronRightIcon } from '../components/icons/Icons';
import LoadingSpinner from '../components/LoadingSpinner';
import PageTitle from '../components/PageTitle';
import StatCard from '../components/StatCard';
import { BACKEND_URL } from '../services/api';
import { Compromisso, Audiencia } from '../types';

const CompromissoItem: React.FC<{ item: Compromisso }> = ({ item }) => (
    <tr className="border-b border-gray-700/50 hover:bg-gray-800">
        <td className="px-4 py-3">
            <div className="flex items-center gap-3">
                <input type="checkbox" aria-label="Marcar compromisso como concluído" className="h-4 w-4 rounded bg-gray-700 border-gray-600 text-blue-500 focus:ring-blue-600" />
                <button aria-label="Marcar como favorito">
                    <StarIcon className="h-5 w-5 text-gray-600 hover:text-yellow-400 cursor-pointer" />
                </button>
                {item.isUrgent && <ExclamationTriangleIcon className="h-5 w-5 text-red-500"><title>Prazo fatal</title></ExclamationTriangleIcon>}
            </div>
        </td>
        <td className="px-4 py-3">
            <p className="font-medium text-gray-200">{item.title}</p>
        </td>
        <td className="px-4 py-3 text-gray-400">{item.assignedTo}</td>
        <td className="px-4 py-3 text-gray-400">{item.relativeDate}</td>
    </tr>
);

// Mock data for the line chart
const lineChartData = [
    { label: 'Jan', value1: 20, value2: 15 },
    { label: 'Fev', value1: 30, value2: 25 },
    { label: 'Mar', value1: 45, value2: 35 },
    { label: 'Abr', value1: 40, value2: 50 },
    { label: 'Mai', value1: 60, value2: 55 },
    { label: 'Jun', value1: 70, value2: 65 },
];

const ProximasAudiencias: React.FC<{ audiencias: Audiencia[] }> = ({ audiencias }) => (
    <div className="bg-gray-800/50 rounded-lg p-6 flex flex-col h-full">
        <h3 className="text-lg font-semibold text-gray-200 mb-4">Próximas Audiências</h3>
        {audiencias.length > 0 ? (
            <div className="space-y-3 overflow-y-auto">
                {audiencias.map(aud => {
                    const dataHora = new Date(aud.data_hora);
                    const dia = dataHora.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
                    const hora = dataHora.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
                    const diaParts = dia.split('/');
                    return (
                        <div key={aud.id} className="bg-gray-900/50 p-3 rounded-lg flex items-center gap-4">
                            <div className="text-center">
                                <p className="font-bold text-lg text-blue-300">{diaParts[0]}</p>
                                <p className="text-xs text-gray-400">{diaParts[1]}</p>
                            </div>
                            <div className="flex-grow">
                                <p className="font-semibold text-gray-200 text-sm">{aud.tipo}</p>
                                <p className="text-xs text-gray-400">{aud.processo_cnj}</p>
                            </div>
                            <div className="text-sm font-semibold text-gray-300">{hora}</div>
                        </div>
                    );
                })}
            </div>
        ) : (
            <div className="flex-grow flex items-center justify-center bg-gray-900/30 rounded-lg">
                <div className="text-center text-gray-500">
                    <CalendarDaysIcon className="h-10 w-10 mx-auto mb-2" />
                    <p className="text-sm">Nenhuma audiência agendada.</p>
                </div>
            </div>
        )}
        <button className="text-xs text-blue-400 hover:underline mt-4 text-center w-full">
            Ver todas as audiências
        </button>
    </div>
);


const DashboardHome: React.FC = () => {
    const [compromissos, setCompromissos] = useState<Compromisso[]>([]);
    const [audiencias, setAudiencias] = useState<Audiencia[]>([]);
    const [stats, setStats] = useState({ tarefasFinalizadas: 0, tarefasPendentes: 0, pontosAcumulados: 0 });
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            setError('');
            try {
                const token = localStorage.getItem('jwt');
                const response = await fetch(`${BACKEND_URL}/api/data/dashboard-home`, {
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                if (!response.ok) throw new Error('Falha ao buscar dados do painel.');
                const data = await response.json();
                setCompromissos(data.compromissos || []);
                setAudiencias(data.audiencias || []);
                setStats(data.stats || { tarefasFinalizadas: 0, tarefasPendentes: 0, pontosAcumulados: 0 });
            } catch (err) {
                setError((err as Error).message);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, []);

    const urgentTasks = compromissos.filter(c => c.isUrgent);
    const otherTasks = compromissos.filter(c => !c.isUrgent);

    return (
        <div>
            <PageTitle title="Meu Painel" description="Visão geral da sua produtividade e compromissos." />
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                <StatCard icon={CheckCircleIcon} title="Tarefas Finalizadas" value={stats.tarefasFinalizadas} />
                <StatCard icon={ClockIcon} title="Tarefas Pendentes" value={stats.tarefasPendentes} />
                <StatCard icon={StarIcon} title="Pontos Acumulados" value={stats.pontosAcumulados} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
                <div className="lg:col-span-2 bg-gray-800/50 rounded-lg p-6">
                    <h3 className="text-lg font-semibold text-gray-200 mb-4">Meu Desempenho</h3>
                    <div className="h-64">
                       <LineChartBI data={lineChartData} />
                    </div>
                </div>
                <ProximasAudiencias audiencias={audiencias} />
            </div>

            <div className="bg-gray-800/50 rounded-lg">
                <div className="p-4 border-b border-gray-700/50">
                     <h3 className="text-lg font-semibold text-gray-200">Compromissos</h3>
                </div>
                 {isLoading ? <div className="flex justify-center p-8"><LoadingSpinner /></div> : error ? <div className="p-4 text-center text-red-400">{error}</div> : (
                <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                        <tbody>
                            {urgentTasks.length > 0 && (
                                <tr className="bg-red-900/20"><td colSpan={4} className="px-4 py-2 text-xs font-semibold text-red-400">Prazo Fatal</td></tr>
                            )}
                            {urgentTasks.map(item => <CompromissoItem key={item.id} item={item} />)}
                            
                            {otherTasks.length > 0 && (
                                <tr className="bg-gray-900/20"><td colSpan={4} className="px-4 py-2 text-xs font-semibold text-gray-400">Não Lidas</td></tr>
                            )}
                            {otherTasks.map(item => <CompromissoItem key={item.id} item={item} />)}
                        </tbody>
                    </table>
                </div>
                )}
            </div>
        </div>
    );
};

export default DashboardHome;
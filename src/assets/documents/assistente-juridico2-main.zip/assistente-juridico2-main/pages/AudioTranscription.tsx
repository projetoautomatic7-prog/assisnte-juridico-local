import React, { useState, useRef, useEffect } from 'react';

import { MicrophoneIcon, StopCircleIcon, ArrowUpTrayIcon } from '../components/icons/Icons';
import LoadingSpinner from '../components/LoadingSpinner';
import PageTitle from '../components/PageTitle';
import { BACKEND_URL, AUDIO_WEBSOCKET_URL, authenticatedFetch, fileToBase64 } from '../services/api';

// Helper types (previously from @google/genai)
type GeminiBlob = { data: string; mimeType: string; };

// Funções auxiliares para codificação/decodificação de áudio
function encode(bytes: Uint8Array): string {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
}

const AudioTranscription: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'live' | 'file'>('live');

  // State for live recording
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [transcription, setTranscription] = useState<string>('');
  const [finalTranscription, setFinalTranscription] = useState<string>('');
  const [summary, setSummary] = useState<string>('');
  const [isLoadingSummary, setIsLoadingSummary] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // State for file upload
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [fileTranscription, setFileTranscription] = useState<string>('');
  const [isFileLoading, setIsFileLoading] = useState<boolean>(false);
  const [fileError, setFileError] = useState<string | null>(null);

  const wsRef = useRef<WebSocket | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const mediaStreamSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
        setAudioFile(e.target.files[0]);
        setFileTranscription('');
        setFileError(null);
    }
  };
  
  const handleFileTranscription = async () => {
    if (!audioFile) {
        setFileError('Por favor, selecione um arquivo de áudio.');
        return;
    }
    setIsFileLoading(true);
    setFileError(null);
    setFileTranscription('');

    try {
        const fileData = await fileToBase64(audioFile);
        const response = await authenticatedFetch(`${BACKEND_URL}/api/ai/transcribe`, {
            method: 'POST',
            body: JSON.stringify({ file: fileData }),
        });

        if (!response.ok) {
            const err = await response.json();
            throw new Error(err.message || 'Falha ao transcrever o arquivo.');
        }

        const result = await response.json();
        setFileTranscription(result.transcription);
    } catch (err) {
        console.error(err);
        setFileError('Ocorreu um erro ao transcrever o arquivo. Tente novamente.');
    } finally {
        setIsFileLoading(false);
    }
  };

  const stopRecording = () => {
    setIsRecording(false);

    wsRef.current?.close();
    wsRef.current = null;
    
    streamRef.current?.getTracks().forEach(track => track.stop());
    streamRef.current = null;
    
    scriptProcessorRef.current?.disconnect();
    scriptProcessorRef.current = null;

    mediaStreamSourceRef.current?.disconnect();
    mediaStreamSourceRef.current = null;

    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close().catch(console.error);
    }
    audioContextRef.current = null;

    setFinalTranscription(prev => (prev + transcription).trim());
    setTranscription('');
  };

  const startRecording = async () => {
    setIsRecording(true);
    setTranscription('');
    setFinalTranscription('');
    setSummary('');
    setError(null);
    try {
      streamRef.current = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioContextRef.current = new ((window as any).AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      
      wsRef.current = new WebSocket(AUDIO_WEBSOCKET_URL);

      wsRef.current.onopen = () => {
        console.log('Conectado ao proxy de áudio do backend.');
        if (!audioContextRef.current || !streamRef.current) return;
        
        mediaStreamSourceRef.current = audioContextRef.current.createMediaStreamSource(streamRef.current);
        scriptProcessorRef.current = audioContextRef.current.createScriptProcessor(4096, 1, 1);

        scriptProcessorRef.current.onaudioprocess = (audioProcessingEvent) => {
            const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
            const l = inputData.length;
            const int16 = new Int16Array(l);
            for (let i = 0; i < l; i++) {
                int16[i] = inputData[i] * 32768;
            }
            const pcmBlob: GeminiBlob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
            };

            if (wsRef.current?.readyState === WebSocket.OPEN) {
                wsRef.current.send(JSON.stringify({ type: 'audio_chunk', payload: pcmBlob }));
            }
        };

        mediaStreamSourceRef.current.connect(scriptProcessorRef.current);
        scriptProcessorRef.current.connect(audioContextRef.current.destination);
      };

      wsRef.current.onmessage = (event) => {
        const { type, payload } = JSON.parse(event.data);
        if (type === 'gemini_message') {
            const message = payload; // This is the LiveServerMessage
            if (message.serverContent?.inputTranscription) {
                const text = message.serverContent.inputTranscription.text;
                setTranscription(prev => prev + text);
            }
            if(message.serverContent?.turnComplete) {
                setFinalTranscription(prev => prev + transcription + ' ');
                setTranscription('');
            }
        } else if (type === 'gemini_error' || type === 'error') {
            console.error('Erro no proxy de áudio:', payload.message);
            setError(`Erro na transcrição: ${payload.message}`);
            stopRecording();
        }
      };

      wsRef.current.onerror = (e) => {
        console.error('WebSocket de áudio error:', e);
        setError('Ocorreu um erro na conexão. Tente novamente.');
        stopRecording();
      };

      wsRef.current.onclose = () => {
        console.log('Conexão de áudio fechada.');
      };
      
    } catch (err) {
      console.error(err);
      setError('Não foi possível iniciar a gravação. Verifique as permissões do microfone.');
      setIsRecording(false);
    }
  };

  const generateSummary = async () => {
    if (!finalTranscription) return;
    setIsLoadingSummary(true);
    setSummary('');
    setError(null);
    try {
        const prompt = `Com base na seguinte transcrição de áudio, gere um sumário acionável, identificando prazos, tarefas e responsáveis. Formate a resposta de forma clara e organizada. Transcrição: "${finalTranscription}"`;
        const response = await authenticatedFetch(`${BACKEND_URL}/api/ai/text`, {
            method: 'POST',
            body: JSON.stringify({ prompt }),
        });

        if (!response.ok) {
            const err = await response.json();
            throw new Error(err.message || 'Falha ao gerar sumário');
        }
        
        const result = await response.json();
        setSummary(result.text);

    } catch (err) {
        console.error(err);
        setError('Não foi possível gerar o sumário.');
    } finally {
        setIsLoadingSummary(false);
    }
  };

  useEffect(() => {
    // This effect runs only once on mount and returns a cleanup function
    // that runs on unmount, ensuring all resources are released unconditionally.
    return () => {
        if (wsRef.current) {
            wsRef.current.close();
        }
        if (streamRef.current) {
            streamRef.current.getTracks().forEach(track => track.stop());
        }
        if (scriptProcessorRef.current) {
            scriptProcessorRef.current.disconnect();
        }
        if (mediaStreamSourceRef.current) {
            mediaStreamSourceRef.current.disconnect();
        }
        if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
            audioContextRef.current.close().catch(console.error);
        }
    };
  }, []); // Empty dependency array ensures this runs only on mount/unmount.

  const renderLiveTab = () => (
    <>
      <div className="flex justify-center mb-8">
        {!isRecording ? (
          <button onClick={startRecording} className="flex items-center gap-3 bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-6 rounded-full transition-transform transform hover:scale-105">
            <MicrophoneIcon className="h-6 w-6" />
            Iniciar Gravação
          </button>
        ) : (
          <button onClick={stopRecording} className="flex items-center gap-3 bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-full transition-transform transform hover:scale-105">
            <StopCircleIcon className="h-6 w-6" />
            Parar Gravação
          </button>
        )}
      </div>
      
      {error && <p className="text-red-400 text-center my-4">{error}</p>}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-gray-800/50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-blue-300 mb-4">Transcrição</h3>
          <div className="min-h-[200px] bg-gray-900/50 p-4 rounded text-gray-300 whitespace-pre-wrap">
            {finalTranscription}
            <span className="text-gray-500">{transcription}</span>
            {!isRecording && !finalTranscription && <span className="text-gray-500">A transcrição aparecerá aqui...</span>}
          </div>
        </div>
        <div className="bg-gray-800/50 rounded-lg p-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold text-blue-300">Sumário Acionável</h3>
            <button
              onClick={generateSummary}
              disabled={isRecording || !finalTranscription || isLoadingSummary}
              className="bg-blue-600 text-white text-sm font-semibold py-2 px-4 rounded-lg hover:bg-blue-700 transition disabled:bg-gray-600"
            >
              Gerar Sumário
            </button>
          </div>
          <div className="min-h-[200px] bg-gray-900/50 p-4 rounded text-gray-300 whitespace-pre-wrap">
            {isLoadingSummary && <LoadingSpinner />}
            {summary ? summary : <span className="text-gray-500">O sumário gerado pela IA aparecerá aqui...</span>}
          </div>
        </div>
      </div>
    </>
  );
  
  const renderFileTab = () => (
    <div className="max-w-3xl mx-auto">
        <div className="bg-gray-800/50 rounded-lg p-6 space-y-4">
            <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">1. Anexe o arquivo de áudio</label>
                <input
                  type="file"
                  id="audioUpload"
                  accept="audio/*"
                  onChange={handleFileChange}
                  className="hidden"
                />
                <label htmlFor="audioUpload" className="w-full h-32 bg-gray-900/50 border-2 border-dashed border-gray-600 rounded-lg flex flex-col justify-center items-center cursor-pointer hover:border-blue-500 transition">
                  {audioFile ? (
                     <div className="text-center">
                        <MicrophoneIcon className="h-8 w-8 text-green-400 mx-auto mb-2" />
                        <span className="text-green-300 font-semibold">{audioFile.name}</span>
                        <span className="text-xs text-gray-400 block">Clique para trocar</span>
                     </div>
                  ) : (
                    <>
                      <ArrowUpTrayIcon className="h-8 w-8 text-gray-500 mb-2" />
                      <span className="text-gray-400 text-center text-sm">Clique para carregar o arquivo<br/>(MP3, WAV, M4A, etc.)</span>
                    </>
                  )}
                </label>
            </div>
            <button
                onClick={handleFileTranscription}
                disabled={isFileLoading || !audioFile}
                className="w-full bg-blue-600 text-white font-semibold py-3 px-4 rounded-lg hover:bg-blue-700 transition disabled:bg-gray-600 disabled:cursor-not-allowed flex justify-center items-center"
            >
                {isFileLoading ? <LoadingSpinner /> : 'Transcrever Arquivo'}
            </button>
            {fileError && <p className="text-red-400 text-sm">{fileError}</p>}
        </div>
        
        <div className="mt-6">
            <h3 className="text-lg font-semibold text-gray-300 mb-2">Resultado da Transcrição</h3>
            <div className="min-h-[200px] bg-gray-800/50 p-4 rounded text-gray-300 whitespace-pre-wrap border border-gray-700">
                {isFileLoading ? <div className="flex justify-center p-8"><LoadingSpinner /></div> : fileTranscription || <span className="text-gray-500">A transcrição do arquivo aparecerá aqui...</span>}
            </div>
        </div>
    </div>
  );

  return (
    <div>
      <PageTitle
        title="Transcrição de Áudio"
        description="Grave áudios ao vivo ou anexe um arquivo para obter a transcrição e gerar um sumário acionável."
      />
      <div className="mb-6 border-b border-gray-700">
            <nav className="-mb-px flex space-x-6" aria-label="Tabs">
                 <button
                    onClick={() => setActiveTab('live')}
                    className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${
                        activeTab === 'live'
                        ? 'border-blue-500 text-blue-400'
                        : 'border-transparent text-gray-400 hover:text-gray-200 hover:border-gray-500'
                    }`}
                >
                    Gravação ao Vivo
                </button>
                 <button
                    onClick={() => setActiveTab('file')}
                    className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${
                        activeTab === 'file'
                        ? 'border-blue-500 text-blue-400'
                        : 'border-transparent text-gray-400 hover:text-gray-200 hover:border-gray-500'
                    }`}
                >
                    Anexar Arquivo
                </button>
            </nav>
        </div>

        {activeTab === 'live' && renderLiveTab()}
        {activeTab === 'file' && renderFileTab()}

    </div>
  );
};

export default AudioTranscription;
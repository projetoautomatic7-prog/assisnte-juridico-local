import React, { useState, useMemo, useEffect } from 'react';

import EventModal from '../components/EventModal';
import { ChevronLeftIcon, ChevronRightIcon, PlusIcon } from '../components/icons/Icons';
import PageTitle from '../components/PageTitle';
import { BACKEND_URL, authenticatedFetch } from '../services/api';
import { AgendaEvent, Audiencia } from '../types';

const colorMap: { [key in AgendaEvent['color']]: { bg: string, text: string } } = {
  blue: { bg: 'bg-blue-500/20', text: 'text-blue-300' },
  green: { bg: 'bg-green-500/20', text: 'text-green-300' },
  red: { bg: 'bg-red-500/20', text: 'text-red-300' },
  yellow: { bg: 'bg-yellow-500/20', text: 'text-yellow-300' },
  purple: { bg: 'bg-purple-500/20', text: 'text-purple-300' },
};

const Agenda: React.FC = () => {
    const [currentDate, setCurrentDate] = useState(new Date());
    const [events, setEvents] = useState<AgendaEvent[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState('');
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedEvent, setSelectedEvent] = useState<AgendaEvent | null>(null);
    const [selectedDate, setSelectedDate] = useState<string | null>(null);

     useEffect(() => {
        const fetchEvents = async () => {
            setIsLoading(true);
            setError('');
            try {
                const response = await authenticatedFetch(`${BACKEND_URL}/api/robot/audiencias`);
                 if (!response.ok) {
                    throw new Error('Falha ao buscar os dados da agenda.');
                }
                const audiencias: Audiencia[] = await response.json();
                
                const agendaEvents: AgendaEvent[] = audiencias.map(aud => {
                    const dataHora = new Date(aud.data_hora);
                    return {
                        id: aud.id,
                        title: aud.tipo,
                        date: dataHora.toISOString().split('T')[0],
                        startTime: dataHora.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', timeZone: 'UTC' }),
                        description: `Processo: ${aud.processo_cnj}\nLocal: ${aud.local}`,
                        color: 'red', 
                    };
                });
                setEvents(agendaEvents);
            } catch (err) {
                setError((err as Error).message);
            } finally {
                setIsLoading(false);
            }
        };
        fetchEvents();
    }, []);

    const handlePrevMonth = () => {
        setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
    };

    const handleNextMonth = () => {
        setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
    };
    
    const handleToday = () => {
        setCurrentDate(new Date());
    }

    const handleOpenModalForNew = (date: Date) => {
        setSelectedEvent(null);
        setSelectedDate(date.toISOString().split('T')[0]);
        setIsModalOpen(true);
    };

    const handleOpenModalForEdit = (event: AgendaEvent) => {
        setSelectedEvent(event);
        setSelectedDate(null);
        setIsModalOpen(true);
    };
    
    const handleCloseModal = () => {
        setIsModalOpen(false);
        setSelectedEvent(null);
        setSelectedDate(null);
    };
    
    // TODO: Integrar com backend para persistir as alterações.
    const handleSaveEvent = (eventData: Omit<AgendaEvent, 'id'> & { id?: string }) => {
        if (eventData.id) { // Update existing
            setEvents(events.map(e => e.id === eventData.id ? { ...e, ...eventData } as AgendaEvent : e));
        } else { // Create new
            setEvents([...events, { ...eventData, id: new Date().toISOString() }]);
        }
        handleCloseModal();
    };
    
    // TODO: Integrar com backend para persistir a exclusão.
    const handleDeleteEvent = (eventId: string) => {
        setEvents(events.filter(e => e.id !== eventId));
        handleCloseModal();
    };

    const calendarGrid = useMemo(() => {
        const startOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
        const endOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
        const startDayOfWeek = startOfMonth.getDay();
        const daysInMonth = endOfMonth.getDate();

        const days = [];
        for (let i = 0; i < startDayOfWeek; i++) {
            const date = new Date(startOfMonth);
            date.setDate(date.getDate() - (startDayOfWeek - i));
            days.push({ date, isCurrentMonth: false, events: [] });
        }
        for (let i = 1; i <= daysInMonth; i++) {
            const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), i);
            const dateString = date.toISOString().split('T')[0];
            const dayEvents = events.filter(e => e.date === dateString).sort((a,b) => (a.startTime || '').localeCompare(b.startTime || ''));
            days.push({ date, isCurrentMonth: true, events: dayEvents });
        }
        const gridCells = 42; // 6 weeks * 7 days
        const remainingDays = gridCells - days.length;
        for (let i = 1; i <= remainingDays; i++) {
            const date = new Date(endOfMonth);
            date.setDate(date.getDate() + i);
            days.push({ date, isCurrentMonth: false, events: [] });
        }
        return days;
    }, [currentDate, events]);

    return (
        <div className="flex flex-col h-full">
            <PageTitle title="Agenda" description="Gerencie seus compromissos, prazos e audiências." />

            <div className="bg-gray-800/50 rounded-lg border border-gray-700/50 flex flex-col flex-grow">
                {/* Header */}
                <div className="flex items-center justify-between p-4 border-b border-gray-700/50">
                    <div className="flex items-center gap-4">
                        <button onClick={handlePrevMonth} className="p-2 rounded-md hover:bg-gray-700"><ChevronLeftIcon className="h-6 w-6" /></button>
                        <h2 className="text-xl font-semibold text-white w-48 text-center">
                            {currentDate.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}
                        </h2>
                        <button onClick={handleNextMonth} className="p-2 rounded-md hover:bg-gray-700"><ChevronRightIcon className="h-6 w-6" /></button>
                         <button onClick={handleToday} className="text-sm font-semibold text-gray-300 border border-gray-600 px-3 py-1.5 rounded-md hover:bg-gray-700">Hoje</button>
                    </div>
                    <button onClick={() => handleOpenModalForNew(new Date())} className="bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-blue-700 transition flex items-center gap-2">
                        <PlusIcon className="h-5 w-5" />
                        <span className="hidden sm:inline">Novo Compromisso</span>
                    </button>
                </div>

                {/* Calendar */}
                <div className="flex-grow grid grid-cols-7">
                    {/* Day Headers */}
                    {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map(day => (
                        <div key={day} className="text-center text-xs font-bold text-gray-400 py-2 border-b border-r border-gray-700/50">
                            {day}
                        </div>
                    ))}

                    {/* Day Cells */}
                    {calendarGrid.map(({ date, isCurrentMonth, events }, index) => (
                        <div 
                            key={index} 
                            className={`relative p-2 border-b border-r border-gray-700/50 flex flex-col group ${!isCurrentMonth ? 'bg-gray-900/40' : 'hover:bg-gray-900/30'}`}
                            onClick={() => handleOpenModalForNew(date)}
                        >
                            <span className={`text-sm font-semibold ${isCurrentMonth ? 'text-gray-200' : 'text-gray-600'}`}>
                                {date.getDate()}
                            </span>
                            <div className="mt-1 space-y-1 overflow-y-auto flex-grow">
                                {events.map(event => (
                                    <div 
                                        key={event.id}
                                        onClick={(e) => { e.stopPropagation(); handleOpenModalForEdit(event); }}
                                        className={`p-1 rounded-md cursor-pointer ${colorMap[event.color].bg} hover:ring-2 hover:ring-offset-2 hover:ring-offset-gray-800 ring-gray-400`}
                                    >
                                        <p className={`text-xs font-semibold truncate ${colorMap[event.color].text}`}>
                                            {event.startTime && `${event.startTime} `}{event.title}
                                        </p>
                                    </div>
                                ))}
                            </div>
                             <button onClick={() => handleOpenModalForNew(date)} className="absolute top-1 right-1 h-6 w-6 rounded-full bg-gray-700/50 text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center hover:bg-blue-600 hover:text-white">
                                <PlusIcon className="h-4 w-4" />
                            </button>
                        </div>
                    ))}
                </div>
            </div>

            <EventModal 
                isOpen={isModalOpen}
                onClose={handleCloseModal}
                onSave={handleSaveEvent}
                onDelete={handleDeleteEvent}
                event={selectedEvent}
                date={selectedDate}
            />
        </div>
    );
};

export default Agenda;
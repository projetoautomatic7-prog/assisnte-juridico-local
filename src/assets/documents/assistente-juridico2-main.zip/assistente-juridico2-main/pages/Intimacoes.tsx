import React, { useState, useEffect } from 'react';

import { StarIcon, MagnifyingGlassIcon, ExclamationTriangleIcon } from '../components/icons/Icons';
import IntimacaoTooltip from '../components/IntimacaoTooltip';
import LoadingSpinner from '../components/LoadingSpinner';
import PageTitle from '../components/PageTitle';
import { BACKEND_URL, authenticatedFetch } from '../services/api';
import { Intimacao, Expediente } from '../types';

const Intimacoes: React.FC = () => {
    const [intimacoes, setIntimacoes] = useState<Intimacao[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState('');
    const [hoveredIntimacaoId, setHoveredIntimacaoId] = useState<string | null>(null);

    useEffect(() => {
        const fetchIntimacoes = async () => {
            setIsLoading(true);
            setError('');
            try {
                const response = await authenticatedFetch(`${BACKEND_URL}/api/robot/expedientes`);
                if (!response.ok) {
                    throw new Error('Falha ao buscar intimações.');
                }
                const data: Expediente[] = await response.json();

                // Map Expediente[] to Intimacao[]
                const mappedIntimacoes: Intimacao[] = data.map(exp => ({
                    id: exp.id,
                    title: exp.ultimo_movimento || exp.tipo,
                    isUrgent: !!(exp.prazo_dias && exp.prazo_dias !== 'N/A'),
                    isNew: exp.status !== 'completed' && exp.status !== 'no_action_needed',
                    processo: {
                        numero: exp.processo_cnj,
                        partes: exp.partes,
                        grupoAcao: exp.processo_classe,
                        tipoAcao: exp.tipo,
                        responsavel: exp.destinatario,
                    },
                    relativeDate: new Date(exp.data_publicacao).toLocaleDateString('pt-BR'),
                    status: exp.status === 'completed' || exp.status === 'no_action_needed' ? 'verificado' : 'analisar',
                    responsavel: { name: exp.destinatario },
                }));

                setIntimacoes(mappedIntimacoes);
            } catch (err) {
                setError((err as Error).message);
            } finally {
                setIsLoading(false);
            }
        };
        fetchIntimacoes();
    }, []);
    
    const hoveredIntimacao = intimacoes.find(i => i.id === hoveredIntimacaoId);

    return (
        <div>
            <PageTitle
                title="Intimações"
                description="Caixa de entrada central para todas as comunicações e intimações judiciais."
            />
            
            <div className="bg-gray-800/50 rounded-lg">
                 <div className="p-4 border-b border-gray-700/50">
                    <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                           <MagnifyingGlassIcon className="h-5 w-5 text-gray-400" />
                        </div>
                        <input
                            type="text"
                            className="bg-gray-900/50 border border-gray-700 text-gray-200 text-sm rounded-lg block w-full pl-10 p-2.5"
                            placeholder="Buscar por nome, cpf, cnj, e-mail, tag ou pasta..."
                        />
                    </div>
                </div>
                 <div className="overflow-x-auto">
                    {isLoading ? (
                        <div className="flex justify-center p-8"><LoadingSpinner /></div>
                    ) : error ? (
                        <p className="text-red-400 text-center p-8">{error}</p>
                    ) : (
                    <table className="w-full text-sm text-left">
                        <thead className="text-xs text-gray-400 uppercase bg-gray-900/50 sr-only">
                            <tr>
                                <th>Ações</th>
                                <th>Título</th>
                                <th>Responsável</th>
                                <th>Data</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody className="text-gray-300">
                             {intimacoes.map(intimacao => (
                                <tr 
                                    key={intimacao.id} 
                                    className="border-b border-gray-700/50 hover:bg-gray-800 relative"
                                    onMouseEnter={() => setHoveredIntimacaoId(intimacao.id)}
                                    onMouseLeave={() => setHoveredIntimacaoId(null)}
                                >
                                    <td className="px-4 py-3 w-20">
                                        <div className="flex items-center gap-3">
                                            <input type="checkbox" aria-label="Selecionar intimação" className="h-4 w-4 rounded bg-gray-700 border-gray-600 text-blue-500 focus:ring-blue-600" />
                                            <button aria-label="Marcar como favorito">
                                                <StarIcon className={`h-5 w-5 cursor-pointer ${intimacao.isNew ? 'text-yellow-400' : 'text-gray-600 hover:text-yellow-400'}`} />
                                            </button>
                                            {intimacao.isUrgent && <ExclamationTriangleIcon className="h-5 w-5 text-red-500"><title>Urgente</title></ExclamationTriangleIcon>}
                                        </div>
                                    </td>
                                    <td className="px-4 py-3 font-semibold text-gray-200">{intimacao.title}</td>
                                    <td className="px-4 py-3">{intimacao.responsavel.name}</td>
                                    <td className="px-4 py-3 text-gray-400">{intimacao.relativeDate}</td>
                                    <td className="px-4 py-3">
                                        <button className={`text-xs font-bold py-1 px-3 rounded-full ${intimacao.status === 'verificado' ? 'bg-green-500/20 text-green-300' : 'bg-blue-500/20 text-blue-300 hover:bg-blue-500/40'}`}>
                                            {intimacao.status === 'verificado' ? 'Verificado' : 'Analisar'}
                                        </button>
                                    </td>
                                     {hoveredIntimacaoId === intimacao.id && (
                                        <td className="absolute top-full left-1/4 transform -translate-x-1/4 mt-1 z-10">
                                          <IntimacaoTooltip intimacao={intimacao} />
                                        </td>
                                    )}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Intimacoes;
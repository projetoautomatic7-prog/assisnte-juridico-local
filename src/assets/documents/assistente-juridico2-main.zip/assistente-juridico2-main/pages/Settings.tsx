import React, { useState, useEffect } from 'react';

import { UserPlusIcon, EllipsisVerticalIcon, XMarkIcon } from '../components/icons/Icons';
import LoadingSpinner from '../components/LoadingSpinner';
import PageTitle from '../components/PageTitle';
import { BACKEND_URL, authenticatedFetch } from '../services/api';
import { User } from '../types';

const InviteUserModal: React.FC<{ 
  isOpen: boolean; 
  onClose: () => void;
  onInviteSent: () => void;
}> = ({ isOpen, onClose, onInviteSent }) => {
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<'Advogado' | 'Estagiário'>('Advogado');
  const [isSending, setIsSending] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSendInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSending(true);
    setError('');
    
    try {
        const response = await authenticatedFetch(`${BACKEND_URL}/api/settings/users/invite`, {
            method: 'POST',
            body: JSON.stringify({ email, role }),
        });
        if (!response.ok) {
            const err = await response.json();
            throw new Error(err.message || 'Falha ao enviar convite.');
        }
        onInviteSent();
        onClose();
    } catch (err) {
        setError((err as Error).message);
    } finally {
        setIsSending(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50" onClick={onClose}>
      <div className="bg-gray-800 rounded-lg shadow-xl w-full max-w-md p-6" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-gray-100">Convidar Novo Usuário</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-200"><XMarkIcon className="h-6 w-6" /></button>
        </div>
        <form onSubmit={handleSendInvite} className="space-y-4">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-300">Email do Convidado</label>
            <input type="email" id="email" value={email} onChange={e => setEmail(e.target.value)} className="mt-1 w-full bg-gray-900/50 border-gray-700 rounded-md p-2 text-gray-200" required />
          </div>
          <div>
            <label htmlFor="role" className="block text-sm font-medium text-gray-300">Cargo</label>
            <select id="role" value={role} onChange={e => setRole(e.target.value as any)} className="mt-1 w-full bg-gray-900/50 border-gray-700 rounded-md p-2 text-gray-200">
              <option>Advogado</option>
              <option>Estagiário</option>
            </select>
          </div>
          {error && <p className="text-red-400 text-sm">{error}</p>}
          <div className="flex justify-end gap-4 pt-4">
            <button type="button" onClick={onClose} className="bg-gray-600 hover:bg-gray-700 text-white font-semibold py-2 px-4 rounded-lg">Cancelar</button>
            <button type="submit" disabled={isSending} className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg flex items-center justify-center w-32">
              {isSending ? <LoadingSpinner size="5"/> : 'Enviar Convite'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

const Settings: React.FC = () => {
    const [activeTab, setActiveTab] = useState<'team' | 'account' | 'integrations'>('team');
    const [users, setUsers] = useState<User[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState('');
    const [isModalOpen, setIsModalOpen] = useState(false);

    // State for "My Account"
    const [accountName, setAccountName] = useState('Dr. Thiago Bodevan');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [accountStatus, setAccountStatus] = useState({ message: '', type: '' });
    const [isSavingAccount, setIsSavingAccount] = useState(false);

    // State for "Integrations"
    const [integrations, setIntegrations] = useState({
        googleDrive: true,
        googleCalendar: true,
        whatsapp: false,
        slack: false,
    });

    const fetchUsers = async () => {
        setIsLoading(true);
        setError('');
        try {
            const response = await authenticatedFetch(`${BACKEND_URL}/api/settings/users`);
            if (!response.ok) {
                const err = await response.json();
                throw new Error(err.message || 'Falha ao buscar usuários.');
            }
            const data = await response.json();
            setUsers(data);
        } catch (err) {
            setError((err as Error).message);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        if (activeTab === 'team') {
            fetchUsers();
        }
    }, [activeTab]);
    
    const handleAccountSave = async (e: React.FormEvent) => {
        e.preventDefault();
        setAccountStatus({ message: '', type: '' });

        if (newPassword && newPassword !== confirmPassword) {
            setAccountStatus({ message: 'As senhas não coincidem.', type: 'error' });
            return;
        }

        setIsSavingAccount(true);
        try {
            const payload: { name: string, newPassword?: string } = { name: accountName };
            if (newPassword) {
                payload.newPassword = newPassword;
            }

            const response = await authenticatedFetch(`${BACKEND_URL}/api/settings/users/account`, {
                method: 'PATCH',
                body: JSON.stringify(payload),
            });

            const data = await response.json();
            if (!response.ok) throw new Error(data.message || 'Falha ao salvar alterações.');
            
            setAccountStatus({ message: data.message, type: 'success' });
            setNewPassword('');
            setConfirmPassword('');

        } catch (err) {
            setAccountStatus({ message: (err as Error).message, type: 'error' });
        } finally {
            setIsSavingAccount(false);
        }
    };

    const handleIntegrationToggle = (integration: keyof typeof integrations) => {
        setIntegrations(prev => ({ ...prev, [integration]: !prev[integration] }));
        // Em um app real, aqui você faria uma chamada de API para conectar/desconectar
    };

    const renderTeamMembers = () => (
        <div className="bg-gray-800/50 rounded-lg p-6">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold text-gray-100">Membros da Equipe</h3>
                <button onClick={() => setIsModalOpen(true)} className="bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-blue-700 transition flex items-center gap-2">
                    <UserPlusIcon className="h-5 w-5" />
                    Convidar Novo Usuário
                </button>
            </div>
            {isLoading ? <div className="flex justify-center p-8"><LoadingSpinner /></div> : error ? <p className="text-red-400">{error}</p> : (
            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left text-gray-300">
                    <thead className="text-xs text-gray-400 uppercase bg-gray-900/50">
                        <tr>
                            <th className="px-6 py-3">Nome</th>
                            <th className="px-6 py-3">Cargo</th>
                            <th className="px-6 py-3">Status</th>
                            <th className="px-6 py-3">Último Login</th>
                            <th className="px-6 py-3"><span className="sr-only">Ações</span></th>
                        </tr>
                    </thead>
                    <tbody>
                        {users.map(user => (
                            <tr key={user.id} className="border-b border-gray-700 hover:bg-gray-800">
                                <td className="px-6 py-4">
                                    <div className="font-semibold text-gray-100">{user.name}</div>
                                    <div className="text-xs text-gray-400">{user.email}</div>
                                </td>
                                <td className="px-6 py-4">{user.role}</td>
                                <td className="px-6 py-4">
                                    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                                        user.status === 'Ativo' ? 'bg-green-600/30 text-green-300' : 'bg-yellow-600/30 text-yellow-300'
                                    }`}>
                                        {user.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4">{user.lastLogin === 'Nunca' ? 'Nunca' : new Date(user.lastLogin).toLocaleDateString('pt-BR')}</td>
                                <td className="px-6 py-4 text-right">
                                    <button className="p-1 text-gray-400 hover:text-white rounded-full hover:bg-gray-700">
                                        <EllipsisVerticalIcon className="h-5 w-5" />
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            )}
        </div>
    );

    const renderMyAccount = () => (
        <div className="bg-gray-800/50 rounded-lg p-6 max-w-2xl mx-auto">
            <h3 className="text-xl font-semibold text-gray-100 mb-6">Minha Conta</h3>
            <form className="space-y-6" onSubmit={handleAccountSave}>
                <div>
                    <label className="block text-sm font-medium text-gray-300">Nome</label>
                    <input type="text" value={accountName} onChange={e => setAccountName(e.target.value)} className="mt-1 w-full bg-gray-900/50 border-gray-700 rounded-md p-2 text-gray-200" />
                </div>
                 <div>
                    <label className="block text-sm font-medium text-gray-300">Email</label>
                    <input type="email" value="thiago@bodevan.com" disabled className="mt-1 w-full bg-gray-900/80 border-gray-700 rounded-md p-2 text-gray-400 cursor-not-allowed" />
                </div>
                <div className="border-t border-gray-700 pt-6">
                     <h4 className="text-lg font-semibold text-gray-200 mb-4">Alterar Senha</h4>
                     <div>
                        <label className="block text-sm font-medium text-gray-300">Nova Senha</label>
                        <input type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} placeholder="••••••••" className="mt-1 w-full bg-gray-900/50 border-gray-700 rounded-md p-2 text-gray-200" />
                    </div>
                     <div className="mt-4">
                        <label className="block text-sm font-medium text-gray-300">Confirmar Nova Senha</label>
                        <input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} placeholder="••••••••" className="mt-1 w-full bg-gray-900/50 border-gray-700 rounded-md p-2 text-gray-200" />
                    </div>
                </div>
                 {accountStatus.message && (
                    <div className={`text-sm text-center p-2 rounded-md ${accountStatus.type === 'error' ? 'bg-red-900/50 text-red-300' : 'bg-green-900/50 text-green-300'}`}>
                        {accountStatus.message}
                    </div>
                 )}
                <div className="flex justify-end pt-4">
                    <button type="submit" disabled={isSavingAccount} className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg flex justify-center items-center w-36 disabled:bg-gray-600">
                        {isSavingAccount ? <LoadingSpinner size="5"/> : 'Salvar Alterações'}
                    </button>
                </div>
            </form>
        </div>
    );

    const renderIntegrations = () => (
        <div className="bg-gray-800/50 rounded-lg p-6">
            <h3 className="text-xl font-semibold text-gray-100 mb-6">Integrações</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-gray-900/50 p-4 rounded-lg flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/d/da/Google_Drive_logo.png" alt="Google Drive" className="h-8 w-8"/>
                        <div>
                            <p className="font-semibold text-gray-200">Google Drive</p>
                            <p className="text-xs text-gray-400">Pastas de processos e documentos.</p>
                        </div>
                    </div>
                    <button onClick={() => handleIntegrationToggle('googleDrive')} className={`${integrations.googleDrive ? 'bg-green-600' : 'bg-gray-700 hover:bg-gray-600'} text-white text-xs font-bold py-1 px-3 rounded-full transition`}>
                        {integrations.googleDrive ? 'Conectado' : 'Conectar'}
                    </button>
                </div>
                 <div className="bg-gray-900/50 p-4 rounded-lg flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/a/a5/Google_Calendar_icon_%282020%29.svg" alt="Google Calendar" className="h-8 w-8"/>
                        <div>
                            <p className="font-semibold text-gray-200">Google Calendar</p>
                            <p className="text-xs text-gray-400">Sincronização de audiências e prazos.</p>
                        </div>
                    </div>
                     <button onClick={() => handleIntegrationToggle('googleCalendar')} className={`${integrations.googleCalendar ? 'bg-green-600' : 'bg-gray-700 hover:bg-gray-600'} text-white text-xs font-bold py-1 px-3 rounded-full transition`}>
                        {integrations.googleCalendar ? 'Conectado' : 'Conectar'}
                    </button>
                </div>
                 <div className="bg-gray-900/50 p-4 rounded-lg flex items-center justify-between">
                    <div className="flex items-center gap-4">
                         <img src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" alt="WhatsApp" className="h-8 w-8"/>
                        <div>
                            <p className="font-semibold text-gray-200">WhatsApp</p>
                            <p className="text-xs text-gray-400">Envio de notificações e cobranças.</p>
                        </div>
                    </div>
                    <button onClick={() => handleIntegrationToggle('whatsapp')} className={`${integrations.whatsapp ? 'bg-green-600' : 'bg-gray-700 hover:bg-gray-600'} text-white text-xs font-bold py-1 px-3 rounded-full transition`}>
                        {integrations.whatsapp ? 'Conectado' : 'Conectar'}
                    </button>
                </div>
                 <div className="bg-gray-900/50 p-4 rounded-lg flex items-center justify-between">
                    <div className="flex items-center gap-4">
                         <img src="https://upload.wikimedia.org/wikipedia/commons/d/d5/Slack_icon_2019.svg" alt="Slack" className="h-8 w-8"/>
                        <div>
                            <p className="font-semibold text-gray-200">Slack</p>
                            <p className="text-xs text-gray-400">Notificações de eventos importantes.</p>
                        </div>
                    </div>
                     <button onClick={() => handleIntegrationToggle('slack')} className={`${integrations.slack ? 'bg-green-600' : 'bg-gray-700 hover:bg-gray-600'} text-white text-xs font-bold py-1 px-3 rounded-full transition`}>
                        {integrations.slack ? 'Conectado' : 'Conectar'}
                    </button>
                </div>
            </div>
        </div>
    );

    return (
        <div>
            <PageTitle
                title="Configurações"
                description="Gerencie os membros da sua equipe, configurações da conta e integrações."
            />

            <div className="mb-6 border-b border-gray-700">
                <nav className="-mb-px flex space-x-6">
                    <button onClick={() => setActiveTab('team')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'team' ? 'border-blue-500 text-blue-400' : 'border-transparent text-gray-400 hover:text-gray-200'}`}>Membros da Equipe</button>
                    <button onClick={() => setActiveTab('account')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'account' ? 'border-blue-500 text-blue-400' : 'border-transparent text-gray-400 hover:text-gray-200'}`}>Minha Conta</button>
                    <button onClick={() => setActiveTab('integrations')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'integrations' ? 'border-blue-500 text-blue-400' : 'border-transparent text-gray-400 hover:text-gray-200'}`}>Integrações</button>
                </nav>
            </div>
            
            {activeTab === 'team' && renderTeamMembers()}
            {activeTab === 'account' && renderMyAccount()}
            {activeTab === 'integrations' && renderIntegrations()}

            <InviteUserModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onInviteSent={fetchUsers} />
        </div>
    );
};

export default Settings;
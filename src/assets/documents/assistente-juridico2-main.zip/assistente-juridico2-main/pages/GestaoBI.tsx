import React, { useState, useEffect } from 'react';

import BarChart from '../components/charts/BarChart';
import DonutChart from '../components/charts/DonutChart';
import LineChartBI from '../components/charts/LineChartBI';
import LoadingSpinner from '../components/LoadingSpinner';
import PageTitle from '../components/PageTitle';
import { BACKEND_URL, authenticatedFetch } from '../services/api';
import { BiReport } from '../types';

interface BiData {
    reports: BiReport[];
    charts: {
        bar: any[];
        line: any[];
        donut: number;
    }
}

const GestaoBI: React.FC = () => {
    const [data, setData] = useState<BiData | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            setError('');
            try {
                const response = await authenticatedFetch(`${BACKEND_URL}/api/data/gestao-bi`);
                if (!response.ok) throw new Error('Falha ao buscar dados de B.I.');
                const fetchedData: BiData = await response.json();
                setData(fetchedData);
            } catch (err) {
                setError((err as Error).message);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, []);

    const renderContent = () => {
        if (isLoading) {
            return <div className="flex justify-center items-center h-96"><LoadingSpinner size="12" /></div>;
        }
        if (error) {
            return <div className="text-center text-red-400 p-8 bg-gray-800/50 rounded-lg">{error}</div>;
        }
        if (!data) {
            return <div className="text-center text-gray-500 p-8 bg-gray-800/50 rounded-lg">Nenhum dado encontrado.</div>;
        }
        
        return (
            <>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                    <div className="lg:col-span-1 bg-gray-800/50 p-6 rounded-lg">
                        <h3 className="text-lg font-semibold text-gray-200 mb-4">Oportunidades e Fechamentos</h3>
                        <div className="h-48">
                            <BarChart data={data.charts.bar} />
                        </div>
                    </div>
                    <div className="lg:col-span-1 bg-gray-800/50 p-6 rounded-lg">
                        <h3 className="text-lg font-semibold text-gray-200 mb-4">Performance por Período</h3>
                        <div className="h-48">
                            <LineChartBI data={data.charts.line} />
                        </div>
                    </div>
                    <div className="lg:col-span-1 bg-gray-800/50 p-6 rounded-lg flex flex-col items-center justify-center">
                        <h3 className="text-lg font-semibold text-gray-200 mb-4">Taxa de Conversão</h3>
                        <DonutChart percentage={data.charts.donut} color="#3b82f6" size={120} strokeWidth={12} label="TOTAL" />
                    </div>
                </div>
                
                <div className="bg-gray-800/50 rounded-lg">
                    <div className="p-4 border-b border-gray-700/50 flex flex-wrap justify-between items-center gap-4">
                        <h3 className="text-lg font-semibold text-gray-200">Relatórios</h3>
                        <div className="flex items-center gap-2">
                            <select className="bg-gray-700/50 border border-gray-600 text-gray-200 text-sm rounded-md p-2">
                                <option>Oportunidades</option>
                                <option>Fechamentos</option>
                            </select>
                            <input type="date" className="bg-gray-700/50 border border-gray-600 text-gray-200 text-sm rounded-md p-2"/>
                            <span className="text-gray-400">até</span>
                            <input type="date" className="bg-gray-700/50 border border-gray-600 text-gray-200 text-sm rounded-md p-2"/>
                            <button className="text-gray-300 hover:text-white font-semibold">MAIS FILTROS</button>
                        </div>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left">
                            <thead className="text-xs text-gray-400 uppercase bg-gray-900/50">
                                <tr>
                                    <th className="px-6 py-3">Partes</th>
                                    <th className="px-6 py-3">Tipo de Ação</th>
                                    <th className="px-6 py-3">Grupo de Ação</th>
                                    <th className="px-6 py-3">Fase</th>
                                    <th className="px-6 py-3">Situação</th>
                                    <th className="px-6 py-3">Cadastro</th>
                                </tr>
                            </thead>
                            <tbody className="text-gray-300">
                                {data.reports.map(report => (
                                    <tr key={report.id} className="border-b border-gray-700/50 hover:bg-gray-800">
                                        <td className="px-6 py-4 font-semibold">{report.parte}</td>
                                        <td className="px-6 py-4">{report.tipoAcao}</td>
                                        <td className="px-6 py-4">{report.grupoAcao}</td>
                                        <td className="px-6 py-4">{report.fase}</td>
                                        <td className="px-6 py-4">{report.situacao}</td>
                                        <td className="px-6 py-4">{report.cadastro}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </>
        );
    };

  return (
    <div>
      <PageTitle title="Gestão B.I." description="Análise de performance e resultados do escritório." />
      {renderContent()}
    </div>
  );
};

export default GestaoBI;
import React, { useState, useEffect } from 'react';

import { FolderIcon, MagnifyingGlassIcon, PlusIcon } from '../components/icons/Icons';
import LoadingSpinner from '../components/LoadingSpinner';
import PageTitle from '../components/PageTitle';
import { BACKEND_URL } from '../services/api';
import { Modelo } from '../types';

const Modelos: React.FC = () => {
  const [modelos, setModelos] = useState<Modelo[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchData = async () => {
        setIsLoading(true);
        setError('');
        try {
            const token = localStorage.getItem('jwt');
            const response = await fetch(`${BACKEND_URL}/api/data/modelos`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (!response.ok) throw new Error('Falha ao buscar modelos.');
            const data = await response.json();
            setModelos(data);
        } catch (err) {
            setError((err as Error).message);
        } finally {
            setIsLoading(false);
        }
    };
    fetchData();
  }, []);


  return (
    <div>
      <PageTitle
        title="Modelos de Documentos"
        description="Gerencie e utilize seus modelos de petições, contratos e outros documentos."
      />
      <div className="bg-gray-800/50 rounded-lg">
        <div className="p-4 border-b border-gray-700/50 flex flex-col sm:flex-row gap-4 justify-between items-center">
            <div className="relative w-full sm:w-auto">
                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                   <MagnifyingGlassIcon className="h-5 w-5 text-gray-400" />
                </div>
                <input
                    type="text"
                    className="bg-gray-900/50 border border-gray-700 text-gray-200 text-sm rounded-lg block w-full pl-10 p-2.5"
                    placeholder="Buscar por nome ou tipo..."
                />
            </div>
            <button className="bg-blue-600 text-white font-semibold py-2.5 px-4 rounded-lg hover:bg-blue-700 transition flex items-center gap-2 w-full sm:w-auto justify-center">
                <PlusIcon className="h-5 w-5" />
                Novo Modelo
            </button>
        </div>
         <div className="overflow-x-auto">
            {isLoading ? <div className="flex justify-center p-8"><LoadingSpinner /></div> : error ? <div className="p-4 text-center text-red-400">{error}</div> : (
            <table className="w-full text-sm text-left">
                <thead className="text-xs text-gray-400 uppercase bg-gray-900/50">
                    <tr>
                        <th className="px-6 py-3">Nome do Modelo</th>
                        <th className="px-6 py-3">Tipo</th>
                        <th className="px-6 py-3">Data de Criação</th>
                        <th className="px-6 py-3">Última Edição</th>
                    </tr>
                </thead>
                <tbody className="text-gray-300">
                    {modelos.map(modelo => (
                        <tr key={modelo.id} className="border-b border-gray-700/50 hover:bg-gray-800 cursor-pointer">
                            <td className="px-6 py-4 font-semibold text-white">{modelo.nome}</td>
                            <td className="px-6 py-4">
                                <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                                    modelo.tipo === 'Petição' ? 'bg-indigo-600/30 text-indigo-300' :
                                    modelo.tipo === 'Contrato' ? 'bg-green-600/30 text-green-300' :
                                    'bg-gray-600/30 text-gray-300'
                                }`}>
                                    {modelo.tipo}
                                </span>
                            </td>
                            <td className="px-6 py-4">{new Date(modelo.dataCriacao).toLocaleDateString('pt-BR')}</td>
                            <td className="px-6 py-4">{new Date(modelo.ultimaEdicao).toLocaleDateString('pt-BR')}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
            )}
        </div>
      </div>
    </div>
  );
};

export default Modelos;
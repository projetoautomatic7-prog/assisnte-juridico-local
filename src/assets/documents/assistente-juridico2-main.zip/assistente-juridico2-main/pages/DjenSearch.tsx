import React, { useState } from 'react';

import { NewspaperIcon, MagnifyingGlassIcon } from '../components/icons/Icons';
import LoadingSpinner from '../components/LoadingSpinner';
import PageTitle from '../components/PageTitle';
import { useDjenStore } from '../stores/djenStore';

const TRIBUNAIS = ['TST', 'TRT3', 'TJMG', 'TRF1', 'TJES', 'TJSP', 'STJ'];

const DjenSearch: React.FC = () => {
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [advogado, setAdvogado] = useState('');
    const [oab, setOab] = useState('');
    const [selectedTribunais, setSelectedTribunais] = useState<string[]>(TRIBUNAIS);
    
    const { results, isLoading, error, searchDjen } = useDjenStore();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        searchDjen({ date, tribunals: selectedTribunais, name: advogado, oab });
    };

    const handleTribunalChange = (tribunal: string) => {
        setSelectedTribunais(prev => 
            prev.includes(tribunal) 
                ? prev.filter(t => t !== tribunal)
                : [...prev, tribunal]
        );
    };

    const handleSelectAll = () => {
        setSelectedTribunais(prev => prev.length === TRIBUNAIS.length ? [] : TRIBUNAIS);
    };

    return (
        <div>
            <PageTitle
                title="Consulta ao Diário de Justiça Eletrônico (DJEN)"
                description="Pesquise publicações por nome de advogado ou OAB nos principais diários de justiça do país."
            />
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <form onSubmit={handleSubmit} className="lg:col-span-1 bg-gray-800/50 p-6 rounded-lg space-y-6 h-fit">
                    {/* ... form fields ... */}
                     <div>
                        <label htmlFor="date" className="block text-sm font-medium text-gray-300">Data da Publicação</label>
                        <input type="date" id="date" value={date} onChange={e => setDate(e.target.value)} className="mt-1 w-full bg-gray-900/50 border-gray-700 rounded-md p-2 text-gray-200" required />
                    </div>
                    <div>
                        <label htmlFor="advogado" className="block text-sm font-medium text-gray-300">Nome do Advogado</label>
                        <input type="text" id="advogado" value={advogado} onChange={e => setAdvogado(e.target.value)} className="mt-1 w-full bg-gray-900/50 border-gray-700 rounded-md p-2 text-gray-200" placeholder="Ex: Thiago Bodevan" />
                    </div>
                     <div>
                        <label htmlFor="oab" className="block text-sm font-medium text-gray-300">Número da OAB</label>
                        <input type="text" id="oab" value={oab} onChange={e => setOab(e.target.value)} className="mt-1 w-full bg-gray-900/50 border-gray-700 rounded-md p-2 text-gray-200" placeholder="Ex: OAB/MG 123456" />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">Tribunais</label>
                        <div className="space-y-2">
                             <div className="flex items-center">
                                <input id="select-all" type="checkbox" checked={selectedTribunais.length === TRIBUNAIS.length} onChange={handleSelectAll} className="h-4 w-4 rounded border-gray-600 bg-gray-700 text-blue-600 focus:ring-blue-500"/>
                                <label htmlFor="select-all" className="ml-2 text-sm text-gray-200 font-semibold">Selecionar Todos</label>
                            </div>
                            <div className="grid grid-cols-2 gap-2 border-t border-gray-700 pt-2">
                                {TRIBUNAIS.map(tribunal => (
                                    <div key={tribunal} className="flex items-center">
                                        <input id={tribunal} type="checkbox" checked={selectedTribunais.includes(tribunal)} onChange={() => handleTribunalChange(tribunal)} className="h-4 w-4 rounded border-gray-600 bg-gray-700 text-blue-600 focus:ring-blue-500"/>
                                        <label htmlFor={tribunal} className="ml-2 text-sm text-gray-300">{tribunal}</label>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                    {error && <p className="text-red-400 text-sm">{error}</p>}
                    <button type="submit" disabled={isLoading} className="w-full bg-blue-600 text-white font-semibold py-3 px-4 rounded-lg hover:bg-blue-700 transition disabled:bg-gray-600 flex justify-center items-center gap-2">
                        {isLoading ? <LoadingSpinner size="5" /> : <MagnifyingGlassIcon className="h-5 w-5"/>}
                        Buscar Publicações
                    </button>
                </form>

                <div className="lg:col-span-2 bg-gray-800/50 p-6 rounded-lg">
                    <h3 className="text-xl font-semibold text-gray-100 mb-4">Resultados da Busca ({results.length})</h3>
                    <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-2">
                        {isLoading && <div className="flex justify-center p-10"><LoadingSpinner size="12"/></div>}
                        {!isLoading && results.length === 0 && (
                            <div className="text-center text-gray-500 p-10">
                                <NewspaperIcon className="h-12 w-12 mx-auto mb-4" />
                                <p>Nenhuma publicação encontrada.</p>
                            </div>
                        )}
                        {results.map((pub, index) => (
                            <div key={index} className="bg-gray-900/50 p-4 rounded-md border-l-4 border-blue-500">
                                <div className="flex justify-between items-center text-xs text-gray-400 mb-2">
                                    <span className="font-bold bg-gray-700 px-2 py-1 rounded">{pub.tribunal}</span>
                                    <span>{new Date(pub.dataPublicacao + 'T00:00:00').toLocaleDateString('pt-BR')}</span>
                                </div>
                                <p className="text-sm text-gray-300 whitespace-pre-wrap">{pub.conteudo}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default DjenSearch;
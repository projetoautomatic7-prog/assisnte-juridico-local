import React, { useState } from 'react';

import { ArrowUpTrayIcon, VideoCameraIcon } from '../components/icons/Icons';
import LoadingSpinner from '../components/LoadingSpinner';
import PageTitle from '../components/PageTitle';
import { BACKEND_URL, authenticatedFetch, fileToBase64 } from '../services/api';

interface VideoAnalysisResult {
    resumo_juridico: string;
    momentos_chave: {
        timestamp: string;
        descricao: string;
    }[];
    proximos_passos: string[];
}

const VideoAnalysis: React.FC = () => {
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [analysis, setAnalysis] = useState<VideoAnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState<string>('');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
        setVideoFile(e.target.files[0]);
        setAnalysis(null);
        setError(null);
    }
  };

  const analyzeVideo = async () => {
    if (!videoFile) {
      setError('Por favor, selecione um arquivo de vídeo.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setAnalysis(null);

    try {
        // Step 1: Transcribe audio from video
        setCurrentStep('Transcrevendo áudio do vídeo...');
        const fileData = await fileToBase64(videoFile);
        const transcribeResponse = await authenticatedFetch(`${BACKEND_URL}/api/ai/transcribe`, {
            method: 'POST',
            body: JSON.stringify({ file: fileData }),
        });
        if (!transcribeResponse.ok) {
            const err = await transcribeResponse.json();
            throw new Error(err.message || 'Falha ao transcrever o áudio do vídeo.');
        }
        const { transcription } = await transcribeResponse.json();
        
        if (!transcription || !transcription.trim()) {
            throw new Error('A transcrição retornou vazia. O vídeo pode não conter áudio.');
        }

        // Step 2: Analyze the transcript
        setCurrentStep('Analisando transcrição com IA...');
        const prompt = `Você é um analista jurídico sênior. Analise a seguinte transcrição de uma audiência em vídeo. Seu trabalho é:
        1. Gerar um briefing jurídico conciso dos eventos.
        2. Identificar os momentos-chave (depoimento de testemunha, decisão interlocutória, proposta de acordo, etc.), criando uma descrição e um "timestamp" aproximado (ex: "Início", "Meio", "Fim", ou parágrafo/linha se possível).
        3. Sugerir os próximos passos processuais com base no que foi discutido.
        Responda em formato JSON.

        Transcrição:
        ---
        ${transcription}
        ---`;
        
        const schema = {
            type: 'OBJECT',
            properties: {
                resumo_juridico: { type: 'STRING' },
                momentos_chave: {
                    type: 'ARRAY',
                    items: {
                        type: 'OBJECT',
                        properties: {
                            timestamp: { type: 'STRING' },
                            descricao: { type: 'STRING' }
                        }
                    }
                },
                proximos_passos: { type: 'ARRAY', items: { type: 'STRING' } }
            }
        };

        const analysisResponse = await authenticatedFetch(`${BACKEND_URL}/api/ai/text`, {
            method: 'POST',
            body: JSON.stringify({ prompt, schema, model: 'gemini-2.5-pro' }),
        });

        if (!analysisResponse.ok) {
            const err = await analysisResponse.json();
            throw new Error(err.message || 'Erro do servidor ao analisar a transcrição.');
        }

        const result = await analysisResponse.json();
        const data = JSON.parse(result.text);
        setAnalysis(data);

    } catch (err) {
      console.error(err);
      setError('Ocorreu um erro ao analisar o vídeo. Tente novamente.');
    } finally {
      setIsLoading(false);
      setCurrentStep('');
    }
  };

  return (
    <div>
      <PageTitle
        title="Análise de Vídeo de Audiência"
        description="Anexe uma gravação de audiência para extrair a transcrição, detectar momentos-chave e obter um briefing jurídico."
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <div className="bg-gray-800/50 rounded-lg p-6">
            <label className="block text-sm font-medium text-gray-300 mb-2">
              1. Anexe o arquivo de vídeo
            </label>
            <input
                type="file"
                id="videoUpload"
                accept="video/*"
                onChange={handleFileChange}
                className="hidden"
            />
            <label htmlFor="videoUpload" className="w-full h-40 bg-gray-900/50 border-2 border-dashed border-gray-600 rounded-lg flex flex-col justify-center items-center cursor-pointer hover:border-blue-500 transition">
                {videoFile ? (
                    <div className="text-center">
                        <VideoCameraIcon className="h-10 w-10 text-green-400 mx-auto mb-2" />
                        <span className="text-green-300 font-semibold">{videoFile.name}</span>
                        <span className="text-xs text-gray-400 block">Clique para trocar o arquivo</span>
                    </div>
                ) : (
                    <>
                        <ArrowUpTrayIcon className="h-10 w-10 text-gray-500 mb-2" />
                        <span className="text-gray-400 text-center text-sm">Clique para carregar o vídeo<br/>(MP4, MOV, WEBM, etc.)</span>
                    </>
                )}
            </label>
            <button
              onClick={analyzeVideo}
              disabled={isLoading || !videoFile}
              className="mt-4 w-full bg-blue-600 text-white font-semibold py-3 px-4 rounded-lg hover:bg-blue-700 transition disabled:bg-gray-600 disabled:cursor-not-allowed flex justify-center items-center"
            >
              {isLoading ? <LoadingSpinner /> : 'Analisar Vídeo'}
            </button>
            {isLoading && <p className="text-center text-blue-300 text-sm mt-2 animate-pulse">{currentStep}</p>}
            {error && <p className="text-red-400 mt-4 text-sm">{error}</p>}
          </div>
        </div>

        <div>
            <h3 className="text-lg font-semibold mb-2 text-gray-300">Resultados da Análise</h3>
            <div className="space-y-4 bg-gray-800/50 rounded-lg p-6 min-h-[400px]">
                {isLoading && <div className="flex justify-center p-10"><LoadingSpinner size="12" /></div>}
                {analysis ? (
                    <>
                        <div>
                            <h4 className="font-bold text-blue-300">Briefing Jurídico</h4>
                            <p className="text-sm text-gray-300 mt-1">{analysis.resumo_juridico}</p>
                        </div>
                        <div>
                            <h4 className="font-bold text-blue-300 mt-4">Momentos-Chave</h4>
                            <ul className="space-y-2 mt-2">
                                {analysis.momentos_chave.map((mom, i) => (
                                    <li key={i} className="flex text-sm">
                                        <span className="font-semibold text-gray-400 w-24 flex-shrink-0">{mom.timestamp}</span>
                                        <span className="text-gray-300">{mom.descricao}</span>
                                    </li>
                                ))}
                            </ul>
                        </div>
                        <div>
                            <h4 className="font-bold text-blue-300 mt-4">Próximos Passos Sugeridos</h4>
                            <ul className="space-y-1.5 mt-2 list-disc list-inside">
                                {analysis.proximos_passos.map((passo, i) => (
                                    <li key={i} className="text-sm text-gray-300">{passo}</li>
                                ))}
                            </ul>
                        </div>
                    </>
                ) : !isLoading && (
                    <div className="text-center text-gray-500 pt-16">
                        A análise do vídeo aparecerá aqui.
                    </div>
                )}
            </div>
        </div>
      </div>
    </div>
  );
};

export default VideoAnalysis;
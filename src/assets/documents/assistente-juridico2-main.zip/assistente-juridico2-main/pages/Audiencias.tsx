import React, { useState, useEffect } from 'react';

import { CalendarDaysIcon, CheckCircleIcon, InformationCircleIcon, XCircleIcon, ArrowTopRightOnSquareIcon, BellIcon } from '../components/icons/Icons';
import LoadingSpinner from '../components/LoadingSpinner';
import PageTitle from '../components/PageTitle';
import { useAudienciasStore } from '../stores/audienciasStore';
import { Audiencia } from '../types';

const AudienciaCard: React.FC<{ audiencia: Audiencia }> = ({ audiencia }) => {
    const dataHora = new Date(audiencia.data_hora);
    const dia = dataHora.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', timeZone: 'UTC' });
    const diaSemana = dataHora.toLocaleDateString('pt-BR', { weekday: 'long', timeZone: 'UTC' });
    const hora = dataHora.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', timeZone: 'UTC' });

    const getStatusIcon = () => {
        switch (audiencia.google_calendar_status) {
            case 'synced':
                return <CheckCircleIcon className="h-5 w-5 text-green-400"><title>Sincronizado com Google Agenda</title></CheckCircleIcon>;
            case 'error':
                return <XCircleIcon className="h-5 w-5 text-red-400"><title>Erro ao sincronizar</title></XCircleIcon>;
            case 'pending':
            default:
                return <InformationCircleIcon className="h-5 w-5 text-gray-500"><title>Sincronização pendente</title></InformationCircleIcon>;
        }
    };
    
    const pjeProcessUrl = `https://pje.tjmg.jus.br/pje/Processo/ConsultaProcesso/Detalhe/list.seam?ca=${audiencia.processo_cnj.replace(/\D/g, '')}`;

    return (
        <div className="bg-gray-800/50 rounded-lg border border-gray-700/50 overflow-hidden">
            <div className="p-5 flex items-start gap-5">
                <div className="text-center flex-shrink-0">
                    <p className="text-3xl font-bold text-blue-300">{dia.split('/')[0]}</p>
                    <p className="text-sm text-gray-400">{dia.split('/')[1]}</p>
                </div>
                <div className="flex-grow">
                    <div className="flex justify-between items-center">
                        <h3 className="font-semibold text-gray-100">{audiencia.tipo}</h3>
                        <span className="text-lg font-bold text-gray-200">{hora}</span>
                    </div>
                    <p className="text-sm text-gray-400 capitalize">{diaSemana}</p>
                    <p className="text-xs text-gray-500 mt-2">{`${audiencia.partes.polo_ativo} X ${audiencia.partes.polo_passivo}`}</p>
                     <div className="flex justify-between items-center mt-3">
                         <a href={pjeProcessUrl} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline font-mono text-xs inline-flex items-center gap-1.5">
                            {audiencia.processo_cnj}
                            <ArrowTopRightOnSquareIcon className="h-4 w-4" />
                        </a>
                         <div className="flex items-center gap-4">
                            {getStatusIcon()}
                         </div>
                    </div>
                </div>
            </div>
        </div>
    );
};


const Audiencias: React.FC = () => {
    const { audiencias, isLoading, isSyncing, error, fetchAudiencias, syncCalendar } = useAudienciasStore();

    useEffect(() => {
        fetchAudiencias();
    }, [fetchAudiencias]);

    const handleSimulateNotification = async () => { /* ... (código existente) ... */ };

    const renderContent = () => {
        if (isLoading) {
            return <div className="flex justify-center items-center h-64"><LoadingSpinner size="12" /></div>;
        }
        if (error) {
            return (
                <div className="text-center text-red-400 bg-red-900/50 p-6 rounded-lg">
                    <h3 className="font-semibold">Não foi possível carregar as audiências</h3>
                    <p className="text-sm mt-2">{error}</p>
                </div>
            );
        }
        if (audiencias.length === 0) {
            return (
                <div className="text-center text-gray-500 p-10 bg-gray-800/50 rounded-lg">
                    <CalendarDaysIcon className="h-12 w-12 mx-auto mb-4" />
                    <h3 className="font-semibold text-gray-300">Nenhuma audiência nos próximos 30 dias.</h3>
                </div>
            );
        }
        return (
            <div className="space-y-4">
                {audiencias.map(aud => <AudienciaCard key={aud.id} audiencia={aud} />)}
            </div>
        );
    };

    return (
        <div>
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
                <PageTitle
                    title="Pauta de Audiências"
                    description="Seus compromissos dos próximos 30 dias, extraídos automaticamente do PJe."
                />
                <div className="flex flex-col sm:flex-row gap-2">
                     <button
                        onClick={handleSimulateNotification}
                        className="w-full sm:w-auto bg-gray-700 text-white font-semibold py-2 px-4 rounded-lg hover:bg-gray-600 transition flex justify-center items-center gap-2"
                    >
                        <BellIcon className="h-5 w-5" />
                        Simular Notificação
                    </button>
                    <button
                        onClick={syncCalendar}
                        disabled={isSyncing || isLoading || audiencias.every(a => a.google_calendar_status === 'synced')}
                        className="w-full sm:w-auto bg-blue-600 text-white font-semibold py-2 px-5 rounded-lg hover:bg-blue-700 transition disabled:bg-gray-600 disabled:cursor-not-allowed flex justify-center items-center gap-2"
                    >
                        {isSyncing ? <LoadingSpinner size="5"/> : <CalendarDaysIcon className="h-5 w-5" />}
                        {isSyncing ? 'Sincronizando...' : 'Sincronizar com Google Agenda'}
                    </button>
                </div>
            </div>
            
            {renderContent()}
        </div>
    );
};

export default Audiencias;
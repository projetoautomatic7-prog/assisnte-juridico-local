import React, { useState } from 'react';

import { PhotoIcon } from '../components/icons/Icons';
import LoadingSpinner from '../components/LoadingSpinner';
import PageTitle from '../components/PageTitle';
import { BACKEND_URL, authenticatedFetch, fileToBase64 } from '../services/api';
import { ExtractedData } from '../types';

const DocumentAnalysis: React.FC = () => {
  const [inputText, setInputText] = useState<string>('');
  const [image, setImage] = useState<{ file: File; preview: string; base64: string } | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  // State for batch results
  const [batchResults, setBatchResults] = useState<ExtractedData[]>([]);
  const [activeTab, setActiveTab] = useState<'text' | 'image'>('text');
  
  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const preview = URL.createObjectURL(file);
      try {
        const { data: base64 } = await fileToBase64(file);
        setImage({ file, preview, base64 });
        setError(null);
      } catch (error) {
        console.error("Error converting file to base64", error);
        setError("Erro ao processar a imagem.");
      }
    }
  };

  const analyzeContent = async () => {
    // Clear previous results
    setIsLoading(true);
    setError(null);
    setBatchResults([]);

    // Handle Image Analysis (single)
    if (activeTab === 'image') {
      if (!image) {
        setError('Por favor, carregue uma imagem.');
        setIsLoading(false);
        return;
      }
      // Image analysis logic is not implemented on the backend in the provided files.
      // Sticking to the user's request, which focuses on batch text processing.
      // The old code had a similar placeholder.
      setError("A análise de imagem via backend ainda não foi implementada. Use a aba de texto.");
      setIsLoading(false);
      return;
    }

    // Handle Text Analysis (batch)
    const documents = inputText.trim().split(/\n---\n/).filter(doc => doc.trim() !== '');

    if (documents.length === 0) {
      setError('Por favor, insira o texto de um ou mais expedientes.');
      setIsLoading(false);
      return;
    }

    try {
      const analysisPrompt = `Você é um assistente jurídico especialista no sistema PJe brasileiro. Analise o conteúdo a seguir (texto de um expediente judicial) e extraia as seguintes informações em formato JSON. Normalize os nomes das partes removendo "LTDA", "S.A.", etc., quando apropriado. Seja conciso no resumo.`;
      const schema = {
        type: 'OBJECT',
        properties: {
          numero_cnj: { type: 'STRING', description: 'Número único do processo no formato CNJ.' },
          partes: {
            type: 'OBJECT',
            properties: {
              polo_ativo: { type: 'ARRAY', items: { type: 'STRING' } },
              polo_passivo: { type: 'ARRAY', items: { type: 'STRING' } }
            }
          },
          classe_judicial: { type: 'STRING' },
          orgao_julgador: { type: 'STRING' },
          data_expediente: { type: 'STRING', description: 'Data do expediente ou da movimentação.' },
          prazo_processual: { type: 'STRING', description: 'Prazo mencionado, se houver. Ex: "5 dias", "15 dias úteis".' },
          resumo_movimentacao: { type: 'STRING', description: 'Um resumo curto e objetivo da última movimentação ou do teor do expediente.' }
        }
      };

      const analysisPromises = documents.map(doc => {
          const requestBody = {
              prompt: analysisPrompt + `\n\n---\n\n${doc}`,
              schema,
          };
          return authenticatedFetch(`${BACKEND_URL}/api/ai/text`, {
              method: 'POST',
              body: JSON.stringify(requestBody),
          }).then(async response => {
              if (!response.ok) {
                  const err = await response.json();
                  throw new Error(err.message || `Erro do servidor ao processar documento.`);
              }
              return response.json();
          }).then(result => JSON.parse(result.text) as ExtractedData);
      });

      const results = await Promise.all(analysisPromises);
      setBatchResults(results);
      
    } catch (err) {
      console.error(err);
      setError('Ocorreu um erro ao analisar os documentos. Verifique o console para mais detalhes.');
    } finally {
      setIsLoading(false);
    }
  };
  
  const renderBatchResultsTable = (results: ExtractedData[]) => (
    <div className="bg-gray-800/50 rounded-lg p-0 overflow-hidden">
        <div className="p-4 border-b border-gray-700">
            <h3 className="text-xl font-semibold text-blue-300">Resultados Consolidados ({results.length})</h3>
        </div>
        <div className="overflow-x-auto max-h-[60vh]">
            <table className="w-full text-sm text-left">
                <thead className="text-xs text-gray-400 uppercase bg-gray-900/50 sticky top-0">
                    <tr>
                        <th className="px-4 py-3">Nº CNJ</th>
                        <th className="px-4 py-3">Partes</th>
                        <th className="px-4 py-3">Prazo</th>
                        <th className="px-4 py-3">Resumo</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-700">
                    {results.map((data, index) => (
                        <tr key={index} className="hover:bg-gray-800">
                            <td className="px-4 py-4 font-mono text-xs align-top whitespace-nowrap">{data.numero_cnj}</td>
                            <td className="px-4 py-4 text-xs align-top">
                                <div className="max-w-xs">
                                    <strong className="text-gray-300">Ativo:</strong> {Array.isArray(data.partes.polo_ativo) ? data.partes.polo_ativo.join(', ') : ''}
                                    <br/>
                                    <strong className="text-gray-300">Passivo:</strong> {Array.isArray(data.partes.polo_passivo) ? data.partes.polo_passivo.join(', ') : ''}
                                </div>
                            </td>
                            <td className="px-4 py-4 font-semibold text-amber-400 align-top whitespace-nowrap">{data.prazo_processual}</td>
                            <td className="px-4 py-4 text-gray-300 text-xs align-top">
                                <p className="max-w-sm" title={data.resumo_movimentacao}>
                                    {data.resumo_movimentacao}
                                </p>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    </div>
  );


  return (
    <div>
      <PageTitle
        title="Análise de Documentos em Lote"
        description="Cole múltiplos expedientes do PJe para extrair dados de forma consolidada em uma tabela."
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <div className="bg-gray-800/50 rounded-lg p-6">
            <div className="flex border-b border-gray-700 mb-4">
                <button onClick={() => setActiveTab('text')} className={`py-2 px-4 text-sm font-medium ${activeTab === 'text' ? 'border-b-2 border-blue-400 text-blue-300' : 'text-gray-400'}`}>
                    Colar Textos
                </button>
                <button onClick={() => setActiveTab('image')} className={`py-2 px-4 text-sm font-medium ${activeTab === 'image' ? 'border-b-2 border-blue-400 text-blue-300' : 'text-gray-400'}`}>
                    Carregar Imagem (Única)
                </button>
            </div>

            {activeTab === 'text' && (
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                rows={15}
                className="w-full bg-gray-900/50 border border-gray-700 rounded-md p-3 text-gray-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                placeholder={'Cole o texto de um ou mais expedientes aqui.\n\nSepare múltiplos documentos com "---" em uma nova linha.'}
              ></textarea>
            )}

            {activeTab === 'image' && (
              <div>
                <input
                  type="file"
                  id="imageUpload"
                  accept="image/png, image/jpeg, image/webp"
                  onChange={handleImageChange}
                  className="hidden"
                />
                <label htmlFor="imageUpload" className="w-full h-48 bg-gray-900/50 border-2 border-dashed border-gray-600 rounded-lg flex flex-col justify-center items-center cursor-pointer hover:border-blue-500 transition">
                  {image ? (
                    <img src={image.preview} alt="Preview" className="h-full w-full object-contain rounded-lg p-2" />
                  ) : (
                    <>
                      <PhotoIcon className="h-10 w-10 text-gray-500 mb-2" />
                      <span className="text-gray-400">Clique para carregar uma imagem (PDF/Print)</span>
                    </>
                  )}
                </label>
              </div>
            )}
            
            <button
              onClick={analyzeContent}
              disabled={isLoading}
              className="mt-4 w-full bg-blue-600 text-white font-semibold py-3 px-4 rounded-lg hover:bg-blue-700 transition disabled:bg-gray-600 disabled:cursor-not-allowed flex justify-center items-center"
            >
              {isLoading ? <LoadingSpinner /> : 'Analisar Expediente(s)'}
            </button>
            {error && <p className="text-red-400 mt-4 text-sm">{error}</p>}
          </div>
        </div>
        
        <div className="space-y-6">
            {isLoading && <div className="flex justify-center p-10"><LoadingSpinner size="12" /></div>}
            {batchResults.length > 0 && renderBatchResultsTable(batchResults)}
        </div>
      </div>
    </div>
  );
};

export default DocumentAnalysis;
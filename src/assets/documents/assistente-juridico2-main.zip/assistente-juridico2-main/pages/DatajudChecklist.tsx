import React, { useState } from 'react';

import { MagnifyingGlassIcon, ClipboardDocumentCheckIcon, ChevronRightIcon, LightBulbIcon } from '../components/icons/Icons';
import LoadingSpinner from '../components/LoadingSpinner';
import PageTitle from '../components/PageTitle';
import { useDatajudStore } from '../stores/datajudStore';

const DatajudChecklist: React.FC = () => {
  const [cnjInput, setCnjInput] = useState<string>('');
  const [tribunal, setTribunal] = useState<string>('tjmg');
  
  const { 
    processoData, analysis, isLoading, isAnalyzing, error, analysisError, 
    searchProcesso, analyzeProcesso 
  } = useDatajudStore();

  const tribunais = [
    { value: 'tjmg', label: 'TJMG - Minas Gerais' },
    { value: 'tjsp', label: 'TJSP - São Paulo' },
    { value: 'tjrj', label: 'TJRJ - Rio de Janeiro' },
    // ... (outros tribunais)
  ];

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cnjInput.trim()) return;
    searchProcesso(cnjInput, tribunal);
  };

  const renderProcessoDetails = () => {
    if (!processoData) return null;

    return (
        <div className="mt-8 bg-gray-800/50 rounded-lg border border-gray-700">
            <div className="p-6 border-b border-gray-700">
                <div className="flex flex-col sm:flex-row justify-between sm:items-start gap-4">
                    <div>
                        <h3 className="text-xl font-semibold text-blue-300">{processoData.classe.nome}</h3>
                        <p className="font-mono text-gray-400">{processoData.numeroProcesso}</p>
                    </div>
                    <button 
                        onClick={analyzeProcesso} 
                        disabled={isAnalyzing}
                        className="bg-yellow-500/20 text-yellow-300 hover:bg-yellow-500/40 font-semibold py-2 px-4 rounded-lg flex items-center justify-center gap-2 transition-colors text-sm disabled:opacity-50 disabled:cursor-wait w-full sm:w-auto"
                    >
                        {isAnalyzing ? <LoadingSpinner size="5"/> : <LightBulbIcon className="h-5 w-5" />}
                        {isAnalyzing ? 'Analisando...' : 'Analisar Andamentos'}
                    </button>
                </div>
            </div>
            {(isAnalyzing || analysis || analysisError) && (
                <div className="p-6 border-b border-gray-700 bg-gray-900/30">
                     <h4 className="text-lg font-semibold text-gray-200 mb-2">Análise da IA</h4>
                     {isAnalyzing && <div className="flex justify-center p-4"><LoadingSpinner /></div>}
                     {analysisError && <p className="text-red-400 text-sm">{analysisError}</p>}
                     {analysis && <div className="text-gray-300 text-sm whitespace-pre-wrap">{analysis}</div>}
                </div>
            )}
            <div className="p-6">
                <h4 className="text-lg font-semibold text-gray-200 mb-4">Últimos Andamentos</h4>
                <ul className="space-y-4">
                    {processoData.movimentos
                        .sort((a, b) => new Date(b.dataHora).getTime() - new Date(a.dataHora).getTime())
                        .slice(0, 10)
                        .map((mov) => (
                        <li key={mov.codigo + mov.dataHora} className="flex items-start">
                            <div className="flex-shrink-0 pt-1"><ChevronRightIcon className="h-5 w-5 text-gray-500"/></div>
                            <div className="ml-3">
                                <p className="font-semibold text-gray-200">{mov.nome}</p>
                                <p className="text-xs text-gray-400">{new Date(mov.dataHora).toLocaleString('pt-BR')}</p>
                            </div>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
  };

  return (
    <div>
      <PageTitle
        title="Checklist Diário via Datajud"
        description="Consulte os últimos andamentos de um processo diretamente da Base Nacional de Dados do Poder Judiciário."
      />
      <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-2 items-center max-w-3xl mx-auto">
        <input type="text" value={cnjInput} onChange={(e) => setCnjInput(e.target.value)} className="flex-1 w-full bg-gray-800/50 border border-gray-700 rounded-lg p-3 text-gray-200" placeholder="Digite o número do processo (CNJ)..." />
        <select value={tribunal} onChange={(e) => setTribunal(e.target.value)} className="w-full sm:w-auto bg-gray-800/50 border border-gray-700 rounded-lg p-3 text-gray-200">
          {tribunais.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
        </select>
        <button type="submit" disabled={isLoading} className="bg-blue-600 text-white font-semibold py-3 px-5 rounded-lg hover:bg-blue-700 transition disabled:bg-gray-600 flex items-center justify-center">
          {isLoading ? <LoadingSpinner size="5" /> : <MagnifyingGlassIcon className="h-5 w-5" />}
        </button>
      </form>
        <div className="mt-8 max-w-4xl mx-auto">
            {isLoading && <div className="flex justify-center p-10"><LoadingSpinner size="12" /></div>}
            {error && <div className="text-center text-red-400 bg-red-900/50 p-6 rounded-lg"><h3 className="font-semibold">Erro na Consulta</h3><p className="text-sm mt-2">{error}</p></div>}
            {!isLoading && !error && !processoData && <div className="text-center text-gray-500 p-10 bg-gray-800/50 rounded-lg"><ClipboardDocumentCheckIcon className="h-12 w-12 mx-auto mb-4" /><h3 className="font-semibold text-gray-300">Pronto para consulta.</h3></div>}
            {processoData && renderProcessoDetails()}
        </div>
    </div>
  );
};

export default DatajudChecklist;
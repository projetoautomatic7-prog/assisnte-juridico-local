import React, { useState, useEffect, useCallback } from 'react';

import { BoltIcon, DocumentDuplicateIcon, CheckIcon, XMarkIcon, CheckCircleIcon } from '../components/icons/Icons';
import LoadingSpinner from '../components/LoadingSpinner';
import PageTitle from '../components/PageTitle';
import { BACKEND_URL, authenticatedFetch } from '../services/api';

// Hook de debounce simples
const useDebounce = <T,>(value: T, delay: number): T => {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);
    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);
  return debouncedValue;
};

interface QuickActionSuggestion {
    acao: string;
    descricao: string;
    checklist: string[];
}

const QuickActions: React.FC = () => {
  const [inputText, setInputText] = useState<string>('');
  const [suggestions, setSuggestions] = useState<QuickActionSuggestion[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const debouncedInputText = useDebounce(inputText, 750);

  // State for the drafting modal
  const [isDraftModalOpen, setIsDraftModalOpen] = useState<boolean>(false);
  const [draftContent, setDraftContent] = useState<string>('');
  const [isDraftLoading, setIsDraftLoading] = useState<boolean>(false);
  const [draftError, setDraftError] = useState<string | null>(null);
  const [selectedActionTitle, setSelectedActionTitle] = useState<string>('');
  const [copySuccess, setCopySuccess] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);

  const fetchSuggestions = useCallback(async (text: string) => {
    if (text.trim().length < 50) {
      setSuggestions([]);
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
        const prompt = `Com base no seguinte texto de um expediente judicial brasileiro, sugira os 3 próximos passos processuais mais prováveis e urgentes. Para cada passo, forneça uma breve descrição e um checklist de itens a serem verificados ou providenciados. Responda em JSON. Texto: "${text}"`;
        const schema = {
            type: 'OBJECT',
            properties: {
                sugestoes: {
                    type: 'ARRAY',
                    items: {
                        type: 'OBJECT',
                        properties: {
                            acao: { type: 'STRING' },
                            descricao: { type: 'STRING' },
                            checklist: { type: 'ARRAY', items: { type: 'STRING' } }
                        }
                    }
                }
            }
        };

        const response = await authenticatedFetch(`${BACKEND_URL}/api/ai/text`, {
            method: 'POST',
            body: JSON.stringify({ prompt, schema }),
        });

        if (!response.ok) {
            const err = await response.json();
            throw new Error(err.message || 'Erro do servidor');
        }
        
        const result = await response.json();
        const data = JSON.parse(result.text);
        setSuggestions(data.sugestoes || []);

    } catch (err) {
      console.error(err);
      setError('Não foi possível obter sugestões. Tente novamente.');
      setSuggestions([]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchSuggestions(debouncedInputText);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedInputText]);
  
  const handleGenerateDraft = async (action: QuickActionSuggestion) => {
    setIsDraftModalOpen(true);
    setIsDraftLoading(true);
    setDraftError(null);
    setDraftContent('');
    setSelectedActionTitle(action.acao);

    try {
      const prompt = `Como um assistente jurídico especialista, redija um documento para a seguinte ação: "${action.acao}". A petição deve ser baseada no contexto do seguinte expediente judicial. Seja formal, técnico e estruture o documento adequadamente com endereçamento, qualificação das partes (se inferível), fatos, direito e pedidos. \n\n## Expediente Original:\n${inputText}\n\n## Detalhes da Ação Sugerida:\n- Ação: ${action.acao}\n- Descrição: ${action.descricao}\n- Checklist: ${action.checklist.join(', ')}`;
      
      const response = await authenticatedFetch(`${BACKEND_URL}/api/ai/text`, {
        method: 'POST',
        body: JSON.stringify({ prompt, model: 'gemini-2.5-pro' }),
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.message || 'Erro do servidor ao gerar a minuta.');
      }

      const result = await response.json();
      setDraftContent(result.text);

    } catch (err) {
      console.error(err);
      setDraftError('Ocorreu um erro ao gerar a minuta. Tente novamente.');
    } finally {
      setIsDraftLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(draftContent);
    setCopySuccess(true);
    setTimeout(() => setCopySuccess(false), 2000);
  };

  const handleSave = () => {
    // The content is already up-to-date in the `draftContent` state.
    // This provides visual feedback to the user that their changes are "saved" locally.
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };


  return (
    <div>
      <PageTitle
        title="Ações Rápidas com IA"
        description="Cole o texto de um expediente e receba sugestões instantâneas dos próximos passos processuais."
      />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <h3 className="text-lg font-semibold mb-2 text-gray-300">Texto do Expediente</h3>
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            rows={15}
            className="w-full bg-gray-800/50 border border-gray-700 rounded-md p-4 text-gray-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
            placeholder="Cole o texto do expediente aqui para ver a mágica acontecer..."
          ></textarea>
        </div>
        <div>
          <h3 className="text-lg font-semibold mb-2 text-gray-300">Sugestões de Ações</h3>
          <div className="space-y-4">
            {isLoading && <div className="flex justify-center p-10"><LoadingSpinner /></div>}
            {error && <p className="text-red-400 text-center">{error}</p>}
            {!isLoading && !error && suggestions.length === 0 && (
                <div className="text-center text-gray-500 p-10 bg-gray-800/50 rounded-lg">
                    <BoltIcon className="h-12 w-12 mx-auto mb-4" />
                    As sugestões aparecerão aqui. Comece a digitar ou cole um texto com mais de 50 caracteres.
                </div>
            )}
            {suggestions.map((s, index) => (
              <div key={index} className="bg-gray-800/50 rounded-lg p-5 border border-gray-700/50">
                <h4 className="font-bold text-blue-300 text-lg">{s.acao}</h4>
                <p className="text-sm text-gray-400 my-2">{s.descricao}</p>
                <div className="mt-3">
                  <h5 className="text-sm font-semibold text-gray-300 mb-2">Checklist:</h5>
                  <ul className="space-y-1.5 list-none">
                    {s.checklist.map((item, i) => (
                      <li key={i} className="flex items-center text-sm text-gray-400">
                         <svg className="w-4 h-4 mr-2 text-green-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
                <button
                    onClick={() => handleGenerateDraft(s)}
                    className="mt-4 w-full bg-blue-600/20 text-blue-300 hover:bg-blue-600/40 font-semibold py-2 px-4 rounded-lg flex items-center justify-center gap-2 transition-colors"
                >
                    <DocumentDuplicateIcon className="h-5 w-5" />
                    Redigir Documento
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

       {isDraftModalOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50" onClick={() => setIsDraftModalOpen(false)}>
            <div className="bg-gray-800 rounded-lg shadow-xl w-full max-w-3xl h-[90vh] flex flex-col" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center p-4 border-b border-gray-700 flex-shrink-0">
                    <h3 className="text-xl font-semibold text-blue-300">Minuta para: {selectedActionTitle}</h3>
                    <button onClick={() => setIsDraftModalOpen(false)} className="text-gray-500 hover:text-gray-200"><XMarkIcon className="h-6 w-6" /></button>
                </div>
                <div className="flex-1 overflow-y-auto p-6">
                    {isDraftLoading && <div className="flex justify-center items-center h-full"><LoadingSpinner size="12" /></div>}
                    {draftError && <p className="text-red-400 text-center">{draftError}</p>}
                    {!isDraftLoading && !draftError && (
                    <textarea
                        value={draftContent}
                        onChange={(e) => setDraftContent(e.target.value)}
                        className="w-full h-full bg-gray-900/50 border border-gray-700 rounded-md p-4 text-gray-300 font-mono text-sm resize-none focus:ring-2 focus:ring-blue-500"
                        placeholder="A minuta gerada pela IA aparecerá aqui..."
                    />
                    )}
                </div>
                <div className="p-4 border-t border-gray-700 flex justify-end gap-4 flex-shrink-0">
                    <button onClick={handleSave} className={`font-semibold py-2 px-4 rounded-lg flex items-center gap-2 transition-colors ${saveSuccess ? 'bg-green-600 text-white' : 'bg-gray-600 hover:bg-gray-700 text-white'}`}>
                        {saveSuccess ? <CheckIcon className="h-5 w-5" /> : <CheckCircleIcon className="h-5 w-5" />}
                        {saveSuccess ? 'Salvo!' : 'Salvar Alterações'}
                    </button>
                    <button onClick={handleCopy} className={`font-semibold py-2 px-4 rounded-lg flex items-center gap-2 transition-colors ${copySuccess ? 'bg-green-600 text-white' : 'bg-blue-600 hover:bg-blue-700 text-white'}`}>
                        {copySuccess ? <CheckIcon className="h-5 w-5" /> : <DocumentDuplicateIcon className="h-5 w-5" />}
                        {copySuccess ? 'Copiado!' : 'Copiar Texto'}
                    </button>
                    <button onClick={() => setIsDraftModalOpen(false)} className="bg-gray-600 hover:bg-gray-700 text-white font-semibold py-2 px-4 rounded-lg">Fechar</button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default QuickActions;
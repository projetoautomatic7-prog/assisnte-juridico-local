// This file is obsolete and can be deleted.
// The test configuration for the backend is located at `backend/jest.config.js`.

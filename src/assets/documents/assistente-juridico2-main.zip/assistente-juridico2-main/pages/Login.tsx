import React, { useState, useEffect, useRef } from 'react';

import { ScaleIcon } from '../components/icons/Icons';
import LoadingSpinner from '../components/LoadingSpinner';
import { useAuthStore } from '../stores/authStore';

declare global {
    interface Window {
        google: any;
    }
}

const Login: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showCredentials, setShowCredentials] = useState(true);
  const { login, googleLogin, isLoading, error } = useAuthStore();
  const googleButtonRef = useRef<HTMLDivElement>(null);

  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await login(username, password);
  };

  const handleQuickLogin = (user: string, pass: string) => {
    setUsername(user);
    setPassword(pass);
    login(user, pass);
  };
  
  const handleGoogleLogin = async (response: any) => {
      await googleLogin(response.credential);
  };

  useEffect(() => {
    if (window.google && googleButtonRef.current) {
      window.google.accounts.id.initialize({
        client_id: (import.meta as any)?.env?.VITE_GOOGLE_CLIENT_ID,
        callback: handleGoogleLogin,
      });
      window.google.accounts.id.renderButton(
        googleButtonRef.current,
        { theme: 'outline', size: 'large', type: 'standard', text: 'signin_with', shape: 'rectangular' }
      );
    }
  }, []);

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-900">
      <div className="w-full max-w-md p-8 space-y-6 bg-gray-800/50 rounded-xl shadow-lg border border-gray-700/50">
        <div className="text-center">
            <div className="flex justify-center mb-4">
                <ScaleIcon className="h-12 w-12 text-blue-400" />
            </div>
          <h1 className="text-3xl font-bold text-white">Bem-vindo</h1>
          <p className="mt-2 text-gray-400">Acesse seu assistente jurídico com IA.</p>
        </div>

        {/* Credenciais padrão - Acesso rápido */}
        {showCredentials && (
          <div className="bg-blue-900/20 border border-blue-500/30 rounded-lg p-4">
            <div className="flex justify-between items-start mb-2">
              <h3 className="text-sm font-semibold text-blue-300">Acesso Rápido</h3>
              <button 
                onClick={() => setShowCredentials(false)}
                className="text-gray-400 hover:text-gray-200"
              >
                ✕
              </button>
            </div>
            <p className="text-xs text-gray-400 mb-3">Clique para entrar automaticamente:</p>
            <div className="space-y-2">
              <button
                onClick={() => handleQuickLogin('admin', 'admin123')}
                className="w-full text-left px-3 py-2 bg-blue-600/20 hover:bg-blue-600/40 rounded border border-blue-500/30 text-sm text-blue-200 transition-colors"
              >
                👤 <strong>admin</strong> / admin123
              </button>
              <button
                onClick={() => handleQuickLogin('demo', 'demo')}
                className="w-full text-left px-3 py-2 bg-blue-600/20 hover:bg-blue-600/40 rounded border border-blue-500/30 text-sm text-blue-200 transition-colors"
              >
                👤 <strong>demo</strong> / demo
              </button>
              <button
                onClick={() => handleQuickLogin('usuario', '123456')}
                className="w-full text-left px-3 py-2 bg-blue-600/20 hover:bg-blue-600/40 rounded border border-blue-500/30 text-sm text-blue-200 transition-colors"
              >
                👤 <strong>usuario</strong> / 123456
              </button>
            </div>
          </div>
        )}

        <form className="space-y-6" onSubmit={handleManualSubmit}>
          <div>
            <label
              htmlFor="username"
              className="text-sm font-medium text-gray-300"
            >
              Usuário
            </label>
            <input
              id="username"
              name="username"
              type="text"
              autoComplete="username"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="mt-2 block w-full rounded-md border-0 bg-gray-900/50 p-3 text-white shadow-sm ring-1 ring-inset ring-gray-700 placeholder:text-gray-500 focus:ring-2 focus:ring-inset focus:ring-blue-500"
              placeholder="admin, demo, ou usuario"
            />
          </div>

          <div>
            <label
              htmlFor="password"
              className="text-sm font-medium text-gray-300"
            >
              Senha
            </label>
            <input
              id="password"
              name="password"
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-2 block w-full rounded-md border-0 bg-gray-900/50 p-3 text-white shadow-sm ring-1 ring-inset ring-gray-700 placeholder:text-gray-500 focus:ring-2 focus:ring-inset focus:ring-blue-500"
              placeholder="••••••••"
            />
          </div>

            {error && <p className="text-sm text-red-400 text-center">{error}</p>}

          <div>
            <button
              type="submit"
              disabled={isLoading}
              className="flex w-full justify-center rounded-md bg-blue-600 px-4 py-3 text-sm font-semibold text-white shadow-sm hover:bg-blue-700 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 disabled:bg-gray-600 disabled:cursor-not-allowed"
            >
              {isLoading ? <LoadingSpinner size="5" /> : 'Entrar'}
            </button>
          </div>
        </form>

        <div className="relative my-4">
            <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-600" />
            </div>
            <div className="relative flex justify-center text-sm">
                <span className="bg-gray-800 px-2 text-gray-400">OU</span>
            </div>
        </div>
        
        <div className="flex justify-center" ref={googleButtonRef}></div>

      </div>
    </div>
  );
};

export default Login;

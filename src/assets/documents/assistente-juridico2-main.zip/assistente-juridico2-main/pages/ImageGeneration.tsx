import React, { useState } from 'react';

import { PhotoIcon } from '../components/icons/Icons';
import LoadingSpinner from '../components/LoadingSpinner';
import PageTitle from '../components/PageTitle';
import { BACKEND_URL, authenticatedFetch, fileToBase64 } from '../services/api';

const ImageGeneration: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'generate' | 'edit'>('generate');

  // Estados para o modo Gerar
  const [generatePrompt, setGeneratePrompt] = useState<string>('');
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generateError, setGenerateError] = useState<string | null>(null);

  // Estados para o modo Editar
  const [editPrompt, setEditPrompt] = useState<string>('');
  const [originalImage, setOriginalImage] = useState<{ file: File; preview: string; base64: string } | null>(null);
  const [editedImage, setEditedImage] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [editError, setEditError] = useState<string | null>(null);


  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const preview = URL.createObjectURL(file);
      const { data: base64 } = await fileToBase64(file);
      setOriginalImage({ file, preview, base64 });
      setEditedImage(null);
    }
  };

  const generateImage = async () => {
    if (!generatePrompt.trim()) {
      setGenerateError('Por favor, descreva a imagem que você deseja gerar.');
      return;
    }
    setIsGenerating(true);
    setGenerateError(null);
    setGeneratedImage(null);

    try {
        const fullPrompt = `Crie um card visual profissional para um painel de escritório de advocacia. O card deve ser limpo, moderno e informativo, usando ícones e tipografia clara. Use uma paleta de cores sóbria (azuis, cinzas, brancos). O card deve conter as seguintes informações: ${generatePrompt}. Estilo: infográfico corporativo, minimalista.`;
        
        const response = await authenticatedFetch(`${BACKEND_URL}/api/ai/image/generate`, {
            method: 'POST',
            body: JSON.stringify({ prompt: fullPrompt }),
        });

        if (!response.ok) {
            const err = await response.json();
            throw new Error(err.message || 'Erro do servidor');
        }

        const result = await response.json();
        setGeneratedImage(`data:image/png;base64,${result.image}`);
    } catch (err) {
      console.error(err);
      setGenerateError('Ocorreu um erro ao gerar a imagem. Tente novamente.');
    } finally {
      setIsGenerating(false);
    }
  };
  
  const editImage = async () => {
    if (!originalImage) {
      setEditError('Por favor, carregue uma imagem para editar.');
      return;
    }
    if (!editPrompt.trim()) {
      setEditError('Por favor, descreva a alteração desejada.');
      return;
    }
    setIsEditing(true);
    setEditError(null);
    setEditedImage(null);

    try {
        const response = await authenticatedFetch(`${BACKEND_URL}/api/ai/image/edit`, {
            method: 'POST',
            body: JSON.stringify({
                prompt: editPrompt,
                image: {
                    data: originalImage.base64,
                    mimeType: originalImage.file.type,
                }
            }),
        });
        
        if (!response.ok) {
            const err = await response.json();
            throw new Error(err.message || 'Erro do servidor');
        }

        const result = await response.json();
        setEditedImage(`data:image/png;base64,${result.image}`);

    } catch (err) {
        console.error(err);
        setEditError('Ocorreu um erro ao editar a imagem. Tente novamente.');
    } finally {
      setIsEditing(false);
    }
  };

  const renderGenerateTab = () => (
     <div className="max-w-4xl mx-auto">
        <div className="bg-gray-800/50 rounded-lg p-6">
          <label htmlFor="prompt" className="block text-sm font-medium text-gray-300 mb-2">
            Descreva os dados do processo para o card:
          </label>
          <textarea
            id="prompt"
            rows={4}
            value={generatePrompt}
            onChange={(e) => setGeneratePrompt(e.target.value)}
            className="w-full bg-gray-900/50 border border-gray-700 rounded-md p-3 text-gray-200 focus:ring-2 focus:ring-blue-500"
            placeholder="Ex: Status: Prazo em curso. Processo: 0123456-78.2023.8.26.0001. Prazo restante: 3 dias. Ação recomendada: Protocolar contestação."
          />
          <button
            onClick={generateImage}
            disabled={isGenerating}
            className="mt-4 w-full bg-blue-600 text-white font-semibold py-3 px-4 rounded-lg hover:bg-blue-700 transition disabled:bg-gray-600 flex justify-center items-center"
          >
            {isGenerating ? <LoadingSpinner /> : 'Gerar Imagem do Card'}
          </button>
          {generateError && <p className="text-red-400 mt-4 text-sm">{generateError}</p>}
        </div>

        <div className="mt-8">
          <h3 className="text-lg font-semibold text-gray-300 mb-2">Imagem Gerada:</h3>
          <div className="w-full aspect-video bg-gray-800/50 rounded-lg flex items-center justify-center border border-gray-700">
            {isGenerating ? (
              <LoadingSpinner size="12" />
            ) : generatedImage ? (
              <img src={generatedImage} alt="Generated card" className="rounded-lg object-contain h-full w-full" />
            ) : (
              <p className="text-gray-500">A imagem gerada aparecerá aqui.</p>
            )}
          </div>
        </div>
      </div>
  );

  const renderEditTab = () => (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-gray-800/50 rounded-lg p-6 space-y-4">
            <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">1. Carregue a Imagem</label>
                <input
                  type="file"
                  id="imageUpload"
                  accept="image/png, image/jpeg, image/webp"
                  onChange={handleImageChange}
                  className="hidden"
                />
                <label htmlFor="imageUpload" className="w-full h-48 bg-gray-900/50 border-2 border-dashed border-gray-600 rounded-lg flex flex-col justify-center items-center cursor-pointer hover:border-blue-500 transition">
                  {originalImage ? (
                    <img src={originalImage.preview} alt="Preview" className="h-full w-full object-contain rounded-lg p-2" />
                  ) : (
                    <>
                      <PhotoIcon className="h-10 w-10 text-gray-500 mb-2" />
                      <span className="text-gray-400 text-center text-sm">Clique para carregar a imagem<br/>que deseja editar</span>
                    </>
                  )}
                </label>
            </div>
             <div>
                <label htmlFor="edit-prompt" className="block text-sm font-medium text-gray-300 mb-2">2. Descreva a Alteração</label>
                <textarea
                    id="edit-prompt"
                    rows={3}
                    value={editPrompt}
                    onChange={(e) => setEditPrompt(e.target.value)}
                    className="w-full bg-gray-900/50 border border-gray-700 rounded-md p-3 text-gray-200 focus:ring-2 focus:ring-blue-500"
                    placeholder="Ex: Adicione um filtro retrô, remova o fundo, faça a imagem ficar em preto e branco..."
                />
             </div>
             <button
                onClick={editImage}
                disabled={isEditing || !originalImage}
                className="w-full bg-blue-600 text-white font-semibold py-3 px-4 rounded-lg hover:bg-blue-700 transition disabled:bg-gray-600 disabled:cursor-not-allowed flex justify-center items-center"
            >
                {isEditing ? <LoadingSpinner /> : 'Editar Imagem com IA'}
            </button>
            {editError && <p className="text-red-400 text-sm">{editError}</p>}
        </div>

        <div>
            <h3 className="text-lg font-semibold text-gray-300 mb-2">Resultado da Edição</h3>
            <div className="w-full aspect-square bg-gray-800/50 rounded-lg flex items-center justify-center border border-gray-700">
                {isEditing ? (
                    <LoadingSpinner size="12" />
                ) : editedImage ? (
                    <img src={editedImage} alt="Edited result" className="rounded-lg object-contain h-full w-full" />
                ) : (
                    <p className="text-gray-500 text-center">A imagem editada aparecerá aqui.</p>
                )}
            </div>
        </div>
    </div>
  );


  return (
    <div>
      <PageTitle
        title="Estúdio de Imagem com IA"
        description="Crie cards visuais para painéis ou edite imagens existentes usando prompts de texto."
      />

        <div className="mb-6 border-b border-gray-700">
            <nav className="-mb-px flex space-x-6" aria-label="Tabs">
                 <button
                    onClick={() => setActiveTab('generate')}
                    className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${
                        activeTab === 'generate'
                        ? 'border-blue-500 text-blue-400'
                        : 'border-transparent text-gray-400 hover:text-gray-200 hover:border-gray-500'
                    }`}
                >
                    Gerar Imagem
                </button>
                 <button
                    onClick={() => setActiveTab('edit')}
                    className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${
                        activeTab === 'edit'
                        ? 'border-blue-500 text-blue-400'
                        : 'border-transparent text-gray-400 hover:text-gray-200 hover:border-gray-500'
                    }`}
                >
                    Editar Imagem
                </button>
            </nav>
        </div>
        
        {activeTab === 'generate' && renderGenerateTab()}
        {activeTab === 'edit' && renderEditTab()}

    </div>
  );
};

export default ImageGeneration;
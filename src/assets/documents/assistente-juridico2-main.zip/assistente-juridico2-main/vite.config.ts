
import path from 'path';

import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

// Esta configuração garante que as variáveis de ambiente do processo de build (como da Vercel)
// sejam corretamente injetadas no código do frontend.
export default defineConfig({
  server: {
    port: 3000,
    host: '0.0.0.0',
  },
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve('./'),
    }
  },
  // Ensure public files like sw.js are copied to dist during build
  publicDir: 'public',
});
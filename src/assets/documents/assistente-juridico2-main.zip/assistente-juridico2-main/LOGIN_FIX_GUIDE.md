# Guia de Correção do Erro "Failed to fetch" no Login

## Problema
Ao tentar fazer login, aparece o erro: **"Failed to fetch"**

Este erro indica que o navegador não conseguiu fazer a requisição HTTP para o backend. As causas mais comuns são:

## 1. Corrigir CORS no Backend (Render)

### Problema Identificado
O arquivo `render.yaml` tinha um erro de digitação na linha 33:
```yaml
# ERRADO (antes)
FRONTEND_ORIGIN: "https://pje-fronted.vercel.app,http://localhost:5173"

# CORRETO (agora)
FRONTEND_ORIGIN: "https://pje-frontend.vercel.app,http://localhost:5173"
```

### Ação Necessária
✅ **JÁ CORRIGIDO** no código. Após fazer o deploy desta correção, o backend permitirá requisições do frontend correto.

---

## 2. Configurar Variáveis de Ambiente no Vercel (Frontend)

O frontend precisa saber onde está o backend. Você **DEVE** configurar esta variável no Vercel:

### Passos para Configurar no Vercel:

1. Acesse o dashboard do Vercel: https://vercel.com/dashboard
2. Selecione seu projeto `assistente-juridico` (ou nome do projeto do frontend)
3. Vá em **Settings** → **Environment Variables**
4. Adicione a seguinte variável:

| Nome da Variável | Valor | Ambiente |
|-----------------|-------|----------|
| `VITE_BACKEND_URL` | `https://assistente-juridico-rs1e.onrender.com` | Production, Preview, Development |

5. Clique em **Save**
6. **IMPORTANTE**: Faça um novo deploy para aplicar as mudanças
   - Vá em **Deployments**
   - Clique nos três pontinhos do último deploy
   - Selecione **Redeploy**

### Por que isso é necessário?

O código em `services/api.ts` usa esta variável:

```typescript
const PROD_BACKEND_URL = (import.meta as any)?.env?.VITE_BACKEND_URL || 'https://assistente-juridico-rs1e.onrender.com';
```

Se `VITE_BACKEND_URL` não estiver configurado, ele usa o fallback, mas é melhor configurar explicitamente.

---

## 3. Verificar se o Backend está Online

### Teste Rápido
Abra esta URL no navegador:
```
https://assistente-juridico-rs1e.onrender.com/health
```

**Resposta esperada:**
```json
{
  "status": "ok",
  "timestamp": "2025-11-14T02:17:31.736Z"
}
```

Se você ver esta resposta, o backend está funcionando! ✅

Se der erro 404, timeout ou outra coisa, o problema está no backend.

### Possíveis Problemas do Backend

#### A. Backend hibernando (Render Free Tier)
- No plano gratuito do Render, o serviço "hiberna" após 15 minutos sem uso
- A primeira requisição após hibernar pode demorar ~30 segundos
- **Solução**: Aguarde e tente novamente, ou considere upgrade para plano pago

#### B. Variáveis de ambiente faltando no Render
Verifique no Render se estas variáveis estão configuradas:
- `JWT_SECRET` (obrigatório)
- `ADMIN_USERNAME` (opcional, default: admin)
- `ADMIN_PASSWORD` (opcional, default: admin123)
- `API_KEY` (Gemini API Key - obrigatório para IA)
- `DATABASE_URL` (obrigatório)

Para verificar:
1. Acesse https://render.com/dashboard
2. Selecione o serviço `pje-robot-backend`
3. Vá em **Environment** → **Environment Variables**
4. Confira se as variáveis essenciais estão preenchidas

---

## 4. Mensagens de Erro Melhoradas

Agora, quando houver erro de conexão, você verá uma mensagem mais clara:

**Antes:**
```
Failed to fetch
```

**Agora:**
```
Não foi possível conectar ao servidor. Verifique sua conexão ou contate o suporte. 
(Backend: https://assistente-juridico-rs1e.onrender.com)
```

Isso ajuda a diagnosticar se o problema é de URL incorreta.

---

## Checklist Completo de Diagnóstico

Use esta checklist para resolver o problema:

- [ ] **1. Deploy do código corrigido**
  - [ ] Fazer commit e push das correções
  - [ ] Aguardar deploy no Render completar (5-10 minutos)
  - [ ] Verificar logs do deploy no Render

- [ ] **2. Configurar variável no Vercel**
  - [ ] Adicionar `VITE_BACKEND_URL=https://assistente-juridico-rs1e.onrender.com`
  - [ ] Fazer redeploy do frontend
  - [ ] Aguardar deploy completar (1-2 minutos)

- [ ] **3. Testar backend diretamente**
  - [ ] Abrir `https://assistente-juridico-rs1e.onrender.com/health` no navegador
  - [ ] Confirmar resposta `{"status":"ok"}`
  - [ ] Se der timeout, aguardar ~30s (hibernação) e tentar novamente

- [ ] **4. Testar login**
  - [ ] Abrir o frontend (Vercel URL)
  - [ ] Tentar fazer login com: `admin` / `admin123`
  - [ ] Se ainda der erro, abrir DevTools (F12) → Console/Network
  - [ ] Verificar qual URL está sendo chamada
  - [ ] Verificar o erro exato na aba Network

- [ ] **5. Se ainda não funcionar**
  - [ ] Tirar screenshot do erro com DevTools aberto
  - [ ] Compartilhar logs do Render (últimas 50 linhas)
  - [ ] Verificar se há erros CORS no console do navegador

---

## Comandos Úteis para Desenvolvimento Local

Se quiser testar localmente:

```bash
# 1. Frontend
cd /caminho/para/projeto
npm install
npm run dev
# Acesse: http://localhost:5173

# 2. Backend (em outro terminal)
cd /caminho/para/projeto/backend
npm install

# Crie arquivo .env com:
# JWT_SECRET=seu_secret_super_secreto_aqui
# API_KEY=sua_gemini_api_key
# DATABASE_URL=postgres://user:pass@localhost:5432/db
# ADMIN_USERNAME=admin
# ADMIN_PASSWORD=admin123

npm run dev
# Backend rodará em: http://localhost:3001
```

---

## Resumo das Correções

✅ **Código Corrigido:**
1. Typo em `render.yaml`: `pje-fronted` → `pje-frontend`
2. Mensagens de erro mais claras em `authStore.ts`

⚙️ **Configuração Necessária (VOCÊ DEVE FAZER):**
1. Adicionar `VITE_BACKEND_URL` no Vercel
2. Fazer redeploy do frontend
3. Aguardar deploy do backend completar

🧪 **Como Testar:**
1. Testar `https://assistente-juridico-rs1e.onrender.com/health`
2. Tentar login no frontend
3. Verificar logs se necessário

---

## Perguntas Frequentes

### Q: Corrigi e ainda dá erro, o que fazer?
**A:** Verifique:
1. Você fez redeploy no Vercel após adicionar a variável?
2. O backend está online? (teste /health)
3. Há erros no console do navegador (F12)?

### Q: Quanto tempo demora para aplicar as correções?
**A:** 
- Deploy Render (backend): 5-10 minutos
- Deploy Vercel (frontend): 1-2 minutos
- Propagação de variáveis: imediato após redeploy

### Q: Como vejo os logs do backend?
**A:**
1. Acesse Render Dashboard
2. Selecione `pje-robot-backend`
3. Clique em **Logs** no menu lateral
4. Procure por erros em vermelho

### Q: O erro mudou para outra mensagem
**A:** Ótimo sinal! Significa que a conexão funcionou. 
- Se for "Usuário ou senha inválidos": credenciais erradas
- Se for erro 500: problema no backend (veja logs)
- Se for erro de CORS: revise as configurações

---

## Precisa de Mais Ajuda?

Se após seguir todos estes passos ainda houver problemas:

1. **Compartilhe:**
   - Screenshot do erro completo
   - Aba Network do DevTools (F12)
   - Últimas 50 linhas dos logs do Render

2. **Informações úteis:**
   - URL do frontend (Vercel)
   - URL do backend (Render)
   - Quando o problema começou
   - Se já funcionou antes

3. **Verifique:**
   - Outros usuários conseguem acessar?
   - Funciona em outro navegador?
   - Funciona em aba anônima?

import React from 'react';

interface LineChartDataPoint {
  label: string;
  value1: number;
  value2: number;
}

interface LineChartProps {
  data: LineChartDataPoint[];
}

const LineChartBI: React.FC<LineChartProps> = ({ data }) => {
  const width = 500;
  const height = 200;
  const padding = 30;

  const maxValue1 = Math.max(...data.map(d => d.value1));
  const maxValue2 = Math.max(...data.map(d => d.value2));
  const maxValue = Math.max(maxValue1, maxValue2);

  const getX = (index: number) => padding + (index / (data.length - 1)) * (width - 2 * padding);
  const getY = (value: number) => height - padding - (value / maxValue) * (height - 2 * padding);

  const linePath1 = data.map((d, i) => `${i === 0 ? 'M' : 'L'} ${getX(i)} ${getY(d.value1)}`).join(' ');
  const linePath2 = data.map((d, i) => `${i === 0 ? 'M' : 'L'} ${getX(i)} ${getY(d.value2)}`).join(' ');

  return (
    <div className="h-full w-full flex flex-col">
        <svg viewBox={`0 0 ${width} ${height}`} className="flex-grow">
            {/* Grid lines */}
            {[...Array(5)].map((_, i) => (
            <line
                key={i}
                x1={padding}
                y1={padding + (i / 4) * (height - 2 * padding)}
                x2={width - padding}
                y2={padding + (i / 4) * (height - 2 * padding)}
                stroke="#374151" // gray-700
                strokeWidth="1"
            />
            ))}
            
            <path d={linePath1} stroke="#3b82f6" strokeWidth="2" fill="none" />
            <path d={linePath2} stroke="#22d3ee" strokeWidth="2" fill="none" />
            
            {/* X-axis labels */}
            {data.map((d, i) => (
            <text
                key={i}
                x={getX(i)}
                y={height - 10}
                textAnchor="middle"
                fontSize="10"
                fill="#9ca3af" // gray-400
            >
                {d.label}
            </text>
            ))}
        </svg>
        <div className="flex-shrink-0 flex justify-center items-center gap-4 mt-4 text-xs text-gray-400">
            <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-sm bg-blue-500"></div>
                <span>Oportunidades</span>
            </div>
            <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-sm bg-cyan-400"></div>
                <span>Fechamentos</span>
            </div>
        </div>
    </div>
  );
};

export default LineChartBI;
import React from 'react';

import { OriginData } from '../../types';

interface BarChartOriginsProps {
  data: OriginData[];
}

const BarChartOrigins: React.FC<BarChartOriginsProps> = ({ data }) => {
  const maxValue = Math.max(...data.map(d => d.value), 1); // Avoid division by zero

  return (
    <div className="h-full w-full flex flex-col justify-end">
      <div className="flex-grow flex items-end gap-2 px-2">
        {data.map((item, index) => (
          <div key={index} className="flex-1 flex flex-col items-center gap-1">
            <div 
                className="w-full bg-blue-500 rounded-t-sm" 
                style={{ height: `${(item.value / maxValue) * 100}%` }}
                title={`${item.name}: ${item.value}`}
            ></div>
          </div>
        ))}
      </div>
      <div className="flex justify-between mt-1 text-xs text-gray-500 px-2">
         {data.map((item, index) => (
            <span key={index} className="flex-1 text-center">{item.name}</span>
         ))}
      </div>
    </div>
  );
};

export default BarChartOrigins;
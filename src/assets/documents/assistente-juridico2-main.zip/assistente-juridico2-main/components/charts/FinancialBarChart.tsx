import React from 'react';

// Mock data similar to what would be expected for a financial chart
const financialData = [
  { month: 'Jan', receitas: 12000, despesas: 8000 },
  { month: 'Fev', receitas: 15000, despesas: 10000 },
  { month: 'Mar', receitas: 13000, despesas: 9500 },
  { month: 'Abr', receitas: 17000, despesas: 11000 },
  { month: 'Mai', receitas: 16000, despesas: 12000 },
  { month: 'Jun', receitas: 18000, despesas: 13000 },
];

const FinancialBarChart: React.FC = () => {
  const maxValue = Math.max(...financialData.flatMap(d => [d.receitas, d.despesas]), 1); // Avoid division by zero

  return (
    <div className="h-full w-full flex flex-col">
      <div className="flex-grow flex items-end gap-2 px-4">
        {financialData.map((item, index) => (
          <div key={index} className="flex-1 flex flex-col items-center gap-1">
            <div className="flex items-end h-full w-full gap-1">
                <div 
                    className="w-1/2 bg-blue-500 rounded-t-sm" 
                    style={{ height: `${(item.receitas / maxValue) * 100}%` }}
                    title={`Receitas: ${item.receitas.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}`}
                ></div>
                <div 
                    className="w-1/2 bg-red-500 rounded-t-sm" 
                    style={{ height: `${(item.despesas / maxValue) * 100}%` }}
                    title={`Despesas: ${item.despesas.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}`}
                ></div>
            </div>
            <span className="text-xs text-gray-500">{item.month}</span>
          </div>
        ))}
      </div>
      <div className="flex-shrink-0 flex justify-center items-center gap-4 mt-4 text-xs text-gray-400">
        <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded-sm bg-blue-500"></div>
            <span>Receitas</span>
        </div>
        <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded-sm bg-red-500"></div>
            <span>Despesas</span>
        </div>
      </div>
    </div>
  );
};

export default FinancialBarChart;

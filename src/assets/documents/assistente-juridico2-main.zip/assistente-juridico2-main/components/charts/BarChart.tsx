import React from 'react';

interface BarChartData {
  label: string;
  opportunities: number;
  closures: number;
}

interface BarChartProps {
  data: BarChartData[];
}

const BarChart: React.FC<BarChartProps> = ({ data }) => {
  const maxValue = Math.max(...data.flatMap(d => [d.opportunities, d.closures]));

  return (
    <div className="h-full w-full flex flex-col">
      <div className="flex-grow flex items-end gap-2 px-4">
        {data.map((item, index) => (
          <div key={index} className="flex-1 flex flex-col items-center gap-1">
            <div className="flex items-end h-32 w-full gap-1">
                <div 
                    className="w-1/2 bg-blue-500 rounded-t-sm" 
                    style={{ height: `${(item.opportunities / maxValue) * 100}%` }}
                    title={`Oportunidades: ${item.opportunities}`}
                ></div>
                <div 
                    className="w-1/2 bg-cyan-400 rounded-t-sm" 
                    style={{ height: `${(item.closures / maxValue) * 100}%` }}
                    title={`Fechamentos: ${item.closures}`}
                ></div>
            </div>
            <span className="text-xs text-gray-500 transform ">{item.label}</span>
          </div>
        ))}
      </div>
      <div className="flex-shrink-0 flex justify-center items-center gap-4 mt-4 text-xs text-gray-400">
        <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded-sm bg-blue-500"></div>
            <span>Oportunidades</span>
        </div>
        <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded-sm bg-cyan-400"></div>
            <span>Fechamentos</span>
        </div>
      </div>
    </div>
  );
};

export default BarChart;
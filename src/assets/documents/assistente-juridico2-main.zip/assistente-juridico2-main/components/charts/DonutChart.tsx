import React from 'react';

interface DonutChartProps {
  percentage: number;
  color?: string;
  size?: number;
  strokeWidth?: number;
  label?: string;
}

const DonutChart: React.FC<DonutChartProps> = ({ 
  percentage, 
  color = '#4ade80', 
  size = 80, 
  strokeWidth = 8,
  label
}) => {
    const radius = (size - strokeWidth) / 2;
    const viewBox = `0 0 ${size} ${size}`;
    const dashArray = radius * Math.PI * 2;
    const dashOffset = dashArray - (dashArray * percentage) / 100;

    return (
        <div className="relative" style={{ width: size, height: size }}>
            <svg width={size} height={size} viewBox={viewBox}>
                <circle
                    className="stroke-current text-gray-700"
                    cx={size / 2}
                    cy={size / 2}
                    r={radius}
                    strokeWidth={`${strokeWidth}px`}
                    fill="none"
                />
                <circle
                    className={`stroke-current`}
                    cx={size / 2}
                    cy={size / 2}
                    r={radius}
                    strokeWidth={`${strokeWidth}px`}
                    transform={`rotate(-90 ${size / 2} ${size / 2})`}
                    fill="none"
                    strokeLinecap="round"
                    strokeDasharray={dashArray}
                    strokeDashoffset={dashOffset}
                    style={{ color, transition: 'stroke-dashoffset 0.5s ease-in-out' }}
                />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-200">
                 <span className="text-lg font-semibold">{`${Math.round(percentage)}%`}</span>
                 {label && <span className="text-xs text-gray-500">{label}</span>}
            </div>
        </div>
    );
};

export default DonutChart;
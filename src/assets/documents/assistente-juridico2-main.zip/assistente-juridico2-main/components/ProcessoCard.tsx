import React from 'react';

import { Processo } from '../types';

import { ClockIcon, UserCircleIcon } from './icons/Icons';

interface ProcessoCardProps {
    processo: Processo;
    onDragStart: (e: React.DragEvent<HTMLDivElement>, processoId: string) => void;
    onDragEnd: (e: React.DragEvent<HTMLDivElement>) => void;
    onClick: (processo: Processo) => void;
}

const ProcessoCard: React.FC<ProcessoCardProps> = ({ processo, onDragStart, onDragEnd, onClick }) => {
    
    // Fallback for potentially missing 'partes'
    const poloAtivo = processo.partes?.polo_ativo || 'Parte Ativa não definida';

    return (
        <div 
            draggable
            onDragStart={(e) => onDragStart(e, processo.id)}
            onDragEnd={onDragEnd}
            onClick={() => onClick(processo)}
            className="bg-[var(--color-surface)] rounded-lg p-4 border border-[var(--color-border)] shadow-lg cursor-grab active:cursor-grabbing hover:border-[var(--color-primary)]/50 transition-colors"
            data-processo-id={processo.id}
        >
            <h4 className="font-bold text-[var(--color-text)] text-sm">{poloAtivo}</h4>
            <p className="text-xs text-blue-300 font-medium mt-1">{processo.classe_judicial}</p>
            <p className="text-xs text-[var(--color-text-muted)] font-mono mt-2">{processo.numero_cnj}</p>
            <div className="flex items-center justify-between mt-3 pt-3 border-t border-[var(--color-border)]">
                <div className="flex items-center gap-1 text-sm text-[var(--color-text-muted)]">
                     <UserCircleIcon className="w-5 h-5 text-gray-500"/>
                     <span className="text-xs">{processo.responsible || 'N/A'}</span>
                </div>
                {processo.isOverdue && (
                    <div className="flex items-center gap-1 text-red-400" title={`${processo.overdueTasks} tarefa(s) atrasada(s)`}>
                        <ClockIcon className="w-4 h-4" />
                        <span className="text-xs font-bold">{processo.overdueTasks}</span>
                    </div>
                )}
            </div>
        </div>
    );
};

export default ProcessoCard;
import React from 'react';

const ProcessoSkeleton: React.FC = () => {
    return (
        <div className="w-80 flex-shrink-0 bg-gray-900/50 rounded-xl p-3 animate-pulse">
            <div className="flex justify-between items-center mb-4 px-2">
                <div className="h-5 bg-gray-700 rounded w-24"></div>
                <div className="h-6 bg-gray-800 rounded-full w-8"></div>
            </div>
            <div className="space-y-3">
                <div className="bg-gray-800 rounded-lg p-4 border border-gray-700/50">
                    <div className="h-4 bg-gray-700 rounded w-3/4 mb-2"></div>
                    <div className="h-3 bg-gray-700 rounded w-1/2 mb-3"></div>
                    <div className="h-3 bg-gray-700 rounded w-full mb-4"></div>
                    <div className="border-t border-gray-700/50 pt-3 flex justify-between items-center">
                        <div className="h-5 bg-gray-700 rounded w-1/4"></div>
                        <div className="h-5 w-5 rounded-full bg-gray-700"></div>
                    </div>
                </div>
                <div className="bg-gray-800 rounded-lg p-4 border border-gray-700/50">
                    <div className="h-4 bg-gray-700 rounded w-3/4 mb-2"></div>
                    <div className="h-3 bg-gray-700 rounded w-1/2 mb-3"></div>
                    <div className="h-3 bg-gray-700 rounded w-full mb-4"></div>
                    <div className="border-t border-gray-700/50 pt-3 flex justify-between items-center">
                        <div className="h-5 bg-gray-700 rounded w-1/4"></div>
                        <div className="h-5 w-5 rounded-full bg-gray-700"></div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ProcessoSkeleton;

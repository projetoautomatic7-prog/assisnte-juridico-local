import React from 'react';

import { Intimacao } from '../types';

interface IntimacaoTooltipProps {
  intimacao: Intimacao;
}

const InfoRow: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <div className="flex justify-between items-center text-sm py-1.5 border-b border-gray-700/50">
    <span className="text-gray-400">{label}:</span>
    <span className="text-gray-200 font-semibold text-right">{value}</span>
  </div>
);

const IntimacaoTooltip: React.FC<IntimacaoTooltipProps> = ({ intimacao }) => {
  if (!intimacao) return null;

  return (
    <div className="absolute z-20 w-80 bg-gray-800 border border-gray-700 rounded-lg shadow-xl p-4 text-white pointer-events-none">
      <h4 className="font-bold text-blue-300 border-b border-gray-700 pb-2 mb-2">Detalhes da Intimação</h4>
      
      <div className="space-y-1">
        <InfoRow label="Processo" value={intimacao.processo.numero} />
        <InfoRow label="Partes" value={intimacao.processo.partes} />
        <InfoRow label="Grupo de Ação" value={intimacao.processo.grupoAcao} />
        <InfoRow label="Tipo de Ação" value={intimacao.processo.tipoAcao} />
        <InfoRow label="Responsável" value={intimacao.processo.responsavel} />
      </div>
    </div>
  );
};

export default IntimacaoTooltip;
// Este arquivo é obsoleto e pode ser removido.
// A lógica da Base de Conhecimento foi migrada para o store Zustand em `stores/knowledgeBaseStore.ts`.

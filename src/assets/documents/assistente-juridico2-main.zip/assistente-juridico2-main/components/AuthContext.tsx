// Este arquivo é obsoleto e pode ser removido.
// A lógica de autenticação foi migrada para o store Zustand em `stores/authStore.ts`.

import React from 'react';

import { Theme } from '../services/theme';

import { useTheme } from './ThemeProvider';

const THEMES: { value: Theme; label: string }[] = [
    { value: 'theme-dark', label: 'Dark' },
    { value: 'theme-mid', label: 'Mid' },
    { value: 'theme-light', label: 'Light' },
    { value: 'theme-corporate', label: 'Corporate' }
];

export const ThemeSwitcher: React.FC = () => {
    const { theme, setTheme } = useTheme();

    return (
        <div className="flex items-center gap-2 p-2 lg:p-0">
            <label htmlFor="theme-select" className="text-sm text-gray-400 hidden lg:block">Tema:</label>
            <select
                id="theme-select"
                value={theme}
                onChange={(e) => setTheme(e.target.value as Theme)}
                className="bg-gray-700/50 border border-gray-600 text-gray-200 text-sm rounded-md focus:ring-blue-500 focus:border-blue-500 block w-full lg:w-auto p-2"
                aria-label="Selecionar tema"
            >
                {THEMES.map(t => (
                    <option key={t.value} value={t.value}>{t.label}</option>
                ))}
            </select>
        </div>
    );
};

export default ThemeSwitcher;
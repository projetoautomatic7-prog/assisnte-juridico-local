import React from 'react';

import { Processo } from '../types';

import { XMarkIcon, ClockIcon, CalendarDaysIcon, PaperAirplaneIcon, DocumentDuplicateIcon, ArrowsRightLeftIcon } from './icons/Icons';
import './ProcessoDetalheDrawer.css';

interface ProcessoDetalheDrawerProps {
    processo: Processo | null;
    onClose: () => void;
}

const TimelineIcon: React.FC<{ type: Processo['timelineEvents'][0]['type'] }> = ({ type }) => {
    const iconMap = {
        creation: DocumentDuplicateIcon,
        phase_change: ArrowsRightLeftIcon,
        deadline: ClockIcon,
        hearing: CalendarDaysIcon,
        protocol: PaperAirplaneIcon,
    };
    const Icon = iconMap[type] || DocumentDuplicateIcon;
    return <Icon className="h-5 w-5" />;
};


const ProcessoDetalheDrawer: React.FC<ProcessoDetalheDrawerProps> = ({ processo, onClose }) => {
    const isOpen = !!processo;

    return (
        <>
            <div 
                className={`fixed inset-0 bg-black/60 z-40 transition-opacity ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} 
                onClick={onClose}
            ></div>
            <div 
                className={`fixed inset-y-0 right-0 w-full max-w-2xl bg-[var(--color-surface)] shadow-xl z-50 transform transition-transform duration-300 ease-in-out flex flex-col ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}
            >
                {processo && (
                    <>
                        <div className="flex justify-between items-center p-4 border-b border-[var(--color-border)] flex-shrink-0">
                            <div>
                                <h2 className="text-xl font-semibold text-[var(--color-text)]">{processo.partes.polo_ativo}</h2>
                                <p className="font-mono text-sm text-[var(--color-text-muted)]">{processo.numero_cnj}</p>
                            </div>
                            <button onClick={onClose} className="text-[var(--color-text-muted)] hover:text-[var(--color-text)] p-2 rounded-full hover:bg-[var(--color-muted)]">
                                <XMarkIcon className="h-6 w-6" />
                            </button>
                        </div>
                        <div className="flex-1 overflow-y-auto p-6 space-y-6">
                             {/* Informações Básicas */}
                            <div className="detail-section">
                                <h3>Informações Básicas</h3>
                                <div className="detail-grid">
                                    <div className="detail-item"><label>Classe</label><span>{processo.classe_judicial}</span></div>
                                    <div className="detail-item"><label>Assunto</label><span>{processo.assunto}</span></div>
                                    <div className="detail-item"><label>Órgão Julgador</label><span>{processo.orgao_julgador}</span></div>
                                    <div className="detail-item"><label>Distribuição</label><span>{processo.distribuicao_data}</span></div>
                                </div>
                            </div>
                            {/* Partes */}
                            <div className="detail-section">
                                <h3>Partes</h3>
                                <div className="detail-grid">
                                    <div className="detail-item"><label>Polo Ativo</label><span>{processo.partes.polo_ativo}</span></div>
                                    <div className="detail-item"><label>Polo Passivo</label><span>{processo.partes.polo_passivo}</span></div>
                                </div>
                            </div>
                            {/* Valores */}
                            <div className="detail-section">
                                <h3>Valores</h3>
                                <div className="detail-grid">
                                    <div className="detail-item"><label>Valor da Causa</label><span>{processo.value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span></div>
                                    <div className="detail-item"><label>Probabilidade</label><span>{processo.probability}</span></div>
                                </div>
                            </div>

                             {/* Linha do Tempo */}
                            <div className="detail-section">
                                <h3>Linha do Tempo</h3>
                                <div className="timeline">
                                    {processo.timelineEvents.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map((event, index) => (
                                        <div key={index} className="timeline-item">
                                            <div className="timeline-marker">
                                                <TimelineIcon type={event.type} />
                                            </div>
                                            <div className="timeline-content">
                                                <time className="timeline-date">{new Date(event.date).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' })}</time>
                                                <p className="timeline-description">{event.description}</p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </>
                )}
            </div>
        </>
    );
};

export default ProcessoDetalheDrawer;
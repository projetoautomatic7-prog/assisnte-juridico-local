import React, { useState } from 'react';

import { PremonicaoJuridica } from '../types';

import { XMarkIcon, LightBulbIcon, ScaleIcon, ChevronRightIcon, DocumentDuplicateIcon, CheckIcon } from './icons/Icons';
import LoadingSpinner from './LoadingSpinner';

interface PremonicaoModalProps {
  isOpen: boolean;
  onClose: () => void;
  isLoading: boolean;
  data: PremonicaoJuridica | null;
  error: string | null;
}

const ProbabilityMeter: React.FC<{ probability: number }> = ({ probability }) => {
    const circumference = 2 * Math.PI * 45; // 2 * pi * raio
    const offset = circumference - (probability / 100) * circumference;
    
    let colorClass = 'text-green-400';
    if (probability < 75) colorClass = 'text-yellow-400';
    if (probability < 50) colorClass = 'text-orange-400';
    if (probability < 25) colorClass = 'text-red-400';

    return (
        <div className="relative flex items-center justify-center w-32 h-32">
            <svg className="w-full h-full" viewBox="0 0 100 100">
                <circle
                    className="text-gray-700"
                    strokeWidth="8"
                    stroke="currentColor"
                    fill="transparent"
                    r="45"
                    cx="50"
                    cy="50"
                />
                <circle
                    className={`${colorClass} transition-all duration-1000 ease-out`}
                    strokeWidth="8"
                    strokeDasharray={circumference}
                    strokeDashoffset={offset}
                    strokeLinecap="round"
                    stroke="currentColor"
                    fill="transparent"
                    r="45"
                    cx="50"
                    cy="50"
                    transform="rotate(-90 50 50)"
                />
            </svg>
            <span className={`absolute text-3xl font-bold ${colorClass}`}>
                {probability}%
            </span>
        </div>
    );
};


const PremonicaoModal: React.FC<PremonicaoModalProps> = ({ isOpen, onClose, isLoading, data, error }) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (textToCopy: string, id: string) => {
    navigator.clipboard.writeText(textToCopy).then(() => {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000); // Reseta o ícone após 2 segundos
    });
  };

  return (
    <div 
        className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 transition-opacity"
        onClick={onClose}
    >
      <div 
        className="bg-gray-800 rounded-lg shadow-2xl w-full max-w-3xl border border-gray-700 m-4"
        onClick={e => e.stopPropagation()}
      >
         <div className="flex justify-between items-center p-4 border-b border-gray-700">
            <div className="flex items-center gap-3">
                <LightBulbIcon className="h-6 w-6 text-yellow-300"/>
                <h2 className="text-xl font-semibold text-gray-100">Premonição Jurídica</h2>
            </div>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-200">
                <XMarkIcon className="h-6 w-6"/>
            </button>
        </div>

        <div className="p-6 max-h-[80vh] overflow-y-auto">
            {isLoading && (
                <div className="flex flex-col items-center justify-center h-64 text-gray-400">
                    <LoadingSpinner size="10" />
                    <p className="mt-4">A IA está analisando o processo...</p>
                    <p className="text-xs text-gray-500">Isso pode levar alguns segundos.</p>
                </div>
            )}
            {error && (
                 <div className="text-center text-red-300 bg-red-900/50 p-6 rounded-lg">
                    <h3 className="font-semibold">Erro na Análise</h3>
                    <p className="text-sm mt-2">{error}</p>
                </div>
            )}
            {data && (
                <div className="space-y-6">
                    <div className="bg-gray-900/50 p-6 rounded-lg flex flex-col md:flex-row items-center gap-6">
                        <div className="flex-shrink-0">
                            <ProbabilityMeter probability={data.probabilidade_exito} />
                            <p className="text-center font-semibold text-gray-300 mt-2">Probabilidade de Êxito</p>
                        </div>
                        <div>
                            <h3 className="font-semibold text-blue-300 text-lg">Análise da IA</h3>
                            <p className="text-sm text-gray-400 mt-2">{data.analise_ia}</p>
                        </div>
                    </div>

                     <div>
                        <h3 className="font-semibold text-gray-200 mb-2">Estratégias Recomendadas</h3>
                        <ul className="space-y-2">
                        {data.estrategias_recomendadas.map((strat, index) => (
                            <li key={index} className="flex items-center justify-between gap-4 text-sm text-gray-300 bg-gray-800 p-3 rounded-md">
                                <div className="flex items-start flex-grow">
                                    <ChevronRightIcon className="h-4 w-4 text-blue-400 mr-2 mt-0.5 flex-shrink-0" />
                                    <span>{strat}</span>
                                </div>
                                <button
                                    onClick={() => handleCopy(strat, `strat-${index}`)}
                                    className="flex-shrink-0 p-1.5 rounded-md bg-gray-700/50 hover:bg-gray-700 text-gray-400 hover:text-gray-200 transition"
                                    title="Copiar Estratégia"
                                >
                                    {copiedId === `strat-${index}` ? <CheckIcon className="h-4 w-4 text-green-400" /> : <DocumentDuplicateIcon className="h-4 w-4" />}
                                </button>
                            </li>
                        ))}
                        </ul>
                    </div>

                    <div>
                        <h3 className="font-semibold text-gray-200 mb-2">Precedentes Relevantes</h3>
                        <div className="space-y-3">
                            {data.precedentes_relevantes.map(prec => (
                                <div key={prec.id} className="bg-gray-800 p-4 rounded-md border-l-4 border-gray-600">
                                    <div className="flex justify-between items-start">
                                        <div className="flex-grow pr-4">
                                            <div className="flex items-center gap-2">
                                                <ScaleIcon className="h-4 w-4 text-gray-400"/>
                                                <p className="font-bold text-sm text-gray-200">{prec.tribunal} - {prec.numero}</p>
                                            </div>
                                            <p className="text-xs text-gray-400 mt-1 font-semibold">{prec.tema}</p>
                                        </div>
                                        <button 
                                            onClick={() => {
                                                const text = `Precedente: ${prec.tribunal} - ${prec.numero}\nTema: ${prec.tema}\nResumo da Relevância: ${prec.resumo_relevancia}`;
                                                handleCopy(text, `prec-${prec.id}`);
                                            }}
                                            className="flex-shrink-0 p-1.5 rounded-md bg-gray-700/50 hover:bg-gray-700 text-gray-400 hover:text-gray-200 transition"
                                            title="Copiar Precedente"
                                        >
                                            {copiedId === `prec-${prec.id}` ? <CheckIcon className="h-4 w-4 text-green-400" /> : <DocumentDuplicateIcon className="h-4 w-4" />}
                                        </button>
                                    </div>
                                    <p className="text-xs text-gray-400 mt-2">{prec.resumo_relevancia}</p>
                                </div>
                            ))}
                        </div>
                    </div>

                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default PremonicaoModal;
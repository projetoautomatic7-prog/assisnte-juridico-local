import React, { useState, useEffect } from 'react';

import { BACKEND_URL } from '../services/api';

import { BellIcon, BellSlashIcon } from './icons/Icons';
import LoadingSpinner from './LoadingSpinner';

// This VAPID key should be generated once and stored in env.
// Frontend needs only the PUBLIC key. Backend needs PUBLIC and PRIVATE keys.
const VAPID_PUBLIC_KEY = (import.meta as any)?.env?.VITE_VAPID_PUBLIC_KEY;

// Helper function to convert the VAPID key from base64 to Uint8Array
function urlBase64ToUint8Array(base64String: string) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

const NotificationManager: React.FC = () => {
    const [permission, setPermission] = useState<NotificationPermission>('default');
    const [isSubscribed, setIsSubscribed] = useState(false);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        if (!('Notification' in window) || !('serviceWorker' in navigator) || !('PushManager' in window)) {
            setIsLoading(false);
            return;
        }

        setPermission(Notification.permission);

        navigator.serviceWorker.ready.then(registration => {
            registration.pushManager.getSubscription().then(subscription => {
                setIsSubscribed(!!subscription);
                setIsLoading(false);
            });
        });
    }, []);

    const subscribeUser = async () => {
        setIsLoading(true);
        try {
            const registration = await navigator.serviceWorker.ready;
            if (!VAPID_PUBLIC_KEY) {
                throw new Error('VITE_VAPID_PUBLIC_KEY não definido no ambiente.');
            }
            const subscription = await registration.pushManager.subscribe({
                userVisibleOnly: true,
                applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY),
            });
            
            console.log('User is subscribed:', JSON.stringify(subscription));
            
            // Send the subscription to the backend
            const token = localStorage.getItem('jwt');
            await fetch(`${BACKEND_URL}/api/notifications/subscribe`, {
              method: 'POST',
              body: JSON.stringify(subscription),
              headers: { 
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
              }
            });
            
            setIsSubscribed(true);
        } catch (error) {
            console.error('Failed to subscribe the user: ', error);
            if (Notification.permission === 'denied') {
                setPermission('denied');
            }
        } finally {
            setIsLoading(false);
        }
    };

    const handleClick = async () => {
        if (permission === 'default') {
            const newPermission = await Notification.requestPermission();
            setPermission(newPermission);
            if (newPermission === 'granted') {
                subscribeUser();
            }
        } else if (permission === 'granted' && !isSubscribed) {
            subscribeUser();
        }
    };

    const getTooltipAndColor = () => {
        if (isLoading) return { tooltip: 'Verificando status...', color: 'text-gray-500' };
        if (permission === 'denied') return { tooltip: 'Notificações bloqueadas', color: 'text-red-500' };
        if (isSubscribed) return { tooltip: 'Notificações ativadas', color: 'text-blue-400' };
        return { tooltip: 'Ativar notificações push', color: 'text-gray-400 hover:text-white' };
    };
    
    const { tooltip, color } = getTooltipAndColor();

    if (!('Notification' in window)) {
        return null; // Don't render if notifications aren't supported
    }

    const getIcon = () => {
        if (isLoading) return <LoadingSpinner size="5" />;
        if (permission === 'denied') return <BellSlashIcon className="h-6 w-6 text-red-500" />;
        if (isSubscribed) return <BellIcon className="h-6 w-6 text-blue-400" />;
        return <BellIcon className={`h-6 w-6 ${color}`} />;
    };


    return (
        <div className="flex items-center justify-center">
             <button
                onClick={handleClick}
                title={tooltip}
                disabled={isLoading || isSubscribed || permission === 'denied'}
                className="p-2 rounded-md transition-colors disabled:cursor-not-allowed"
            >
                {getIcon()}
            </button>
        </div>
    );
};

export default NotificationManager;
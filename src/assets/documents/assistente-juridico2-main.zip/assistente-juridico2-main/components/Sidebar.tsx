import React, { useState } from 'react';

import { useAppStore } from '../stores/appStore';
import { useAuthStore } from '../stores/authStore';
import { Page } from '../types';

import { HomeIcon, DocumentTextIcon, BoltIcon, MicrophoneIcon, PhotoIcon, VideoCameraIcon, CalendarDaysIcon, ScaleIcon, CpuChipIcon, BriefcaseIcon, InboxStackIcon, ClipboardDocumentCheckIcon, CurrencyDollarIcon, BookOpenIcon, NewspaperIcon, ArrowLeftOnRectangleIcon, Cog6ToothIcon, ChartPieIcon, UserGroupIcon, FolderIcon, CheckCircleIcon, ChevronUpIcon, BellIcon, GlobeAltIcon, QuestionMarkCircleIcon } from './icons/Icons';
import NotificationManager from './NotificationManager';
import ThemeSwitcher from './ThemeSwitcher';

const Sidebar: React.FC = () => {
  const { logout } = useAuthStore();
  const { activePage, setActivePage } = useAppStore();
  const [isIaMenuOpen, setIsIaMenuOpen] = useState(true);

  const mainNavItems = [
    { id: 'dashboard-home', label: 'Meu Painel', icon: HomeIcon },
    { id: 'pessoas', label: 'Pessoas', icon: UserGroupIcon },
    { id: 'acervo', label: 'CRM de Processos', icon: BriefcaseIcon },
    { id: 'intimacoes', label: 'Intimações', icon: BellIcon },
    { id: 'agenda', label: 'Agenda', icon: CalendarDaysIcon },
    { id: 'rede', label: 'Rede', icon: GlobeAltIcon },
    { id: 'modelos', label: 'Modelos', icon: FolderIcon },
    { id: 'atividades', label: 'Atividades', icon: CheckCircleIcon },
    { id: 'financial-management', label: 'Financeiro', icon: CurrencyDollarIcon },
    { id: 'gestao-bi', label: 'Gestão B.I.', icon: ChartPieIcon },
  ];

  const iaNavItems = [
     { id: 'agent-dashboard', label: 'Dashboard Agentes', icon: CpuChipIcon },
     { id: 'pje-robot', label: 'Robô PJe', icon: CpuChipIcon },
     { id: 'expedientes', label: 'Expedientes', icon: InboxStackIcon },
     { id: 'audiencias', label: 'Audiências', icon: CalendarDaysIcon },
     { id: 'datajud-checklist', label: 'Checklist Datajud', icon: ClipboardDocumentCheckIcon },
     { id: 'djen-search', label: 'Consulta DJEN', icon: NewspaperIcon },
     { id: 'document-analysis', label: 'Análise de Documentos', icon: DocumentTextIcon },
     { id: 'quick-actions', label: 'Ações Rápidas', icon: BoltIcon },
     { id: 'audio-transcription', label: 'Transcrição de Áudio', icon: MicrophoneIcon },
     { id: 'image-generation', label: 'Gerador de Imagens', icon: PhotoIcon },
     { id: 'video-analysis', label: 'Análise de Vídeo', icon: VideoCameraIcon },
     { id: 'deadline-calculator', label: 'Calculadora de Prazos', icon: CalendarDaysIcon },
     { id: 'knowledge-base', label: 'Base de Conhecimento', icon: BookOpenIcon },
  ];
  
  const settingsNavItems = [
    { id: 'settings', label: 'Configurações', icon: Cog6ToothIcon },
    { id: 'suporte', label: 'Suporte', icon: QuestionMarkCircleIcon },
  ];

  const renderNavList = (items: typeof mainNavItems) => (
      items.map((item) => {
        const isActive = activePage === item.id;
        return (
          <li key={item.id}>
            <button
              onClick={() => setActivePage(item.id as Page)}
              aria-label={item.label}
              className={`group flex items-center w-full p-3 rounded-lg transition-colors duration-200 relative ${
                isActive
                  ? 'bg-blue-900/50 text-white'
                  : 'text-gray-400 hover:text-white hover:bg-gray-800'
              }`}
            >
              {isActive && <div className="absolute left-0 top-2 bottom-2 w-1 bg-blue-400 rounded-r-full"></div>}
              <item.icon className={`h-6 w-6 flex-shrink-0 transition-colors ${
                  isActive ? 'text-blue-400' : 'text-gray-500 group-hover:text-gray-300'
              }`} />
              <span className="ml-4 font-semibold hidden lg:block">{item.label}</span>
            </button>
          </li>
        );
      })
  );


  return (
    <nav className="flex flex-col bg-gray-900/50 backdrop-blur-sm border-r border-gray-700/50 p-3 transition-all duration-300 w-20 lg:w-64">
      <div className="flex items-center gap-3 mb-8 pb-6 border-b border-gray-700/50 px-2 lg:px-0">
        <ScaleIcon className="h-8 w-8 text-blue-400 flex-shrink-0" />
        <h1 className="text-xl font-bold text-white hidden lg:block">Thiago Bodevan</h1>
      </div>
      <div className="flex-grow overflow-y-auto pr-1">
        <ul className="flex flex-col space-y-2">
          {renderNavList(mainNavItems)}
        </ul>
        
        <div className="mt-4 pt-4 border-t border-gray-700/50">
            <button 
                onClick={() => setIsIaMenuOpen(!isIaMenuOpen)}
                className="w-full flex justify-between items-center text-left text-xs font-bold uppercase text-gray-500 hover:text-gray-300 p-3 rounded-lg"
            >
                <span className="hidden lg:inline">Agentes IA</span>
                <ChevronUpIcon className={`h-5 w-5 transition-transform ${isIaMenuOpen ? 'rotate-0' : 'rotate-180'}`} />
            </button>
            {isIaMenuOpen && (
                <ul className="flex flex-col space-y-2 mt-2">
                    {renderNavList(iaNavItems as any)}
                </ul>
            )}
        </div>
        
         <div className="mt-4 pt-4 border-t border-gray-700/50">
             <ul className="flex flex-col space-y-2">
                {renderNavList(settingsNavItems as any)}
             </ul>
        </div>
      </div>


      <div className="mt-auto pt-4 border-t border-gray-700/50 flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <ThemeSwitcher />
          <NotificationManager />
        </div>
        <div>
          <button
            onClick={logout}
            aria-label="Sair"
            className="group flex items-center w-full p-3 rounded-lg transition-colors duration-200 text-gray-400 hover:text-white hover:bg-gray-800"
          >
            <ArrowLeftOnRectangleIcon className="h-6 w-6 flex-shrink-0 text-gray-500 group-hover:text-gray-300" />
            <span className="ml-4 font-semibold hidden lg:block">Sair</span>
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Sidebar;

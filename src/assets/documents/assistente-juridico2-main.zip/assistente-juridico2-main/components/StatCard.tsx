import React from 'react';

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
};

interface StatCardProps {
  title: string;
  value: string | number;
  icon?: React.FC<any>;
  colorClass?: string;
  formatAsCurrency?: boolean;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon: Icon, colorClass = 'text-white', formatAsCurrency = false }) => {
  const displayValue = formatAsCurrency && typeof value === 'number' ? formatCurrency(value) : value;

  if (Icon) {
    return (
        <div className="bg-gray-800/50 p-6 rounded-lg flex items-center gap-4">
            <div className="bg-gray-700/50 p-3 rounded-full">
                <Icon className="h-6 w-6 text-blue-400" />
            </div>
            <div>
                <p className="text-gray-400 text-sm">{title}</p>
                <p className={`text-2xl font-bold ${colorClass}`}>{displayValue}</p>
            </div>
        </div>
    );
  }

  // Version without icon (for Financial page)
  return (
    <div className="bg-gray-800/50 p-6 rounded-lg">
      <h3 className="text-sm font-medium text-gray-400">{title}</h3>
      <p className={`text-3xl font-bold mt-2 ${colorClass}`}>{displayValue}</p>
    </div>
  );
};

export default StatCard;
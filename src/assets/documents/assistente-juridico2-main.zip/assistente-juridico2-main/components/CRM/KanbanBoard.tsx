import React, { useState, useMemo } from 'react';

import { ProcessPhase } from '../../types';
import { XMarkIcon, CheckCircleIcon, ClockIcon } from '../icons/Icons';

export interface CRMCardComponentProps {
  id: string;
  cnj?: string;
  titulo: string;
  partes: { polo_ativo: string[]; polo_passivo: string[] };
  estagio: string;
  prazos: { fatal: string | null; resposta: string | null };
  status: string;
  valor?: number;
  onDragStart: (e: React.DragEvent, cardId: string) => void;
  onDragEnd: (e: React.DragEvent) => void;
  onClick: () => void;
}

/**
 * Card individual de processo no CRM Kanban
 */
export const CRMCard: React.FC<CRMCardComponentProps> = ({
  id,
  cnj,
  titulo,
  partes,
  estagio,
  prazos,
  status,
  valor,
  onDragStart,
  onDragEnd,
  onClick,
}) => {
  const isOverdue = prazos.fatal && new Date(prazos.fatal) < new Date();
  const diasRestantes = prazos.fatal
    ? Math.ceil((new Date(prazos.fatal).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))
    : null;

  return (
    <div
      draggable
      onDragStart={(e) => onDragStart(e, id)}
      onDragEnd={onDragEnd}
      onClick={onClick}
      data-processo-id={id}
      className={`
        p-3 rounded-lg cursor-move transition-all duration-200
        border-l-4 bg-gray-800/60 hover:bg-gray-800/80 backdrop-blur
        ${
          isOverdue
            ? 'border-red-500 shadow-lg shadow-red-500/20'
            : status === 'completado'
              ? 'border-green-500 shadow-lg shadow-green-500/20'
              : 'border-blue-500 shadow-lg shadow-blue-500/20'
        }
        active:scale-95 transition-transform
      `}
    >
      {/* Header com CNJ */}
      <div className="flex justify-between items-start mb-2">
        <div className="flex-1">
          <h4 className="text-sm font-semibold text-gray-100 line-clamp-2">{titulo}</h4>
          {cnj && <p className="text-xs text-gray-400 font-mono">{cnj}</p>}
        </div>
        <div
          className={`
            text-xs px-2 py-1 rounded-full font-bold
            ${
              isOverdue
                ? 'bg-red-500/20 text-red-300'
                : status === 'completado'
                  ? 'bg-green-500/20 text-green-300'
                  : 'bg-blue-500/20 text-blue-300'
            }
          `}
        >
          {status}
        </div>
      </div>

      {/* Partes */}
      {(partes.polo_ativo.length > 0 || partes.polo_passivo.length > 0) && (
        <div className="mb-2 text-xs text-gray-400 line-clamp-1">
          <span className="text-gray-500">vs.</span>{' '}
          {partes.polo_ativo.slice(0, 1).join(', ')} vs {partes.polo_passivo.slice(0, 1).join(', ')}
        </div>
      )}

      {/* Prazos e Valor */}
      <div className="flex items-center justify-between gap-2 text-xs">
        {prazos.fatal && (
          <div className="flex items-center gap-1">
            <ClockIcon className={`w-3 h-3 ${isOverdue ? 'text-red-400' : 'text-yellow-400'}`} />
            <span className={isOverdue ? 'text-red-400' : 'text-yellow-400'}>
              {diasRestantes ? (diasRestantes > 0 ? `${diasRestantes}d` : 'Vencido') : 'N/A'}
            </span>
          </div>
        )}

        {valor && (
          <div className="text-emerald-400 font-semibold">
            R$ {(valor / 1000).toFixed(1)}k
          </div>
        )}
      </div>

      {/* Estágio */}
      <div className="mt-2 pt-2 border-t border-gray-700/50 text-xs text-gray-500">
        {estagio}
      </div>
    </div>
  );
};

export interface CRMColumnProps {
  stage: string;
  cards: CRMCardComponentProps[];
  isDragOver: boolean;
  onDragStart: (e: React.DragEvent, cardId: string) => void;
  onDrop: (e: React.DragEvent, stage: string) => void;
  onDragEnd: (e: React.DragEvent) => void;
  onCardClick: (card: CRMCardComponentProps) => void;
  onDragEnter: (e: React.DragEvent, stage: string) => void;
}

/**
 * Coluna do Kanban para cada estágio
 */
export const CRMColumn: React.FC<CRMColumnProps> = ({
  stage,
  cards,
  isDragOver,
  onDragStart,
  onDrop,
  onDragEnd,
  onCardClick,
  onDragEnter,
}) => {
  const totalValue = useMemo(() => cards.reduce((sum, card) => sum + (card.valor || 0), 0), [cards]);
  const overduedCount = useMemo(() => cards.filter((c) => c.prazos.fatal && new Date(c.prazos.fatal) < new Date()).length, [cards]);

  return (
    <div
      className={`
        w-80 flex-shrink-0 rounded-xl p-3 transition-all duration-200
        ${isDragOver ? 'bg-blue-900/40 ring-2 ring-blue-500/50' : 'bg-gray-900/50'}
        backdrop-blur border border-gray-700/30
      `}
      onDragOver={(e) => e.preventDefault()}
      onDragEnter={(e) => onDragEnter(e, stage)}
      onDrop={(e) => onDrop(e, stage)}
    >
      {/* Header da Coluna */}
      <div className="flex justify-between items-center mb-4 px-2">
        <div>
          <h3 className="font-semibold text-gray-200 text-sm">{stage}</h3>
          <p className="text-xs text-gray-500">
            {cards.length} card{cards.length !== 1 ? 's' : ''}
            {overduedCount > 0 && <span className="text-red-400 ml-1">• {overduedCount} atraso</span>}
          </p>
        </div>
        <div className="text-right">
          <div className="text-xs font-bold text-emerald-400">
            R$ {(totalValue / 1000).toFixed(1)}k
          </div>
        </div>
      </div>

      {/* Área de Drop */}
      <div
        className={`
          h-full min-h-96 overflow-y-auto space-y-3 p-1 rounded-lg
          border-2 border-dashed transition-colors duration-200
          ${isDragOver ? 'border-blue-500 bg-blue-900/10' : 'border-gray-700/50'}
        `}
      >
        {cards.map((card) => (
          <CRMCard
            key={card.id}
            {...card}
            onDragStart={onDragStart}
            onDragEnd={onDragEnd}
            onClick={() => onCardClick(card)}
          />
        ))}

        {cards.length === 0 && (
          <div className="flex items-center justify-center h-24 text-sm text-gray-600">
            📭 Nenhum processo aqui
          </div>
        )}
      </div>
    </div>
  );
};

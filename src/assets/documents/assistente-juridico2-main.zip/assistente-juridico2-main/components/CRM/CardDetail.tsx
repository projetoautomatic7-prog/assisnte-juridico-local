import React, { useState } from 'react';

import { CRMCard as CRMCardType } from '../../types';
import { XMarkIcon, PlusIcon } from '../icons/Icons';

interface CRMCardDetailProps {
  card: CRMCardType;
  onClose: () => void;
  onSave: (card: CRMCardType) => void;
}

/**
 * Drawer/Modal detalhado de um card CRM
 */
export const CRMCardDetail: React.FC<CRMCardDetailProps> = ({ card, onClose, onSave }) => {
  const [editMode, setEditMode] = useState(false);
  const [formData, setFormData] = useState(card);

  const handleAddAnnotation = (newNote: string) => {
    const updated = {
      ...formData,
      anotacoes: formData.anotacoes + '\n' + newNote,
    };
    setFormData(updated);
  };

  const handleSave = () => {
    onSave(formData);
    setEditMode(false);
  };

  const isOverdue = card.prazos.fatal && new Date(card.prazos.fatal) < new Date();

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />

      <div className="absolute right-0 top-0 h-full w-full max-w-xl bg-gray-900 border-l border-gray-700 shadow-2xl overflow-y-auto">
        {/* Header */}
        <div className={`sticky top-0 p-6 border-b border-gray-700/50 backdrop-blur-sm bg-gray-900/80 ${isOverdue ? 'border-red-500/50 bg-red-900/10' : ''}`}>
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <h2 className="text-2xl font-bold text-gray-100 mb-1">{card.titulo}</h2>
              {card.cnj && <p className="text-sm text-gray-400 font-mono">{card.cnj}</p>}
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
            >
              <XMarkIcon className="w-5 h-5 text-gray-400" />
            </button>
          </div>
        </div>

        {/* Conteúdo */}
        <div className="p-6 space-y-6">
          {/* Status e Fase */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-gray-400 uppercase">Fase</label>
              <div className="mt-1 text-lg text-blue-400 font-semibold">{card.fase}</div>
            </div>
            <div>
              <label className="text-xs font-semibold text-gray-400 uppercase">Estágio</label>
              <div className="mt-1 text-lg text-purple-400 font-semibold">{card.estagio}</div>
            </div>
            <div>
              <label className="text-xs font-semibold text-gray-400 uppercase">Status</label>
              <div className={`mt-1 text-lg font-semibold ${
                card.status === 'completado' ? 'text-green-400' :
                card.status === 'arquivado' ? 'text-gray-500' :
                'text-yellow-400'
              }`}>
                {card.status}
              </div>
            </div>
            <div>
              <label className="text-xs font-semibold text-gray-400 uppercase">Valor</label>
              <div className="mt-1 text-lg text-emerald-400 font-semibold">
                R$ {card.valor ? (card.valor / 1000).toFixed(1) + 'k' : '—'}
              </div>
            </div>
          </div>

          {/* Prazos */}
          <div className="bg-gray-800/30 rounded-lg p-4 border border-gray-700/30">
            <h3 className="font-semibold text-gray-200 mb-3">⏰ Prazos</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">Prazo Fatal:</span>
                <span className={`font-semibold ${isOverdue ? 'text-red-400' : 'text-yellow-400'}`}>
                  {card.prazos.fatal ? new Date(card.prazos.fatal).toLocaleDateString('pt-BR') : '—'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Prazo Resposta:</span>
                <span className="font-semibold text-gray-300">
                  {card.prazos.resposta ? new Date(card.prazos.resposta).toLocaleDateString('pt-BR') : '—'}
                </span>
              </div>
            </div>
          </div>

          {/* Partes */}
          <div className="bg-gray-800/30 rounded-lg p-4 border border-gray-700/30">
            <h3 className="font-semibold text-gray-200 mb-3">👥 Partes</h3>
            <div className="space-y-2">
              <div>
                <p className="text-xs text-gray-400 uppercase font-semibold mb-1">Polo Ativo</p>
                {card.partes.polo_ativo.map((parte, i) => (
                  <p key={i} className="text-sm text-blue-300">✓ {parte}</p>
                ))}
              </div>
              <div className="border-t border-gray-700/30 pt-2">
                <p className="text-xs text-gray-400 uppercase font-semibold mb-1">Polo Passivo</p>
                {card.partes.polo_passivo.map((parte, i) => (
                  <p key={i} className="text-sm text-red-300">✗ {parte}</p>
                ))}
              </div>
            </div>
          </div>

          {/* Anotações */}
          <div className="bg-gray-800/30 rounded-lg p-4 border border-gray-700/30">
            <h3 className="font-semibold text-gray-200 mb-3">📝 Anotações</h3>
            <textarea
              value={formData.anotacoes}
              onChange={(e) => setFormData({ ...formData, anotacoes: e.target.value })}
              className="w-full h-32 bg-gray-900/50 border border-gray-700 rounded p-2 text-sm text-gray-100 focus:border-blue-500 focus:outline-none resize-none"
              placeholder="Adicione notas sobre o processo..."
            />
          </div>

          {/* Minutas */}
          {card.minutas && card.minutas.length > 0 && (
            <div className="bg-gray-800/30 rounded-lg p-4 border border-gray-700/30">
              <h3 className="font-semibold text-gray-200 mb-3">📄 Minutas</h3>
              <div className="space-y-2">
                {card.minutas.map((minuta, i) => (
                  <a
                    key={i}
                    href={minuta}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-blue-400 hover:text-blue-300 underline block truncate"
                  >
                    📎 Minuta {i + 1}
                  </a>
                ))}
              </div>
            </div>
          )}

          {/* Automações IA */}
          {card.autoAtomacoes && (
            <div className="bg-blue-900/20 rounded-lg p-4 border border-blue-700/30">
              <h3 className="font-semibold text-blue-300 mb-2">🤖 Sugestões IA</h3>
              <p className="text-xs text-blue-400 mb-2">Status: {card.autoAtomacoes.statusIA}</p>
              <ul className="text-sm text-blue-200 space-y-1">
                {card.autoAtomacoes.sugestaoAcoes.map((acao, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span>→</span>
                    <span>{acao}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 p-6 bg-gray-900/80 border-t border-gray-700/50 backdrop-blur-sm flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-200 rounded-lg transition-colors font-medium"
          >
            Fechar
          </button>
          <button
            onClick={handleSave}
            className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition-colors font-medium"
          >
            💾 Salvar
          </button>
        </div>
      </div>
    </div>
  );
};

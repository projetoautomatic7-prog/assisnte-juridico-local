import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
  }

  private handleReload = () => {
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          height: '100vh',
          backgroundColor: '#0b1220',
          color: '#e5e7eb',
          fontFamily: 'sans-serif',
          padding: '2rem'
        }}>
          <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#ef4444' }}>Ocorreu um Erro Inesperado</h1>
          <p style={{ marginTop: '1rem', color: '#a3b1c6', textAlign: 'center' }}>
            A aplicação encontrou um problema e não pôde continuar.
          </p>
          <p style={{ marginTop: '0.5rem', color: '#a3b1c6', textAlign: 'center' }}>
            Nossa equipe foi notificada. Tente recarregar a página.
          </p>
          <button
            onClick={this.handleReload}
            style={{
              marginTop: '1.5rem',
              padding: '0.75rem 1.5rem',
              backgroundColor: '#60a5fa',
              color: '#0b1220',
              border: 'none',
              borderRadius: '0.5rem',
              fontWeight: 'bold',
              cursor: 'pointer'
            }}
          >
            Recarregar a Página
          </button>
          {this.state.error && (
             <details style={{ marginTop: '1.5rem', color: '#64748b', fontSize: '0.8rem', width: '100%', maxWidth: '600px' }}>
                <summary>Detalhes do Erro</summary>
                <pre style={{ 
                    backgroundColor: '#101826',
                    padding: '1rem',
                    borderRadius: '0.5rem',
                    marginTop: '0.5rem',
                    whiteSpace: 'pre-wrap',
                    wordBreak: 'break-all',
                    maxHeight: '200px',
                    overflowY: 'auto'
                }}>
                    {this.state.error.toString()}
                </pre>
            </details>
          )}
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;

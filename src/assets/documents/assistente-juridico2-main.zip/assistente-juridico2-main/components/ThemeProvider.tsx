import React, { createContext, useState, useContext, useEffect, useCallback, ReactNode } from 'react';

import { Theme, getInitialTheme, applyTheme, persistTheme } from '../services/theme';

interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [theme, _setTheme] = useState<Theme>(getInitialTheme);

  // Sync React state with the DOM on initial client-side load.
  // The anti-FOUC script in index.html handles the very first paint.
  useEffect(() => {
    // Defer to next tick to avoid calling setState synchronously during render
    const id = setTimeout(() => _setTheme(getInitialTheme()), 0);
    return () => clearTimeout(id);
  }, []);

  const setTheme = useCallback((newTheme: Theme) => {
    persistTheme(newTheme);
    applyTheme(newTheme);
    _setTheme(newTheme);
  }, []);

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};
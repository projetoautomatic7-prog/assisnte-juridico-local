import React from 'react';

interface PageTitleProps {
  title: string;
  description: string;
}

const PageTitle: React.FC<PageTitleProps> = ({ title, description }) => {
  return (
    <div className="mb-8">
      <h1 className="text-3xl font-bold text-gray-100 tracking-tight">{title}</h1>
      <p className="mt-2 text-gray-400">{description}</p>
    </div>
  );
};

export default PageTitle;

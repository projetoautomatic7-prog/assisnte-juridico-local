# 🚀 GUIA RÁPIDO: Conectar Vercel ao Render

## ⚠️ AÇÃO IMEDIATA NECESSÁRIA

Este guia irá resolver o problema de conexão entre o frontend (Vercel) e backend (Render) em **5 minutos**.

---

## 🎯 Problema

Seu frontend no Vercel não consegue conectar ao backend no Render porque a configuração de CORS está incorreta.

**Sintomas:**
- ❌ Erro CORS no console do navegador
- ❌ Login não funciona
- ❌ Erro 401 Unauthorized
- ❌ APIs não respondem

---

## ✅ Solução (2 Passos Simples)

### PASSO 1: Configurar Backend no Render ⚡ (PRIORITÁRIO)

1. **Acesse**: https://dashboard.render.com/
2. **Clique** no serviço: `pje-robot-backend`
3. **No menu lateral**, clique em: `Environment`
4. **Procure** a variável: `FRONTEND_ORIGIN`
5. **Clique no lápis** para editar
6. **Cole este valor** (substitua o antigo):
   ```
   https://assistente-jurídico-sandy.vercel.app,https://assistente-jurídico-git-main-thiagos-projects-9834ca6f.vercel.app,http://localhost:5173
   ```
7. **Clique**: `Save Changes`
8. **Aguarde** 2-5 minutos (o Render fará redeploy automaticamente)
9. **Verifique** que o deploy completou (logs mostram: `🚀 Servidor backend rodando na porta 10000`)

### PASSO 2: Verificar Frontend no Vercel ✅ (OPCIONAL)

1. **Acesse**: https://vercel.com/dashboard
2. **Clique** no projeto: `assistente-jurídico`
3. **Vá em**: `Settings` → `Environment Variables`
4. **Verifique** se existe: `VITE_BACKEND_URL`
   - **Valor correto**: `https://assistente-juridico-rs1e.onrender.com`
   - **Se não existe ou está errado**: adicione/corrija
   - **Selecione**: Production, Preview, Development
   - **Clique**: `Save`
5. **SE VOCÊ ALTEROU ALGO**: faça redeploy
   - Vá em `Deployments`
   - Clique nos 3 pontos `...` da última deployment
   - Clique `Redeploy`
   - Aguarde 30-60 segundos

---

## 🧪 Teste (30 segundos)

1. **Abra** seu site: https://assistente-jurídico-sandy.vercel.app
2. **Pressione** `F12` (abre o console)
3. **Cole e execute** no console:
   ```javascript
   fetch('https://assistente-juridico-rs1e.onrender.com/health')
     .then(r => r.json())
     .then(d => console.log('✅ SUCESSO:', d))
     .catch(e => console.error('❌ ERRO:', e))
   ```
4. **Resultado esperado**:
   ```
   ✅ SUCESSO: {status: "ok", timestamp: "..."}
   ```

5. **Teste o login** normalmente

---

## ❓ Se Não Funcionar

### Erro CORS ainda aparece?
**Solução**: Verifique se você colocou o valor EXATO no FRONTEND_ORIGIN do Render (PASSO 1)

### Backend não responde?
**Causa**: Serviço dormindo (Free tier)
**Solução**: Acesse `https://assistente-juridico-rs1e.onrender.com/health` e aguarde 30-60s

### Variável de ambiente não carrega no Vercel?
**Causa**: Não fez redeploy
**Solução**: Vá em Deployments → ... → Redeploy

---

## 📚 Documentação Completa

Precisa de mais detalhes? Consulte:

| Arquivo | Quando Usar |
|---------|-------------|
| **PASSOS_MANUAIS_DEPLOY.md** | Instruções detalhadas passo a passo |
| **CONFIGURACAO_VERCEL_RENDER.md** | Documentação técnica completa + troubleshooting |
| **RESUMO_CORRECAO_CONEXAO.md** | Resumo executivo das mudanças |

---

## ✅ Checklist Final

- [ ] Atualizei FRONTEND_ORIGIN no Render
- [ ] Aguardei o redeploy do backend completar
- [ ] Verifiquei que `/health` responde
- [ ] Verifiquei VITE_BACKEND_URL no Vercel (se necessário)
- [ ] Teste do console mostra ✅ SUCESSO
- [ ] Login funciona sem erros

---

## 🎉 Pronto!

Após completar os passos:
- ✅ Frontend conecta ao backend
- ✅ Login funciona
- ✅ APIs respondem normalmente
- ✅ Sem erros CORS

**Observação**: O backend roda na porta 10000 no Render, mas você não precisa especificar a porta na URL. Use apenas: `https://assistente-juridico-rs1e.onrender.com`

---

**Criado em**: 2025-11-14  
**Problema**: Conexão Vercel ↔️ Render  
**Status**: ✅ Resolvido (requer configuração manual no dashboard)

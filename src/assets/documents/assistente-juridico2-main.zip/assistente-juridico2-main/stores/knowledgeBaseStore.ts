import { create } from 'zustand';

import { authenticatedFetch, BACKEND_URL } from '../services/api';

interface KnowledgeBaseState {
    isIndexing: boolean;
    indexSuccess: string | null;
    indexError: string | null;
    isSearching: boolean;
    searchResult: { answer: string; sources: any[] } | null;
    searchError: string | null;
    indexText: (text: string) => Promise<void>;
    searchText: (query: string, context: string | null) => Promise<void>;
    resetSearch: () => void;
}

export const useKnowledgeBaseStore = create<KnowledgeBaseState>((set) => ({
    isIndexing: false,
    indexSuccess: null,
    indexError: null,
    isSearching: false,
    searchResult: null,
    searchError: null,

    indexText: async (text) => {
        set({ isIndexing: true, indexSuccess: null, indexError: null });
        try {
            const response = await authenticatedFetch(`${BACKEND_URL}/api/memory/index`, {
                method: 'POST',
                body: JSON.stringify({ text }),
            });
            if (!response.ok) {
                throw new Error('Falha ao indexar.');
            }
            const result = await response.json();
            set({ indexSuccess: result.message });
        } catch (err) {
            set({ indexError: (err as Error).message });
        } finally {
            set({ isIndexing: false });
        }
    },

    searchText: async (query, context) => {
        set({ isSearching: true, searchResult: null, searchError: null });
        try {
            const contextualQuery = context ? `No contexto do processo ${context}, ${query}` : query;
            const response = await authenticatedFetch(`${BACKEND_URL}/api/memory/search`, {
                method: 'POST',
                body: JSON.stringify({ query: contextualQuery }),
            });
            if (!response.ok) {
                throw new Error('Falha na busca.');
            }
            const result = await response.json();
            set({ searchResult: result });
        } catch (err) {
            set({ searchError: (err as Error).message });
        } finally {
            set({ isSearching: false });
        }
    },

    resetSearch: () => {
        set({ searchResult: null, searchError: null });
    },
}));
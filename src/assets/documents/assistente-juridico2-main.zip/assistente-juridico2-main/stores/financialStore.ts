import { create } from 'zustand';

import { authenticatedFetch, BACKEND_URL } from '../services/api';
import { Transaction } from '../types';

type SortConfig = { key: keyof Transaction; direction: 'asc' | 'desc' };

interface FinancialState {
    transactions: Transaction[];
    isLoading: boolean;
    error: string | null;
    sortConfig: SortConfig | null;
    summary: { revenue: number; expenses: number; receivable: number; netBalance: number };
    fetchTransactions: () => Promise<void>;
    saveTransaction: (transactionData: Omit<Transaction, 'id'>, id?: string) => Promise<void>;
    deleteTransaction: (id: string) => Promise<void>;
    requestSort: (key: keyof Transaction) => void;
}

const calculateSummary = (transactions: Transaction[]) => {
    const summary = transactions.reduce((acc, t) => {
        if (t.type === 'credit') acc.revenue += t.amount;
        if (t.type === 'debit') acc.expenses += t.amount;
        if (t.type === 'credit' && t.status === 'pending') acc.receivable += t.amount;
        return acc;
    }, { revenue: 0, expenses: 0, receivable: 0 });
    const netBalance = summary.revenue - summary.expenses;
    return { ...summary, netBalance };
};

export const useFinancialStore = create<FinancialState>((set, get) => ({
    transactions: [],
    isLoading: true,
    error: null,
    sortConfig: { key: 'date', direction: 'desc' },
    summary: { revenue: 0, expenses: 0, receivable: 0, netBalance: 0 },
    
    fetchTransactions: async () => {
        set({ isLoading: true, error: null });
        try {
            const response = await authenticatedFetch(`${BACKEND_URL}/api/data/financeiro`);
            if (!response.ok) throw new Error('Falha ao buscar transações.');
            const data: Transaction[] = await response.json();
            set({ 
                transactions: data, 
                isLoading: false,
                summary: calculateSummary(data)
            });
        } catch (err) {
            set({ error: (err as Error).message, isLoading: false });
        }
    },

    saveTransaction: async (transactionData, id) => {
        const method = id ? 'PUT' : 'POST';
        const url = id ? `${BACKEND_URL}/api/data/financeiro/${id}` : `${BACKEND_URL}/api/data/financeiro`;

        try {
            const response = await authenticatedFetch(url, {
                method,
                body: JSON.stringify(transactionData),
            });
            if (!response.ok) throw new Error('Falha ao salvar transação.');
            const savedTransaction = await response.json();

            const newTransactions = id
                ? get().transactions.map(t => t.id === id ? savedTransaction : t)
                : [savedTransaction, ...get().transactions];
            
            set({ 
                transactions: newTransactions,
                summary: calculateSummary(newTransactions) 
            });
        } catch (err) {
            console.error("Failed to save transaction", err);
            set({ error: 'Falha ao salvar a transação.' });
        }
    },

    deleteTransaction: async (id) => {
        if (!window.confirm('Tem certeza que deseja excluir esta transação?')) return;
        try {
            const response = await authenticatedFetch(`${BACKEND_URL}/api/data/financeiro/${id}`, {
                method: 'DELETE',
            });
            if (!response.ok && response.status !== 204) throw new Error('Falha ao excluir transação.');
            
            const newTransactions = get().transactions.filter(t => t.id !== id);
            set({ 
                transactions: newTransactions,
                summary: calculateSummary(newTransactions)
            });
        } catch (err) {
             console.error("Failed to delete transaction", err);
            set({ error: 'Falha ao excluir a transação.' });
        }
    },
    
    requestSort: (key) => {
        const currentConfig = get().sortConfig;
        let direction: 'asc' | 'desc' = 'asc';
        if (currentConfig && currentConfig.key === key && currentConfig.direction === 'asc') {
            direction = 'desc';
        }
        set({ sortConfig: { key, direction } });
    },
}));

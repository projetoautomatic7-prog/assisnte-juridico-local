import { create } from 'zustand';

import { authenticatedFetch, BACKEND_URL } from '../services/api';
import { DjenPublication } from '../types';

interface DjenState {
    results: DjenPublication[];
    isLoading: boolean;
    error: string | null;
    searchDjen: (params: { date: string; tribunals: string[]; name: string; oab: string }) => Promise<void>;
}

export const useDjenStore = create<DjenState>((set) => ({
    results: [],
    isLoading: false,
    error: null,

    searchDjen: async (params) => {
        set({ isLoading: true, error: null, results: [] });
        try {
            const response = await authenticatedFetch(`${BACKEND_URL}/api/robot/djen-search`, {
                method: 'POST',
                body: JSON.stringify(params),
            });
            if (!response.ok) {
                const errData = await response.json();
                throw new Error(errData.message || 'Erro do servidor ao buscar publicações.');
            }
            const data = await response.json();
            set({ results: data, isLoading: false });
        } catch (err) {
            set({ error: (err as Error).message, isLoading: false });
        }
    },
}));
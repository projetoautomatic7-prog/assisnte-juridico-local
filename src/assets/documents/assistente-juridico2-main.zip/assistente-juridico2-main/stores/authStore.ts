import { create } from 'zustand';

import { BACKEND_URL } from '../services/api';

interface AuthState {
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login: (user: string, pass: string) => Promise<boolean>;
  googleLogin: (idToken: string) => Promise<boolean>;
  localLogin: (user: string, pass: string) => boolean;
  logout: () => void;
  checkAuth: () => void;
}

// Credenciais padrão para acesso local
const DEFAULT_USERS = [
  { username: 'admin', password: 'admin123' },
  { username: 'demo', password: 'demo' },
  { username: 'usuario', password: '123456' }
];

export const useAuthStore = create<AuthState>((set) => ({
  isAuthenticated: false,
  isLoading: true, // Começa com loading true para checar a autenticação inicial
  error: null,
  
  checkAuth: () => {
    const token = localStorage.getItem('jwt');
    const localAuth = localStorage.getItem('localAuth');
    if (token || localAuth) {
      // Para um app mais seguro, você verificaria o token com o backend aqui.
      set({ isAuthenticated: true, isLoading: false });
    } else {
      set({ isAuthenticated: false, isLoading: false });
    }
  },

  // Login local simplificado - não requer backend
  localLogin: (user: string, pass: string) => {
    const validUser = DEFAULT_USERS.find(
      u => u.username === user && u.password === pass
    );
    
    if (validUser) {
      localStorage.setItem('localAuth', 'true');
      localStorage.setItem('username', user);
      
      // Generate a simple JWT-like token for local auth
      // This allows the frontend to work with authenticatedFetch
      const payload = {
        sub: user,
        type: 'local',
        iat: Date.now()
      };
      const localToken = btoa(JSON.stringify(payload));
      localStorage.setItem('jwt', `local_${localToken}`);
      
      set({ isAuthenticated: true, isLoading: false, error: null });
      return true;
    }
    
    set({ error: 'Usuário ou senha inválidos.', isLoading: false });
    return false;
  },

  login: async (user: string, pass: string) => {
    set({ isLoading: true, error: null });
    
    // Primeiro, tenta login local
    const localSuccess = useAuthStore.getState().localLogin(user, pass);
    if (localSuccess) {
      return true;
    }
    
    // Se o login local falhar, tenta o backend (se disponível)
    try {
      const response = await fetch(`${BACKEND_URL}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: user, password: pass }),
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.message || 'Usuário ou senha inválidos.');
      }
      
      const { token } = await response.json();
      localStorage.setItem('jwt', token);
      set({ isAuthenticated: true, isLoading: false, error: null });
      return true;
    } catch (error) {
      console.error("Backend login failed, fallback handled", error);
      // Erro já foi definido pelo localLogin
      set({ isLoading: false });
      return false;
    }
  },

  googleLogin: async (idToken: string) => {
    set({ isLoading: true, error: null });
    try {
      const response = await fetch(`${BACKEND_URL}/api/auth/google`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken }),
      });

      if (!response.ok) {
         const err = await response.json();
        throw new Error(err.message || 'Falha no login com o Google.');
      }
      
      const { token } = await response.json();
      localStorage.setItem('jwt', token);
      set({ isAuthenticated: true, isLoading: false, error: null });
      return true;
    } catch (error) {
      console.error("Google Login API call failed", error);
      set({ error: 'Falha no login com o Google. Tente o login padrão.', isLoading: false });
      return false;
    }
  },

  logout: () => {
    localStorage.removeItem('jwt');
    localStorage.removeItem('localAuth');
    localStorage.removeItem('username');
    set({ isAuthenticated: false });
  },
}));

// Realiza a checagem de autenticação inicial quando o store é carregado
useAuthStore.getState().checkAuth();

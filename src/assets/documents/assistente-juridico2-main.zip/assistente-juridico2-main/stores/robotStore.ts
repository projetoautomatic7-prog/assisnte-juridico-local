import { create } from 'zustand';

import { PjeRobotLog, ProcessedNotification, RobotStatus, SessionStatus, WsConnectionStatus, ConnectionStep } from '../types';

interface RobotState {
    robotStatus: RobotStatus;
    sessionStatus: SessionStatus;
    wsConnectionStatus: WsConnectionStatus;
    connectionStep: ConnectionStep;
    logs: PjeRobotLog[];
    results: ProcessedNotification[];
    history: ProcessedNotification[];
    uptime: number;
    appError: string | null;
    is2faRequired: boolean;
    isSessionExpiredModalOpen: boolean;
    isAuthenticated: boolean;
    loginError: string | null;
    twoFactorError: string | null;
    isSubmitting2fa: boolean;

    setRobotStatus: (status: RobotStatus) => void;
    setSessionStatus: (status: SessionStatus) => void;
    setWsConnectionStatus: (status: WsConnectionStatus) => void;
    setConnectionStep: (step: ConnectionStep) => void;
    addLog: (log: PjeRobotLog) => void;
    setLogs: (logs: PjeRobotLog[]) => void;
    setResults: (results: ProcessedNotification[] | ((prev: ProcessedNotification[]) => ProcessedNotification[])) => void;
    setHistory: (history: ProcessedNotification[] | ((prev: ProcessedNotification[]) => ProcessedNotification[])) => void;
    setUptime: (uptime: number) => void;
    setAppError: (error: string | null) => void;
    setIs2faRequired: (required: boolean) => void;
    setIsSessionExpiredModalOpen: (isOpen: boolean) => void;
    setIsAuthenticated: (authenticated: boolean) => void;
    setLoginError: (error: string | null) => void;
    setTwoFactorError: (error: string | null) => void;
    setIsSubmitting2fa: (isSubmitting: boolean) => void;
    resetConnectionState: () => void;
    resetOnDisconnect: () => void;
}

export const useRobotStore = create<RobotState>((set) => ({
    robotStatus: 'inactive',
    sessionStatus: 'disconnected',
    wsConnectionStatus: 'connecting',
    connectionStep: 'idle',
    logs: [],
    results: [],
    history: [],
    uptime: 0,
    appError: null,
    is2faRequired: false,
    isSessionExpiredModalOpen: false,
    isAuthenticated: false,
    loginError: null,
    twoFactorError: null,
    isSubmitting2fa: false,

    setRobotStatus: (status) => set({ robotStatus: status }),
    setSessionStatus: (status) => set({ sessionStatus: status }),
    setWsConnectionStatus: (status) => set({ wsConnectionStatus: status }),
    setConnectionStep: (step) => set({ connectionStep: step }),
    addLog: (log) => set((state) => ({ logs: [...state.logs.slice(-199), log] })),
    setLogs: (logs) => set({ logs }),
    setResults: (results) => set(state => ({ results: typeof results === 'function' ? results(state.results) : results })),
    setHistory: (history) => set(state => ({ history: typeof history === 'function' ? history(state.history) : history })),
    setUptime: (uptime) => set({ uptime }),
    setAppError: (error) => set({ appError: error }),
    setIs2faRequired: (required) => set({ is2faRequired: required }),
    setIsSessionExpiredModalOpen: (isOpen) => set({ isSessionExpiredModalOpen: isOpen }),
    setIsAuthenticated: (authenticated) => set({ isAuthenticated: authenticated }),
    setLoginError: (error) => set({ loginError: error }),
    setTwoFactorError: (error) => set({ twoFactorError: error }),
    setIsSubmitting2fa: (isSubmitting) => set({ isSubmitting2fa: isSubmitting }),
    resetConnectionState: () => set({ robotStatus: 'inactive', connectionStep: 'idle' }),
    resetOnDisconnect: () => set({
        isAuthenticated: false,
        is2faRequired: false,
        logs: [],
        results: [],
        history: [],
        uptime: 0,
        appError: null,
        robotStatus: 'inactive',
        sessionStatus: 'disconnected',
        connectionStep: 'idle',
    }),
}));

import { create } from 'zustand';

import { authenticatedFetch, BACKEND_URL } from '../services/api';
import { Audiencia } from '../types';

interface AudienciasState {
  audiencias: Audiencia[];
  isLoading: boolean;
  isSyncing: boolean;
  error: string | null;
  fetchAudiencias: () => Promise<void>;
  syncCalendar: () => Promise<void>;
}

export const useAudienciasStore = create<AudienciasState>((set) => ({
  audiencias: [],
  isLoading: true,
  isSyncing: false,
  error: null,
  
  fetchAudiencias: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await authenticatedFetch(`${BACKEND_URL}/api/robot/audiencias`);
      if (!response.ok) {
        throw new Error('Falha ao buscar audiências.');
      }
      const data: Audiencia[] = await response.json();
      set({ audiencias: data, isLoading: false });
    } catch (err) {
      set({ error: (err as Error).message, isLoading: false });
    }
  },

  syncCalendar: async () => {
    set({ isSyncing: true, error: null });
    try {
      const response = await authenticatedFetch(`${BACKEND_URL}/api/robot/sync-calendar`, { method: 'POST' });
      if (!response.ok) {
        throw new Error('Falha ao sincronizar com o Google Calendar.');
      }
      const data: Audiencia[] = await response.json();
      set({ audiencias: data, isSyncing: false });
    } catch (err) {
      set({ error: (err as Error).message, isSyncing: false });
    }
  },
}));
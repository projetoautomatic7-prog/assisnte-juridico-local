import { create } from 'zustand';

import { authenticatedFetch, BACKEND_URL } from '../services/api';
import { Expediente, PremonicaoJuridica } from '../types';

interface ExpedientesState {
    expedientes: Expediente[];
    isLoading: boolean;
    error: string | null;
    isModalOpen: boolean;
    isModalLoading: boolean;
    premonicaoData: PremonicaoJuridica | null;
    modalError: string | null;
    fetchExpedientes: () => Promise<void>;
    fetchPremonicao: (cnj: string) => Promise<void>;
    closeModal: () => void;
    saveDraft: (expedienteId: string, newContent: string) => void;
    toggleGoogleDocsEdit: (expedienteId: string, status: Expediente['google_docs_editing_status']) => void;
}

export const useExpedientesStore = create<ExpedientesState>((set) => ({
    expedientes: [],
    isLoading: true,
    error: null,
    isModalOpen: false,
    isModalLoading: false,
    premonicaoData: null,
    modalError: null,

    fetchExpedientes: async () => {
        set({ isLoading: true, error: null });
        try {
            const response = await authenticatedFetch(`${BACKEND_URL}/api/robot/expedientes`);
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({ message: 'Failed to parse error response from server.' }));
                throw new Error(errorData.message || `Erro do servidor: ${response.status}`);
            }
            const data: Expediente[] = await response.json();
            set({ expedientes: data, isLoading: false });
        } catch (err) {
            set({ error: (err as Error).message, isLoading: false });
        }
    },

    fetchPremonicao: async (cnj: string) => {
        set({ isModalOpen: true, isModalLoading: true, modalError: null, premonicaoData: null });
        try {
            const response = await authenticatedFetch(`${BACKEND_URL}/api/robot/premonicao`, {
                method: 'POST',
                body: JSON.stringify({ cnj }),
            });
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({ message: 'Failed to parse error response.' }));
                throw new Error(errorData.message || `Erro do servidor: ${response.status}`);
            }
            const data: PremonicaoJuridica = await response.json();
            set({ premonicaoData: data });
        } catch (err) {
            set({ modalError: (err as Error).message });
        } finally {
            set({ isModalLoading: false });
        }
    },
    
    closeModal: () => set({ isModalOpen: false, premonicaoData: null, modalError: null }),

    saveDraft: (expedienteId, newContent) => {
        set(state => ({
            expedientes: state.expedientes.map(exp => {
                if (exp.id === expedienteId && exp.ai_drafted_document) {
                    return { ...exp, ai_drafted_document: { ...exp.ai_drafted_document, content: newContent } };
                }
                return exp;
            })
        }));
    },

    toggleGoogleDocsEdit: (expedienteId, status) => {
        set(state => ({
            expedientes: state.expedientes.map(exp =>
                exp.id === expedienteId ? { ...exp, google_docs_editing_status: status } : exp
            )
        }));
    },
}));

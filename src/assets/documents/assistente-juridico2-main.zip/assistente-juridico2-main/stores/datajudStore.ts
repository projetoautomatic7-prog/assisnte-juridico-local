import { create } from 'zustand';

import { authenticatedFetch, BACKEND_URL } from '../services/api';
import { DatajudProcesso } from '../types';

interface DatajudState {
    processoData: DatajudProcesso | null;
    analysis: string | null;
    isLoading: boolean;
    isAnalyzing: boolean;
    error: string | null;
    analysisError: string | null;
    searchProcesso: (cnj: string, tribunal: string) => Promise<void>;
    analyzeProcesso: () => Promise<void>;
}

export const useDatajudStore = create<DatajudState>((set, get) => ({
    processoData: null,
    analysis: null,
    isLoading: false,
    isAnalyzing: false,
    error: null,
    analysisError: null,

    searchProcesso: async (cnj, tribunal) => {
        set({ isLoading: true, error: null, processoData: null, analysis: null, analysisError: null });
        try {
            const response = await authenticatedFetch(`${BACKEND_URL}/api/robot/datajud-search`, {
                method: 'POST',
                body: JSON.stringify({ cnj, tribunal }),
            });
            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.message || 'Erro na API do Datajud.');
            }
            if (data.hits && data.hits.hits.length > 0) {
                set({ processoData: data.hits.hits[0]._source });
            } else {
                set({ error: 'Nenhum processo encontrado.' });
            }
        } catch (err) {
            set({ error: (err as Error).message });
        } finally {
            set({ isLoading: false });
        }
    },

    analyzeProcesso: async () => {
        const { processoData } = get();
        if (!processoData) return;
        set({ isAnalyzing: true, analysis: null, analysisError: null });
        try {
            const recentMovements = processoData.movimentos
                .sort((a, b) => new Date(b.dataHora).getTime() - new Date(a.dataHora).getTime())
                .slice(0, 15)
                .map(m => `- ${m.nome} (em ${new Date(m.dataHora).toLocaleDateString('pt-BR')})`)
                .join('\n');
            const prompt = `Analise os andamentos do processo e forneça um resumo objetivo, o estado atual e o próximo passo esperado.\n\nAndamentos:\n${recentMovements}`;
            
            const response = await authenticatedFetch(`${BACKEND_URL}/api/ai/text`, {
                method: 'POST',
                body: JSON.stringify({ prompt }),
            });
            if (!response.ok) {
                throw new Error('Falha ao gerar análise.');
            }
            const result = await response.json();
            set({ analysis: result.text });
        } catch (err) {
            set({ analysisError: (err as Error).message });
        } finally {
            set({ isAnalyzing: false });
        }
    },
}));
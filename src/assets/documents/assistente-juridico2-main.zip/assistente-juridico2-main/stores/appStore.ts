import { create } from 'zustand';

import { Page } from '../types';

interface AppState {
  activePage: Page;
  setActivePage: (page: Page) => void;
}

export const useAppStore = create<AppState>((set) => ({
  activePage: 'dashboard-home',
  setActivePage: (page) => set({ activePage: page }),
}));

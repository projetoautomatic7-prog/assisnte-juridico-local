import { create } from 'zustand';

import { authenticatedFetch, BACKEND_URL } from '../services/api';
import { Processo, ProcessPhase } from '../types';

interface AcervoState {
  processos: Processo[];
  isLoading: boolean;
  error: string | null;
  fetchProcessos: () => Promise<void>;
  updateProcessoStage: (processoId: string, newStage: string, newPhase: ProcessPhase) => Promise<void>;
  archiveProcesso: (processoId: string) => Promise<void>;
  setError: (error: string | null) => void;
}

export const useAcervoStore = create<AcervoState>((set, get) => ({
  processos: [],
  isLoading: true,
  error: null,
  setError: (error) => set({ error }),
  fetchProcessos: async () => {
    set({ isLoading: true, error: null });
    try {
      // Change: now queries CRM pipeline by phase for Kanban
      const phaseQuery = 'Consultoria';
      const response = await authenticatedFetch(`${BACKEND_URL}/api/crm/phase/${phaseQuery}`);
      if (!response.ok) {
        throw new Error('Falha ao buscar os dados dos processos do servidor.');
      }
      const data: Processo[] = await response.json();
      set({ processos: data, isLoading: false });
    } catch (err) {
      set({ error: (err as Error).message, isLoading: false });
    }
  },
  updateProcessoStage: async (processoId, newStage, newPhase) => {
    const originalProcessos = get().processos;
    
    // Optimistic update
    set(state => ({
      processos: state.processos.map(p => 
        p.id === processoId ? { ...p, stage: newStage, phase: newPhase } : p
      )
    }));

    try {
        const response = await authenticatedFetch(`${BACKEND_URL}/api/crm/cards/${processoId}/move`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ stage: newStage, phase: newPhase }),
      });

      if (!response.ok) {
        throw new Error('Falha ao atualizar o processo no servidor.');
      }
    } catch (err) {
      set({ error: `Falha ao salvar alteração: ${(err as Error).message}. A alteração foi desfeita.`, processos: originalProcessos });
    }
  },
  archiveProcesso: async (processoId: string) => {
    const originalProcessos = get().processos;
    
    // Optimistic update
    set(state => ({
      processos: state.processos.filter(p => p.id !== processoId)
    }));

    try {
        await authenticatedFetch(`${BACKEND_URL}/api/crm/cards/${processoId}/archive`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ stage: 'Arquivado Definitivamente', phase: 'Arquivamento' }),
      });
    } catch (err) {
      set({ error: `Falha ao arquivar: ${(err as Error).message}. O processo foi restaurado.`, processos: originalProcessos });
    }
  }
}));
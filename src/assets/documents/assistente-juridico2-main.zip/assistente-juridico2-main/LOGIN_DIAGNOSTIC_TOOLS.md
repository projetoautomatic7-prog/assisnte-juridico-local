# Login Diagnostic Tools

Este documento descreve as ferramentas disponíveis para diagnosticar problemas de login no Assistente Jurídico.

## 1. Página de Teste Interativa

### Acesso
```
https://seu-backend.onrender.com/test/test-login.html
```

### Funcionalidades

A página de teste oferece 4 ferramentas principais:

#### 1.1 Verificar Backend
- Testa se o backend está online
- Verifica o endpoint `/health`
- Mostra timestamp do servidor

#### 1.2 Verificar Configuração de Autenticação
- Mostra quais variáveis de ambiente estão configuradas
- Indica se está usando hash ou senha plain text
- **Não expõe dados sensíveis** (apenas status booleanos)

Exemplo de resposta:
```json
{
  "adminUsernameConfigured": true,
  "adminUsernameValue": "admin",
  "adminPasswordConfigured": true,
  "adminPasswordHashConfigured": true,
  "usingHashAuth": true,
  "jwtSecretConfigured": true,
  "timestamp": "2025-11-14T03:22:05.818Z"
}
```

#### 1.3 Testar Login
- Permite testar login com qualquer username/senha
- Mostra mensagens de erro detalhadas
- Exibe o token JWT gerado (se sucesso)

#### 1.4 Testar Senhas Alternativas
- Testa rapidamente senhas pré-configuradas
- Inclui as senhas mencionadas no problema:
  - `admin123` (padrão)
  - `Aj!2025#Juri-Assist%Z7`
  - `Adv@2025!Secure_X9`
- Permite testar senha customizada

## 2. Endpoint de Diagnóstico de Configuração

### Acesso Direto via API
```bash
curl https://seu-backend.onrender.com/api/auth/config-check
```

### Resposta
```json
{
  "adminUsernameConfigured": true,
  "adminUsernameValue": "admin",
  "adminPasswordConfigured": true,
  "adminPasswordHashConfigured": true,
  "usingHashAuth": true,
  "jwtSecretConfigured": true,
  "timestamp": "2025-11-14T03:22:05.818Z"
}
```

### Campos

- **adminUsernameConfigured**: Se `ADMIN_USERNAME` está definido
- **adminUsernameValue**: Valor do username (seguro compartilhar)
- **adminPasswordConfigured**: Se `ADMIN_PASSWORD` está definido
- **adminPasswordHashConfigured**: Se `ADMIN_PASSWORD_HASH` está definido
- **usingHashAuth**: `true` se usando hash, `false` se usando plain text
- **jwtSecretConfigured**: Se `JWT_SECRET` está definido (obrigatório)

## 3. Logs Aprimorados

### Formato das Mensagens

Quando você tenta fazer login, o servidor agora gera logs detalhados:

#### Tentativa de Login
```
[Login Attempt] Username: "admin" | Expected: "admin" | Using hash: true
```

#### Login Bem-Sucedido
```
[Login Success] User "admin" logged in successfully
```

#### Falha por Username Incorreto
```
[Login Failed] Username mismatch: received "seu.usuario", expected "admin"
```

#### Falha por Senha Incorreta
```
[Login Failed] Password validation failed for user "admin"
```

### Como Acessar os Logs no Render

1. Acesse o [Render Dashboard](https://render.com/dashboard)
2. Selecione seu serviço backend
3. Clique em **Logs** no menu lateral
4. Tente fazer login no aplicativo
5. Observe as mensagens `[Login Attempt]`, `[Login Success]` ou `[Login Failed]`

## 4. Uso Combinado das Ferramentas

### Fluxo Recomendado de Diagnóstico

1. **Abra a página de teste**
   ```
   https://assistente-juridico-rs1e.onrender.com/test/test-login.html
   ```

2. **Verifique o Backend** (botão 1)
   - Se falhar: backend está offline ou URL incorreta
   - Se passar: backend está funcionando

3. **Verifique a Configuração** (botão 2)
   - Confirme `jwtSecretConfigured: true`
   - Confirme `adminUsernameValue` é o esperado
   - Verifique se está usando hash ou plain text

4. **Teste o Login** (botão 3)
   - Use as credenciais que você acha que são corretas
   - Se falhar, veja a mensagem de erro
   - Verifique os logs do Render para detalhes

5. **Teste Senhas Alternativas** (botão 4)
   - Teste as 3 senhas pré-configuradas
   - Descubra qual senha está realmente configurada no backend

6. **Ajuste as Variáveis** se necessário
   - Se descobriu qual senha funciona, atualize a documentação
   - Ou gere uma nova hash para a senha desejada

## 5. Exemplos de Uso

### Exemplo 1: Descobrir Qual Senha Está Configurada

**Cenário:** Você não sabe qual senha foi configurada no Render.

**Solução:**
1. Abra `/test/test-login.html`
2. Vá para a seção "Testar Senhas Alternativas"
3. Teste cada senha:
   - `admin123`
   - `Aj!2025#Juri-Assist%Z7`
   - `Adv@2025!Secure_X9`
4. A senha que retornar "✅ Senha Aceita!" é a correta

### Exemplo 2: Verificar Se JWT_SECRET Está Configurado

**Cenário:** Login retorna erro 500.

**Solução:**
1. Abra `/test/test-login.html`
2. Clique em "Ver Configuração (Seguro)"
3. Verifique se `jwtSecretConfigured: true`
4. Se `false`, adicione `JWT_SECRET` no Render

### Exemplo 3: Identificar Username Incorreto

**Cenário:** Sempre recebe "Usuário ou senha inválidos".

**Solução:**
1. Abra `/test/test-login.html`
2. Clique em "Ver Configuração (Seguro)"
3. Veja o valor de `adminUsernameValue`
4. Use esse username exato (não "seu.usuario")

## 6. Segurança

### O Que É Seguro Compartilhar

✅ **Seguro:**
- Resposta do endpoint `/api/auth/config-check`
- Logs do servidor (exceto se contiverem senhas)
- Screenshots da página de teste
- Username (geralmente é "admin")

❌ **NUNCA Compartilhe:**
- Valores de `JWT_SECRET`
- Valores de `ADMIN_PASSWORD`
- Valores de `ADMIN_PASSWORD_HASH`
- Tokens JWT gerados

### Proteções Implementadas

- ✅ Endpoint `/api/auth/config-check` não expõe senhas
- ✅ Logs não mostram senhas enviadas
- ✅ Página de teste não envia dados para terceiros
- ✅ Tudo roda localmente no seu navegador

## 7. Solução Rápida

Se você só quer fazer o login funcionar rapidamente:

1. **Resetar para Padrão:**
   - No Render, **remova** as variáveis:
     - `ADMIN_USERNAME`
     - `ADMIN_PASSWORD`
     - `ADMIN_PASSWORD_HASH`
   - Use credenciais padrão: `admin` / `admin123`

2. **Ou Usar Senha Específica:**
   - Se quer usar `Aj!2025#Juri-Assist%Z7`:
     ```
     ADMIN_USERNAME=admin
     ADMIN_PASSWORD_HASH=$2b$12$fDwsnagsVN4KMUZkVJLaEOZE03vt43uc1F2vy7zK1gfd4FuCH./TO
     ```
   - Se quer usar `Adv@2025!Secure_X9`:
     ```
     ADMIN_USERNAME=admin
     ADMIN_PASSWORD_HASH=$2b$12$Zfe7o4UehA9caaURrEatku8JtSOt.oM272eD5JajZkg//MedQwmYS
     ```
   - **Remova** `ADMIN_PASSWORD` se existir

3. **Redeploy:**
   - Salve as variáveis no Render
   - Aguarde o redeploy (5-10 minutos)
   - Teste na página `/test/test-login.html`

## 8. Suporte

Se ainda tiver problemas:

1. Acesse `/test/test-login.html` e faça todos os testes
2. Tire screenshots dos resultados
3. Copie os logs do Render (últimas 50 linhas)
4. Compartilhe a resposta de `/api/auth/config-check`

Com essas informações, será muito mais fácil identificar o problema!

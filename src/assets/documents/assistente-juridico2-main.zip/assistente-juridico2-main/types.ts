export type Page = 
  'dashboard-home' | // New home page
  'pje-robot' |
  'agent-dashboard' |
  'document-analysis' | 
  'quick-actions' | 
  'audio-transcription' | 
  'image-generation' | 
  'video-analysis' | 
  'deadline-calculator' |
  'acervo' |
  'pessoas' |
  'expedientes' |
  'audiencias' |
  'agenda' |
  'atividades' | // New Page
  'datajud-checklist' |
  'financial-management' |
  'knowledge-base' |
  'djen-search' |
  'gestao-bi' |
  'modelos' |
  'intimacoes' | // New Page
  'settings' | // New Page
  'rede' | // New Page
  'suporte'; // New Page

export type KnowledgeBaseContextType = {
  processContext: string | null;
  setProcessContext: (cnj: string | null) => void;
};

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'Administrador' | 'Advogado' | 'Estagiário';
  status: 'Ativo' | 'Pendente';
  lastLogin: string;
}

export interface ExtractedData {
  numero_cnj: string;
  partes: {
    polo_ativo: string[];
    polo_passivo: string[];
  };
  classe_judicial: string;
  orgao_julgador: string;
  data_expediente: string;
  prazo_processual: string;
  resumo_movimentacao: string;
}

export interface PjeRobotLog {
  timestamp: string;
  message: string;
  level: 'info' | 'success' | 'error' | 'warn' | 'fatal';
  code?: string;
}

export type RobotStatus = 'inactive' | 'running' | 'connecting' | 'error' | 'paused';
export type SessionStatus = 'disconnected' | 'active' | 'reconnecting';
export type WsConnectionStatus = 'connected' | 'reconnecting' | 'disconnected' | 'connecting';

export type ConnectionStep =
  | 'idle'
  | 'launching'
  | 'navigating'
  | 'filling'
  | 'submitting'
  | 'waiting'
  | 'success'
  | 'failed';


export interface AuditLogEntry {
  timestamp: string;
  action: string;
}

export type NotificationStatus = 
  | 'pending'
  | 'analyzing'
  | 'drafting'
  | 'review'
  | 'protocoling'
  | 'success'
  | 'error'
  | 'awaiting_documents';

export interface ProcessedNotification {
  id: string;
  cnj: string;
  client: string;
  originalContent: string;
  summary: string;
  actionClassification: 'SIMPLE_REPLY' | 'DRAFT_RESPONSE' | 'HUMAN_REVIEW' | null;
  deadline: string;
  draftContent?: string;
  status: NotificationStatus;
  error?: string;
  auditTrail: AuditLogEntry[];
  processedAt?: string;
  requiredDocuments?: string[];
}

export type ProcessPhase = 'Marketing' | 'Negociação' | 'Consultoria' | 'Administrativo' | 'Judicial' | 'Recursal' | 'Execução' | 'Financeiro' | 'Arquivamento';

export interface Processo {
  id: string; // Using cnj as id
  numero_cnj: string;
  classe_judicial: string;
  assunto: string;
  partes: {
    polo_ativo: string;
    polo_passivo: string;
  };
  orgao_julgador: string;
  distribuicao_data: string;
  ultimo_movimento: {
    data: string;
    descricao: string;
  };
  // New fields for Kanban
  phase: ProcessPhase;
  stage: string;
  value: number;
  probability: 'Provável' | 'Possível' | 'Remota';
  responsible: string;
  isOverdue: boolean;
  overdueTasks: number;
  hasOpenTasks: boolean;
  activeAgents?: Agent[];
   // Fields for details drawer
  timelineEvents: {
    date: string;
    description: string;
    type: 'creation' | 'phase_change' | 'deadline' | 'hearing' | 'protocol';
  }[];
}


// Tipos para a nova página de Expedientes
export type ExpedienteStatus =
  | 'human_review'
  | 'awaiting_documents'
  | 'drafting'
  | 'completed'
  | 'no_action_needed';

export interface Expediente {
  id: string; // ID da comunicação
  agentTaskId?: string; // ID da tarefa do agente associada
  destinatario: string;
  tipo: string;
  fonte: string;
  data_publicacao: string;
  prazo_dias: string;
  data_ciencia: string;
  data_limite: string;
  processo_cnj: string;
  processo_classe: string;
  partes: string;
  orgao_julgador: string;
  ultimo_movimento: string;
  // Campos adicionados pela IA
  status: ExpedienteStatus;
  ai_summary: string;
  tasks_total: number;
  tasks_completed_by_ai: number;
  tasks_pending_human: number;
  required_documents: string[];
  human_tasks_list: string[];
  ai_completed_tasks_list: string[];
  ai_drafted_document?: {
    name: string;
    content: string;
  };
  google_docs_editing_status: 'idle' | 'editing_local' | 'editing_google_docs';
  google_doc_link?: string;
}

// Tipos para a nova página de Audiências
export interface Audiencia {
  id: string;
  processo_cnj: string;
  data_hora: string;
  local: string;
  tipo: string;
  partes: {
    polo_ativo: string;
    polo_passivo: string;
  };
  status: 'Agendada' | 'Cancelada' | 'Realizada';
  google_calendar_status: 'pending' | 'synced' | 'error';
  // Campos detalhados para exibição
  classe_judicial?: string;
  orgao_julgador?: string;
  advogado_responsavel?: string;
}

// Tipos para a funcionalidade de Premonição Jurídica
export interface Precedente {
  id: string; // e.g., "STJ - REsp 1.234.567"
  tribunal: string;
  numero: string;
  tema: string;
  resumo_relevancia: string;
  link: string;
}

export interface PremonicaoJuridica {
  processo_cnj: string;
  probabilidade_exito: number; // 0 a 100
  analise_ia: string; // Textual explanation
  estrategias_recomendadas: string[];
  precedentes_relevantes: Precedente[];
}

// Tipos para a nova página de Checklist do Datajud
export interface DatajudMovimento {
  codigo: number;
  nome: string;
  dataHora: string;
  complementosTabelados: any[];
}

export interface DatajudProcesso {
  numeroProcesso: string;
  classe: { codigo: number; nome: string; };
  sistema: { codigo: number; nome: string; };
  formato: { codigo: number; nome: string; };
  tribunal: string;
  dataAjuizamento: string;
  movimentos: DatajudMovimento[];
  orgaoJulgador: { codigo: number; nome: string; };
  assuntos: { codigo: number; nome: string; }[];
}

// Tipos para a nova página Financeira
export interface Transaction {
  id: string;
  date: string;
  processo_cnj: string;
  description: string;
  amount: number;
  type: 'credit' | 'debit';
  status: 'paid' | 'pending';
  attachment?: {
    name: string;
    data: string; // base64 content
    mimeType: string;
  };
}

export interface FinancialChartData {
    month: string;
    receitas: number;
    despesas: number;
}

export interface PerformanceDataPoint {
    day: number;
    esteMes: number | null;
    mesAnterior: number | null;
}

// Tipos para o Agente Autônomo
export interface AgentGoal {
  id: string;
  title: string;
  status: 'PENDING' | 'PLANNED' | 'RUNNING' | 'PAUSED' | 'DONE' | 'FAILED';
  created_at: string;
}

export interface AgentStep {
  id: string;
  goal_id: string;
  idx: number;
  tool: string;
  input: any;
  status: 'PENDING' | 'RUNNING' | 'DONE' | 'FAILED' | 'SKIPPED';
  result?: any;
  error?: string;
}

export interface AgentEvent {
  id: number;
  level: 'INFO' | 'WARN' | 'ERROR';
  code: string;
  message: string;
  created_at: string;
  data?: any;
  goalId?: string;
  stepId?: string;
  taskId?: string;
}

export interface AgentTask {
  id: string;
  type: string;
  payload: any;
  status: 'QUEUED' | 'RUNNING' | 'DONE' | 'FAILED' | 'CANCELLED';
  attempts: number;
  last_error?: string;
  created_at: string;
  scheduled_for?: string;
}

export type AgentStatus = 'RUNNING' | 'IDLE' | 'ERROR' | 'PAUSED' | 'SUCCESS';

export interface Agent {
    id: string;
    name: string;
    type: string;
    status: AgentStatus;
    description: string;
    progress?: number;
    tasksCompleted?: number;
    totalTasks?: number;
    timeElapsed?: string;
    estimatedTime?: string;
    currentTask?: string;
    lastRun?: string;
    successRate?: number;
    errorDetails?: string;
    nextAction?: string;
}


// Tipos para a nova consulta ao DJEN
export interface DjenPublication {
  tribunal: string;
  dataPublicacao: string;
  tipo: string;
  conteudo: string;
  advogados?: string[];
  oabs?: Array<{ uf?: string; numero: string }>;
}

// Tipos para o novo Dashboard "Meu Painel"
export interface Compromisso {
  id: string;
  title: string;
  assignedTo: string;
  relativeDate: string; // "2 dias atrás", "Amanhã"
  isUrgent: boolean;
}

// Tipos para a página de Gestão B.I.
export interface BiReport {
  id: string;
  parte: string;
  tipoAcao: string;
  grupoAcao: string;
  fase: string;
  situacao: string;
  cadastro: string;
}

// Tipos para a página Pessoas
export interface Pessoa {
    id: string;
    name: string;
    contact: string;
    location: string;
    registrationDate: string;
    // Fields for charts
    origin: string;
    age: number;
    profession: string;
}

export interface OriginData {
    name: string;
    value: number;
}

export interface DemographicData {
    name: string;
    value: number;
}

// New Type for Agenda
export interface AgendaEvent {
  id: string;
  title: string;
  date: string; // YYYY-MM-DD
  startTime?: string; // HH:mm
  endTime?: string; // HH:mm
  description?: string;
  color: 'blue' | 'green' | 'red' | 'yellow' | 'purple';
}

// New Type for Modelos
export interface Modelo {
  id: string;
  nome: string;
  tipo: 'Petição' | 'Contrato' | 'Documento';
  dataCriacao: string; // YYYY-MM-DD
  ultimaEdicao: string; // YYYY-MM-DD
}

// New Type for Atividades
export interface Atividade {
    id: string;
    isUrgent: boolean;
    tarefa: string;
    partes: string;
    dataCompromisso: string; // YYYY-MM-DD
    prazoFatal: string | null;
    status: 'Pendente' | 'Atrasada' | 'Concluída';
}

// New Types for Intimações
export interface ProcessoDetalhado {
    numero: string;
    partes: string;
    grupoAcao: string;
    tipoAcao: string;
    responsavel: string;
}

export interface Intimacao {
    id: string;
    title: string;
    isUrgent: boolean;
    isNew: boolean;
    processo: ProcessoDetalhado;
    relativeDate: string;
    status: 'analisar' | 'verificado';
    responsavel: {
        name: string;
        avatarUrl?: string;
    };
}

// Tipo para a página Rede
export interface Contact {
    id: string;
    name: string;
    role: string;
    location: string;
    expertise: string[];
    avatarUrl?: string;
}

// =============== TIPOS RAG (Recuperação Aumentada por Geração) ===============

export interface RAGDocument {
    id: string;
    content: string;
    documentType: 'petição' | 'contrato' | 'parecer' | 'jurisprudência' | 'outro';
    sourceUrl?: string;
    embeddingId?: string;
    metadata: {
        cnj?: string;
        autor?: string;
        dataDocumento?: string;
        tags?: string[];
        [key: string]: any;
    };
    dataIndexacao: string;
    dataAtualizacao: string;
}

export interface RAGSearchResult {
    id: string;
    content: string;
    similarity: number;
    metadata: any;
    sourceUrl?: string;
}

export interface RAGSearchQuery {
    query: string;
    limit?: number;
    minSimilarity?: number;
    filters?: {
        documentType?: string;
        cnj?: string;
        dateRange?: { start: string; end: string };
    };
}

// =============== TIPOS CRM (Gestão Visual de Processos) ===============

export type ProcessPhase = 'Marketing' | 'Negociação' | 'Consultoria' | 'Administrativo' | 'Judicial' | 'Recursal' | 'Execução' | 'Financeiro' | 'Arquivamento';

export interface CRMCard {
    id: string;
    processoId: string;
    cnj?: string;
    titulo: string;
    partes: {
        polo_ativo: string[];
        polo_passivo: string[];
    };
    fase: ProcessPhase;
    estagio: string;
    prazos: {
        fatal: string | null;
        resposta: string | null;
    };
    status: 'novo' | 'em_progresso' | 'aguardando' | 'completado' | 'arquivado';
    valor?: number;
    minutas?: string[];
    anotacoes: string;
    dataUltimaAtualizacao: string;
    responsavel?: string;
    autoAtomacoes?: {
        sugestaoAcoes: string[];
        statusIA: string;
        ultimaAnalise: string;
    };
}

export interface CRMPipeline {
    id: string;
    nome: string;
    fases: Array<{
        id: ProcessPhase;
        label: string;
        estagios: string[];
        cards: CRMCard[];
    }>;
    configuracao?: {
        responsavelPadrao?: string;
        automacaoativada: boolean;
        frequenciaAtualizacao: 'hourly' | 'daily' | 'on-demand';
    };
}

// =============== TIPOS INTEGRAÇÕES (DJEN & DataJud) ===============

export interface DJENPublication {
    id: string;
    dje: string;
    publicationDate: string;
    content: string;
    parsedData: {
        advogados: string[];
        oabs: Array<{ uf?: string; numero: string }>;
        descricao?: string;
        [key: string]: any;
    };
    cnj?: string;
    processed: boolean;
    dataCriacao: string;
}

export interface DatajudProcesso {
    numeroCNJ: string;
    tribunal: string;
    classe?: string;
    assunto?: string;
    partes?: Array<{
        polo: 'ativo' | 'passivo' | string;
        nome: string;
    }>;
    movimentos?: Array<{
        data: string;
        descricao: string;
    }>;
    bruto?: any;
}

export interface IntegrationAuditLog {
    id: string;
    serviceName: 'djen' | 'datajud' | 'pje' | 'gemini' | 'chroma';
    operation: string;
    status: 'success' | 'error' | 'pending';
    requestData?: any;
    responseData?: any;
    errorMessage?: string;
    executionTimeMs?: number;
    dataCriacao: string;
}

// =============== TIPOS IA/AUTOMAÇÕES ===============

export interface AIAutomation {
    id: string;
    cardId: string;
    automationType: 'analise' | 'sumarização' | 'geração_minuta' | 'calculo_prazo';
    prompt: string;
    response?: string;
    status: 'pending' | 'processing' | 'completed' | 'failed';
    retryCount: number;
    maxRetries: number;
    dataCriacao: string;
    dataAtualizacao: string;
}
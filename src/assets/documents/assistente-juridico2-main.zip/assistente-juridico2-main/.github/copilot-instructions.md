# GitHub Copilot Instructions for Assistente Jurídico PJe

## Project Overview

This is a legal assistant application integrating AI (Google Gemini) with the Brazilian PJe (Processo Judicial Eletrônico) system. The application consists of:

- **Frontend**: React 19 + TypeScript + Vite + Tailwind CSS
- **Backend**: Node.js + Express + TypeScript
- **Database**: PostgreSQL
- **Vector Store**: ChromaDB for RAG (Retrieval-Augmented Generation)
- **Automation**: Puppeteer for PJe portal interaction
- **AI Integration**: Google Gemini API (`@google/genai`)

## Project Structure

```
/
├── backend/                    # Node.js backend server
│   ├── src/
│   │   ├── agent/              # Autonomous agent system logic
│   │   ├── agents/             # Specific agent implementations
│   │   ├── middleware/         # Auth and other middlewares
│   │   ├── routes/             # API route definitions
│   │   ├── services/           # Business logic (PJe, Gemini, DB)
│   │   └── server.ts           # Server entry point
│   ├── package.json
│   └── tsconfig.json
├── components/                 # Reusable React components
├── pages/                      # Page components (routing)
├── services/                   # Client-side logic (API, themes)
├── stores/                     # Zustand state management
├── styles/                     # Global styles and theme CSS
├── types.ts                    # TypeScript type definitions
├── App.tsx                     # Main app component with routing
└── package.json
```

## Coding Standards

### General Guidelines

- **Language**: All code should be in **TypeScript** with strict type checking enabled
- **Code Style**: Follow existing patterns in the codebase
- **Comments**: Use comments sparingly and only when necessary to explain complex logic. The code should be self-documenting
- **Naming Conventions**:
  - Use camelCase for variables, functions, and methods
  - Use PascalCase for components, classes, and type definitions
  - Use SCREAMING_SNAKE_CASE for constants
- **Imports**: Organize imports with Node.js built-ins first, then external dependencies, then internal modules
- **Error Handling**: Always handle errors gracefully with try-catch blocks and appropriate error messages

### Frontend Standards

- **React Components**: Use functional components with TypeScript
- **Hooks**: Prefer React hooks for state management
- **State Management**: Use Zustand stores (located in `/stores/`) for global state
- **Styling**: Use Tailwind CSS classes for styling. Follow the theme system defined in `styles/themes.css`
- **TypeScript**: Define proper interfaces/types for component props
- **File Organization**: Place components in `/components/`, pages in `/pages/`

### Backend Standards

- **Express Routes**: Define routes in `/backend/src/routes/` following the existing pattern
- **Services**: Business logic should be in `/backend/src/services/`
- **Middleware**: Authentication and other middleware in `/backend/src/middleware/`
- **Database**: Use the `pool` from `services/db` for PostgreSQL queries
- **Type Safety**: Use TypeScript types defined in `src/types.ts`
- **Validation**: Use Zod for input validation where applicable
- **Security**: Always use authentication middleware for protected routes

## Testing Requirements

### Backend Testing

- **Framework**: Jest with ts-jest preset
- **Configuration**: Tests configured in `backend/jest.config.js`
- **Test Location**: Place tests alongside source files with `.test.ts` extension or in `__tests__` directories
- **Test Pattern**: Use descriptive test names following the pattern: `describe('Component/Function', () => { it('should do something', () => {...}) })`
- **Coverage**: All new routes and services should have corresponding tests
- **Mocking**: Use Jest mocks for external dependencies (database, API calls)

### Testing Commands

```bash
# Backend tests
cd backend && npm test

# Frontend build (no test suite currently configured)
npm run build
```

## Build and Development

### Local Development

```bash
# Install dependencies
npm install                    # Frontend
cd backend && npm install      # Backend

# Run development servers
npm run dev                    # Frontend (Vite dev server on port 5173)
cd backend && npm run dev      # Backend (ts-node on port 3001)

# Build for production
npm run build                  # Frontend (outputs to /dist)
cd backend && npm run build    # Backend (outputs to /backend/dist)
```

### Docker Support

Use `docker-compose.yml` to run PostgreSQL and ChromaDB locally:

```bash
docker compose up -d
```

## Environment Variables

### Frontend (.env)

- `VITE_BACKEND_URL`: Backend API URL (default: http://localhost:3001 for dev)
- `VITE_GOOGLE_CLIENT_ID`: Google OAuth client ID
- `VITE_VAPID_PUBLIC_KEY`: Web Push VAPID public key

### Backend (backend/.env)

Required variables:
- `API_KEY`: Google Gemini API key
- `JWT_SECRET`: Secret for JWT token generation
- `DATABASE_URL`: PostgreSQL connection string
- `FRONTEND_ORIGIN`: Allowed CORS origins (comma-separated)
- `DATAJUD_API_KEY`: DataJud API key
- `CHROMA_URL`: ChromaDB URL
- `PJE_LOGIN_URL`: PJe portal login URL

Refer to `.env.example` files for complete lists.

## Deployment

- **Frontend**: Deployed on Vercel (Vite preset)
- **Backend**: Deployed on Render.com (uses `render.yaml`)
- **Database**: PostgreSQL on Render.com
- **Build Configuration**: See `render.yaml` for backend deployment config

## Scope and Boundaries

### What You Should Change

- Add new features following existing patterns
- Fix bugs in source code
- Improve error handling and logging
- Update or add tests for changed functionality
- Update documentation when modifying APIs or features
- Optimize performance where applicable
- Fix security vulnerabilities

### What You Should NOT Change

- Do not modify or remove working code unless fixing a bug or security issue
- Do not change the project structure (moving files between directories)
- Do not remove existing tests unless they are genuinely broken
- Do not modify build tool configurations (vite.config.ts, tsconfig.json) unless required
- Do not add new dependencies without justification
- Do not modify Docker or deployment configurations unless specifically requested
- Do not touch `.github/agents/` directory (contains instructions for other agents)

## Security Guidelines

1. **Never commit secrets** - Use environment variables for API keys, credentials, and secrets
2. **Authentication**: All protected routes must use `authMiddleware`
3. **Input Validation**: Validate all user inputs using Zod schemas
4. **SQL Injection**: Use parameterized queries with the `pg` library
5. **CORS**: Properly configure CORS origins in backend
6. **JWT**: Use secure JWT token generation and validation
7. **Dependencies**: Keep dependencies up to date, review for vulnerabilities

## AI/Gemini Integration

- Use appropriate Gemini models:
  - `gemini-2.5-flash`: Fast tasks (summaries, conversations)
  - `gemini-2.5-pro`: Complex tasks (document analysis, legal briefs)
  - `gemini-2.5-flash-native-audio-preview`: Audio transcription
- Handle API rate limits gracefully
- Always handle AI API errors and provide fallbacks
- Use structured outputs where possible

## Documentation

- Update README.md when adding major features
- Keep API documentation up to date
- Document complex algorithms or business logic
- Portuguese is the primary language for user-facing documentation
- Code comments should be clear and in English or Portuguese

## Review Checklist

Before submitting changes, ensure:

- [ ] Code follows TypeScript best practices with proper typing
- [ ] No console.log statements in production code (use proper logging)
- [ ] All new code has appropriate error handling
- [ ] Tests are added or updated for changed functionality
- [ ] No new dependencies added without necessity
- [ ] Environment variables are properly documented
- [ ] Security best practices are followed
- [ ] Code is properly formatted and readable
- [ ] No secrets or sensitive data in code
- [ ] CORS configuration is correct for deployment

## Common Patterns

### Creating a New API Route

1. Define route in `/backend/src/routes/`
2. Add business logic in `/backend/src/services/`
3. Use `authMiddleware` for protected routes
4. Add proper TypeScript types
5. Write tests in adjacent `.test.ts` file
6. Register route in `server.ts`

### Creating a New React Page

1. Create component in `/pages/`
2. Use existing components from `/components/`
3. Define TypeScript interfaces for props and state
4. Add route in `App.tsx`
5. Use Zustand stores for state management
6. Follow Tailwind CSS patterns for styling

### Adding a New Feature

1. Plan the changes and understand existing patterns
2. Update types in `types.ts` if needed
3. Implement backend changes first (API, database)
4. Write tests for backend logic
5. Implement frontend changes
6. Test the feature end-to-end
7. Update documentation

## Language Note

This is a Brazilian Portuguese-focused application. User-facing content, error messages, and documentation should be in Portuguese. Code and technical comments can be in English or Portuguese.
# 🤖 Copilot Instructions - Assistente Jurídico PJe

## Objetivo
Orientações específicas para GitHub Copilot auxiliar no desenvolvimento do **Assistente Jurídico PJe - Thiago Bodevan Advocacia**, um sistema full-stack de automação jurídica com agentes IA autônomos.

---

## 1️⃣ CONTEXTO DO PROJETO

### Stack Tecnológico
- **Frontend**: React 19 + TypeScript 5.4 + Vite 5.4 + Tailwind CSS 4.1
- **Backend**: Node.js + Express + TypeScript + PostgreSQL 15
- **Automação**: Puppeteer + Chromium (RPA do PJe)
- **IA**: Google Gemini API (análise, geração de documentos)
- **Infraestrutura**: Render (Postgres), Vercel (Frontend), GitHub Actions (CI/CD)
- **Agents**: Sistema autônomo com Worker Loop (3s) + Scheduler (Cron)

### Arquitetura
```
Frontend (Vite+React) ←WebSocket→ Backend (Express) ←→ PostgreSQL
                                        ↓
                            Worker Loop (Agent Kernel)
                                        ↓
                        ┌───────────────┼───────────────┐
                        ↓               ↓               ↓
                   Puppeteer       Google Gemini    DJEN/DataJud
                    (RPA PJe)      (IA Analysis)     (APIs)
```

---

## 2️⃣ PADRÕES DE CÓDIGO

### Frontend (React/TypeScript)

#### ✅ Componentes Funcionais com Hooks
```typescript
// ✅ CORRETO
const MeuComponente: React.FC<Props> = ({ prop }) => {
  const [state, setState] = useState<Type>();
  useEffect(() => { /* setup */ }, [dep]);
  return <div>{state}</div>;
};

// ❌ EVITAR
class MeuComponente extends React.Component { /* ... */ }
function MeuComponente(prop) { /* sem types */ }
```

#### ✅ Gerenciamento de Estado
- **Zustand** para store global (expedientes, agentes, etc)
- **useState** para estado local (UI temporário)
- **localStorage** APENAS para JWT e preferências
- ❌ **Evitar**: Redux, Context API profundo nesting

#### ✅ Styling
- **Tailwind CSS** classes direto no JSX
- **CSS Modules** APENAS para estilos complexos (`.module.css`)
- ❌ **Evitar**: Styled-components, LESS, inline styles

#### ✅ Requisições HTTP
```typescript
// ✅ CORRETO
const response = await authenticatedFetch(`${BACKEND_URL}/api/data`);
const data = await response.json();

// ❌ EVITAR
fetch(...).then(...).then(...) // sem erro handling
axios (não está configurado)
```

### Backend (Node.js/TypeScript)

#### ✅ Estrutura de Rotas
```typescript
// /backend/src/routes/meuRoutes.ts
const router = express.Router();

router.get('/endpoint', authMiddleware, async (req, res) => {
  try {
    // lógica
    res.status(200).json({ data });
  } catch (error) {
    res.status(500).json({ message: (error as Error).message });
  }
});

export default router;
```

#### ✅ Database Queries
- **Usar Pool.query()** SEMPRE com parameterized queries
- ❌ **NUNCA** concatenar strings (SQL injection!)

```typescript
// ✅ CORRETO
const result = await pool.query(
  'SELECT * FROM atividades WHERE id=$1',
  [id]
);

// ❌ ERRADO
const result = await pool.query(
  `SELECT * FROM atividades WHERE id=${id}`
);
```

#### ✅ Error Handling
```typescript
// ✅ CORRETO
try {
  // operação
} catch (error) {
  log.error({ error }, 'Descrição');
  res.status(500).json({ message: (error as Error).message });
}

// ❌ EVITAR
throw new Error('genérico');
res.status(500).send('erro');
```

#### ✅ Logging
- **Usar Pino** estruturado: `log.info({ field }, 'message')`
- ❌ **Evitar**: `console.log()`

### Agent System

#### ✅ Criando Nova Tarefa
```typescript
// Enfileirar tarefa
await taskRepo.queue('NOVO_TIPO_TAREFA', {
  param1: 'valor',
  param2: 123
});

// Adicionar case no worker.ts
case 'NOVO_TIPO_TAREFA':
  toolName = 'meu.tool.name';
  break;
```

#### ✅ Padrão de Retry
- **Já implementado**: 4 tentativas com backoff (1s, 5s, 15s, 30s)
- **Adicionar timeout** SEMPRE: `Promise.race()` com 30s

#### ✅ Registrar Ferramenta
```typescript
// /backend/src/agent/bootstrap.ts
export function buildToolRegistry(): ToolRegistry {
  const tools = new ToolRegistry();
  
  tools.register('my.tool', {
    execute: async (payload: any, ctx: any) => {
      // implementação
      return result;
    }
  });
  
  return tools;
}
```

---

## 3️⃣ CONVENÇÕES DE NOMENCLATURA

### Arquivos/Pastas
```
pages/              → Componentes de página (React)
components/        → Componentes reutilizáveis
stores/            → Zustand stores
services/          → Chamadas API, utilitários
backend/src/
  routes/          → Express routes
  services/        → Lógica de negócio (PJe, Gemini, etc)
  agent/           → Worker, kernel, repos
  agents/          → Implementações específicas de agentes
  types.ts         → Interfaces TypeScript
  middleware/      → Auth, error handling, etc
```

### Variáveis/Funções
```
// ✅ CORRETO
const processoBydatenumber = 'string'; // camelCase
async function fetchExpedientesFromPJe() {} // função clara
const STATUS = { PENDING: 'PENDING' }; // constantes UPPERCASE

// ❌ EVITAR
const processo_by_date_number = ''; // snake_case no JS
function process() {} // vago
const statusPending = 'PENDING'; // redundante
```

### Database
```
-- ✅ CORRETO: snake_case, singular/plural consistente
CREATE TABLE processos (
  id UUID PRIMARY KEY,
  numero_cnj VARCHAR(255),
  created_at TIMESTAMPTZ,
  ...
);

-- ❌ EVITAR
CREATE TABLE Processos (...); -- PascalCase
CREATE TABLE processo_list (...); -- inconsistente
```

---

## 4️⃣ SEGURANÇA & BOAS PRÁTICAS

### ✅ Autenticação
- **JWT** obrigatório em rotas `/api/`
- **authMiddleware** verifica token
- **localStorage** armazena JWT (HTTPS only)
- ❌ **Nunca** armazenar senhas em código

### ✅ Variáveis de Ambiente
```typescript
// ✅ CORRETO: .env.example documentado
GOOGLE_API_KEY=
DATABASE_URL=
JWT_SECRET=

// ❌ NUNCA
const apiKey = "abc123"; // hardcoded
process.env.random_value // undocumented
```

### ✅ Validação de Input
```typescript
// ✅ CORRETO
if (!payload.id || typeof payload.id !== 'string') {
  throw new Error('ID inválido');
}

// ❌ EVITAR
const id = payload.id; // assume validade
```

### ✅ HTTPS/TLS
- Production: Render + Vercel (ambos com HTTPS automático)
- Local: HTTP ok para desenvolvimento

---

## 5️⃣ COMMITS & VERSIONAMENTO

### Mensagens de Commit
```bash
# ✅ CORRETO
git commit -m "feat: Adicionar análise de documentos com Gemini"
git commit -m "fix: Corrigir timeout no Worker do Agente"
git commit -m "docs: Adicionar guia de instalação"
git commit -m "refactor: Extrair lógica de PJe em serviço"

# ❌ EVITAR
git commit -m "update" # vago
git commit -m "WIP" # sem contexto
git commit -m "fix bug" # não especifica qual
```

### Branches
```
main              → Produção (protegida, requer PR review)
develop           → Pre-produção
feature/*         → feature/add-agent-kernel
bugfix/*          → bugfix/worker-timeout
docs/*            → docs/architecture-diagram
```

---

## 6️⃣ TESTES

### Unit Tests (Jest)
```typescript
// ✅ PADRÃO
describe('AgentKernel', () => {
  it('should queue a task successfully', async () => {
    const result = await kernel.createGoal({ ... });
    expect(result.id).toBeDefined();
  });

  it('should handle errors gracefully', async () => {
    await expect(kernel.createGoal(null)).rejects.toThrow();
  });
});
```

### Quando Testar
- ✅ Lógica de negócio crítica (Worker, Agent)
- ✅ Validação de input
- ✅ Cálculos de prazo, status
- ❌ UI componentes (usar React Testing Library se necessário)
- ❌ Integrações externas (mock com `jest.mock()`)

---

## 7️⃣ PERFORMANCE & OTIMIZAÇÃO

### Frontend
- ✅ Lazy load de páginas via React Router
- ✅ Memoização de componentes com `useMemo`, `useCallback`
- ✅ Virtualization para listas > 100 itens
- ❌ Evitar re-renders desnecessários

### Backend
- ✅ Pooling de conexões PostgreSQL
- ✅ Índices em colunas `WHERE` frequentes
- ✅ Paginação em endpoints listagem
- ❌ N+1 queries (usar JOIN)

### Agentes
- ✅ Polling de 3s é ótimo
- ✅ Backoff exponencial previne picos
- ✅ Circuit breaker protege serviços terceiros
- ❌ Sem timeout = travamento potencial

---

## 8️⃣ DEBUGGING & LOGGING

### Logs Estruturados (Pino)
```typescript
// ✅ CORRETO
log.info({ taskId: job.id, type: job.type }, 'Task started');
log.error({ error: e.message, attempts: 3 }, 'Task failed');
log.warn({ queueSize: tasks.length }, 'Queue growing');

// ❌ EVITAR
console.log('Task started'); // sem contexto
console.error(error); // sem estrutura
```

### Debugging Local
```bash
# Frontend
npm run dev -- --open  # Abre com Vite devserver
# Browser DevTools (F12) para React/Network

# Backend
npm run dev  # Nodemon recarrega em mudanças
# Logs aparecem em stdout (via Pino)
```

---

## 9️⃣ DOCUMENTAÇÃO

### README
- ✅ Setup local (npm install, npm run dev)
- ✅ Variáveis de ambiente necessárias
- ✅ Como rodar testes
- ✅ Link para architecture diagram

### Inline Comments
```typescript
// ✅ CORRETO: Por quê?
// Retry logic: Google Gemini frequentemente timeout em 1-5s,
// mas geralmente sucede em 2ª tentativa. Backoff evita rate limit.
await taskRepo.markFailed(job.id, err, attempts, 'QUEUED', backoff);

// ❌ EVITAR
// Update status
await taskRepo.markFailed(...); // óbvio
```

### PR Description
```markdown
## Descrição
Fix: Corrigir Worker do Agente travando em respostas lentas

## Problema
Quando Google Gemini demora > 10s, todo worker trava

## Solução
Adicionar Promise.race() com timeout de 30s

## Teste
- [ ] Rodar `npm test`
- [ ] Verificar logs: `npm run dev | grep Worker`
- [ ] Testar manualmente em /api/agent/tasks
```

---

## 🔟 RECURSOS & REFERÊNCIAS

### Documentos Importantes
- Architecture: `ARCHITECTURE.md` (criar se necessário)
- API: `API.md` com endpoints e payloads
- Deploy: `DEPLOY.md` com passos Render/Vercel
- Agent System: `AGENT_SYSTEM.md` com guia de extensão

### Ferramentas
- TypeScript Docs: https://www.typescriptlang.org/docs/
- React Docs: https://react.dev
- PostgreSQL: https://www.postgresql.org/docs/
- Node.js Docs: https://nodejs.org/en/docs/
- Puppeteer: https://pptr.dev/
- Google Gemini: https://ai.google.dev/

### Análises Técnicas
- `ANALISE_DJEN_DATAJUD.md` - Testes e cobertura
- `ANALISE_TECNICA_WORKER_SCHEDULER.md` - Detalhes da automação
- `FIX_ROBOT_DIAGNOSTICO.md` - Setup do RPA
- `FIX_DASHBOARD_AGENTES.md` - Dados de teste

---

## 1️⃣1️⃣ CHECKLIST PARA NOVOS FEATURES

Antes de mergear PR, verificar:

- [ ] TypeScript compila sem erros: `npm run build`
- [ ] Testes passam: `npm test`
- [ ] Sem `console.log()` ou `debugger` no código
- [ ] SQL usa parameterized queries
- [ ] Sem hardcoded secrets/URLs
- [ ] Comentários explicam o "por quê"
- [ ] Mensagem de commit segue convenção
- [ ] Database migration criada (se necessário)
- [ ] Arquivo `.env.example` atualizado
- [ ] Logs estruturados com Pino (se backend)

---

## 1️⃣2️⃣ TROUBLESHOOTING COMUM

### Build falha
```bash
# Limpar cache
rm -r node_modules package-lock.json
npm install
npm run build
```

### Worker não processa tarefas
```bash
# Verificar fila
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:3001/api/agent/tasks

# Ver logs
npm run dev 2>&1 | grep Worker
```

### PostgreSQL connection fail
```bash
# Checar .env
echo $DATABASE_URL

# Testar conexão
psql $DATABASE_URL -c "SELECT 1"
```

### Puppeteer/Chromium error
```bash
# Reinstalar
npm rebuild @sparticuz/chromium
npm run dev
```

---

## 1️⃣3️⃣ PRÓXIMOS PASSOS PRIORITÁRIOS

**Crítico (Esta semana):**
1. [ ] Implementar timeout global (30s) no Worker
2. [ ] Criar Dead Letter Queue para reprocessing
3. [ ] Adicionar circuit breaker por ferramenta

**Importante (Este mês):**
4. [ ] Prometheus metrics + Grafana
5. [ ] Alertas Slack para anomalias
6. [ ] Testes de carga (100+ tarefas/min)

**Nice-to-have (Próxima sprint):**
7. [ ] Dashboard "Agentes" com dados em tempo real
8. [ ] Integração com Stripe para billing
9. [ ] Mobile app (React Native)

---

## 📞 SUPORTE

**Dúvidas sobre Copilot?**
- Este arquivo: `.github/copilot-instructions.md`
- Documentação oficial: https://github.com/features/copilot

**Issues no projeto?**
- GitHub Issues: https://github.com/thiagobodevan/assistente-juridico/issues
- Análises técnicas na raiz do repo

**Contato:**
- Desenvolvedor: Thiago Bodevan
- Email: (em .env ou README)

---

**Última atualização**: 14 de novembro de 2025  
**Versão**: 1.0  
**Status**: ✅ Ativo

# GitHub Copilot Agents - Quick Reference

## 🎯 When to Use Each Agent

| Your Task | Agent to Use | Example Prompt |
|-----------|-------------|----------------|
| Analyze legal documents | `@legal-expert` | Extract CNJ, parties, and deadlines from this expediente |
| Generate legal drafts | `@legal-expert` | Create a contestação draft for this intimation |
| Calculate legal deadlines | `@legal-expert` | Calculate prazo considering CPC rules and holidays |
| Add new agent tool | `@agent-system-expert` | Create a tool for sending email notifications |
| Modify worker loop | `@agent-system-expert` | Add timeout handling to the worker |
| Implement task retry | `@agent-system-expert` | Add exponential backoff for failed tasks |
| Build React component | `@frontend-expert` | Create a card component for displaying processos |
| Add dashboard feature | `@frontend-expert` | Implement real-time updates using WebSocket |
| Style with Tailwind | `@frontend-expert` | Style this form with our theme colors |
| Design database schema | `@database-expert` | Create schema for tracking document versions |
| Optimize slow query | `@database-expert` | This query takes 5s, please optimize it |
| Write migration | `@database-expert` | Add indexes for faster expediente searches |
| Automate PJe portal | `@automation-expert` | Implement login flow with 2FA handling |
| Fix robot errors | `@automation-expert` | Handle session timeout in PJe robot |
| Download documents | `@automation-expert` | Add document download from expediente page |
| Integrate Gemini API | `@ai-integration-expert` | Call Gemini to analyze this legal text |
| Improve prompts | `@ai-integration-expert` | Optimize prompt for better deadline extraction |
| Select AI model | `@ai-integration-expert` | Should I use Flash or Pro for this task? |
| Write unit tests | `@testing-expert` | Create tests for the CNJ validation function |
| Test API endpoint | `@testing-expert` | Write integration tests for POST /api/processos |
| Mock external API | `@testing-expert` | Mock Gemini API responses in tests |

## 📋 Common Workflows

### Adding a New Feature

```
Step 1: @database-expert Design schema for feature X
Step 2: @agent-system-expert Create tool for feature X
Step 3: @frontend-expert Build UI for feature X
Step 4: @testing-expert Write tests for feature X
```

### Fixing a Bug

```
Step 1: @[relevant-expert] This error occurs: [paste error]
Step 2: Follow their diagnostic steps
Step 3: @testing-expert Add regression test
```

### Optimizing Performance

```
Step 1: @database-expert Optimize this query
Step 2: @frontend-expert Reduce re-renders in this component
Step 3: @automation-expert Speed up browser automation
```

## 💡 Pro Tips

### Be Specific
❌ "Fix the robot"
✅ "@automation-expert The PJe robot fails with 'Session expired' after 30 minutes. Add session refresh logic."

### Provide Context
❌ "Create a component"
✅ "@frontend-expert Create a ProcessoCard component that shows CNJ, client name, and status. Use our Tailwind theme colors."

### Reference Files
❌ "Update the tool"
✅ "@agent-system-expert In /backend/src/agent/tools.ts, add a tool called 'djen.search' that queries DJEN API"

### Ask for Explanation
```
@agent-system-expert Explain how the task retry logic works in worker.ts
@ai-integration-expert What's the difference between gemini-2.5-flash and gemini-2.5-pro?
```

## 🚫 What Agents CAN'T Do

- Access external systems directly (they generate code, you run it)
- Make production changes (they suggest, you review and deploy)
- Override security best practices (they follow them strictly)
- Test code execution (you must test their solutions)

## 🔄 Iterating with Agents

```
You: @legal-expert Create a deadline calculator
Agent: [provides solution]

You: @legal-expert Good, but add support for CLT deadlines too
Agent: [updates solution]

You: @legal-expert Now handle holidays from the database
Agent: [final solution]
```

## 📚 Learn More

- [Full Agent Documentation](.github/agents/README.md)
- [Detailed Usage Guide](.github/agents/USAGE_GUIDE.md)
- [Repository README](README.md)
- [Copilot Instructions](.github/copilot-instructions.md)

## 🎓 Best Practices

1. **Choose the Right Agent**: Match task to agent expertise
2. **Start Small**: Begin with simple, well-defined tasks
3. **Review Everything**: Agents assist, you decide
4. **Test Thoroughly**: Always test agent-generated code
5. **Provide Feedback**: Refine prompts based on results

---

**Remember**: Agents are specialized assistants. Use them to accelerate development, but always apply your judgment and testing before deploying to production.

# GitHub Copilot Cloud Agents

This directory contains specialized GitHub Copilot agents for the Assistente Jurídico PJe project. Each agent is an expert in a specific domain and can be invoked to handle specialized tasks.

## Available Agents

### 1. Legal Expert (`legal-expert`)
**Specialization**: Brazilian legal system (PJe), document analysis, and legal drafting

**Use Cases**:
- Analyzing legal documents (expedientes, intimações)
- Extracting structured information (CNJ numbers, parties, deadlines)
- Generating legal briefs and petitions (minutas)
- Calculating legal deadlines (CPC, CLT)
- PJe portal automation tasks

**Key Expertise**:
- PJe system knowledge
- Brazilian legal framework (Civil, Labor, Procedural law)
- Document classification (SIMPLE_REPLY, DRAFT_RESPONSE, HUMAN_REVIEW)
- Legal document generation

### 2. Agent System Expert (`agent-system-expert`)
**Specialization**: Autonomous agent architecture, task queues, and orchestration

**Use Cases**:
- Creating new agent tools
- Extending the worker loop
- Implementing task retry logic
- Building agent orchestration flows
- Event-driven system integration

**Key Expertise**:
- AgentKernel architecture
- Worker loop with polling and backoff
- Tool Registry pattern
- Task queue management
- Event bus implementation

### 3. Frontend Expert (`frontend-expert`)
**Specialization**: React 19, TypeScript, Vite, and Tailwind CSS

**Use Cases**:
- Building new UI components
- Implementing dashboard features
- WebSocket integration for real-time updates
- State management with Zustand
- Theme system customization

**Key Expertise**:
- Modern React patterns (hooks, functional components)
- Tailwind CSS styling
- Responsive design
- WebSocket communication
- TypeScript strict typing

### 4. Database Expert (`database-expert`)
**Specialization**: PostgreSQL design, migrations, and optimization

**Use Cases**:
- Creating database schemas
- Writing optimized queries
- Implementing repository patterns
- Database migrations
- Performance tuning

**Key Expertise**:
- PostgreSQL 15 features
- SQL injection prevention (parameterized queries)
- Connection pooling
- Index optimization
- Transaction management

### 5. Automation Expert (`automation-expert`)
**Specialization**: Puppeteer automation and PJe portal RPA

**Use Cases**:
- Building PJe portal automation flows
- Handling session management and 2FA
- Implementing error recovery strategies
- Scheduling automated checks
- Browser automation optimization

**Key Expertise**:
- Puppeteer best practices
- PJe portal navigation
- Session persistence
- Error handling with screenshots
- Headless Chrome optimization

### 6. AI Integration Expert (`ai-integration-expert`)
**Specialization**: Google Gemini API integration and prompt engineering

**Use Cases**:
- Integrating new AI features
- Prompt engineering for legal tasks
- Implementing structured output (JSON mode)
- RAG (Retrieval-Augmented Generation)
- Cost optimization

**Key Expertise**:
- Gemini API (Flash, Pro models)
- Prompt engineering patterns
- Token management
- Error handling and rate limiting
- Model selection strategies

### 7. Testing Expert (`testing-expert`)
**Specialization**: Testing strategies, Jest, and quality assurance

**Use Cases**:
- Writing unit and integration tests
- Mocking external services (PJe, Gemini API)
- Testing agent tools and workflows
- Database testing strategies
- CI/CD test automation

**Key Expertise**:
- Jest testing framework
- Supertest for API testing
- Test organization (AAA pattern)
- Mock strategies
- Test coverage optimization

## How to Use Cloud Agents

### In GitHub Copilot Chat

1. **Mention the agent** in your prompt:
   ```
   @legal-expert Please analyze this expediente and extract the deadline
   ```

2. **Delegate complex tasks**:
   ```
   @agent-system-expert Create a new tool for DJEN analysis with retry logic
   ```

3. **Ask for specialized guidance**:
   ```
   @frontend-expert How should I implement real-time updates for the dashboard?
   ```

### In Pull Requests

Agents can be invoked in PR comments:
```
@automation-expert Please review the PJe login flow changes
```

### Best Practices

1. **Choose the Right Agent**: Select the agent that matches your task domain
2. **Provide Context**: Give the agent relevant information about your specific task
3. **Be Specific**: Clear, specific requests get better results
4. **Combine Agents**: For complex tasks, you may need multiple agents
5. **Review Agent Work**: Always review and test agent-generated code

## Agent Architecture

All agents follow these principles:
- **Domain Expertise**: Deep knowledge in their specific area
- **Code Quality**: Follow repository standards and best practices
- **Testing**: Emphasize testing and validation
- **Documentation**: Clear, maintainable code with good comments
- **Security**: Follow security best practices (SQL injection prevention, etc.)

## Extending Agents

To add a new agent:

1. Create a new JSON file in `.github/agents/`:
   ```json
   {
     "name": "my-expert",
     "description": "Expert in...",
     "instructions": "Detailed instructions...",
     "tools": ["bash", "view", "create", "edit"]
   }
   ```

2. Define clear:
   - Name and description
   - Domain expertise
   - Use cases
   - Code standards
   - Key files

3. Test the agent with sample tasks

## Repository Context

These agents are specifically tuned for:
- **Project**: Assistente Jurídico PJe - Thiago Bodevan Advocacia
- **Stack**: Node.js, React, TypeScript, PostgreSQL, Puppeteer, Google Gemini
- **Domain**: Legal automation for Brazilian judicial system (PJe)
- **Architecture**: Full-stack with autonomous agents

## Additional Resources

- [Repository README](../../README.md)
- [Copilot Instructions](../copilot-instructions.md)
- [Architecture Documentation](../../ARCHITECTURE.md) (if exists)
- [Agent System Documentation](../../backend/src/agent/README.md) (if exists)

---

**Last Updated**: November 2024
**Maintained By**: Thiago Bodevan
**Version**: 1.0
# GitHub Copilot Agents

This directory contains specialized GitHub Copilot agent configurations for the Assistente Jurídico PJe project.

## What are Copilot Agents?

GitHub Copilot agents are specialized AI assistants that have deep knowledge of specific domains, tools, and coding patterns. They can be "delegated to" when working on specialized tasks, providing expert-level assistance that goes beyond generic coding help.

## Available Agents

### Legal Assistant Agent

**File**: `legal-assistant.md` | **Manifest**: `legal-assistant.json`

A specialized agent for Brazilian legal process automation with expertise in:

- **PJe System**: Deep understanding of PJe (Processo Judicial Eletrônico) workflow and automation
- **Brazilian Legal Framework**: CPC, CLT, and procedural rules
- **Legal Document Analysis**: CNJ numbers, parties, deadlines extraction
- **Legal Drafting**: Generating petições, manifestações, and legal documents
- **Deadline Calculation**: Brazilian legal deadline rules (dias úteis, corridos, holidays)
- **Court Systems**: DJEN, DataJud integration and analysis
- **Agent System Development**: Adding tools, managing worker loops, event buses

#### When to Use

Delegate to this agent when:
- Implementing new legal automation features
- Working with the agent system (`/backend/src/agent/`)
- Integrating legal APIs (DJEN, DataJud, PJe)
- Analyzing or drafting legal documents with AI
- Calculating legal deadlines
- Adding new agent tools to the registry
- Debugging PJe automation issues

#### Example Delegations

```
@legal-assistant Add a new agent tool to calculate honorários advocatícios based on case value and complexity

@legal-assistant Implement deadline calculation for CLT labor law cases considering feriados nacionais

@legal-assistant Create a function to parse CNJ numbers and validate their structure

@legal-assistant Debug why the DJEN search is not returning results for OAB queries
```

## How to Use Agents

### In GitHub Copilot Chat

1. **Direct Delegation**: Start your message with `@agent-name` to directly invoke the agent
   ```
   @legal-assistant How do I add a new tool to the agent registry?
   ```

2. **Context-Aware**: The agent has full knowledge of the codebase structure and patterns
   ```
   @legal-assistant Implement a service to query DataJud API with proper caching
   ```

3. **Specialized Tasks**: Delegate domain-specific work that requires expert knowledge
   ```
   @legal-assistant Calculate prazo recursal for a sentença considering the CPC rules
   ```

### In Development Workflow

1. **Planning**: Ask the agent to plan implementation approach
   ```
   @legal-assistant What's the best way to integrate a new tribunal's DJEN API?
   ```

2. **Implementation**: Get expert-level code generation
   ```
   @legal-assistant Create the route, service, and agent tool for processo calculation
   ```

3. **Review**: Ask for code review with domain expertise
   ```
   @legal-assistant Review this legal document parser for edge cases
   ```

4. **Testing**: Generate appropriate tests
   ```
   @legal-assistant Create Jest tests for the deadline calculation function
   ```

## Agent Architecture

Each agent configuration includes:

### Markdown Documentation (`*.md`)
Human-readable comprehensive guide with:
- Expertise areas and domain knowledge
- System architecture overview
- Coding standards and best practices
- Common task patterns
- Security and performance guidelines
- Examples and references

### JSON Manifest (`*.json`)
Machine-readable specification with:
- Agent metadata (name, version, description)
- Capabilities and domains
- Tech stack definition
- Key features mapping
- Common tasks with steps
- Coding standards
- Tool definitions
- Environment variables
- Deployment configuration
- Best practices list

## Creating New Agents

To create a new specialized agent:

1. **Create Documentation**: `agents/[agent-name].md`
   - Define expertise and domain
   - Document system architecture relevant to domain
   - Provide coding standards and patterns
   - Include examples and common tasks

2. **Create Manifest**: `agents/[agent-name].json`
   - Define capabilities and tech stack
   - List tools and features
   - Specify coding standards
   - Document environment requirements

3. **Update This README**: Add agent to the "Available Agents" section

## Agent Development Guidelines

When developing agent configurations:

### ✅ Do
- Focus on specific domain expertise
- Include practical examples and code snippets
- Document common patterns and anti-patterns
- Provide clear task-oriented guidance
- Reference actual codebase structure
- Include security and performance considerations
- Maintain consistency with project standards

### ❌ Don't
- Create overly generic agents (use base Copilot)
- Duplicate information across agents
- Include outdated or incorrect information
- Ignore security best practices
- Forget to update when system evolves

## Integration with CI/CD

Agents can help with:
- **GitHub Actions**: Debugging workflow failures, optimizing builds
- **Deployment**: Render and Vercel configuration issues
- **Database**: PostgreSQL migrations and query optimization
- **Testing**: Jest test generation and debugging

## Maintenance

Agent configurations should be updated when:
- New features are added to the system
- Tech stack changes (new libraries, frameworks)
- Coding standards evolve
- New tools are added to the agent registry
- Deployment infrastructure changes

## Benefits of Using Agents

1. **Domain Expertise**: Deep knowledge of Brazilian legal system and PJe
2. **Consistency**: Follows established patterns and standards
3. **Speed**: Faster implementation with expert guidance
4. **Quality**: Built-in best practices and security considerations
5. **Learning**: Helps developers understand domain-specific concepts
6. **Reduced Errors**: Catches common mistakes and edge cases

## Examples of Agent Impact

### Before Agent
```typescript
// Generic implementation without legal domain knowledge
function calculateDeadline(days: number) {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return date;
}
```

### With Legal Assistant Agent
```typescript
// Proper implementation considering Brazilian legal rules
function calculateDeadline(
  prazo: number,
  tipo: 'uteis' | 'corridos',
  dataInicial: Date,
  tribunal: string
): Date {
  const feriados = getFeriadosNacionais(dataInicial.getFullYear());
  const feriadosLocais = getFeriadosLocais(tribunal);
  
  let diasContados = 0;
  let currentDate = new Date(dataInicial);
  
  while (diasContados < prazo) {
    currentDate.setDate(currentDate.getDate() + 1);
    
    if (tipo === 'corridos') {
      diasContados++;
    } else {
      // Skip weekends and holidays for 'úteis'
      if (!isWeekend(currentDate) && !isFeriado(currentDate, feriados, feriadosLocais)) {
        diasContados++;
      }
    }
  }
  
  return currentDate;
}
```

## Support

For issues or improvements to agent configurations:
- Open an issue with tag `agent-configuration`
- Propose changes via PR to `.github/agents/`
- Discuss in team chat for major agent additions

## References

- [GitHub Copilot Documentation](https://docs.github.com/en/copilot)
- [Project README](/README.md)
- [Coding Standards](/.github/copilot-instructions.md)
- [Agent System Architecture](/backend/src/agent/)

---

**Last Updated**: November 2025  
**Maintained By**: Development Team  
**Status**: ✅ Active

# How to Use GitHub Copilot Cloud Agents

This guide shows you how to effectively use the specialized cloud agents configured for the Assistente Jurídico PJe project.

## Quick Start

### 1. Invoking Agents in Copilot Chat

In your IDE with GitHub Copilot enabled, use the `@` symbol to invoke agents:

```
@legal-expert How do I implement deadline extraction from expedientes?
```

The agent will provide specialized guidance based on its domain expertise.

### 2. Delegating Tasks

Instead of asking for advice, you can delegate entire tasks:

```
@agent-system-expert Create a new tool for checking PJe session status and register it in the bootstrap
```

The agent will implement the complete solution, following the repository's patterns.

### 3. Code Review

Ask agents to review specific changes:

```
@frontend-expert Review this new dashboard component for best practices
```

## Agent Usage Examples

### Legal Expert

**Task**: Implement expediente analysis
```
@legal-expert I need to extract CNJ numbers, parties, and deadlines from PJe expedientes. 
The data comes as HTML content. Please create a parser function.
```

**Task**: Generate legal documents
```
@legal-expert Create a tool that generates a legal brief (minuta de contestação) 
based on expediente content using Gemini API.
```

### Agent System Expert

**Task**: Add new agent tool
```
@agent-system-expert Add a new tool for sending WhatsApp notifications 
when deadlines are approaching. Include retry logic and event emission.
```

**Task**: Optimize worker
```
@agent-system-expert The worker loop is processing tasks slowly. 
Review worker.ts and suggest optimizations.
```

### Frontend Expert

**Task**: Create new page
```
@frontend-expert Create a new page for managing client contacts with 
CRUD operations, using our existing API service and Tailwind styling.
```

**Task**: Add real-time updates
```
@frontend-expert Implement WebSocket updates for the robot status 
in the dashboard. The backend sends 'robot.status' events.
```

### Database Expert

**Task**: Design schema
```
@database-expert Design a database schema for tracking document versions 
with full audit trail. Include migration script.
```

**Task**: Optimize query
```
@database-expert This query is slow:
SELECT * FROM processos WHERE status = 'active' AND prazo_final < NOW()
Please optimize it.
```

### Automation Expert

**Task**: PJe automation
```
@automation-expert Implement a Puppeteer flow to download documents 
from PJe portal for a specific process number, handling 2FA and session management.
```

**Task**: Error handling
```
@automation-expert The robot crashes when PJe shows a CAPTCHA. 
Add proper error detection and recovery.
```

### AI Integration Expert

**Task**: Prompt engineering
```
@ai-integration-expert Create a prompt for Gemini to extract structured 
deadline information from legal text, returning JSON with prazo_dias, tipo, and data_final.
```

**Task**: Model selection
```
@ai-integration-expert Should I use gemini-2.5-flash or gemini-2.5-pro 
for analyzing 50-page legal documents? Consider cost and accuracy.
```

## Advanced Usage Patterns

### Combining Multiple Agents

For complex features, you might need multiple agents:

1. **Database Expert**: Design the schema
2. **Backend Expert**: Implement the API
3. **Frontend Expert**: Create the UI
4. **Testing Expert**: Write tests

Example workflow:
```
@database-expert Design a schema for legal timeline tracking

[Wait for implementation]

@agent-system-expert Create a tool that records timeline events to the database

[Wait for implementation]

@frontend-expert Create a timeline visualization component
```

### Iterative Refinement

You can iterate with agents:

```
@legal-expert Create a deadline calculator

[Review output]

@legal-expert The calculator doesn't handle feriados (holidays). 
Please add support for Brazilian legal holidays from a database table.

[Review again]

@legal-expert Add support for CLT (labor law) deadlines which have 
different rules than CPC deadlines.
```

### Asking for Explanations

Agents can explain code:

```
@agent-system-expert Explain how the task retry logic works in worker.ts
```

## Best Practices

### ✅ DO:
- **Be Specific**: Provide clear requirements and context
- **Provide Examples**: Show sample data or expected outputs
- **Mention Files**: Reference specific files when relevant
- **Review Output**: Always review and test agent-generated code
- **Iterate**: Refine the output through follow-up questions

### ❌ DON'T:
- **Be Vague**: "Make it better" - specify what needs improvement
- **Skip Testing**: Always test agent-generated code
- **Mix Concerns**: Keep tasks focused on the agent's domain
- **Ignore Warnings**: Pay attention to security and best practice warnings

## Common Scenarios

### Scenario 1: Adding a New Feature

**Goal**: Add DJEN (legal gazette) analysis

1. **Design Phase**:
   ```
   @legal-expert What data should we extract from DJEN publications? 
   Suggest a data structure.
   ```

2. **Backend Implementation**:
   ```
   @agent-system-expert Create a tool 'djen.analyze' that fetches DJEN data 
   and analyzes it with Gemini API
   ```

3. **Database Schema**:
   ```
   @database-expert Create a table to store DJEN analysis results
   ```

4. **Frontend UI**:
   ```
   @frontend-expert Create a page to view DJEN analysis results with filters
   ```

### Scenario 2: Debugging an Issue

**Problem**: PJe robot login fails intermittently

1. **Initial Diagnosis**:
   ```
   @automation-expert The PJe login sometimes fails with "Session expired". 
   Here's the error log: [paste log]
   ```

2. **Solution Implementation**:
   ```
   @automation-expert Add session validation before each action and 
   automatic re-login if session is invalid
   ```

### Scenario 3: Performance Optimization

**Problem**: Dashboard loads slowly

1. **Database Review**:
   ```
   @database-expert The dashboard query takes 5 seconds. Here's the query: 
   [paste query]. How can I optimize it?
   ```

2. **Frontend Optimization**:
   ```
   @frontend-expert The dashboard re-renders too often. 
   Review the component and suggest React optimization techniques.
   ```

## Tips for Success

1. **Start Small**: Begin with small, well-defined tasks
2. **Provide Context**: Share relevant code, errors, or requirements
3. **Ask Questions**: If unsure, ask the agent for guidance first
4. **Combine Tools**: Use agent expertise with your own knowledge
5. **Document Changes**: Ensure agent changes are properly documented

## Troubleshooting

### Agent Doesn't Understand Context

**Solution**: Provide more specific information:
```
@legal-expert I'm working on /backend/src/agent/tools.ts. 
I need to add a tool that validates CNJ numbers according to 
Resolution 65/2008 of CNJ. The format is NNNNNNN-DD.AAAA.J.TR.OOOO.
```

### Agent Suggests Wrong Approach

**Solution**: Redirect with constraints:
```
@agent-system-expert Don't use Redis. We only have PostgreSQL available. 
Please implement the queue using PostgreSQL.
```

### Need Human Oversight

Some tasks need human review:
- Security-critical changes
- Legal logic validation
- Production deployment decisions
- API contract changes

## Learning Resources

- [GitHub Copilot Documentation](https://docs.github.com/copilot)
- [Repository README](../README.md)
- [Copilot Instructions](../.github/copilot-instructions.md)
- [Agent README](./.github/agents/README.md)

## Feedback

If an agent isn't meeting your needs:
1. Refine your prompt with more specifics
2. Provide examples of desired output
3. Iterate with follow-up questions
4. Consider if a different agent might be more appropriate

---

**Remember**: Agents are assistants, not replacements for your judgment. Always review, test, and validate agent-generated code before committing to production.

# 🔐 GitHub Secrets - Referência Completa

## 📋 Variáveis de Ambiente Obrigatórias para CI/CD

Este arquivo documenta TODOS os secrets requeridos para o pipeline funcionar corretamente.

### ✅ Secrets do Backend (Backend API)

| Secret | Descrição | Exemplo | Crítico |
|--------|-----------|---------|---------|
| `API_KEY` | Chave da Google Gemini API | `AIza...` | 🔴 SIM |
| `DATAJUD_API_KEY` | Token API DataJud | `Bearer abc123...` | 🔴 SIM |
| `DATAJUD_BASE_URL` | URL base DataJud | `https://api.datajud.cnj.jus.br` | 🔴 SIM |
| `DATAJUD_CACHE_TTL_MS` | TTL cache DataJud | `3600000` | 🟡 NÃO |
| `DATAJUD_DEFAULT_TRIBUNAL` | Tribunal padrão | `TJMG` | 🟡 NÃO |
| `DJEN_BASE_URL` | URL base DJEN | `https://www.conjur.com.br/api` | 🔴 SIM |
| `DJEN_CACHE_TTL_MS` | TTL cache DJEN | `7200000` | 🟡 NÃO |
| `DJEN_REQUEST_INTERVAL_MS` | Rate limit DJEN | `1000` | 🟡 NÃO |
| `JWT_SECRET` | Secret JWT para auth | `my-super-secret-key-min-32-chars!` | 🔴 SIM |
| `PGSSL` | PostgreSQL SSL mode | `require` ou `disable` | 🔴 SIM |
| `PJE_LOGIN_URL` | URL base PJe | `https://pje.tjmg.jus.br` | 🔴 SIM |
| `PJE_LOGIN_USER` | Usuário PJe (teste) | `usuario.teste@tjmg.jus.br` | 🔴 SIM |
| `PJE_LOGIN_PASS` | Senha PJe (teste) | `SenhaTemporaria123!` | 🔴 SIM |
| `CHROMA_URL` | Endpoint ChromaDB | `http://localhost:8000` | 🟡 NÃO |
| `GOOGLE_CLIENT_ID` | Google OAuth Client ID | `123456.apps.googleusercontent.com` | 🔴 SIM |
| `GOOGLE_ALLOWED_DOMAIN` | Domínios OAuth permitidos | `example.com,test.com` | 🟡 NÃO |
| `VAPID_PUBLIC_KEY` | Push notifications public key | `BCXY...` | 🔴 SIM |
| `VAPID_PRIVATE_KEY` | Push notifications private key | `abc123...` | 🔴 SIM |
| `ADMIN_USERNAME` | Admin backend username | `admin` | 🔴 SIM |
| `ADMIN_PASSWORD` | Admin backend password | `AdminPass123!` | 🔴 SIM |

### ✅ Secrets do Frontend

| Secret | Descrição | Exemplo | Crítico |
|--------|-----------|---------|---------|
| `VITE_BACKEND_URL` | URL do backend | `https://api.example.com` | 🟡 NÃO* |
| `GOOGLE_CLIENT_ID` | Google OAuth (same as backend) | `123456.apps.googleusercontent.com` | 🔴 SIM |
| `VAPID_PUBLIC_KEY` | Push notifications (same as backend) | `BCXY...` | 🔴 SIM |

*Fallback padrão: `https://assistente-juridico-rs1e.onrender.com`

---

## 🔧 Como Configurar

### 1️⃣ GitHub Web UI
```
Repo → Settings → Secrets and variables → Actions → New repository secret
```

### 2️⃣ GitHub CLI
```bash
gh secret set API_KEY --body "AIza..."
gh secret set JWT_SECRET --body "my-secret-32-chars-minimum!"
gh secret set DATAJUD_API_KEY --body "Bearer token..."
# ... etc para todos
```

### 3️⃣ Validar Secrets Configurados
```bash
gh secret list
```

---

## 📝 Template para .env.local (Desenvolvimento)

```bash
# Backend
NODE_ENV=development
PORT=3001
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/assistente_juridico
API_KEY=AIza...
DATAJUD_API_KEY=Bearer...
DATAJUD_BASE_URL=https://api.datajud.cnj.jus.br
DATAJUD_CACHE_TTL_MS=3600000
DATAJUD_DEFAULT_TRIBUNAL=TJMG
DJEN_BASE_URL=https://www.conjur.com.br/api
DJEN_CACHE_TTL_MS=7200000
DJEN_REQUEST_INTERVAL_MS=1000
JWT_SECRET=my-super-secret-key-min-32-chars!
PGSSL=disable
PJE_LOGIN_URL=https://pje.tjmg.jus.br
PJE_LOGIN_USER=usuario.teste@tjmg.jus.br
PJE_LOGIN_PASS=SenhaTemporaria123!
CHROMA_URL=http://localhost:8000
GOOGLE_CLIENT_ID=123456.apps.googleusercontent.com
GOOGLE_ALLOWED_DOMAIN=example.com
VAPID_PUBLIC_KEY=BCXY...
VAPID_PRIVATE_KEY=abc123...
ADMIN_USERNAME=admin
ADMIN_PASSWORD=AdminPass123!
FRONTEND_ORIGIN=http://localhost:5173

# Frontend
VITE_BACKEND_URL=http://localhost:3001
```

---

## ✅ Checklist de Validação

- [ ] Todos os 20 secrets configurados no GitHub
- [ ] Nenhum secret contém espaços extras
- [ ] API keys testadas e funcionando
- [ ] Senhas são seguras (min 12 caracteres, complexas)
- [ ] URLs terminam sem trailing slash
- [ ] JWT_SECRET tem pelo menos 32 caracteres
- [ ] Secrets não estão no código-fonte
- [ ] `.env` não está versionado (em `.gitignore`)

---

## 🚨 Troubleshooting

### "Secret not found" no CI
```
✓ Verificar nome exato (case-sensitive)
✓ Verificar se está em "Actions" secrets (não "Dependabot")
✓ Fazer commit nova branch, abrir PR para testar
```

### Testes falhando por secrets
```bash
# No CI, adicione debug:
- name: Debug secrets
  run: |
    echo "API_KEY: ${#API_KEY}"  # Printa comprimento, não valor
    echo "JWT_SECRET length: ${#JWT_SECRET}"
    # Nunca printe o valor completo dos secrets!
```

### Build backend falhando com "Cannot connect to DB"
```
✓ Verificar DATABASE_URL (CI usa postgres:postgres@localhost)
✓ Verificar PGSSL=disable (CI não tem SSL)
✓ Ver se PostgreSQL service está healthy (check logs)
```

---

## 🔒 Segurança

### ❌ NÃO FAÇA
- Commitear `.env` com valores reais
- Pringar secrets em logs
- Compartilhar URLs com senhas
- Usar mesma senha para todos os ambientes

### ✅ FAÇA
- Rotacionar secrets periodicamente (3-6 meses)
- Usar vault/secret manager para produção
- Auditoria de quem acessou secrets
- Secrets diferentes por ambiente (dev, staging, prod)

---

## 📞 Suporte

Para dúvidas:
1. Verificar este arquivo
2. Ver logs do CI/CD (Actions → workflow)
3. Contactar `thiagobodevan`

**Última atualização**: 14 de novembro de 2025  
**Versão**: 1.0  
**Status**: ✅ Ativo

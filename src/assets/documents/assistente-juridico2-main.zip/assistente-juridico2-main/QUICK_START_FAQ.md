# ⚡ Quick Start & FAQ - Assistente Jurídico PJe

**Data**: 14 de novembro de 2025  
**Propósito**: Referência rápida para desenvolvedores  
**Tempo de Leitura**: 10 minutos

---

## 🚀 QUICK START (5 minutos)

### 1️⃣ Setup Inicial

```bash
# Clone repo
git clone https://github.com/thiagobodevan/assistente-juridico.git
cd assistente-juridico

# Install dependencies
npm install
cd backend && npm install && cd ..

# Setup environment
cp .env.example .env
nano .env  # Edit with your secrets

# Start PostgreSQL (Docker)
docker compose up -d

# Start dev servers
# Terminal 1:
npm run dev

# Terminal 2:
cd backend && npm run dev
```

**Result**: 
- Frontend: http://localhost:5173
- Backend: http://localhost:3001
- Database: localhost:5432

---

### 2️⃣ Primeiro Teste

```bash
# Terminal 3: Test API
curl -X GET http://localhost:3001/health

# Expected:
# {"status":"ok","timestamp":"2025-11-14T..."}
```

---

### 3️⃣ Verificar Builds

```bash
# Frontend build
npm run build
# ✅ dist/ criado

# Backend build
cd backend && npm run build
# ✅ dist/ criado
```

---

## ❓ FAQ - PERGUNTAS FREQUENTES

### Q1: "Como adicionar nova rota API?"

**R**: Criar em `/backend/src/routes/`:

```typescript
// /backend/src/routes/minhaRota.ts
import express, { Request, Response } from 'express';
import { authMiddleware } from '../middleware/authMiddleware';

const router = express.Router();

router.get('/novo-endpoint', authMiddleware, async (req: Request, res: Response) => {
    try {
        // Sua lógica aqui
        res.status(200).json({ mensagem: 'sucesso' });
    } catch (error) {
        res.status(500).json({ erro: (error as Error).message });
    }
});

export default router;
```

Depois, registrar em `/backend/src/server.ts`:
```typescript
import minhaRota from './routes/minhaRota';

// ...
app.use('/api/minha', authMiddleware as RequestHandler, minhaRota);
```

---

### Q2: "Como adicionar nova tarefa ao Worker?"

**R**: 
```typescript
// backend/src/agent/worker.ts - adicionar case:
case 'MINHA_TAREFA':
    toolName = 'meu.namespace.tarefa';
    break;

// backend/src/agent/bootstrap.ts - registrar tool:
tools.register('meu.namespace.tarefa', {
    execute: async (payload: any, ctx: any) => {
        // Sua implementação
        return { resultado: 'ok' };
    }
});

// Enfileirar tarefa:
await taskRepo.queue('MINHA_TAREFA', { param: 'valor' });
```

---

### Q3: "Como testar localmente sem Gemini API?"

**R**: Mock the service:

```typescript
// backend/src/services/geminiService.ts
const mockResponse = {
    text: 'Parecer jurídico mockado para testes',
    confidence: 0.95
};

export async function generateLegalOpinion(query: string) {
    if (process.env.NODE_ENV === 'test' || process.env.USE_MOCK) {
        return mockResponse;
    }
    // ... real Gemini call
}
```

Set env:
```bash
export USE_MOCK=true
npm run dev
```

---

### Q4: "Como corrigir erro 'Cannot find module'?"

**R**: 
```bash
# 1. Limpar cache
rm -rf node_modules package-lock.json
npm install

# 2. Verificar imports
# ✅ CORRETO: import { service } from '../services/service'
# ❌ ERRADO: import { service } from './services/service' (caminho relativo wrong)

# 3. Se for TypeScript
npm run type-check

# 4. Se for ESLint
npm run lint --fix
```

---

### Q5: "Como debugar API call falhando?"

**R**:
```bash
# 1. Ver logs do backend
npm run dev 2>&1 | grep -i "error\|warn"

# 2. Testar com curl
curl -X GET http://localhost:3001/api/robot/acervo \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -v

# 3. Ver código da resposta
# -v mostra headers + status code

# 4. Verificar secrets
echo $API_KEY
echo $JWT_SECRET

# 5. Check database
psql $DATABASE_URL -c "SELECT COUNT(*) FROM agent_tasks;"
```

---

### Q6: "Como aumentar cobertura de testes?"

**R**:
```bash
# Ver cobertura atual
npm --prefix backend test -- --coverage

# Output: coverage/lcov-report/index.html

# Para aumentar:
1. Escrever testes em backend/src/**/*.test.ts
2. Usar padrão: describe('Component', () => { it('should...', () => {...}) })
3. Mock dependências externas
4. Target: 80% coverage

# Exemplo test:
describe('pjeService', () => {
    it('should fetch acervo successfully', async () => {
        const result = await pjeService.getAcervo();
        expect(result).toBeDefined();
        expect(result.length).toBeGreaterThan(0);
    });
});
```

---

### Q7: "CI Pipeline está falhando, o quê fazer?"

**R**:
```bash
# 1. Ver último log
gh run list  # List runs
gh run view <RUN_ID> --log  # View logs

# 2. Problemas comuns:
# ❌ Secret ausente → gh secret set <NAME> --body <VALUE>
# ❌ Node version → Check .github/workflows/ci.yml
# ❌ Database → Check .env DATABASE_URL
# ❌ ESLint errors → npm run lint --fix
# ❌ Type errors → npm run type-check

# 3. Testar localmente
npm run build
npm run lint
npm test
cd backend && npm run build && npm run lint && npm test
```

---

### Q8: "Preciso fazer deploy manual, como?"

**R**:
```bash
# Vercel (Frontend)
npm run build
vercel deploy --prod

# OU: Automático ao mergear em main

# Render (Backend)
# Automático via render.yaml
# Ou: Push para main e Render detecta mudanças

# Ver status
# https://dashboard.render.com/
# https://vercel.com/thiagobodevan/assistente-juridico
```

---

### Q9: "Como adicionar nova página React?"

**R**:
```typescript
// pages/MinhaPage.tsx
import React, { useState } from 'react';
import { useStore } from '../stores/store'; // Se precisar state global

interface Props {
    id: string;
}

const MinhaPage: React.FC<Props> = ({ id }) => {
    const [loading, setLoading] = useState(false);
    const globalState = useStore(state => state.data);

    const handleClick = async () => {
        setLoading(true);
        try {
            // Sua lógica
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="p-6">
            <h1 className="text-2xl font-bold">Minha Página</h1>
            {loading && <span>Carregando...</span>}
            <button onClick={handleClick}>Clique aqui</button>
        </div>
    );
};

export default MinhaPage;
```

Depois, adicionar rota em `App.tsx`:
```typescript
import MinhaPage from './pages/MinhaPage';

// ... dentro de BrowserRouter
<Route path="/minha-pagina/:id" element={<MinhaPage />} />
```

---

### Q10: "Worker está falhando, como debugar?"

**R**:
```bash
# 1. Ver logs
npm run dev 2>&1 | grep -i "worker\|task\|circuit"

# 2. Verificar DLQ
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:3001/api/robot/dlq/stats

# 3. Check circuit breaker status
npm run dev 2>&1 | grep "Circuit Breaker"

# 4. Testes unitários
npm --prefix backend test -- --testNamePattern="worker"

# 5. Verificar timeout
# Backend deve ter: Promise.race([operation, timeout_30s])

# 6. Check database
psql $DATABASE_URL -c "SELECT * FROM agent_tasks ORDER BY created_at DESC LIMIT 5;"
```

---

### Q11: "Como contribuir com código?"

**R**:
```bash
# 1. Branch de feature
git checkout -b feature/minha-feature
git checkout -b bugfix/meu-bug

# 2. Fazer mudanças
# Seguir padrões em .github/copilot-instructions.md

# 3. Testar localmente
npm run build
npm run lint
npm test
cd backend && npm run build && npm run lint && npm test

# 4. Commit com mensagem clara
git commit -m "feat: adicionar nova funcionalidade"
git commit -m "fix: corrigir bug de autenticação"
git commit -m "docs: adicionar documentação"

# 5. Push e PR
git push origin feature/minha-feature
# Abrir PR no GitHub

# 6. Aguardar CI passar
# GitHub Actions rodará automaticamente
# Se falhar, corrigir e fazer push novamente
```

---

### Q12: "Qual TypeScript version devo usar?"

**R**:
```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "ESNext",
    "strict": true,  // ✅ IMPORTANTE
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true
  }
}
```

**Verificar**:
```bash
npx tsc --version
# Deve ser 5.4+

npm run type-check  # Rodar sempre
```

---

### Q13: "Como estruturar um novo serviço?"

**R**:
```typescript
// backend/src/services/meuService.ts
import pino from 'pino';

const log = pino({ name: 'MeuService' });

export class MeuService {
    private static instance: MeuService;

    private constructor() {}

    static getInstance(): MeuService {
        if (!MeuService.instance) {
            MeuService.instance = new MeuService();
        }
        return MeuService.instance;
    }

    async metodo(param: string): Promise<any> {
        try {
            log.info({ param }, 'Executando método');
            // Sua lógica
            return { sucesso: true };
        } catch (error) {
            log.error({ erro: (error as Error).message }, 'Erro no método');
            throw error;
        }
    }
}

export const meuService = MeuService.getInstance();
```

Usage:
```typescript
import { meuService } from '../services/meuService';

const resultado = await meuService.metodo('valor');
```

---

### Q14: "Qual é o padrão de nomeação?"

**R**:
```
✅ CORRETO:
- Variáveis: camelCase (minhaVariavel)
- Funções: camelCase (minhaFuncao)
- Classes: PascalCase (MinhaClasse)
- Componentes React: PascalCase (MeuComponente)
- Constantes: SCREAMING_SNAKE_CASE (MINHA_CONSTANTE)
- Arquivos: kebab-case (meu-arquivo.ts) ou PascalCase (MeuComponente.tsx)
- Pastas: kebab-case (meu-modulo/)

❌ EVITAR:
- snake_case para funções
- UPPERCASE para variáveis
- Nomes genéricos (data, info, processamento)
```

---

### Q15: "Como monitorar performance?"

**R**:
```bash
# Frontend
npm run build  # Check tamanho final
# → dist/ deve ser < 500KB JS

# Backend
npm run dev 2>&1 | grep "ms"  # Ver tempos de response

# Database
psql $DATABASE_URL -c "\d+ agent_tasks;"  # Ver indexes

# API Response Time
curl -w "Tempo: %{time_total}s\n" http://localhost:3001/health

# Page Load (Frontend)
# F12 → Lighthouse → Run audit
```

---

## 📚 REFERÊNCIAS RÁPIDAS

### Comandos Essenciais
```bash
npm run dev           # Start dev servers
npm run build         # Production build
npm run lint          # Code style
npm run lint:fix      # Auto-fix
npm test              # Run tests
npm run type-check    # TypeScript check

cd backend
npm run dev           # Backend only
npm run test:ci       # CI tests
npm run test:watch    # Watch mode
```

### Arquivos Importantes
```
.env.example              → Template de variáveis
.eslintrc.json           → Configuração ESLint
tsconfig.json            → TypeScript config
vite.config.ts           → Frontend bundler
backend/jest.config.js   → Test config
.github/workflows/ci.yml → CI/CD
```

### URLs Importantes
```
Frontend:   http://localhost:5173
Backend:    http://localhost:3001
Database:   localhost:5432
Health:     http://localhost:3001/health
Docs:       ./ANALISE_ESTRATEGICA.md
```

---

## ✅ CHECKLIST PRÉ-DEPLOY

- [ ] `npm run build` passa
- [ ] `npm run lint` sem erros
- [ ] `npm run type-check` sem erros
- [ ] `npm test` passa
- [ ] `cd backend && npm run build` passa
- [ ] `cd backend && npm run test:ci` passa
- [ ] `.env` configurado com todos os secrets
- [ ] Commit message segue padrão
- [ ] GitHub PR criada
- [ ] CI pipeline passou
- [ ] Code review feito
- [ ] Merge para main

---

**Última Atualização**: 14 de novembro de 2025  
**Versão**: 1.0

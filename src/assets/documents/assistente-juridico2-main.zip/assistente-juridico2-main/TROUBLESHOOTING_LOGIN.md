# Guia de Solução de Problemas de Login

Este guia ajuda a diagnosticar e resolver problemas de autenticação no Assistente Jurídico.

## 🧪 Ferramenta de Teste Rápido

**NOVO!** Acesse a ferramenta de teste interativa em:
```
https://seu-backend.onrender.com/test/test-login.html
```

Esta página permite:
- ✅ Verificar se o backend está online
- ✅ Ver a configuração de autenticação (sem expor senhas)
- ✅ Testar login com diferentes credenciais
- ✅ Testar senhas alternativas rapidamente

**Recomendado:** Use esta ferramenta primeiro antes de seguir o guia manual abaixo!

---

## Sintomas Comuns

### 1. "Usuário ou senha inválidos"

Este erro aparece quando as credenciais fornecidas não correspondem às configuradas no servidor.

#### Possíveis Causas:

**A. Credenciais Incorretas**
- ✅ **Verifique se está usando o username correto**: Por padrão, é `admin`
- ✅ **Verifique se está usando a senha correta**: Por padrão, é `admin123`
- ⚠️ **Não confunda o placeholder**: O campo de usuário mostra "seu.usuario" como exemplo, mas você deve digitar `admin`

**B. Variáveis de Ambiente Incorretas**

As seguintes variáveis controlam a autenticação:
```bash
ADMIN_USERNAME=admin                    # Nome de usuário (padrão: admin)
ADMIN_PASSWORD=admin123                 # Senha em texto plano (opcional)
ADMIN_PASSWORD_HASH=$2b$12$...         # Hash bcrypt da senha (recomendado)
JWT_SECRET=sua_chave_secreta_aqui      # Obrigatório para gerar tokens
```

**Importante:** Se `ADMIN_PASSWORD_HASH` estiver definido, o sistema usará ele. Caso contrário, usará `ADMIN_PASSWORD`.

## Passo a Passo para Diagnóstico

### Passo 1: Verificar Configuração do Backend

Acesse o endpoint de diagnóstico (não expõe dados sensíveis):
```
https://seu-backend.onrender.com/api/auth/config-check
```

Você deve ver uma resposta como:
```json
{
  "adminUsernameConfigured": true,
  "adminUsernameValue": "admin",
  "adminPasswordConfigured": true,
  "adminPasswordHashConfigured": true,
  "usingHashAuth": true,
  "jwtSecretConfigured": true,
  "timestamp": "2025-11-14T03:22:05.818Z"
}
```

**Verifique:**
- ✅ `jwtSecretConfigured: true` (obrigatório)
- ✅ `adminUsernameValue` mostra o username esperado
- ✅ `adminPasswordConfigured: true` OU `adminPasswordHashConfigured: true`

### Passo 2: Verificar Logs do Servidor

No Render.com:
1. Acesse seu serviço backend
2. Clique em **Logs** no menu lateral
3. Tente fazer login no aplicativo
4. Observe as mensagens no log:

```
[Login Attempt] Username: "admin" | Expected: "admin" | Using hash: true
[Login Success] User "admin" logged in successfully
```

OU se falhar:

```
[Login Attempt] Username: "seu.usuario" | Expected: "admin" | Using hash: true
[Login Failed] Username mismatch: received "seu.usuario", expected "admin"
```

ou

```
[Login Attempt] Username: "admin" | Expected: "admin" | Using hash: true
[Login Failed] Password validation failed for user "admin"
```

### Passo 3: Corrigir Configuração

#### Problema: Username Incorreto
Se você vê `Username mismatch` nos logs, está digitando o username errado.

**Solução:** Digite `admin` no campo de usuário (não "seu.usuario").

#### Problema: Password Incorreta
Se você vê `Password validation failed` nos logs, a senha está incorreta.

**Opção A - Resetar para Padrão:**
No Render, **remova** as variáveis:
- `ADMIN_PASSWORD`
- `ADMIN_PASSWORD_HASH`
- `ADMIN_USERNAME` (opcional)

O sistema usará as credenciais padrão: `admin` / `admin123`

**Opção B - Gerar Nova Hash:**

1. No seu computador local, clone o repositório
2. Instale as dependências:
   ```bash
   cd backend
   npm install
   ```
3. Gere a hash para sua senha:
   ```bash
   node src/utils/generatePasswordHash.js SuaSenhaAqui
   ```
4. Copie a hash gerada
5. No Render, defina as variáveis:
   ```
   ADMIN_USERNAME=admin
   ADMIN_PASSWORD_HASH=<hash copiada>
   ```
6. Remova `ADMIN_PASSWORD` se existir

#### Problema: JWT_SECRET não configurado

Se nos logs aparece: `JWT_SECRET não está definido`

**Solução:**
1. Gere uma chave secreta longa e aleatória
2. No Render, adicione a variável:
   ```
   JWT_SECRET=sua_chave_super_secreta_e_longa_aqui_min_32_caracteres
   ```

## Testes de Senha e Hash

### Verificar se uma Hash Corresponde a uma Senha

Você pode verificar se uma hash bcrypt corresponde a uma senha:

```bash
cd backend
node -e "
const bcrypt = require('bcrypt');
const password = 'admin123';
const hash = '\$2b\$12\$NJ4fC6T/kMcVRV3Ye4CgreW93og4nLO6jXYFJ5WlJDPlBms.7N/8e';
bcrypt.compare(password, hash).then(result => {
  console.log('Match:', result);
});
"
```

### Gerar Nova Hash

Para gerar uma hash bcrypt para qualquer senha:

```bash
cd backend
node src/utils/generatePasswordHash.js MinhaNovaSenh@2025
```

## Exemplos de Configuração

### Configuração 1: Padrão (Desenvolvimento)
```bash
# Não define nenhuma variável, usa padrão
# Username: admin
# Password: admin123
JWT_SECRET=minha_chave_secreta_desenvolvimento
```

### Configuração 2: Senha Customizada (Plain Text - Não Recomendado para Produção)
```bash
ADMIN_USERNAME=admin
ADMIN_PASSWORD=MinhaSenh@123
JWT_SECRET=minha_chave_secreta_producao
```

### Configuração 3: Hash Bcrypt (Recomendado para Produção)
```bash
ADMIN_USERNAME=admin
ADMIN_PASSWORD_HASH=$2b$12$NJ4fC6T/kMcVRV3Ye4CgreW93og4nLO6jXYFJ5WlJDPlBms.7N/8e
JWT_SECRET=minha_chave_secreta_producao_super_longa_e_aleatoria
```

## Hashes de Exemplo

Aqui estão algumas hashes bcrypt pré-geradas para referência:

| Senha | Hash Bcrypt |
|-------|-------------|
| `admin123` | `$2b$12$NJ4fC6T/kMcVRV3Ye4CgreW93og4nLO6jXYFJ5WlJDPlBms.7N/8e` |
| `Aj!2025#Juri-Assist%Z7` | `$2b$12$fDwsnagsVN4KMUZkVJLaEOZE03vt43uc1F2vy7zK1gfd4FuCH./TO` |
| `Adv@2025!Secure_X9` | `$2b$12$Zfe7o4UehA9caaURrEatku8JtSOt.oM272eD5JajZkg//MedQwmYS` |

## Checklist Completo de Diagnóstico

Use esta checklist para resolver problemas:

- [ ] **1. Verificar Backend Online**
  - [ ] Acessar `https://seu-backend.onrender.com/health`
  - [ ] Deve retornar `{"status":"ok"}`

- [ ] **2. Verificar Configuração de Auth**
  - [ ] Acessar `https://seu-backend.onrender.com/api/auth/config-check`
  - [ ] Confirmar que `jwtSecretConfigured: true`
  - [ ] Verificar `adminUsernameValue` está correto

- [ ] **3. Testar Login com Credenciais Corretas**
  - [ ] Usar username: `admin` (ou o valor de `ADMIN_USERNAME`)
  - [ ] Usar senha correta (padrão: `admin123`)
  - [ ] NÃO usar o placeholder "seu.usuario"

- [ ] **4. Verificar Logs do Render**
  - [ ] Observar mensagens `[Login Attempt]`
  - [ ] Verificar se username coincide
  - [ ] Verificar se há erro de senha

- [ ] **5. Corrigir Variáveis se Necessário**
  - [ ] Definir `JWT_SECRET` (obrigatório)
  - [ ] Definir `ADMIN_USERNAME` (opcional, padrão: admin)
  - [ ] Definir `ADMIN_PASSWORD_HASH` (recomendado) OU `ADMIN_PASSWORD`
  - [ ] Fazer redeploy após mudanças

- [ ] **6. Limpar Cache do Navegador**
  - [ ] Abrir DevTools (F12)
  - [ ] Ir em Application > Storage > Clear site data
  - [ ] Ou usar modo anônimo

- [ ] **7. Testar Novamente**
  - [ ] Tentar login com credenciais corretas
  - [ ] Verificar logs do Render novamente

## Perguntas Frequentes

### P: O que acontece se eu definir ADMIN_PASSWORD e ADMIN_PASSWORD_HASH?
**R:** O sistema dará prioridade ao `ADMIN_PASSWORD_HASH`. Se quiser usar a senha em plain text, remova `ADMIN_PASSWORD_HASH`.

### P: Como gero uma senha segura?
**R:** Use um gerenciador de senhas ou execute:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

### P: Posso ter múltiplos usuários?
**R:** Atualmente o sistema suporta apenas um usuário admin. Para múltiplos usuários, seria necessário implementar um sistema de banco de dados de usuários.

### P: Como desabilito o login por senha e uso apenas Google?
**R:** Você pode modificar o componente de login no frontend para remover o formulário de senha, mas o endpoint `/api/auth/login` continuará disponível. Para segurança máxima, você precisaria modificar o código.

### P: A hash bcrypt muda toda vez que gero?
**R:** Sim! Bcrypt usa um salt aleatório, então a mesma senha gera hashes diferentes. Isso é normal e seguro. Para verificar se uma hash corresponde a uma senha, use a função `bcrypt.compare()`.

## Suporte Adicional

Se ainda tiver problemas após seguir este guia:

1. **Compartilhe os logs**: Copie as últimas 50 linhas dos logs do Render
2. **Compartilhe a configuração**: Use o endpoint `/api/auth/config-check` (não expõe dados sensíveis)
3. **Compartilhe o erro**: Screenshot da tela de login com o erro
4. **Compartilhe DevTools**: Abra F12, vá em Network, tente login, compartilhe a resposta da requisição `/api/auth/login`

## Segurança

⚠️ **Nunca compartilhe:**
- Valores de `JWT_SECRET`
- Valores de `ADMIN_PASSWORD`
- Valores de `ADMIN_PASSWORD_HASH`
- Tokens JWT gerados

✅ **Seguro para compartilhar:**
- Saída do endpoint `/api/auth/config-check`
- Logs do servidor (se não contiverem senhas)
- Mensagens de erro do frontend

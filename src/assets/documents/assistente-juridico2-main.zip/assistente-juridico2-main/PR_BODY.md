## feat: Add DLQ migrations + CI + E2E skeleton + docs

### Principais mudanças

- **Migração robusta para Dead Letter Queue (DLQ):**
  - Criação da tabela `agent_tasks_dlq` com índices e constraints para garantir reprocessamento seguro de tarefas do agente.
  - Script de migração idempotente e seguro para produção.
- **CI/CD aprimorado:**
  - Workflows GitHub Actions para rodar migrações (`migrate.yml`), CI (`ci.yml`) e E2E opcional (`e2e.yml`).
  - `render.yaml` atualizado para rodar migrações antes do deploy.
- **Testes:**
  - Teste unitário para migração (`migrations.test.ts`).
  - Esqueleto de teste E2E para DLQ/Worker (opcional, não roda por padrão no CI).
- **Documentação:**
  - Atualização do `README.md` e `CHANGELOG.md` com instruções de uso, deploy e troubleshooting.
  - Novo template de PR padronizado.

### Como testar

1. Rode `npm install` na raiz e em `backend/`.
2. Execute `npm run migrate` na raiz ou `cd backend && npm run migrate` para aplicar as migrações.
3. Rode os testes: `cd backend && npm test`.
4. Para E2E: `RUN_E2E=1 npm test` (requer Docker Compose).

### Observações
- Migração é idempotente e segura para produção.
- E2E é opcional e não roda no CI por padrão.
- Workflows CI/CD garantem que deploys nunca quebrem por falta de migração.

### Checklist
- [x] Migração DLQ criada e testada
- [x] CI/CD atualizado
- [x] Testes unitários e E2E (skeleton)
- [x] Documentação e PR template

cc @thiagobodevan

# Guia de Troubleshooting - Deployment na Vercel

## 📋 Índice

1. [Erro 401 Unauthorized](#erro-401-unauthorized)
2. [Erro 404 Not Found](#erro-404-not-found)
3. [Assets não carregam](#assets-não-carregam)
4. [Service Worker não funciona](#service-worker-não-funciona)
5. [Variáveis de ambiente não funcionam](#variáveis-de-ambiente-não-funcionam)
6. [CORS errors](#cors-errors)

---

## Erro 401 Unauthorized

### 🔍 Sintomas

```
GET / → 401 Unauthorized
GET /assets/icon-xxx.svg → 401 Unauthorized
GET /assets/manifest-xxx.json → 401 Unauthorized
```

Presença de parâmetros `_vercel_jwt` e `_vercel_jwe` nas URLs.

### 🎯 Causa

**Vercel Deployment Protection está ativado** no projeto. Isso adiciona uma camada de autenticação antes de servir qualquer conteúdo.

### ✅ Solução

#### Para aplicações públicas:

1. Acesse: https://vercel.com/dashboard
2. Selecione seu projeto
3. Vá em **Settings** → **Deployment Protection**
4. **Desabilite todas as proteções:**
   - ❌ Vercel Authentication
   - ❌ Password Protection
   - ❌ Trusted IPs
5. Clique em **Save**
6. Aguarde 1-2 minutos
7. Teste acessando seu site

#### Para manter proteção em Preview (opcional):

- **Production Deployments:** Desabilite todas as proteções
- **Preview Deployments:** Mantenha ativas (se desejar)

### 🧪 Como testar

```bash
# Abra no navegador ou use curl
curl -I https://seu-projeto.vercel.app

# Resposta esperada:
# HTTP/2 200 OK  (não 401)
```

### 📌 Nota importante

Este projeto **já possui autenticação própria** via login com JWT. A Proteção de Deployment da Vercel é desnecessária e causa conflito, impedindo que usuários acessem até mesmo a tela de login.

---

## Erro 404 Not Found

### 🔍 Sintomas

```
GET /dashboard → 404 Not Found
GET /settings → 404 Not Found
```

Páginas funcionam ao acessar diretamente a home `/` e navegar, mas dão 404 ao fazer refresh.

### 🎯 Causa

Falta configuração de rewrite para Single Page Application (SPA).

### ✅ Solução

Verifique se o `vercel.json` contém:

```json
{
  "rewrites": [
    { "source": "/(.*)", "destination": "/index.html" }
  ]
}
```

✅ **Este projeto já está configurado corretamente.**

---

## Assets não carregam

### 🔍 Sintomas

- Console mostra erros 404 para `/icon.svg`, `/manifest.json`, `/sw.js`
- Página carrega mas sem ícones, sem PWA capabilities

### 🎯 Causa

Assets públicos não estão sendo copiados para o diretório `dist` durante o build.

### ✅ Solução

Certifique-se de que existe o diretório `public/` na raiz do projeto com os arquivos:

```
public/
├── icon.svg
├── manifest.json
└── sw.js
```

E que o `vite.config.ts` tem:

```typescript
export default defineConfig({
  publicDir: 'public',
  // ... resto da config
});
```

✅ **Este projeto foi corrigido para incluir essa configuração.**

### 🧪 Como testar localmente

```bash
npm run build
ls -la dist/

# Deve mostrar:
# dist/icon.svg
# dist/manifest.json
# dist/sw.js
```

---

## Service Worker não funciona

### 🔍 Sintomas

- Console mostra: `ServiceWorker registration failed`
- PWA não funciona offline
- Push notifications não funcionam

### 🎯 Causa

1. Service Worker não está no diretório `dist/`
2. HTTPS não está habilitado (SW requer HTTPS, exceto localhost)
3. Scope incorreto

### ✅ Solução

#### 1. Verificar se sw.js existe

```bash
# Após build
ls -la dist/sw.js
```

Se não existir, adicione `sw.js` ao diretório `public/`.

#### 2. Verificar registro

No `index.html`, certifique-se de que tem:

```javascript
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    const swUrl = `${location.origin}/sw.js`;
    navigator.serviceWorker.register(swUrl).then(registration => {
      console.log('SW registered:', registration.scope);
    }).catch(err => {
      console.log('SW registration failed:', err);
    });
  });
}
```

✅ **Este projeto já está configurado corretamente.**

#### 3. Verificar HTTPS

Vercel automaticamente fornece HTTPS. Certifique-se de acessar via `https://` e não `http://`.

---

## Variáveis de ambiente não funcionam

### 🔍 Sintomas

- `import.meta.env.VITE_BACKEND_URL` retorna `undefined`
- Aplicação usa valores de fallback errados
- Console mostra erros de conexão com backend

### 🎯 Causa

Variáveis não configuradas na Vercel ou deployment não foi refeito após adicionar/alterar variáveis.

### ✅ Solução

#### 1. Configurar na Vercel

1. Dashboard Vercel → Projeto → **Settings** → **Environment Variables**
2. Adicione as variáveis necessárias:

```
VITE_BACKEND_URL=https://seu-backend.onrender.com
VITE_GOOGLE_CLIENT_ID=seu-client-id
VITE_VAPID_PUBLIC_KEY=sua-vapid-key
```

3. Selecione os ambientes:
   - ✅ Production
   - ✅ Preview
   - ✅ Development

4. Clique em **Save**

#### 2. ⚠️ IMPORTANTE: Redeploy

Variáveis só são injetadas durante o build. Após adicionar/alterar:

1. Vá em **Deployments**
2. Clique nos 3 pontinhos do último deploy
3. Selecione **Redeploy**
4. Aguarde o novo deploy completar

### 🧪 Como verificar

Após deployment, abra DevTools Console e digite:

```javascript
console.log(import.meta.env.VITE_BACKEND_URL);
```

Deve mostrar a URL configurada, não `undefined`.

---

## CORS Errors

### 🔍 Sintomas

```
Access to fetch at 'https://backend.com/api/login' from origin 'https://frontend.vercel.app' 
has been blocked by CORS policy
```

### 🎯 Causa

Backend não está permitindo requests do frontend.

### ✅ Solução

#### No Backend (Render.com)

Certifique-se de que a variável `FRONTEND_ORIGIN` está configurada:

```
FRONTEND_ORIGIN=https://seu-projeto.vercel.app,http://localhost:5173
```

**Nota:** Pode listar múltiplas origens separadas por vírgula.

#### Verificar código do backend

O backend deve ter CORS configurado:

```javascript
app.use(cors({
  origin: process.env.FRONTEND_ORIGIN?.split(',') || '*',
  credentials: true
}));
```

✅ **Este projeto já está configurado corretamente no backend.**

### 🧪 Como testar

Abra DevTools → Network tab → Clique em uma request falhando → Veja a aba Headers:

```
Response Headers:
Access-Control-Allow-Origin: https://seu-projeto.vercel.app ✓
```

Se não aparecer ou for diferente, corrija `FRONTEND_ORIGIN`.

---

## 🔧 Checklist Completo de Deploy

Use este checklist ao fazer deploy:

### Antes do Deploy

- [ ] ✅ Build local funciona: `npm run build`
- [ ] ✅ Preview local funciona: `npm run preview`
- [ ] ✅ Variáveis de ambiente no `.env` estão corretas
- [ ] ✅ Backend está online e respondendo: teste `/health`
- [ ] ✅ Diretório `public/` contém: `sw.js`, `icon.svg`, `manifest.json`

### Configuração Vercel

- [ ] ✅ Projeto criado/importado do GitHub
- [ ] ✅ Framework: Vite (ou auto-detectado)
- [ ] ✅ Build Command: `npm run build`
- [ ] ✅ Output Directory: `dist`
- [ ] ✅ Environment Variables configuradas:
  - `VITE_BACKEND_URL`
  - `VITE_GOOGLE_CLIENT_ID`
  - `VITE_VAPID_PUBLIC_KEY`

### Após Deploy

- [ ] ✅ Site carrega (não 401, não 404)
- [ ] ✅ Assets carregam (ícones, manifest)
- [ ] ✅ Service Worker registra (console log)
- [ ] ✅ Login funciona
- [ ] ✅ Chamadas API funcionam (não CORS error)
- [ ] ✅ Navegação entre páginas funciona
- [ ] ✅ Refresh em qualquer página funciona (não 404)

### Se algo falhar

- [ ] 🔍 Verificar logs do build na Vercel
- [ ] 🔍 Abrir DevTools (F12) → Console + Network
- [ ] 🔍 Testar em aba anônima (descartar cache)
- [ ] 🔍 Verificar Settings → Deployment Protection
- [ ] 🔍 Verificar Environment Variables
- [ ] 🔍 Fazer redeploy se variáveis foram alteradas

---

## 🚨 Erros Comuns e Soluções Rápidas

| Erro | Causa Provável | Solução Rápida |
|------|---------------|----------------|
| 401 Unauthorized | Deployment Protection ativo | Desativar em Settings |
| 404 em rotas | Falta rewrite SPA | Verificar `vercel.json` |
| Assets 404 | `public/` vazio | Copiar assets para `public/` |
| CORS error | Backend não permite origin | Atualizar `FRONTEND_ORIGIN` |
| Env vars undefined | Não configuradas ou não redeployed | Adicionar e fazer redeploy |
| SW falha | HTTPS ou sw.js faltando | Verificar `dist/sw.js` e usar HTTPS |

---

## 📞 Precisa de Ajuda?

Se após seguir este guia você ainda tiver problemas:

1. **Capture informações:**
   - Screenshot do erro (com DevTools aberto)
   - URL do deployment
   - Logs do build (se houver falha)
   - Screenshot das configurações (Environment Variables, Deployment Protection)

2. **Verifique:**
   - Qual é a mensagem de erro exata?
   - Funciona em localhost?
   - Funciona em outro navegador?
   - Funciona em aba anônima?

3. **Recursos úteis:**
   - [Documentação Vercel](https://vercel.com/docs)
   - [Vite Build Guide](https://vitejs.dev/guide/build.html)
   - [Service Workers MDN](https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API)

---

**Última atualização:** Novembro 2024  
**Versão:** 1.0

# Correção do Service Worker - Problema com 401 Unauthorized

## 🔍 Problema Identificado

Os logs mostram um padrão onde:
1. Requests para assets retornam **401 Unauthorized** 
2. O Service Worker **cacheia essas respostas 401**
3. Requests subsequentes retornam 401 do cache
4. Apenas após múltiplas tentativas, o 200 OK é obtido

### Exemplo dos Logs:
```
GET /assets/icon-LBgKhUI_.svg → 401 (primeira tentativa)
GET /assets/icon-LBgKhUI_.svg → 401 (do cache)
GET /assets/icon-LBgKhUI_.svg → 401 (do cache)
GET /assets/icon-LBgKhUI_.svg → 200 (finalmente da rede)
```

## 🎯 Causa Raiz

O Service Worker anterior tinha duas falhas:

### 1. Cacheava apenas status 200
```javascript
// Código antigo - PROBLEMA
if (!response || response.status !== 200) {
  return response; // Retorna mas NÃO cacheia
}
```

**Problema:** Quando Deployment Protection da Vercel está ativo temporariamente, retorna 401. O SW não cacheia, mas também não tenta buscar novamente da rede.

### 2. Servia do cache sem validar
```javascript
// Código antigo - PROBLEMA
if (response) {
  return response; // Serve qualquer coisa do cache, até 401!
}
```

**Problema:** Se um 401 for cacheado (por outra parte do código), ele será servido indefinidamente.

## ✅ Solução Implementada

### 1. Nunca cachear respostas de erro

```javascript
// NOVO - Só cacheia 200-399
if (!response || response.status < 200 || response.status >= 400) {
  console.log('Not caching error response:', response?.status);
  return response; // Retorna mas NÃO cacheia
}
```

### 2. Nunca servir 401 do cache

```javascript
// NOVO - Detecta 401 cacheado e refaz request
if (response) {
  if (response.status === 401) {
    console.log('Cached 401 found, fetching from network instead');
    // Remove do cache
    caches.open(CACHE_NAME).then(cache => cache.delete(event.request));
    // Busca da rede
  } else {
    return response; // Só serve se for válido
  }
}
```

### 3. Fallback para cache em caso de erro de rede

```javascript
// NOVO - Se a rede falhar completamente, tenta cache
.catch(error => {
  console.error('Fetch failed:', error);
  return caches.match(event.request); // Melhor algo velho que nada
});
```

### 4. Atualização da versão do cache

```javascript
// Força atualização do SW em todos os clientes
const CACHE_NAME = 'pje-assistente-cache-v5'; // v4 → v5
```

## 🔧 Arquivos Modificados

### 1. `/sw.js` (raiz do projeto)
- ✅ Atualizado com lógica de tratamento de 401
- ✅ Versão do cache: v4 → v5
- ✅ Logging melhorado para debug

### 2. `/public/sw.js` (cópia para build)
- ✅ Sincronizado com a versão da raiz
- ✅ Será copiado para `dist/` durante build

### 3. `/vite.config.ts`
- ✅ Adicionado `publicDir: 'public'`
- ✅ Garante que `sw.js` seja copiado para `dist/`

## 📊 Fluxo de Trabalho Corrigido

### Antes (Com Bug)

```
1. Request → Vercel (401) → SW cacheia 401
2. Request → SW cache (401) → Usuário vê erro
3. Request → SW cache (401) → Usuário vê erro
4. Cache expira → Request → Vercel (200) → Finalmente funciona
```

❌ **Resultado:** Usuário vê erros até cache expirar

### Depois (Corrigido)

```
1. Request → Vercel (401) → SW NÃO cacheia, retorna 401
2. Request → Cache vazio → Network (401 ou 200) → Retorna resultado
3. Se 200, cacheia para próximas requests
4. Se 401 no cache, deleta e tenta network novamente
```

✅ **Resultado:** Sempre tenta a rede em caso de erro

## 🧪 Como Testar

### Teste Local

1. **Build do projeto:**
```bash
npm run build
```

2. **Verificar se sw.js foi copiado:**
```bash
ls -la dist/sw.js
# Deve existir e ter o conteúdo atualizado
```

3. **Servir localmente:**
```bash
npm run preview
# ou
npx serve dist
```

4. **Verificar no navegador:**
- Abra DevTools (F12)
- Vá para **Application** → **Service Workers**
- Clique em **Unregister** (para limpar cache antigo)
- Recarregue a página (Ctrl+R)
- Verifique no Console:
  ```
  ServiceWorker registration successful with scope: ...
  ```

5. **Testar cache:**
- Carregue a página
- Vá offline (DevTools → Network → Offline)
- Recarregue a página
- ✅ Deve funcionar offline

### Teste de Produção

1. **Deploy na Vercel:**
```bash
git push origin main
# ou através do dashboard Vercel
```

2. **Testar diferentes cenários:**

#### Cenário A: Deployment Protection DESABILITADO (correto)
```
Request → 200 OK → Cacheia → Futuras requests do cache
✅ Funciona perfeitamente
```

#### Cenário B: Deployment Protection HABILITADO (incorreto mas agora tolerado)
```
Request → 401 → NÃO cacheia → Retorna erro para usuário
Próximo request → 401 → NÃO cacheia → Retorna erro
(Até desabilitar a proteção)
✅ Não fica em loop de 401 cacheado
```

#### Cenário C: Network offline
```
Request → Falha de rede → Tenta cache → Serve versão antiga
✅ App funciona offline com dados cacheados
```

### Verificar Logs

No Console do navegador, você deve ver:

```javascript
// Sucesso normal
ServiceWorker registration successful with scope: https://seu-app.vercel.app/

// Detectou 401 cacheado (se houver)
Cached 401 found, fetching from network instead: /assets/icon.svg

// Não cacheou erro
Not caching error response: 401 /assets/icon.svg

// Cacheou sucesso
(nenhuma mensagem, cacheia silenciosamente)
```

## 🚨 Importante: Limpeza de Cache

### Para Usuários Existentes

Usuários que já têm o SW antigo com 401 cacheado precisam limpar:

#### Opção 1: Automático (implementado)
O novo SW (v5) automaticamente apaga caches antigos (v1-v4) no evento `activate`.

#### Opção 2: Manual (se necessário)
```javascript
// No console do navegador
navigator.serviceWorker.getRegistrations().then(regs => {
  regs.forEach(reg => reg.unregister());
});

// Depois recarregar
location.reload();
```

#### Opção 3: Hard Refresh
```
Ctrl + Shift + Delete → Limpar cache e cookies
ou
Ctrl + F5 (hard refresh)
```

## 📝 Melhores Práticas Implementadas

✅ **Nunca cachear respostas de erro (4xx, 5xx)**  
✅ **Validar respostas cacheadas antes de servir**  
✅ **Fallback para cache apenas em caso de erro de rede**  
✅ **Logging para debugging**  
✅ **Versionamento de cache para forçar atualizações**  
✅ **Limpeza automática de caches antigos**  

## 🎓 Lições Aprendidas

### 1. Service Workers são agressivos com cache
- Uma vez cacheado, será servido até expirar
- Sempre validar conteúdo antes de cachear

### 2. Deployment Protection e SW não combinam bem
- SW tenta cachear tudo, incluindo respostas de auth
- Melhor desabilitar Deployment Protection para apps públicos

### 3. Cache versioning é essencial
- Incrementar versão força update do SW
- Activate event limpa versões antigas

### 4. Network-first para recursos críticos
- HTML/API: sempre tenta network primeiro
- Assets estáticos: cache-first é OK se validado

## 🔗 Documentação Relacionada

- `VERCEL_401_FIX.md` - Como desabilitar Deployment Protection
- `DEPLOYMENT_TROUBLESHOOTING.md` - Guia completo de troubleshooting
- `README.md` - Instruções gerais de deployment

## 🎯 Checklist de Verificação

Após aplicar esta correção:

- [ ] ✅ Build funciona localmente
- [ ] ✅ `dist/sw.js` existe e tem versão v5
- [ ] ✅ Deploy na Vercel concluído
- [ ] ✅ Deployment Protection desabilitado
- [ ] ✅ Site carrega sem erros 401
- [ ] ✅ Service Worker registra com sucesso
- [ ] ✅ Assets carregam normalmente
- [ ] ✅ App funciona offline (após primeira carga)
- [ ] ✅ Não há mensagens de "Cached 401" no console

---

**Status:** ✅ Corrigido  
**Versão do Cache:** v5  
**Data:** Novembro 2024

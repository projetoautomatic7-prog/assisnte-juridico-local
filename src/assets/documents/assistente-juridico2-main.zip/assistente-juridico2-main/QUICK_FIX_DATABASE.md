# 🚨 Erro DATABASE_URL - Correção Rápida

Se você está vendo este erro ao fazer deploy no Render:

```
❌ Falha ao iniciar o servidor: Error: getaddrinfo ENOTFOUND base
```

## ⚡ Solução Rápida (5 minutos)

### 1️⃣ Copie a Connection String do Banco

1. Vá para o [Dashboard do Render](https://dashboard.render.com/)
2. Clique no seu **Banco de Dados PostgreSQL** (não é o serviço web!)
3. Clique na aba **Info** ou **Connect**
4. Copie a **Internal Connection String** completa
   - Ela começa com `postgres://` ou `postgresql://`
   - Exemplo: `postgres://pje_user:ABC123@dpg-xyz-a.oregon-postgres.render.com:5432/pje_robot_db`

### 2️⃣ Configure no Serviço Web

1. Volte para o Dashboard do Render
2. Clique no seu **serviço web** (pje-robot-backend)
3. Clique na aba **Environment**
4. Encontre ou adicione a variável `DATABASE_URL`
5. Cole a connection string completa que você copiou
6. Clique em **Save Changes**

### 3️⃣ Aguarde o Deploy

O Render fará um novo deploy automaticamente. Em alguns minutos você verá nos logs:

```
✅ Variáveis obrigatórias presentes.
🔌 Connecting to PostgreSQL at dpg-xyz-a.oregon-postgres.render.com:5432/...
🔌 Conectado ao banco de dados PostgreSQL.
🚀 Servidor backend rodando na porta 10000
```

## ✅ Pronto!

Seu aplicativo agora deve estar funcionando perfeitamente!

---

## 📚 Precisa de Mais Detalhes?

- **Guia Completo**: [DATABASE_TROUBLESHOOTING.md](DATABASE_TROUBLESHOOTING.md)
- **O Que Foi Corrigido**: [FIX_DATABASE_ERROR.md](FIX_DATABASE_ERROR.md)
- **Documentação Geral**: [README.md](README.md)

## 🆘 Ainda Está com Problemas?

Verifique:
- [ ] Você copiou a **Internal** Connection String (não a External)
- [ ] A string foi colada completamente (sem espaços extras)
- [ ] O banco de dados está "Available" no Dashboard do Render
- [ ] Você clicou em "Save Changes" depois de colar a URL
- [ ] Aguardou o deploy completar (veja os logs em tempo real)

Se o problema persistir, consulte o [guia de troubleshooting completo](DATABASE_TROUBLESHOOTING.md).

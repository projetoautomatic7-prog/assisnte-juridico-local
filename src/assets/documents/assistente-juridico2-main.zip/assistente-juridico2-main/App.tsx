import React, { useMemo, useEffect, useCallback, useRef, useState } from 'react';

import LoadingSpinner from './components/LoadingSpinner';
import Sidebar from './components/Sidebar';
import Acervo from './pages/Acervo';
import AgentDashboard from './pages/AgentDashboard';
import Atividades from './pages/Atividades';
import Audiencias from './pages/Audiencias';
import AudioTranscription from './pages/AudioTranscription';
import DashboardHome from './pages/DashboardHome';
import DatajudChecklist from './pages/DatajudChecklist';
import DeadlineCalculator from './pages/DeadlineCalculator';
import DjenSearch from './pages/DjenSearch';
import DocumentAnalysis from './pages/DocumentAnalysis';
import Expedientes from './pages/Expedientes';
import FinancialManagement from './pages/FinancialManagement';
import GestaoBI from './pages/GestaoBI';
import ImageGeneration from './pages/ImageGeneration';
import Intimacoes from './pages/Intimacoes';
import KnowledgeBase from './pages/KnowledgeBase';
import Login from './pages/Login';
import Modelos from './pages/Modelos';
import Pessoas from './pages/Pessoas';
import PjeRobot from './pages/PjeRobot';
import QuickActions from './pages/QuickActions';
import Rede from './pages/Rede';
import Settings from './pages/Settings';
import Suporte from './pages/Suporte';
import VideoAnalysis from './pages/VideoAnalysis';
import { BACKEND_URL } from './services/api';
import { useAppStore } from './stores/appStore';
import { useAuthStore } from './stores/authStore';

const IDLE_TIMEOUT = 2 * 60 * 1000; // 2 minutes

const useIdle = (timeout: number) => {
    const [isIdle, setIsIdle] = useState(false);
    const timeoutId = useRef<ReturnType<typeof setTimeout> | null>(null);

    const resetTimer = useCallback(() => {
        setIsIdle(false);
        if (timeoutId.current) {
            clearTimeout(timeoutId.current);
        }
        timeoutId.current = setTimeout(() => {
            setIsIdle(true);
        }, timeout);
    }, [timeout]);

    useEffect(() => {
        const events = ['mousemove', 'keydown', 'scroll', 'touchstart', 'click'];
        const handler = () => resetTimer();
        events.forEach(event => window.addEventListener(event, handler));
        
        // Initialize timer on mount without direct setState
        const initializeTimer = () => {
            timeoutId.current = setTimeout(() => {
                setIsIdle(true);
            }, timeout);
        };
        initializeTimer();

        return () => {
            if (timeoutId.current) {
                clearTimeout(timeoutId.current);
            }
            events.forEach(event => window.removeEventListener(event, handler));
        };
    }, [resetTimer, timeout]);

    return isIdle;
};

const App: React.FC = () => {
  const { isAuthenticated, isLoading } = useAuthStore();
  const { activePage } = useAppStore();
  const isIdle = useIdle(IDLE_TIMEOUT);

  useEffect(() => {
    if (!isAuthenticated) return;

    const isUserActive = !isIdle;
    
    const token = localStorage.getItem('jwt');
    fetch(`${BACKEND_URL}/api/robot/set-human-activity`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ active: isUserActive }),
    }).catch(err => console.error("Failed to report user activity:", err));

  }, [isIdle, isAuthenticated]);
  
  const CurrentPage = useMemo(() => {
    switch (activePage) {
      case 'dashboard-home': return DashboardHome;
      case 'pje-robot': return PjeRobot;
      case 'document-analysis': return DocumentAnalysis;
      case 'quick-actions': return QuickActions;
      case 'expedientes': return Expedientes;
      case 'audiencias': return Audiencias;
      case 'atividades': return Atividades;
      case 'modelos': return Modelos;
      case 'acervo': return Acervo;
      case 'pessoas': return Pessoas;
      case 'datajud-checklist': return DatajudChecklist;
      case 'djen-search': return DjenSearch;
      case 'audio-transcription': return AudioTranscription;
      case 'image-generation': return ImageGeneration;
      case 'video-analysis': return VideoAnalysis;
      case 'deadline-calculator': return DeadlineCalculator;
      case 'financial-management': return FinancialManagement;
      case 'knowledge-base': return KnowledgeBase;
      case 'gestao-bi': return GestaoBI;
      case 'agent-dashboard': return AgentDashboard;
      case 'intimacoes': return Intimacoes;
      case 'settings': return Settings;
      case 'rede': return Rede;
      case 'suporte': return Suporte;
      default: return DashboardHome;
    }
  }, [activePage]);
  
  if (isLoading) {
    return (
      <div className="flex h-screen w-screen items-center justify-center bg-gray-900">
        <LoadingSpinner size="12" />
      </div>
    );
  }
  
  if (!isAuthenticated) {
    return <Login />;
  }

  return (
    <div className="flex h-screen bg-gray-900 text-gray-100 font-sans">
      <Sidebar />
      <main className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8">
        <CurrentPage />
      </main>
    </div>
  );
};

export default App;
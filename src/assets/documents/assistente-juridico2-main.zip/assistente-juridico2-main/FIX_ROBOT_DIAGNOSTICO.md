# 🔧 Corrigindo Diagnóstico do Robô PJe

## 📊 Status Atual

```
✅ Backend          - Online
✅ Gemini API       - Acessível
❌ Navegador        - FALHA (Chromium não instalado)
❌ Google Workspace - FALHA (Credenciais faltando)
```

**Taxa de Aprovação:** 2/4 (50%)

---

## ❌ Problema 1: Navegador de Automação

### 📌 Causa
O servidor Render não tem **Chromium** instalado. O Puppeteer precisa do navegador para fazer automação.

### ✅ Solução
Atualizar `render.yaml` para instalar dependências do Chromium durante build.

**Arquivo:** `render.yaml`  
**Mudança:** Adicionar instalação de pacotes ao `buildCommand`

```yaml
# ANTES:
buildCommand: npm ci && npm run build

# DEPOIS:
buildCommand: apt-get update && apt-get install -y chromium-browser libxss1 libnss3 libfontconfig1 && npm ci && npm run build
```

**Status:** ✅ JÁ APLICADO

---

## ❌ Problema 2: Google Workspace API

### 📌 Causa
Variável de ambiente `GOOGLE_API_KEY` não está configurada no Render.

### ✅ Solução
Adicionar variável ao `render.yaml` e configurar no painel do Render.

**Arquivo:** `render.yaml`  
**Mudança:** Adicionar `GOOGLE_API_KEY` às variáveis de ambiente

```yaml
envVars:
  # ... outras variáveis ...
  - key: GOOGLE_API_KEY
    sync: false  # Sua chave secreta não é sincronizada
```

**Status:** ✅ JÁ APLICADO

---

## 📝 Passo a Passo Para Corrigir

### Passo 1: Commit das Mudanças
```bash
cd "c:\Users\thiag\Downloads\assistente-jurídico-pje---thiago-bodevan-advocacia (8)"
git add render.yaml
git commit -m "Fix: Adicionar dependências Chromium e Google API ao render.yaml"
git push origin main
```

### Passo 2: Configurar Credenciais no Render
1. Acesse https://dashboard.render.com
2. Selecione o serviço **pje-robot-backend**
3. Vá em **Environment**
4. Clique em **Add Environment Variable**
5. Configure:

| Chave | Valor | Origem |
|-------|-------|--------|
| `GOOGLE_API_KEY` | Sua chave da Google Cloud | [Google Cloud Console](https://console.cloud.google.com) |
| `GOOGLE_CLIENT_ID` | OAuth 2.0 Client ID | Já configurado? |

### Passo 3: Fazer Deploy Manual
1. No Render Dashboard, clique em **Manual Deploy**
2. Selecione **Deploy latest commit**
3. Aguarde 5-10 minutos o build completar

**Dica:** Verifique os logs do build para confirmar instalação do Chromium:
```
$ apt-get install -y chromium-browser libxss1 libnss3 libfontconfig1
Setting up chromium-browser ... done
```

### Passo 4: Testar Diagnóstico Novamente
1. Acesse seu app
2. Vá em **Robô PJe**
3. Clique em **Verificar Conexão e Diagnóstico**
4. Confirme que todos 4 itens passaram ✅

---

## 🔍 Como Obter GOOGLE_API_KEY

Se ainda não tem a chave:

### 1. Criar Projeto Google Cloud
1. Vá em https://console.cloud.google.com
2. Crie um novo projeto
3. Ative as seguintes APIs:
   - **Google Drive API** (para organizar pastas)
   - **Google Docs API** (para gerar documentos)
   - **Google Sheets API** (opcional, se usar)

### 2. Gerar Chave de API
1. Vá em **Credenciais** → **Criar Credenciais**
2. Selecione **Chave de API**
3. Copie a chave gerada
4. Adicione ao Render com nome: `GOOGLE_API_KEY`

### 3. Restringir Chave (Segurança)
1. Na página da chave, clique em **Editar**
2. Em **Restrições de API**, selecione:
   - Google Drive API
   - Google Docs API
3. Em **Restrições de HTTP referrer**, adicione:
   - `https://seu-app.vercel.app`
   - `https://seu-backend.onrender.com`

---

## 📋 Checklist Pós-Fix

Após aplicar as mudanças:

- [ ] Commit + Push do `render.yaml` concluído
- [ ] Variável `GOOGLE_API_KEY` configurada no Render
- [ ] Deploy manual completado no Render
- [ ] Logs de build mostram instalação do Chromium
- [ ] Diagnóstico rodado novamente
- [ ] ✅ Navegador = OK
- [ ] ✅ Google Workspace = OK
- [ ] ✅ Todos 4 itens passando

---

## 🚨 Se Ainda Falhar

### Erro: "Chromium not found"
**Solução:** O Render pode ter limite de armazenamento. Tente:
```bash
buildCommand: npm ci && npm prune --production && npm run build
```

### Erro: "GOOGLE_API_KEY undefined"
**Solução:** Verifique no dashboard do Render se a variável foi salva e está sincronizada.

### Erro: "Timeout ao fazer diagnóstico"
**Solução:** Aumentar timeout no backend (`pjeService.ts`, linha 200):
```typescript
public async checkBrowserHealth(): Promise<boolean> {
    let browser = null;
    try {
        browser = await puppeteer.launch({
            args: chromium.args,
            executablePath: await chromium.executablePath(),
            timeout: 30000  // Aumentar para 30s
        });
        // ...
    }
}
```

---

## 📞 Resultado Esperado

Após todas as mudanças:

```
✅ Backend          - Online
✅ Gemini API       - Acessível
✅ Navegador        - OK (Chromium instalado)
✅ Google Workspace - OK (API Key configurada)

Status Final: 4/4 (100%) ✅
Robô pronto para funcionar 24/7
```

---

## 🎯 Próximos Passos

Quando diagnóstico passar 100%:

1. **Testar Conexão**: Clique em "Conectar" com suas credenciais PJe
2. **Iniciar Monitoramento**: Clique em "Iniciar Monitoramento 24/7"
3. **Verificar Logs**: Acompanhe logs em tempo real na página
4. **Aguardar Expedientes**: O robô começará a processar automaticamente

---

**Arquivo Modificado:** `render.yaml`  
**Versão:** 1.0  
**Data:** 14 de novembro de 2025  
**Status:** Aguardando deploy no Render

// services/api.ts

const isLocalhost = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
const PROD_BACKEND_URL = (import.meta as any)?.env?.VITE_BACKEND_URL || 'https://assistente-juridico-rs1e.onrender.com';

export const BACKEND_URL = isLocalhost ? 'http://localhost:3001' : PROD_BACKEND_URL;

// Extrair hostname com tratamento de erro
const getWebsocketHostname = (): string => {
  try {
    const url = new URL(PROD_BACKEND_URL);
    return url.hostname;
  } catch (e) {
    console.warn('Erro ao fazer parse da URL do backend, usando fallback', e);
    return 'assistente-juridico-rs1e.onrender.com';
  }
};

export const WEBSOCKET_URL = isLocalhost ? 'ws://localhost:3001' : `wss://${getWebsocketHostname()}`;
export const AUDIO_WEBSOCKET_URL = `${WEBSOCKET_URL}/api/ai/live-audio`;

// Função de fetch com retentativa e exponential backoff
export const fetchWithRetry = async (url: string, options: RequestInit = {}, retries = 3, backoff = 300): Promise<Response> => {
    try {
        const response = await fetch(url, options);
        if (!response.ok && response.status >= 500 && retries > 1) { // Retry on server errors
            await new Promise(resolve => setTimeout(resolve, backoff));
            return fetchWithRetry(url, options, retries - 1, backoff * 2);
        }
        return response;
    } catch (error) {
        if (retries > 1) {
            await new Promise(resolve => setTimeout(resolve, backoff));
            return fetchWithRetry(url, options, retries - 1, backoff * 2);
        }
        throw error;
    }
};


// Função de fetch autenticada
export const authenticatedFetch = async (url: string, options: RequestInit = {}): Promise<Response> => {
    const token = localStorage.getItem('jwt');
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers,
        'Authorization': `Bearer ${token}`
    };

    const response = await fetchWithRetry(url, { ...options, headers });

    if (response.status === 401) {
        // Deslogar o usuário se o token for inválido
        localStorage.removeItem('jwt');
        window.location.href = '/'; 
        throw new Error('Sessão expirada ou inválida.');
    }

    return response;
};


// Unified utility function for file to base64 conversion
export const fileToBase64 = (file: File): Promise<{ data: string; mimeType: string; name: string }> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
        const result = reader.result as string;
        resolve({ data: result.split(',')[1], mimeType: file.type, name: file.name });
    };
    reader.onerror = (error) => reject(error);
  });
};

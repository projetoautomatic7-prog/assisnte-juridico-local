export type Theme = 'theme-dark' | 'theme-mid' | 'theme-light' | 'theme-corporate';

export const THEME_KEY = 'ui-theme';

export const THEMES: Theme[] = ['theme-dark', 'theme-mid', 'theme-light', 'theme-corporate'];

/**
 * Reads the persisted theme from localStorage.
 */
export function readPersistedTheme(): Theme | null {
  if (typeof window === 'undefined') return null;
  try {
    const persisted = localStorage.getItem(THEME_KEY);
    return THEMES.includes(persisted as Theme) ? (persisted as Theme) : null;
  } catch (e) {
    console.warn('Failed to read theme from localStorage', e);
    return null;
  }
}

/**
 * Persists the chosen theme to localStorage.
 */
export function persistTheme(t: Theme): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(THEME_KEY, t);
  } catch (e) {
    console.warn('Failed to persist theme to localStorage', e);
  }
}

/**
 * Determines the initial theme based on localStorage or system preference.
 */
export function getInitialTheme(): Theme {
  const persisted = readPersistedTheme();
  if (persisted) return persisted;

  if (typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
    return 'theme-dark';
  }

  return 'theme-light'; // Default fallback
}

/**
 * Applies the theme class to <html> and <body> and handles the animation.
 */
export function applyTheme(t: Theme): void {
    if (typeof document === 'undefined') return;

    const { documentElement, body } = document;
    const animationClass = 'theme-anim';

    // Add animation class to start transition
    documentElement.classList.add(animationClass);
    body.classList.add(animationClass);

    // Remove old theme classes
    THEMES.forEach(themeClass => {
        documentElement.classList.remove(themeClass);
        body.classList.remove(themeClass);
    });

    // Add new theme classes
    documentElement.classList.add(t);
    body.classList.add(t);
    
    // Remove animation class after the transition duration
    setTimeout(() => {
        documentElement.classList.remove(animationClass);
        body.classList.remove(animationClass);
    }, 300);
}
# 🔧 Corrigindo Dashboard dos Agentes

## ❌ Problema Identificado

O painel está mostrando **0/0/0/0** porque:

1. **Tabela vazia**: `agent_goals` não tem dados
2. **Sem objetivos criados**: Nenhum agente foi criado ainda
3. **Falta endpoint de teste**: Sem dados mock para demonstração

---

## ✅ Solução

### 1. Adicionar Agentes de Teste

Execute isso no seu backend (preferencialmente em uma migration ou seed):

```sql
-- Adicionar alguns objetivos de teste ao dashboard
INSERT INTO agent_goals (title, description, department, priority, status) VALUES
(
  'Monitoramento PJe Automático',
  'Monitorar portal PJe para novos expedientes e processar automaticamente',
  'Robótica',
  1,
  'RUNNING'
),
(
  'Análise de Documentos com Gemini',
  'Extrair informações de documentos jurídicos usando IA',
  'IA',
  2,
  'RUNNING'
),
(
  'Geração de Minutas',
  'Gerar automaticamente minutas e rascunhos de petições',
  'IA',
  1,
  'PENDING'
),
(
  'Verificação de Prazos',
  'Detector automático de prazos e alertas',
  'Automação',
  1,
  'DONE'
),
(
  'Sincronização DataJud',
  'Buscar dados de processos no DataJud e sincronizar com base local',
  'Integração',
  2,
  'FAILED'
)
ON CONFLICT DO NOTHING;
```

### 2. Código para Seed (Node.js)

Se preferir adicionar via aplicação, crie um arquivo `backend/src/seeds/agent-goals.ts`:

```typescript
import { pool } from '../services/db';

export async function seedAgentGoals() {
  try {
    const agentGoals = [
      {
        title: 'Monitoramento PJe Automático',
        description: 'Monitorar portal PJe para novos expedientes e processar automaticamente',
        department: 'Robótica',
        priority: 1,
        status: 'RUNNING'
      },
      {
        title: 'Análise de Documentos com Gemini',
        description: 'Extrair informações de documentos jurídicos usando IA',
        department: 'IA',
        priority: 2,
        status: 'RUNNING'
      },
      {
        title: 'Geração de Minutas',
        description: 'Gerar automaticamente minutas e rascunhos de petições',
        department: 'IA',
        priority: 1,
        status: 'PENDING'
      },
      {
        title: 'Verificação de Prazos',
        description: 'Detector automático de prazos e alertas',
        department: 'Automação',
        priority: 1,
        status: 'DONE'
      },
      {
        title: 'Sincronização DataJud',
        description: 'Buscar dados de processos no DataJud e sincronizar com base local',
        department: 'Integração',
        priority: 2,
        status: 'FAILED'
      }
    ];

    for (const goal of agentGoals) {
      await pool.query(
        `INSERT INTO agent_goals (title, description, department, priority, status)
         VALUES ($1, $2, $3, $4, $5)
         ON CONFLICT DO NOTHING`,
        [goal.title, goal.description, goal.department, goal.priority, goal.status]
      );
    }

    console.log('✅ Agentes de teste adicionados com sucesso');
  } catch (err) {
    console.error('❌ Erro ao adicionar agentes de teste:', err);
  }
}
```

Chame em `backend/src/server.ts` após conectar ao banco:

```typescript
import { seedAgentGoals } from './seeds/agent-goals';

// ... após pool.connect()
if (process.env.NODE_ENV === 'development') {
  await seedAgentGoals();
}
```

### 3. Testar no Frontend

Depois de adicionar os dados:

1. Acesse **Agentes IA** → **Dashboard Agentes**
2. Aguarde carregar (1-2 segundos)
3. Confirme que aparecem os agentes:

```
✅ 5 Objetivos Ativos
✅ 2 Em Execução
✅ 1 Com Falha (Atenção)
✅ 1 Concluído
```

---

## 📊 Estrutura dos Dados

Cada agente tem:

| Campo | Tipo | Valor |
|-------|------|-------|
| `id` | UUID | Auto-gerado |
| `title` | String | Nome do objetivo |
| `description` | String | O que o agente faz |
| `department` | String | Área (Robótica, IA, etc) |
| `priority` | Int | 1-5 (1 = mais importante) |
| `status` | Enum | PENDING, RUNNING, DONE, FAILED, PAUSED |
| `created_at` | Timestamp | Auto-preenchido |
| `updated_at` | Timestamp | Auto-preenchido |

---

## 🔄 Mapeamento de Status

O frontend mapeia:

| Status BD | Status UI | Cor |
|-----------|-----------|-----|
| PENDING | Ocioso | Cinza |
| RUNNING | Ativo | Verde |
| PAUSED | Pausado | Amarelo |
| DONE | Concluído | Azul |
| FAILED | Erro | Vermelho |

---

## 🧪 Teste Manual

### Option 1: SQL Direto (Render PostgreSQL)

```bash
# No Render Dashboard → PostgreSQL
# Execute a query de INSERT acima
```

### Option 2: API REST

```bash
curl -X POST https://seu-backend.onrender.com/api/agent/goal \
  -H "Authorization: Bearer SEU_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Novo Objetivo",
    "description": "Descrição do objetivo",
    "department": "IA",
    "priority": 1
  }'
```

### Option 3: Via Frontend

Clique em **Criar Novo Objetivo** (quando implementado) ou execute no console:

```javascript
fetch('https://seu-backend.onrender.com/api/agent/goal', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${localStorage.getItem('jwt')}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    title: 'Teste Manual',
    description: 'Agente criado manualmente',
    department: 'Teste',
    priority: 1
  })
})
.then(r => r.json())
.then(data => console.log('Criado:', data))
.catch(err => console.error('Erro:', err));
```

---

## ✅ Checklist

- [ ] Tabela `agent_goals` foi criada (verificar em migrations)
- [ ] Dados de teste foram inseridos (5 agentes)
- [ ] Frontend recarregado
- [ ] Dashboard mostra agentes corretamente
- [ ] Filtros funcionam (Em Execução, Concluídos, etc)
- [ ] Clique em "Detalhes & Config" abre modal

---

## 🎯 Próximos Passos

1. **Criar função "Novo Objetivo"**: Adicionar botão para criar agentes via UI
2. **Detalhes do Agente**: Implementar página com:
   - Logs em tempo real
   - Performance (uptime, taxa de sucesso)
   - Histórico de execução
3. **Editar/Deletar**: Permitir gerenciar agentes
4. **Integração WebSocket**: Atualizar status em tempo real

---

**Arquivo:** Instruções de correção  
**Data:** 14 de novembro de 2025  
**Status:** Pronto para implementar

# 🧪 GUIA DE TESTES PÓS-CORREÇÃO

**Data**: 14 de novembro de 2025  
**Objetivo**: Validar que todas as correções estão funcionando corretamente

---

## ✅ Checklist de Validação Funcional

Execute os testes abaixo para confirmar que as correções estão funcionando:

### Teste 1: LoadingSpinner - Tamanhos Dinâmicos ✅
```bash
# Localização: components/LoadingSpinner.tsx
# Teste: Verificar se spinner aparece com tamanhos corretos

□ Tamanho pequeno (size=\"5\") - h-5 w-5
□ Tamanho médio (size=\"8\") - h-8 w-8  
□ Tamanho grande (size=\"10\") - h-10 w-10
□ Tamanho xlarge (size=\"12\") - h-12 w-12
□ Tamanho padrão (sem prop) - h-8 w-8
□ Tamanho inválido - fallback para h-8 w-8
```

**Como Testar:**
```tsx
// Em qualquer componente
import LoadingSpinner from './LoadingSpinner';

<LoadingSpinner size=\"5\" />   // Pequeno
<LoadingSpinner size=\"8\" />   // Médio
<LoadingSpinner size=\"12\" />  // Grande
```

**Resultado Esperado**: Spinner gira com tamanho consistente ✅

---

### Teste 2: DashboardHome - Performance com Audiências ✅
```bash
# Localização: pages/DashboardHome.tsx
# Teste: Verificar se lista de audiências renderiza rapidamente

□ Lista com 10 audiências - <100ms
□ Lista com 100 audiências - <500ms
□ Lista com 1000 audiências - <1s
□ Data formatada corretamente - dd/mm
□ Sem memory leaks ao renderizar
```

**Como Testar:**
```bash
npm run dev
# Abra DevTools (F12)
# Vá para Performance
# Grave enquanto renderiza a página
# Verifique o tempo de renderização
```

**Resultado Esperado**: Renderização rápida sem glitches ✅

---

### Teste 3: API Service - WebSocket Fallback ✅
```bash
# Localização: services/api.ts
# Teste: Verificar tratamento de erros de URL

□ URL válida - WebSocket conecta
□ URL inválida - Usa fallback
□ Sem VITE_BACKEND_URL - Usa fallback
□ Console sem erros críticos
□ Conexão WebSocket estabelece
```

**Como Testar:**
```tsx
// No DevTools Console
import { WEBSOCKET_URL, BACKEND_URL } from './services/api';
console.log('Backend URL:', BACKEND_URL);
console.log('WebSocket URL:', WEBSOCKET_URL);
```

**Resultado Esperado**: URLs válidas sem exceções ✅

---

### Teste 4: Sidebar - Rotação do Chevron ✅
```bash
# Localização: components/Sidebar.tsx
# Teste: Verificar animação de rotação ao abrir/fechar menu

□ Chevron começa apontando para cima (0°)
□ Ao clicar, rotaciona para baixo (180°)
□ Ao clicar novamente, volta para cima (0°)
□ Transição suave e fluida
□ Menu abre/fecha sem delay
```

**Como Testar:**
```bash
npm run dev
# Abra o Sidebar
# Clique em "Agentes IA"
# Observe o ícone girar suavemente
```

**Resultado Esperado**: Rotação consistente e suave ✅

---

## 🔄 Testes de Regressão

### Testes que Não Devem Quebrar
Execute estes testes para garantir que nada quebrou:

```bash
□ Login funciona
□ Navbar renderiza corretamente
□ Páginas carregam sem erros
□ Notificações funcionam
□ Tema (dark/light) funciona
□ Autenticação persiste
□ WebSocket conecta (se backend online)
□ Requisições HTTP funcionam
```

---

## 📊 Testes de Performance

### Executar Lighthouse
```bash
npm run build
npx lighthouse http://localhost:5173 --view
```

**Esperado:**
- Performance: > 90
- Accessibility: > 90
- Best Practices: > 90
- SEO: > 90

---

## 🐛 Debug Guide

Se algo não funcionar, aqui está como debugar:

### Problema: LoadingSpinner não aparece
```bash
# 1. Verifique o console
F12 → Console → veja se há erros

# 2. Verifique as classes CSS
Inspecione o elemento → veja se tem as classes h-5 w-5

# 3. Verifique o prop
console.log('Size prop:', size);
```

### Problema: Lista lenta
```bash
# 1. Abra Performance tab
F12 → Performance → Grava → Renderiza → Vê o tempo

# 2. Se > 1s, há muitos itens
# Implemente virtualização com windowing

# 3. Verifique key prop
Todos os items devem ter key prop única
```

### Problema: WebSocket não conecta
```bash
# 1. Verifique o URL
console.log('WEBSOCKET_URL:', WEBSOCKET_URL);

# 2. Verifique se backend está online
curl https://assistente-juridico-rs1e.onrender.com/health

# 3. Veja os logs de conexão
F12 → Network → WS → veja a conexão
```

### Problema: Chevron não rotaciona
```bash
# 1. Inspecione o elemento
F12 → elementos → veja se tem rotate-0 ou rotate-180

# 2. Verifique se CSS está carregando
F12 → Styles → busque por rotate

# 3. Teste o estado
console.log('isIaMenuOpen:', isIaMenuOpen);
```

---

## 🚀 Teste de Deploy

### Antes de Deploy para Produção

```bash
# 1. Build local
npm run build

# 2. Teste o build
npm run preview

# 3. Verifique tamanho
ls -lh dist/

# 4. Teste todas as páginas
□ Abra Dashboard
□ Abra Settings
□ Abra PJe Robot
□ Abra Intimações
□ Verifique Sidebar

# 5. Teste no modo escuro/claro
□ Mude tema
□ Verifique contrastes

# 6. Teste em mobile
□ Redimensione viewport
□ Teste toque em botões
□ Teste input fields
```

---

## 📱 Testes Cross-Browser

Teste em múltiplos navegadores:

```bash
□ Chrome (Desktop)
□ Firefox (Desktop)
□ Safari (macOS)
□ Edge (Desktop)
□ Chrome (Mobile)
□ Safari (iOS)
□ Firefox (Android)
```

---

## ✨ Teste de Acessibilidade

```bash
□ Navegação por Tab funciona
□ Focus visível em todos botões
□ Screen reader lê conteúdo
□ Cores têm contraste > 4.5:1
□ Sem conteúdo flutuante
```

**Ferramentas Recomendadas:**
- axe DevTools
- Wave
- Lighthouse (Accessibility tab)

---

## 📝 Relatório de Testes

Após testar, preencha este formulário:

```
Data: ___/___/_____
Ambiente: [ ] Local [ ] Staging [ ] Produção

Teste 1 - LoadingSpinner:     [ ] PASSOU [ ] FALHOU
Teste 2 - DashboardHome:      [ ] PASSOU [ ] FALHOU
Teste 3 - API Service:         [ ] PASSOU [ ] FALHOU
Teste 4 - Sidebar Chevron:    [ ] PASSOU [ ] FALHOU

Regressão:                     [ ] OK [ ] PROBLEMA
Performance:                   [ ] OK [ ] LENTO
Acessibilidade:                [ ] OK [ ] FALHA

Observações:
_______________________________________
_______________________________________

Status Final: [ ] APROVADO [ ] REVISAR
```

---

## 🎯 Conclusão

Se todos os testes passarem ✅, você está pronto para:
1. ✅ Fazer commit das mudanças
2. ✅ Fazer push para repositório
3. ✅ Deploy para staging
4. ✅ Deploy para produção

---

**Dúvidas?** Verifique:
- `ANALISE_COMPLETA_ERROS.md` - Detalhes técnicos
- `CORRECOES_RESUMO.md` - Resumo das mudanças
- `CHECKLIST_VALIDACAO.md` - Checklist completo

---

*Happy testing! 🎉*

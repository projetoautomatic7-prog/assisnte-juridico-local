# Configuração Correta: Vercel Frontend + Render Backend

## 📋 Resumo da Configuração

### Backend (Render)
- **URL**: `https://assistente-juridico-rs1e.onrender.com`
- **Porta**: 10000 (gerenciada automaticamente pelo Render)
- **Serviço**: pje-robot-backend

### Frontend (Vercel)
- **URL Principal**: `https://assistente-jurídico-sandy.vercel.app`
- **URL Git/Preview**: `https://assistente-jurídico-git-main-thiagos-projects-9834ca6f.vercel.app`
- **Framework**: Vite + React

## 🔧 Configuração do Backend no Render

### Variáveis de Ambiente Necessárias

A variável mais importante para a conexão é o `FRONTEND_ORIGIN`:

```
FRONTEND_ORIGIN=https://assistente-jurídico-sandy.vercel.app,https://assistente-jurídico-git-main-thiagos-projects-9834ca6f.vercel.app,http://localhost:5173
```

**⚠️ IMPORTANTE**: 
- Esta variável controla o CORS (Cross-Origin Resource Sharing)
- Sem ela configurada corretamente, o frontend receberá erros 401 ou CORS blocked
- Inclua TODOS os domínios do Vercel (produção + preview + git branches)

### Como Configurar no Render

1. Acesse [Render Dashboard](https://dashboard.render.com/)
2. Selecione o serviço **pje-robot-backend**
3. Vá em **Environment** → **Environment Variables**
4. Atualize `FRONTEND_ORIGIN` com o valor acima
5. Clique em **Save Changes**
6. O Render fará redeploy automaticamente

### Verificar se o Backend Está Rodando

```bash
curl https://assistente-juridico-rs1e.onrender.com/health
```

Resposta esperada:
```json
{"status":"ok","timestamp":"2025-11-14T18:48:52.156Z"}
```

## 🌐 Configuração do Frontend no Vercel

### Variáveis de Ambiente Necessárias

Configure estas variáveis no dashboard do Vercel:

| Variável | Valor | Ambientes |
|----------|-------|-----------|
| `VITE_BACKEND_URL` | `https://assistente-juridico-rs1e.onrender.com` | Production, Preview, Development |
| `VITE_GOOGLE_CLIENT_ID` | Seu Google Client ID | Production, Preview, Development |
| `VITE_VAPID_PUBLIC_KEY` | Sua chave pública VAPID | Production, Preview, Development |

### Como Configurar no Vercel

1. Acesse [Vercel Dashboard](https://vercel.com/dashboard)
2. Selecione o projeto **assistente-jurídico**
3. Vá em **Settings** → **Environment Variables**
4. Adicione cada variável:
   - Nome: `VITE_BACKEND_URL`
   - Valor: `https://assistente-juridico-rs1e.onrender.com`
   - Selecione todos os ambientes (Production, Preview, Development)
5. Clique em **Save**
6. **⚠️ IMPORTANTE**: Faça um **Redeploy** após adicionar variáveis:
   - Vá em **Deployments**
   - Clique nos 3 pontos ao lado da última deployment
   - Selecione **Redeploy**

### Verificar se as Variáveis Estão Configuradas

Após o deploy, abra o console do navegador em:
`https://assistente-jurídico-sandy.vercel.app`

Execute:
```javascript
console.log(import.meta.env.VITE_BACKEND_URL)
```

Deve retornar: `https://assistente-juridico-rs1e.onrender.com`

## 🔍 Testando a Conexão

### 1. Teste de Health Check

Abra o console do navegador no Vercel e execute:

```javascript
fetch('https://assistente-juridico-rs1e.onrender.com/health')
  .then(r => r.json())
  .then(console.log)
```

Resultado esperado:
```json
{"status":"ok","timestamp":"..."}
```

### 2. Teste de Autenticação

Tente fazer login no frontend. Se aparecer erro de CORS:

```
Access to fetch at 'https://assistente-juridico-rs1e.onrender.com/api/auth/...' 
from origin 'https://assistente-jurídico-sandy.vercel.app' has been blocked by CORS policy
```

**Solução**: Verifique se `FRONTEND_ORIGIN` no Render inclui o domínio correto do Vercel.

### 3. Teste de WebSocket

O sistema usa WebSocket para comunicação em tempo real:

```javascript
const ws = new WebSocket('wss://assistente-juridico-rs1e.onrender.com');
ws.onopen = () => console.log('WebSocket conectado!');
ws.onerror = (e) => console.error('Erro WebSocket:', e);
```

## 🐛 Troubleshooting

### Problema: Erro 401 Unauthorized

**Causa**: CORS bloqueando a requisição
**Solução**: 
1. Verifique `FRONTEND_ORIGIN` no Render
2. Certifique-se de incluir o domínio exato do Vercel
3. Faça redeploy do backend após alterar

### Problema: Backend não responde

**Causa**: Serviço dormindo (Free tier do Render)
**Solução**: 
1. Acesse `https://assistente-juridico-rs1e.onrender.com/health`
2. Aguarde 30-60 segundos para o serviço acordar
3. Tente novamente

### Problema: Variáveis de ambiente não carregam

**Causa**: Vercel não fez rebuild com as novas variáveis
**Solução**:
1. Vá em Deployments no Vercel
2. Faça **Redeploy** (não apenas redeploy, mas rebuild completo)
3. Aguarde o build completar

### Problema: WebSocket não conecta

**Causa**: URL incorreta ou firewall
**Solução**:
1. Verifique se está usando `wss://` (não `ws://`)
2. URL deve ser: `wss://assistente-juridico-rs1e.onrender.com`
3. Verifique logs do navegador para detalhes

## 📝 Checklist de Deployment

### Backend (Render)
- [ ] `FRONTEND_ORIGIN` inclui todos os domínios do Vercel
- [ ] Backend está respondendo em `/health`
- [ ] Porta 10000 está configurada (automático no Render)
- [ ] Variáveis sensíveis configuradas (API_KEY, JWT_SECRET, etc.)

### Frontend (Vercel)
- [ ] `VITE_BACKEND_URL` configurado com URL do Render
- [ ] Variáveis configuradas em todos os ambientes
- [ ] Redeploy feito após adicionar variáveis
- [ ] Console não mostra erros de variáveis undefined

### Teste Final
- [ ] Login funciona sem erros CORS
- [ ] API responde corretamente
- [ ] WebSocket conecta sem erros
- [ ] Notificações funcionam (se aplicável)

## 📚 Referências

- [Documentação Render Environment Variables](https://render.com/docs/environment-variables)
- [Documentação Vercel Environment Variables](https://vercel.com/docs/projects/environment-variables)
- [Vite Environment Variables](https://vitejs.dev/guide/env-and-mode.html)

## 🆘 Suporte

Se após seguir todos os passos ainda houver problemas:

1. Verifique os logs do Render: Dashboard → Service → Logs
2. Verifique os logs do Vercel: Dashboard → Deployments → Runtime Logs
3. Verifique o console do navegador (F12) para erros JavaScript
4. Teste a conexão com curl/Postman antes de testar no navegador

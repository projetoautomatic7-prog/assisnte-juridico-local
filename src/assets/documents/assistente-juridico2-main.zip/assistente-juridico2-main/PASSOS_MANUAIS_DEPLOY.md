# 🚀 Passos Manuais para Deploy - IMPORTANTE

## ⚠️ ATENÇÃO: Configuração Manual Necessária

Este arquivo contém os passos **obrigatórios** que você precisa executar manualmente no Render e Vercel para que o sistema funcione corretamente.

## 📋 Checklist de Configuração

### 1️⃣ Configurar Backend no Render (PRIORITÁRIO)

#### Passo 1: Acessar o Dashboard do Render
1. Vá para: https://dashboard.render.com/
2. Faça login com sua conta
3. Localize o serviço: **pje-robot-backend**

#### Passo 2: Atualizar Variável FRONTEND_ORIGIN
1. No serviço **pje-robot-backend**, clique em **Environment** (menu lateral esquerdo)
2. Procure pela variável `FRONTEND_ORIGIN`
3. Clique no ícone de editar (lápis) ao lado da variável
4. Substitua o valor atual por:
   ```
   https://assistente-jurídico-sandy.vercel.app,https://assistente-jurídico-git-main-thiagos-projects-9834ca6f.vercel.app,http://localhost:5173
   ```
5. Clique em **Save Changes**

#### Passo 3: Redeploy do Backend
1. Após salvar, o Render iniciará automaticamente um redeploy
2. Aguarde o deploy completar (geralmente 2-5 minutos)
3. Verifique os logs para confirmar que não há erros
4. Procure pela mensagem: `🚀 Servidor backend rodando na porta 10000`

#### Passo 4: Verificar Backend
Execute no terminal ou navegador:
```bash
curl https://assistente-juridico-rs1e.onrender.com/health
```

Resposta esperada:
```json
{"status":"ok","timestamp":"2025-11-14T..."}
```

---

### 2️⃣ Configurar Frontend no Vercel

#### Passo 1: Acessar o Dashboard do Vercel
1. Vá para: https://vercel.com/dashboard
2. Faça login com sua conta
3. Localize o projeto: **assistente-jurídico**

#### Passo 2: Adicionar Variáveis de Ambiente
1. No projeto, vá em **Settings** → **Environment Variables**
2. Adicione ou verifique as seguintes variáveis:

**Variável 1: VITE_BACKEND_URL**
- Nome: `VITE_BACKEND_URL`
- Valor: `https://assistente-juridico-rs1e.onrender.com`
- Ambientes: ✅ Production ✅ Preview ✅ Development
- Clique em **Save**

**Variável 2: VITE_GOOGLE_CLIENT_ID** (se você tem Google OAuth configurado)
- Nome: `VITE_GOOGLE_CLIENT_ID`
- Valor: `[SEU_GOOGLE_CLIENT_ID]`
- Ambientes: ✅ Production ✅ Preview ✅ Development
- Clique em **Save**

**Variável 3: VITE_VAPID_PUBLIC_KEY** (se você tem notificações push configuradas)
- Nome: `VITE_VAPID_PUBLIC_KEY`
- Valor: `[SUA_VAPID_PUBLIC_KEY]`
- Ambientes: ✅ Production ✅ Preview ✅ Development
- Clique em **Save**

#### Passo 3: Redeploy do Frontend
⚠️ **IMPORTANTE**: Adicionar variáveis não atualiza automaticamente o build!

1. Vá em **Deployments**
2. Localize a última deployment bem-sucedida
3. Clique nos **3 pontos** (...) ao lado dela
4. Selecione **Redeploy**
5. Aguarde o build completar (geralmente 30-60 segundos)

#### Passo 4: Verificar Frontend
1. Abra: https://assistente-jurídico-sandy.vercel.app
2. Pressione **F12** para abrir o console do navegador
3. Execute no console:
   ```javascript
   console.log('Backend URL:', import.meta.env.VITE_BACKEND_URL)
   ```
4. Deve mostrar: `Backend URL: https://assistente-juridico-rs1e.onrender.com`

---

### 3️⃣ Testar a Conexão Completa

#### Teste 1: Health Check do Backend
No console do navegador (F12), execute:
```javascript
fetch('https://assistente-juridico-rs1e.onrender.com/health')
  .then(r => r.json())
  .then(data => console.log('✅ Backend OK:', data))
  .catch(err => console.error('❌ Erro:', err))
```

#### Teste 2: Login
1. Tente fazer login no sistema
2. Se funcionar sem erros CORS → **Sucesso!**
3. Se mostrar erro CORS → Verifique o Passo 1 novamente

#### Teste 3: WebSocket (Opcional)
```javascript
const ws = new WebSocket('wss://assistente-juridico-rs1e.onrender.com');
ws.onopen = () => console.log('✅ WebSocket conectado!');
ws.onerror = (e) => console.error('❌ WebSocket erro:', e);
```

---

## 🐛 Troubleshooting

### Erro: "Access to fetch... has been blocked by CORS policy"
**Solução**:
1. Volte ao Render
2. Verifique se `FRONTEND_ORIGIN` está configurado corretamente
3. Certifique-se de incluir TODOS os domínios do Vercel
4. Faça redeploy do backend

### Erro: "Failed to fetch" ou "Network Error"
**Causas Possíveis**:
1. Backend ainda não acordou (Free tier dorme após inatividade)
   - Solução: Acesse `/health` e aguarde 30-60 segundos
2. URL do backend incorreta no frontend
   - Solução: Verifique `VITE_BACKEND_URL` no Vercel

### Erro: import.meta.env.VITE_BACKEND_URL is undefined
**Causa**: Variável não configurada ou redeploy não foi feito
**Solução**:
1. Verifique se a variável foi adicionada no Vercel
2. Faça um **Redeploy** completo (não apenas redeploy, mas rebuild)

### Backend responde 500 Internal Server Error
**Causa**: Provavelmente variáveis de ambiente obrigatórias faltando
**Solução**:
1. No Render, verifique os logs do backend
2. Procure por mensagens de erro sobre variáveis faltando
3. Configure as variáveis necessárias (API_KEY, JWT_SECRET, DATABASE_URL, etc.)

---

## ✅ Confirmação Final

Depois de executar todos os passos:

- [ ] `FRONTEND_ORIGIN` configurado no Render
- [ ] Backend respondendo em `/health`
- [ ] `VITE_BACKEND_URL` configurado no Vercel
- [ ] Frontend redployado após adicionar variáveis
- [ ] Login funciona sem erros CORS
- [ ] Console do navegador não mostra erros de conexão

---

## 📞 Precisa de Ajuda?

Se após seguir todos os passos ainda houver problemas:

1. **Logs do Render**: Dashboard → pje-robot-backend → Logs
2. **Logs do Vercel**: Dashboard → Deployments → Runtime Logs
3. **Console do Navegador**: F12 → Console tab
4. **Network Tab**: F12 → Network tab (para ver requisições falhando)

Compare os logs com os exemplos no arquivo `CONFIGURACAO_VERCEL_RENDER.md`.

---

## 📚 Documentação Adicional

- `CONFIGURACAO_VERCEL_RENDER.md` - Guia completo com detalhes técnicos
- `.env.example` - Exemplo de variáveis do frontend
- `backend/.env.example` - Exemplo de variáveis do backend

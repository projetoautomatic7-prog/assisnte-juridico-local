# Assistente Jurídico PJe com IA Gemini

Uma suíte de ferramentas de alta performance construída para otimizar e automatizar a rotina de escritórios de advocacia que utilizam o sistema PJe (Processo Judicial Eletrônico) no Brasil. A aplicação integra o poder da IA generativa do Google Gemini para transformar tarefas manuais em fluxos de trabalho inteligentes e eficientes.

## 🔑 Acesso Rápido ao Sistema

**NOVO!** Sistema de login simplificado com acesso instantâneo:

### Como fazer login:
1. Abra a aplicação
2. Clique em qualquer um dos botões de **Acesso Rápido**:
   - 👤 **admin** / admin123 (recomendado)
   - 👤 **demo** / demo
   - 👤 **usuario** / 123456

Ou digite manualmente as credenciais acima. **Não requer configuração!**

📖 **Guia completo**: Veja [LOGIN_SIMPLES.md](LOGIN_SIMPLES.md) para instruções detalhadas.

## ✨ Principais Funcionalidades

Este assistente jurídico é composto por um ecossistema de módulos integrados para gerenciar todo o ciclo de vida de um processo:

- **Meu Painel:** Um dashboard centralizado que oferece uma visão geral de compromissos, prazos fatais, tarefas pendentes e a atividade recente dos agentes de IA.
- **Robô PJe Autônomo:** Um agente que opera 24/7, conectando-se ao PJe para monitorar novos expedientes, intimações e audiências em tempo real, com gestão de sessão e autenticação de dois fatores.
- **CRM de Processos (Acervo):** Um painel Kanban completo para a gestão visual do fluxo de processos, permitindo arrastar e soltar cards entre as fases e etapas do funil jurídico.
- **Painel de Expedientes:** Caixa de entrada inteligente para intimações, onde a IA analisa o conteúdo, resume os pontos-chave, classifica a ação necessária, identifica documentos pendentes e gera minutas de petições.
- **Análise de Documentos em Lote:** Ferramenta para extrair informações estruturadas (Nº CNJ, partes, prazos) de múltiplos expedientes colados de uma só vez.
- **Transcrição de Áudio:** Transcrição em tempo real (via microfone) ou por arquivo de audiências e reuniões, com a capacidade de gerar um sumário acionável dos pontos discutidos.
- **Calculadora de Prazos com Raciocínio:** Calcula prazos processuais (CPC, CLT) considerando feriados e contexto, fornecendo uma análise passo a passo auditável gerada pelo Gemini 2.5 Pro.
- **Consultas a Bases de Dados Nacionais:**
    - **Datajud:** Consulta direta à Base Nacional de Dados do Poder Judiciário para obter andamentos processuais oficiais.
    - **DJEN:** Pesquisa por nome de advogado ou OAB nos Diários de Justiça Eletrônicos de múltiplos tribunais.
- **Agenda Integrada:** Um calendário completo para gerenciar compromissos, audiências e prazos, com visualização mensal e gerenciamento de eventos.
- **Gestão Financeira:** Módulo para controle de receitas e despesas vinculadas a processos, com dashboards visuais e extração de dados de documentos (via IA).
- **Base de Conhecimento (RAG):** Um sistema de Retrieval-Augmented Generation que permite indexar documentos do escritório (petições, doutrina, anotações) e conversar com essa base para obter respostas contextuais.
- **Gestão de Equipe e Configurações:** Painel para gerenciar usuários, permissões e configurações da plataforma.

## 🚀 Stack de Tecnologia

A aplicação é construída com uma arquitetura moderna e robusta, separando frontend e backend para escalabilidade e manutenção.

### Frontend
- **Framework:** React 19 com TypeScript
- **Build Tool:** Vite
- **Estilização:** Tailwind CSS e um sistema de temas customizável com variáveis CSS.
- **IA:** Integração direta com o backend para consumir os serviços do Google Gemini API.

### Backend
- **Ambiente:** Node.js com Express.js e TypeScript
- **Comunicação em Tempo Real:** WebSocket para comunicação bidirecional entre o frontend e o robô PJe.
- **Automação (Robô):** Puppeteer com `@sparticuz/chromium` para automação do navegador e interação com o portal PJe.
- **Inteligência Artificial:**
    - **Google Gemini API (`@google/genai`):** Utilizado para:
        - **Geração de Texto:** `gemini-2.5-flash` para tarefas rápidas como resumos e conversas.
        - **Análise e Raciocínio:** `gemini-2.5-pro` para tarefas complexas como análise de documentos, geração de minutas e cálculo de prazos.
        - **Análise Multimodal:** `gemini-2.5-pro` para analisar a tela de erro do PJe (imagem + texto) e `gemini-2.5-flash-image` para edição de imagens.
        - **Transcrição de Áudio:** `gemini-2.5-flash-native-audio-preview` através de um proxy WebSocket para transcrição em tempo real.
    - **Embeddings & RAG:** `@xenova/transformers` para gerar embeddings de texto e ChromaDB como vector store para a Base de Conhecimento.
- **Banco de Dados:** PostgreSQL para armazenamento de dados da aplicação (usuários, processos, tarefas).
- **Agendamento de Tarefas:** `node-cron` para tarefas recorrentes (ex: health checks, relatórios diários).

## 📂 Estrutura do Projeto

O projeto está organizado da seguinte forma:

```
/
├── backend/                  # Servidor Node.js
│   ├── src/
│   │   ├── agent/            # Lógica para o sistema de agentes autônomos
│   │   ├── middleware/       # Middlewares de autenticação
│   │   ├── routes/           # Definição das rotas da API
│   │   ├── services/         # Lógica de negócio (PJe, Gemini, DB, etc.)
│   │   └── server.ts         # Ponto de entrada do servidor
│   └── ...
├── src/
│   ├── components/           # Componentes React reutilizáveis
│   ├── pages/                # Componentes que representam as páginas da aplicação
│   ├── services/             # Lógica do lado do cliente (API, temas)
│   ├── styles/               # Estilos globais e CSS de componentes
│   ├── types.ts              # Definições de tipos TypeScript
│   └── App.tsx               # Componente principal que gerencia o roteamento
├── .env.example              # Variáveis de ambiente do Frontend
├── .gitignore                # Arquivos e pastas a serem ignorados pelo Git
├── index.html                # Ponto de entrada do HTML
├── package.json              # Dependências e scripts do projeto
└── vite.config.ts            # Configuração do Vite
```

## 🎨 Funcionalidade de Temas

O aplicativo possui um sistema de temas totalmente integrado, com 4 opções e animação suave na transição.

### Como Alterar o Tema
No canto inferior esquerdo da barra de navegação, você encontrará um seletor de temas. Basta escolher uma das opções (`Dark`, `Mid`, `Light`, `Corporate`) para aplicar a mudança instantaneamente. Sua preferência será salva localmente no navegador.

### Como Criar um Novo Tema
Para adicionar um novo tema, edite o arquivo `styles/themes.css` e adicione uma nova classe (ex: `.theme-meuTema`). Dentro dela, defina as variáveis de cor (tokens) que deseja alterar:

```css
.theme-meuTema {
  --color-bg: #f0f0f0;
  --color-surface: #ffffff;
  --color-text: #222222;
  --color-primary: #ff6600;
  /* ... e outras variáveis de cor ... */
}
```
Após adicionar a nova classe, atualize o componente `components/ThemeSwitcher.tsx` para incluir a nova opção no seletor.

## 🚀 Implantação (Deployment)

Este guia mostra como implantar o **backend na Render.com** e o **frontend na Vercel**.

### Pré-requisitos
1.  **Conta no GitHub:** Seu código deve estar em um repositório no GitHub.
2.  **Conta na Render.com:** Para o backend e o banco de dados.
3.  **Conta na Vercel:** Para o frontend.
4.  **Chaves de API:**
    -   `API_KEY` do Google Gemini.
    -   `DATAJUD_API_KEY` do Datajud (CNJ).
    -   Crie uma string longa e segura para o `JWT_SECRET` (pode usar um gerador de senhas).

---

### Parte 1: Implantando o Backend na Render.com

O backend precisa de um banco de dados PostgreSQL para funcionar.

#### Passo 1: Criar o Banco de Dados PostgreSQL na Render
1.  No seu dashboard da Render, clique em **New +** > **PostgreSQL**.
2.  Dê um nome para seu banco de dados (ex: `pje-robot-db`), escolha uma região próxima a você e clique em **Create Database**.
3.  Após a criação, copie a **Internal Connection String**. Você usará isso como `DATABASE_URL`.

#### Passo 2: Criar o Serviço do Backend
1.  No dashboard da Render, clique em **New +** > **Blueprint**.
2.  Conecte seu repositório do GitHub e selecione-o.
3.  A Render irá detectar automaticamente o arquivo `backend/render.yaml` e configurar o serviço.
4.  Dê um nome ao seu grupo de serviços (ex: `PJe-Assistente`).
5.  Clique em **Apply**.

#### Passo 3: Configurar as Variáveis de Ambiente
1.  Navegue até o serviço web criado (ex: `pje-robot-backend`).
2.  Vá para a aba **Environment**.
3.  Adicione as seguintes variáveis em **Secret Files & Environment Variables**:
    -   **`DATABASE_URL`**: Cole a *Internal Connection String* que você copiou do seu banco de dados PostgreSQL na Render.
    -   **`API_KEY`**: Cole sua chave da API do Google Gemini.
    -   **`DATAJUD_API_KEY`**: Cole sua chave da API do Datajud.
    -   **`JWT_SECRET`**: Cole a string segura que você gerou.
    -   **`FRONTEND_ORIGIN`**: Por enquanto, deixe um valor temporário como `https://temp.com`. **Você atualizará isso no final.**
4.  Salve as variáveis. O serviço fará o deploy automaticamente.

#### Passo 4: Verificar o Deploy do Backend
1.  Aguarde o deploy ser concluído. Verifique os logs para a mensagem: `🚀 Servidor backend rodando na porta...`.
2.  Copie a URL do seu serviço backend (ex: `https://assistente-juridico-rs1e.onrender.com`). Você precisará dela para o frontend.

> **⚠️ Problemas com DATABASE_URL?** Se você ver erros como `getaddrinfo ENOTFOUND base`, consulte o [Guia de Solução de Problemas do DATABASE_URL](DATABASE_TROUBLESHOOTING.md) para resolver.

---

### Parte 2: Implantando o Frontend na Vercel

#### Passo 1: Criar o Projeto na Vercel
1.  No seu dashboard da Vercel, clique em **Add New...** > **Project**.
2.  Importe o seu repositório do GitHub.
3.  A Vercel deve detectar automaticamente que é um projeto Vite e preencher as configurações de build.
    -   **Framework Preset:** Vite
    -   **Build Command:** `npm run build`
    -   **Output Directory:** `dist`

#### Passo 2: Configurar a Variável de Ambiente
1.  Expanda a seção **Environment Variables**.
2.  Adicione a seguinte variável:
    -   **`VITE_BACKEND_URL`**: Cole a URL do seu backend que você copiou da Render (ex: `https://assistente-juridico-rs1e.onrender.com`).
3.  Clique em **Deploy**.

#### Passo 3: Verificar o Deploy do Frontend
1.  Aguarde a conclusão do deploy.
2.  Acesse a URL fornecida pela Vercel. Você deverá ver a tela de login da sua aplicação.
3.  Copie a URL principal do seu projeto na Vercel (ex: `https://seu-projeto.vercel.app`).

---

### Parte 3: Configuração Final

#### Passo 1: Corrigir a Configuração de CORS
1.  Volte para o seu serviço de backend na **Render.com**.
2.  Vá para a aba **Environment**.
3.  Edite a variável **`FRONTEND_ORIGIN`** e cole a URL do seu frontend da Vercel (ex: `https://seu-projeto.vercel.app`).
4.  Salve as alterações. A Render fará um novo deploy do seu backend com a origem correta.

**Pronto!** Sua aplicação agora está totalmente implantada e funcional. O frontend na Vercel se comunicará de forma segura com o backend na Render.

---
## 🧪 Execução Local (Desenvolvimento)

Siga estes passos para configurar e rodar a aplicação no seu ambiente de desenvolvimento.

### Pré-requisitos
- Node.js (versão 20 ou superior)
- npm (versão 10 ou superior)
- Docker (recomendado, para rodar o PostgreSQL facilmente)

### 1. Clonar e Instalar Dependências

Primeiro, clone o repositório e instale as dependências para o frontend e o backend.

```bash
# Clone o repositório
git clone https://github.com/seu-usuario/seu-repositorio.git
cd seu-repositorio

# Instale as dependências do frontend (na raiz)
npm install

# Instale as dependências do backend
cd backend
npm install
cd ..
```

### 2. Configurar Variáveis de Ambiente

As variáveis de ambiente são cruciais para a aplicação funcionar. Use os arquivos de exemplo como template.

**Para o Backend:**
1. Navegue até a pasta `backend`.
2. Copie o arquivo `.env.example` para um novo arquivo chamado `.env`.
   ```bash
   cp backend/.env.example backend/.env
   ```
3. Edite o arquivo `backend/.env` e preencha com suas chaves e URLs, principalmente:
    - `API_KEY`: chave do Google Gemini (obtenha no Google AI Studio)
    - `JWT_SECRET`: gere uma string segura e longa
    - `DATABASE_URL`: conexão com PostgreSQL (ex.: `postgres://postgres:postgres@localhost:5432/assistente_juridico`)
    - `FRONTEND_ORIGIN`: URL do frontend (ex.: `http://localhost:5173` no dev)
    - `PJE_LOGIN_URL`: URL de login do PJe que você utiliza
    - `DATAJUD_API_KEY`: chave do DataJud (CNJ)
    - `CHROMA_URL`: URL do ChromaDB (ex.: `http://localhost:8000`)
    - `VAPID_PUBLIC_KEY` e `VAPID_PRIVATE_KEY`: chaves Web Push (VAPID)

**Para o Frontend:**
1. Na raiz do projeto, copie `.env.example` para um novo arquivo `.env`.
   ```bash
   cp .env.example .env
   ```
2. Edite o arquivo `.env` e preencha com as suas chaves.
   - `VITE_BACKEND_URL`: Mantenha `http://localhost:3001` para desenvolvimento local.
   - `VITE_GOOGLE_CLIENT_ID`: Sua chave de cliente do Google para o login.
    - `VITE_VAPID_PUBLIC_KEY`: Sua chave pública VAPID para notificações push.

> **Importante:** Os arquivos `.env` contêm informações sensíveis e já estão no `.gitignore` para não serem enviados ao GitHub.

### 3. Subir dependências com Docker (PostgreSQL + ChromaDB)

Você pode subir Postgres e ChromaDB com um único comando usando o `docker-compose.yml` incluído na raiz do projeto.

```bash
docker compose up -d
```

Isso iniciará:
- Postgres em `localhost:5432` (db `assistente_juridico`, usuário `postgres`, senha `postgres`)
- ChromaDB em `http://localhost:8000`

Depois, ajuste no `backend/.env`:
- `DATABASE_URL=postgres://postgres:postgres@localhost:5432/assistente_juridico`
- `CHROMA_URL=http://localhost:8000`

### 4. Rodar o Backend

Com o banco de dados e as variáveis de ambiente configuradas, inicie o servidor backend.

```bash
# A partir da raiz do projeto
cd backend
npm run dev
```

Você deve ver logs indicando que o servidor e o banco de dados estão conectados e prontos. O servidor rodará em `http://localhost:3001`.

### 5. Rodar o Frontend

Abra um **novo terminal** na raiz do projeto e inicie a aplicação React.

```bash
# A partir da raiz do projeto
npm run dev
```

O Vite iniciará o servidor de desenvolvimento, geralmente em `http://localhost:5173`. Acesse essa URL no seu navegador para ver a aplicação.

---
## ✅ Checklist de Deploy (Resumo)
1. Criar PostgreSQL na Render → copiar Internal Connection String
2. Criar Blueprint (Render) → usar `backend/render.yaml`
3. Adicionar variáveis: `API_KEY`, `DATAJUD_API_KEY`, `JWT_SECRET`, `DATABASE_URL`, `FRONTEND_ORIGIN` (temporário) 
4. Esperar URL do backend (ex: `https://assistente-juridico-rs1e.onrender.com`)
5. Criar projeto na Vercel → definir `VITE_BACKEND_URL`
6. Deploy frontend → obter URL pública
7. Atualizar `FRONTEND_ORIGIN` no backend com URL pública do frontend
8. Testar fluxo: login, chamadas API, WebSockets

---

## 🤖 GitHub Copilot Agent

Este projeto inclui um **agente especializado do GitHub Copilot** para desenvolvimento com expertise em:
- Sistema PJe e automação jurídica brasileira
- Análise e redação de documentos legais com IA
- Cálculo de prazos processuais (CPC/CLT)
- Integração DJEN/DataJud
- Sistema de agentes autônomos

Para usar o agente, veja a documentação em [`.github/agents/`](.github/agents/README.md).

**Exemplo de uso**:
```
@legal-assistant Add a new tool to calculate honorários advocatícios
```

---
## 📌 Próximos Aprimoramentos Sugestivos
- Script automatizado de seed para dados de demonstração
- Monitoramento (uptime + métricas) via health route e logs estruturados
- Adicionar CI (GitHub Actions) para testes antes do deploy

Se precisar, peça para gerar pipeline GitHub Actions ou Dockerfile multi-stage.

---
## 🤖 GitHub Copilot Cloud Agents

Este projeto inclui **7 agentes especializados** do GitHub Copilot para auxiliar no desenvolvimento:

1. **@legal-expert** - Especialista em sistema jurídico brasileiro, PJe e análise de documentos
2. **@agent-system-expert** - Especialista em arquitetura de agentes autônomos e orquestração
3. **@frontend-expert** - Especialista em React 19, TypeScript, Vite e Tailwind CSS
4. **@database-expert** - Especialista em PostgreSQL, migrações e otimização
5. **@automation-expert** - Especialista em automação Puppeteer e RPA do PJe
6. **@ai-integration-expert** - Especialista em Google Gemini API e engenharia de prompts
7. **@testing-expert** - Especialista em testes, Jest e garantia de qualidade

### Como Usar

No GitHub Copilot Chat, mencione o agente desejado:

```
@legal-expert Como implementar extração de prazos de expedientes?
@agent-system-expert Criar nova ferramenta para análise DJEN
@frontend-expert Implementar atualização em tempo real no dashboard
```

📖 **Documentação completa**: Veja [.github/agents/README.md](.github/agents/README.md) e [.github/agents/USAGE_GUIDE.md](.github/agents/USAGE_GUIDE.md)
# 🔐 Como Resolver Seu Problema de Login

## 🎯 Problema que Você Está Enfrentando

Você tentou fazer login e recebeu: **"Usuário ou senha inválidos"**

## ✅ Boa Notícia!

O sistema de autenticação está funcionando perfeitamente! Criamos ferramentas para te ajudar a identificar **exatamente** qual é o problema.

---

## 🚀 Solução Rápida (2 minutos)

### Passo 1: Abra a Página de Teste
```
https://assistente-juridico-rs1e.onrender.com/test/test-login.html
```

### Passo 2: Clique em "Testar Senhas Alternativas"

Teste estas 3 senhas:
- ✅ `admin123` (padrão)
- ✅ `Aj!2025#Juri-Assist%Z7`
- ✅ `Adv@2025!Secure_X9`

### Passo 3: Veja Qual Senha Funciona

A senha que retornar **"✅ Senha Aceita!"** é a senha correta do seu sistema.

### Passo 4: Use Essa Senha no App

Agora use:
- **Username:** `admin` (NÃO use "seu.usuario")
- **Senha:** A senha que funcionou no teste

---

## 🔍 Se Ainda Não Funcionar

### Verifique o Username

⚠️ **MUITO IMPORTANTE:**
- O campo de usuário mostra **"seu.usuario"** como exemplo
- Mas você deve digitar: **`admin`**
- NÃO digite "seu.usuario" - isso é só um placeholder!

### Verifique os Logs do Render

1. Acesse: https://render.com/dashboard
2. Clique no seu serviço backend
3. Clique em **Logs**
4. Tente fazer login
5. Procure por mensagens como:
   ```
   [Login Attempt] Username: "SEU_USERNAME_AQUI" | Expected: "admin"
   [Login Failed] Username mismatch: received "seu.usuario", expected "admin"
   ```

Isso mostra **exatamente** o que você está enviando!

---

## 📋 Checklist de Verificação

Use esta lista para garantir que tudo está certo:

- [ ] Estou usando username **"admin"** (não "seu.usuario")
- [ ] Testei as 3 senhas na página de teste
- [ ] Vi qual senha foi aceita
- [ ] Estou usando essa senha no app
- [ ] Verifiquei os logs do Render para confirmar
- [ ] O backend está online (luz verde no Render)

---

## 🛠️ Configurações Testadas e Verificadas

Estas configurações foram **testadas e confirmadas funcionando**:

### Opção 1: Credenciais Padrão
```bash
# No Render, REMOVA estas variáveis (se existirem):
ADMIN_USERNAME
ADMIN_PASSWORD
ADMIN_PASSWORD_HASH

# Use no login:
Username: admin
Password: admin123
```

### Opção 2: Senha "Aj!2025#Juri-Assist%Z7"
```bash
# No Render, configure:
ADMIN_USERNAME=admin
ADMIN_PASSWORD_HASH=$2b$12$fDwsnagsVN4KMUZkVJLaEOZE03vt43uc1F2vy7zK1gfd4FuCH./TO

# REMOVA (se existir):
ADMIN_PASSWORD

# Use no login:
Username: admin
Password: Aj!2025#Juri-Assist%Z7
```

### Opção 3: Senha "Adv@2025!Secure_X9"
```bash
# No Render, configure:
ADMIN_USERNAME=admin
ADMIN_PASSWORD_HASH=$2b$12$Zfe7o4UehA9caaURrEatku8JtSOt.oM272eD5JajZkg//MedQwmYS

# REMOVA (se existir):
ADMIN_PASSWORD

# Use no login:
Username: admin
Password: Adv@2025!Secure_X9
```

---

## 🎓 Entendendo as Variáveis

### O Que Cada Variável Faz

| Variável | Função | Obrigatória? |
|----------|--------|--------------|
| `JWT_SECRET` | Gera tokens de autenticação | ✅ SIM (obrigatória) |
| `ADMIN_USERNAME` | Nome de usuário | ❌ Opcional (padrão: admin) |
| `ADMIN_PASSWORD` | Senha em texto plano | ❌ Opcional (não recomendado) |
| `ADMIN_PASSWORD_HASH` | Senha criptografada | ⭐ Recomendado |

### Regra Importante

⚠️ **Se você definir `ADMIN_PASSWORD_HASH`, o sistema ignora `ADMIN_PASSWORD`**

Isso significa:
- Se tem hash → usa o hash (mais seguro)
- Se não tem hash → usa a senha plain text
- Se não tem nenhum → usa padrão (admin123)

---

## 🆘 Precisa de Mais Ajuda?

### 1. Ferramentas Disponíveis

- 🔍 **Página de Teste:** https://assistente-juridico-rs1e.onrender.com/test/test-login.html
- 📖 **Guia Completo:** [TROUBLESHOOTING_LOGIN.md](./TROUBLESHOOTING_LOGIN.md)
- 🛠️ **Ferramentas Diagnósticas:** [LOGIN_DIAGNOSTIC_TOOLS.md](./LOGIN_DIAGNOSTIC_TOOLS.md)

### 2. O Que Compartilhar

Se precisar de suporte, compartilhe:

✅ **SEGURO compartilhar:**
- Screenshot da página de teste
- Resultado do endpoint `/api/auth/config-check`
- Logs do Render (últimas 50 linhas)
- Mensagem de erro do navegador

❌ **NUNCA compartilhe:**
- Valor do `JWT_SECRET`
- Valor do `ADMIN_PASSWORD`
- Valor do `ADMIN_PASSWORD_HASH`
- Tokens JWT gerados

### 3. Como Pedir Ajuda

Se ainda tiver problemas, faça assim:

1. Acesse https://assistente-juridico-rs1e.onrender.com/test/test-login.html
2. Faça todos os 4 testes
3. Tire screenshot de cada resultado
4. Copie os logs do Render
5. Compartilhe tudo isso

Com essas informações, podemos resolver rapidamente!

---

## 💡 Dicas Importantes

### ✅ Faça Isso
- Use a página de teste primeiro
- Verifique os logs do Render
- Use "admin" como username (não o placeholder)
- Teste as 3 senhas fornecidas
- Leia as mensagens de erro com atenção

### ❌ Não Faça Isso
- Não digite "seu.usuario" - é só um exemplo!
- Não compartilhe senhas ou tokens
- Não remova variáveis sem testar antes
- Não use múltiplas abas/navegadores simultaneamente

---

## 🎯 Resumo de 1 Minuto

1. Abra: https://assistente-juridico-rs1e.onrender.com/test/test-login.html
2. Teste as 3 senhas
3. Use a que funcionar
4. Username é sempre: **admin**
5. Se falhar, veja os logs do Render

**Pronto!** 🎉

---

## 📞 Suporte

Se seguiu tudo isso e ainda não funciona:
1. Tire screenshots da página de teste
2. Copie os logs do Render
3. Abra uma issue no GitHub com essas informações

Vamos resolver juntos! 💪




interface ImportMetaEnv {
  readonly VITE_BACKEND_URL: string;
  readonly VITE_GOOGLE_CLIENT_ID: string;
  readonly VITE_VAPID_PUBLIC_KEY: string;
  // adicione outras variáveis de ambiente que você usa no frontend aqui
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
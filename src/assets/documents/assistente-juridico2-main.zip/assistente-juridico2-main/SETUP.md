# Guia Rápido de Configuração Local

Este guia rápido ajuda você a configurar e rodar a aplicação localmente.

## Pré-requisitos

- Node.js (versão 20 ou superior)
- npm (versão 10 ou superior)
- Docker e Docker Compose (para PostgreSQL e ChromaDB)

## Passos para Configuração

### 1. Instalar Dependências

```bash
# Na raiz do projeto (frontend)
npm install

# No diretório backend
cd backend
npm install
cd ..
```

### 2. Configurar Variáveis de Ambiente

Os arquivos `.env` já estão configurados com valores padrão para desenvolvimento local:

- **Frontend**: `.env` na raiz do projeto
- **Backend**: `backend/.env`

**Credenciais padrão:**
- **Usuário**: admin
- **Senha**: admin123

### 3. Iniciar Serviços com Docker

```bash
# Na raiz do projeto
docker compose up -d
```

Este comando inicia:
- PostgreSQL na porta 5432
- ChromaDB na porta 8000

### 4. Iniciar o Backend

```bash
# Na pasta backend
cd backend
npm run dev
```

O backend estará rodando em `http://localhost:3001`

### 5. Iniciar o Frontend

Em outro terminal:

```bash
# Na raiz do projeto
npm run dev
```

O frontend estará rodando em `http://localhost:3000`

### 6. Acessar a Aplicação

Abra seu navegador e acesse: `http://localhost:3000`

Use as credenciais:
- **Usuário**: admin
- **Senha**: admin123

## Solução de Problemas

### Erro "Failed to fetch"

Este erro ocorre quando o backend não está rodando ou não está acessível. Verifique se:

1. O backend está rodando na porta 3001
2. O Docker está rodando e o PostgreSQL está acessível
3. As variáveis de ambiente estão configuradas corretamente

### Porta em Uso

Se as portas 3000, 3001, 5432 ou 8000 já estiverem em uso, você pode:

1. Parar os serviços que estão usando essas portas
2. Ou modificar as portas nos arquivos de configuração

## Próximos Passos

Consulte o [README.md](./README.md) para informações detalhadas sobre:
- Funcionalidades da aplicação
- Deployment em produção
- Configurações avançadas

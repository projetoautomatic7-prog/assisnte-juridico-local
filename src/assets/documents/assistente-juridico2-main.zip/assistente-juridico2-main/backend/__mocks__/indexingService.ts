// Mock para indexingService: evita import ESM de @xenova/transformers nos testes
export async function generateEmbeddings(texts: string[]): Promise<number[][]> {
  // Retorna vetor determinístico simples baseado em length dos textos
  return texts.map(t => {
    const base = t.length % 10;
    return [base, base + 1, base + 2];
  });
}

export function isGPUAvailable(): boolean {
  return false;
}
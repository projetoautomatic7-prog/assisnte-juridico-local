// Mock simples do ChromaClient para uso nos testes unitários.
// Ele fornece funções espias para `add` e `query`.

// state exposed for tests to inspect lastAdd call
const state = {
  lastAdd: null
};

const collectionMock = {
  add: jest.fn(async (payload) => {
    // store last add so tests can validate it
    state.lastAdd = {
      ids: payload.ids,
      embeddings: payload.embeddings,
      metadatas: payload.metadatas,
      documents: payload.documents
    };
    return { ids: payload.ids, embeddings: payload.embeddings };
  }),
  query: jest.fn(async (payload) => {
    return {
      documents: [
        payload.nResults === 1 ? ['doc-result'] : ['doc1', 'doc2']
      ],
      metadatas: [
        payload.nResults === 1 ? [{ id: 'm1' }] : [{ id: 'm1' }, { id: 'm2' }]
      ],
      distances: [[0.1, 0.2]]
    };
  })
};

module.exports = {
  ChromaClient: function (opts) {
    return {
      getOrCreateCollection: async ({ name }) => {
        return collectionMock;
      }
    };
  },
  // tests expect to be able to read the state from the mock
  state,
  Collection: function () {}
};

/* eslint-disable no-unused-vars */
// Simple Jest mock for @xenova/transformers to avoid ESM parsing issues while testing
// Exports minimal API expected by indexingService: env and pipeline

exports.env = {
  allowLocalModels: false,
  allowRemoteModels: false
};

// pipeline(task, model?) => returns an `extractor` function
// The extractor returns an object with `.data` that can be converted to an array
exports.pipeline = async (_task, _model) => {
  return async (_text, _opts) => {
    // Return deterministic fake embedding array (Float32Array works with Array.from)
    const fakeVec = new Float32Array([0.123, 0.456, 0.789]);
    return { data: fakeVec };
  };
};

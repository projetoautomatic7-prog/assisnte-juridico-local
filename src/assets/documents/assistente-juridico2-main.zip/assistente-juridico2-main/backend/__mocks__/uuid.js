module.exports = {
  v4: () => 'mock-uuid'
};

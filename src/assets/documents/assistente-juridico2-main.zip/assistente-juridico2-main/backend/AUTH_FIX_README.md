# Admin Login Authentication Fix

## Problem
The login endpoint was hardcoded to only accept `admin`/`admin123` credentials, ignoring the environment variables `ADMIN_USERNAME`, `ADMIN_PASSWORD`, and `ADMIN_PASSWORD_HASH`.

## Solution
The authentication logic has been updated to:
1. Read admin credentials from environment variables (`ADMIN_USERNAME`, `ADMIN_PASSWORD`, `ADMIN_PASSWORD_HASH`)
2. Support both plain password comparison and bcrypt hashed passwords
3. Prioritize bcrypt hash if `ADMIN_PASSWORD_HASH` is set
4. Fallback to plain password if hash is not set
5. Use default credentials (`admin`/`admin123`) if environment variables are not set

## Configuration

### Option 1: Using Plain Password (Not Recommended for Production)
Set only the username and plain password:
```bash
ADMIN_USERNAME=admin
ADMIN_PASSWORD=admin123
```
Leave `ADMIN_PASSWORD_HASH` unset or empty.

### Option 2: Using Bcrypt Hash (Recommended)
Set the username and password hash:
```bash
ADMIN_USERNAME=admin
ADMIN_PASSWORD_HASH=$2b$12$...your-hash-here...
```

To generate a bcrypt hash for your password:
```bash
cd backend
node src/utils/generatePasswordHash.js your-password
```

## Fixing the Current Issue

The environment currently has:
- `ADMIN_USERNAME=admin` ✓
- `ADMIN_PASSWORD=admin123` ✓
- `ADMIN_PASSWORD_HASH=$2b$12$uyxyrv1DDxUL0RQEBySwuul2vV4jPPCRR8/3swAgveLtPTbxO8KDO` ✗ (incorrect hash)

The hash does not match the password `admin123`. To fix this:

### Solution A: Generate Correct Hash (Recommended)
```bash
cd backend
node src/utils/generatePasswordHash.js admin123
```
Then update the `ADMIN_PASSWORD_HASH` environment variable with the generated hash.

### Solution B: Remove the Hash
Simply remove or unset the `ADMIN_PASSWORD_HASH` environment variable. The system will use the plain password from `ADMIN_PASSWORD`.

## Security Notes
- Always use `ADMIN_PASSWORD_HASH` in production environments
- Never commit passwords or hashes to source control
- Bcrypt hashes are one-way and cannot be reversed
- The default salt rounds is set to 12 for good security/performance balance

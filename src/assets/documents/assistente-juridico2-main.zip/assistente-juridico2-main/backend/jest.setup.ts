// Configura variáveis de ambiente mínimas para testes
process.env.API_KEY = process.env.API_KEY || 'test-api-key';
process.env.JWT_SECRET = process.env.JWT_SECRET || 'test-jwt-secret';
process.env.CHROMA_URL = process.env.CHROMA_URL || 'http://localhost:8000';

// In case there are other service env vars expected, provide safe defaults
process.env.DATAJUD_API_KEY = process.env.DATAJUD_API_KEY || 'test-datajud-key';
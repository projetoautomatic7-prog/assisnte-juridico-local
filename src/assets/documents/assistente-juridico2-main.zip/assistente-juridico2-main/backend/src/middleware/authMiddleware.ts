import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

export const authMiddleware = (req: Request, res: Response, next: NextFunction) => {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ message: 'Acesso negado. Nenhum token fornecido.' });
    }

    const token = authHeader.split(' ')[1];
    
    // Check if this is a local auth token
    if (token.startsWith('local_')) {
        try {
            const payload = JSON.parse(atob(token.substring(6)));
            if (payload.type === 'local' && payload.sub) {
                (req as any).user = payload;
                return next();
            }
        } catch (error) {
            console.error('Invalid local token:', error);
            return res.status(401).json({ message: 'Token inválido ou expirado.' });
        }
    }

    // In test environment, allow a fallback secret to keep tests stable
    const jwtSecret = process.env.JWT_SECRET || (process.env.NODE_ENV === 'test' ? 'test-secret' : undefined);

    if (!jwtSecret) {
        console.error("JWT_SECRET não está definido nas variáveis de ambiente.");
        return res.status(500).json({ message: 'Erro de configuração do servidor.' });
    }

    try {
        const decoded = jwt.verify(token, jwtSecret);
        (req as any).user = decoded; // Adiciona os dados do usuário decodificados à requisição
        next();
    } catch (error) {
        return res.status(401).json({ message: 'Token inválido ou expirado.' });
    }
};
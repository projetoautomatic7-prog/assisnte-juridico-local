

import { Server } from 'http';

import { WebSocketServer, WebSocket } from 'ws';

class WebSocketService {
    private wss!: WebSocketServer;
    private clients: Set<WebSocket> = new Set();

    public initialize(): void {
        this.wss = new WebSocketServer({ noServer: true });

        this.wss.on('connection', (ws: WebSocket) => {
            console.log('Frontend conectado via WebSocket (Robot).');
            this.clients.add(ws);

            ws.on('close', () => {
                console.log('Frontend desconectado (Robot).');
                this.clients.delete(ws);
            });
            
            ws.on('error', (error) => {
                console.error('Erro no WebSocket (Robot):', error);
                this.clients.delete(ws);
            });
        });
    }

    public getWss(): WebSocketServer {
        return this.wss;
    }

    public broadcast(type: string, payload: any): void {
        const message = JSON.stringify({ type, payload });
        this.clients.forEach(client => {
            if (client.readyState === WebSocket.OPEN) {
                client.send(message);
            }
        });
    }
}

// Exporta uma instância única (Singleton)
export const webSocketService = new WebSocketService();
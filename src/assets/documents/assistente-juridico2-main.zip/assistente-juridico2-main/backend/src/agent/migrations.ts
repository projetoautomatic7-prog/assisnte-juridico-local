import { Pool } from 'pg';

import { pool } from '../services/db'; // Garante que a pool seja importada

const createTablesQueries = [
    // Tabela para Agentes (já existente)
    `CREATE TABLE IF NOT EXISTS agent_goals (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        title VARCHAR(255) NOT NULL,
        description TEXT,
        department VARCHAR(100),
        priority SMALLINT DEFAULT 3,
        status VARCHAR(50) DEFAULT 'PENDING',
        created_at TIMESTAMPTZ DEFAULT now(),
        updated_at TIMESTAMPTZ DEFAULT now()
    );`,
    `CREATE TABLE IF NOT EXISTS agent_steps (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        goal_id UUID REFERENCES agent_goals(id) ON DELETE CASCADE,
        idx SMALLINT NOT NULL,
        tool VARCHAR(100) NOT NULL,
        input JSONB,
        result JSONB,
        error TEXT,
        status VARCHAR(50) DEFAULT 'PENDING',
        created_at TIMESTAMPTZ DEFAULT now(),
        updated_at TIMESTAMPTZ DEFAULT now()
    );`,
    `CREATE TABLE IF NOT EXISTS agent_tasks (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        type VARCHAR(100) NOT NULL,
        payload JSONB,
        result JSONB,
        status VARCHAR(50) DEFAULT 'QUEUED',
        attempts SMALLINT DEFAULT 0,
        last_error TEXT,
        locked_at TIMESTAMPTZ,
        created_at TIMESTAMPTZ DEFAULT now(),
        updated_at TIMESTAMPTZ DEFAULT now(),
        scheduled_for TIMESTAMPTZ
    );`,
    `CREATE TABLE IF NOT EXISTS agent_events (
        id SERIAL PRIMARY KEY,
        goal_id UUID REFERENCES agent_goals(id) ON DELETE SET NULL,
        step_id UUID REFERENCES agent_steps(id) ON DELETE SET NULL,
        task_id UUID REFERENCES agent_tasks(id) ON DELETE SET NULL,
        level VARCHAR(20) NOT NULL,
        code VARCHAR(50),
        message TEXT NOT NULL,
        data JSONB,
        created_at TIMESTAMPTZ DEFAULT now()
    );`,
    // Novas Tabelas para a Aplicação
    `CREATE TABLE IF NOT EXISTS processos (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        numero_cnj VARCHAR(255) UNIQUE NOT NULL,
        classe_judicial VARCHAR(255),
        assunto TEXT,
        partes JSONB,
        orgao_julgador VARCHAR(255),
        distribuicao_data TIMESTAMPTZ,
        ultimo_movimento JSONB,
        phase VARCHAR(100),
        stage VARCHAR(100),
        value NUMERIC(15, 2),
        probability VARCHAR(50),
        responsible VARCHAR(255),
        is_overdue BOOLEAN DEFAULT false,
        overdue_tasks INT DEFAULT 0,
        has_open_tasks BOOLEAN DEFAULT false,
        timeline_events JSONB,
        created_at TIMESTAMPTZ DEFAULT now(),
        updated_at TIMESTAMPTZ DEFAULT now()
    );`,
    `CREATE TABLE IF NOT EXISTS pessoas (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name VARCHAR(255) NOT NULL,
        contact VARCHAR(255),
        location VARCHAR(255),
        registration_date DATE,
        origin VARCHAR(100),
        age INT,
        profession VARCHAR(100)
    );`,
    `CREATE TABLE IF NOT EXISTS atividades (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        is_urgent BOOLEAN DEFAULT false,
        tarefa TEXT NOT NULL,
        partes TEXT,
        data_compromisso DATE,
        prazo_fatal DATE,
        status VARCHAR(50)
    );`,
    `CREATE TABLE IF NOT EXISTS modelos (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        nome VARCHAR(255) NOT NULL,
        tipo VARCHAR(100),
        data_criacao DATE,
        ultima_edicao DATE,
        conteudo TEXT
    );`,
    `CREATE TABLE IF NOT EXISTS transacoes (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        date DATE NOT NULL,
        processo_cnj VARCHAR(255),
        description TEXT NOT NULL,
        amount NUMERIC(15, 2) NOT NULL,
        type VARCHAR(20) NOT NULL,
        status VARCHAR(50) NOT NULL,
        attachment JSONB,
        created_at TIMESTAMPTZ DEFAULT now(),
        updated_at TIMESTAMPTZ DEFAULT now()
    );`,
    `CREATE TABLE IF NOT EXISTS audiencias (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        processo_cnj VARCHAR(255) NOT NULL,
        data_hora TIMESTAMPTZ NOT NULL,
        local TEXT,
        tipo VARCHAR(255),
        partes JSONB,
        status VARCHAR(50),
        google_calendar_status VARCHAR(50) DEFAULT 'pending',
        classe_judicial VARCHAR(255),
        orgao_julgador VARCHAR(255),
        advogado_responsavel VARCHAR(255)
    );`,
    `CREATE TABLE IF NOT EXISTS compromissos (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        title TEXT NOT NULL,
        assigned_to VARCHAR(255),
        relative_date VARCHAR(100),
        is_urgent BOOLEAN DEFAULT false
    );`,
    `CREATE TABLE IF NOT EXISTS push_subscriptions (
        id SERIAL PRIMARY KEY,
        subscription JSONB NOT NULL,
        user_id VARCHAR(255),
        created_at TIMESTAMPTZ DEFAULT now()
    );`,
    // Tabelas para CRM - Gestão Visual de Processos
    `CREATE TABLE IF NOT EXISTS crm_cards (
        id VARCHAR(255) PRIMARY KEY,
        processo_id UUID REFERENCES processos(id) ON DELETE CASCADE,
        cnj VARCHAR(255),
        titulo VARCHAR(500),
        partes JSONB,
        fase VARCHAR(50),
        estagio VARCHAR(100),
        prazos JSONB,
        status VARCHAR(50) DEFAULT 'novo',
        valor NUMERIC(15, 2),
        minutas TEXT[],
        anotacoes TEXT,
        responsavel VARCHAR(255),
        auto_automacoes JSONB,
        data_criacao TIMESTAMPTZ DEFAULT NOW(),
        data_ultima_atualizacao TIMESTAMPTZ DEFAULT NOW()
    );`,
    `CREATE INDEX IF NOT EXISTS idx_crm_cards_fase ON crm_cards(fase);`,
    `CREATE INDEX IF NOT EXISTS idx_crm_cards_status ON crm_cards(status);`,
    `CREATE INDEX IF NOT EXISTS idx_crm_cards_cnj ON crm_cards(cnj);`,
    // Tabelas para RAG - Recuperação Aumentada por Geração
    `CREATE TABLE IF NOT EXISTS rag_documents (
        id VARCHAR(255) PRIMARY KEY,
        content TEXT,
        document_type VARCHAR(50),
        source_url VARCHAR(500),
        embedding_id VARCHAR(255),
        metadata JSONB,
        data_indexacao TIMESTAMPTZ DEFAULT NOW(),
        data_atualizacao TIMESTAMPTZ DEFAULT NOW()
    );`,
    `CREATE INDEX IF NOT EXISTS idx_rag_document_type ON rag_documents(document_type);`,
    `CREATE INDEX IF NOT EXISTS idx_rag_embedding_id ON rag_documents(embedding_id);`,
    // Tabelas para Integrações DJEN e DataJud
    `CREATE TABLE IF NOT EXISTS djen_publications (
        id VARCHAR(255) PRIMARY KEY,
        dje VARCHAR(50),
        publication_date DATE,
        content TEXT,
        parsed_data JSONB,
        advogados TEXT[],
        oabs TEXT[],
        cnj VARCHAR(255),
        processed BOOLEAN DEFAULT false,
        data_criacao TIMESTAMPTZ DEFAULT NOW()
    );`,
    `CREATE INDEX IF NOT EXISTS idx_djen_cnj ON djen_publications(cnj);`,
    `CREATE INDEX IF NOT EXISTS idx_djen_publication_date ON djen_publications(publication_date);`,
    `CREATE TABLE IF NOT EXISTS datajud_cache (
        key VARCHAR(255) PRIMARY KEY,
        cnj VARCHAR(255),
        tribunal VARCHAR(100),
        data JSONB,
        expires_at TIMESTAMPTZ,
        data_criacao TIMESTAMPTZ DEFAULT NOW()
    );`,
    `CREATE INDEX IF NOT EXISTS idx_datajud_cnj ON datajud_cache(cnj);`,
    `CREATE INDEX IF NOT EXISTS idx_datajud_expires ON datajud_cache(expires_at);`,
    // Dead Letter Queue (DLQ) para tarefas do agente
    `CREATE TABLE IF NOT EXISTS agent_tasks_dlq (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        task_id UUID NOT NULL UNIQUE REFERENCES agent_tasks(id) ON DELETE CASCADE,
        type VARCHAR(255) NOT NULL,
        payload JSONB NOT NULL,
        reason TEXT NOT NULL,
        attempts INT DEFAULT 0,
        created_at TIMESTAMPTZ DEFAULT NOW(),
        retry_count INT DEFAULT 0,
        last_error TEXT,
        created_at_original TIMESTAMPTZ
    );`,
    `CREATE INDEX IF NOT EXISTS idx_dlq_created_at ON agent_tasks_dlq(created_at DESC);`,
    `CREATE INDEX IF NOT EXISTS idx_dlq_type ON agent_tasks_dlq(type);`,
    `CREATE INDEX IF NOT EXISTS idx_dlq_retry_count ON agent_tasks_dlq(retry_count);`,
    // Tabelas para Automações com IA
    `CREATE TABLE IF NOT EXISTS ai_automations (
        id VARCHAR(255) PRIMARY KEY,
        card_id VARCHAR(255) REFERENCES crm_cards(id) ON DELETE CASCADE,
        automation_type VARCHAR(50),
        prompt TEXT,
        response TEXT,
        status VARCHAR(50) DEFAULT 'pending',
        retry_count INT DEFAULT 0,
        max_retries INT DEFAULT 3,
        data_criacao TIMESTAMPTZ DEFAULT NOW(),
        data_atualizacao TIMESTAMPTZ DEFAULT NOW()
    );`,
    `CREATE INDEX IF NOT EXISTS idx_ai_automations_status ON ai_automations(status);`,
    `CREATE INDEX IF NOT EXISTS idx_ai_automations_card ON ai_automations(card_id);`,
    // Tabela de Audit Log para Integrações
    `CREATE TABLE IF NOT EXISTS integration_audit_log (
        id VARCHAR(255) PRIMARY KEY,
        service_name VARCHAR(100),
        operation VARCHAR(100),
        status VARCHAR(50),
        request_data JSONB,
        response_data JSONB,
        error_message TEXT,
        execution_time_ms INT,
        data_criacao TIMESTAMPTZ DEFAULT NOW()
    );`,
    `CREATE INDEX IF NOT EXISTS idx_integration_service ON integration_audit_log(service_name);`,
    `CREATE INDEX IF NOT EXISTS idx_integration_status ON integration_audit_log(status);`
];

export const initializeDatabase = async () => {
    const client = await pool.connect();
    try {
        for (const query of createTablesQueries) {
            await client.query(query);
        }
        console.log('✅ Todas as tabelas foram criadas com sucesso');
    } catch (error) {
        console.error('❌ Erro ao criar tabelas:', error);
        throw error;
    } finally {
        client.release();
    }
};
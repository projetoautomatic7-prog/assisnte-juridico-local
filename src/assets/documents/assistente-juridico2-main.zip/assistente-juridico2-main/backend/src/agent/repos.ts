import { Pool } from 'pg';
import pino from 'pino';

import { pool } from '../services/db';
import { validateTaskPayload } from './taskSchemas';
import { webSocketService } from '../websocketService';
const log = pino({ name:'AgentRepos' });

export class GoalRepo {
  constructor(private pool:Pool){}
  async create(g:any){
    const r = await this.pool.query(
      'INSERT INTO agent_goals (title, description, department, priority) VALUES ($1,$2,$3,$4) RETURNING *',
      [g.title, g.description, g.department, g.priority ?? 3]
    );
    return r.rows[0];
  }
  get(id:string){ return this.pool.query('SELECT * FROM agent_goals WHERE id=$1',[id]).then(r=>r.rows[0]); }
  listAll(){ return this.pool.query('SELECT * FROM agent_goals ORDER BY created_at DESC LIMIT 50').then(r=>r.rows); }
  updateStatus(id:string, st:string){ return this.pool.query('UPDATE agent_goals SET status=$2, updated_at=now() WHERE id=$1',[id,st]); }
  
  getRecentEvents(hours: number = 24){
    return this.pool.query(
      `SELECT * FROM agent_events 
       WHERE created_at >= now() - interval '${hours} hours' 
       ORDER BY created_at DESC`
    ).then(r=>r.rows);
  }
}

export class StepRepo {
  constructor(private pool:Pool){}
  bulkInsert(goalId:string, plan:any[]){
    if (plan.length === 0) return Promise.resolve();
    const values = plan.map(p=>`('${goalId}',${p.idx},'${p.tool.replace(/'/g,"''")}', '${JSON.stringify(p.input).replace(/'/g,"''")}')`).join(',');
    return this.pool.query(
      `INSERT INTO agent_steps (goal_id, idx, tool, input) VALUES ${values} RETURNING *`
    );
  }
  listByGoal(goalId:string){ return this.pool.query('SELECT * FROM agent_steps WHERE goal_id=$1 ORDER BY idx ASC',[goalId]).then(r=>r.rows); }
  async done(id:string, result:any){ await this.pool.query('UPDATE agent_steps SET status=$1, result=$2, updated_at=now() WHERE id=$3',['DONE',result,id]); }
  async fail(id:string, err:string){ await this.pool.query('UPDATE agent_steps SET status=$1, error=$2, updated_at=now() WHERE id=$3',['FAILED',err,id]); }
}

export class TaskRepo {
  constructor(private pool:Pool){}
  
  async queue(type:string, payload:any, when:Date|null=null){
    // Use helper validateTaskPayload to validate payloads per schema when available.
    // This centralizes Zod handling and returns normalized payload with defaults.
    const validation = validateTaskPayload(type, payload);
    if (!validation.success) {
      // Log and fail fast without inserting into DB
      const err = validation.error!; // ensure non-null for TS (we are in !success branch)
      log.warn({ type, payload, issues: err.issues?.length ?? 0 }, 'Payload inválido detectado durante validação de task');
      // Compose user-friendly message similar to previous behaviour for tests compatibility
      const reason = err.issues?.map((i:any) => i.message).join(', ');
      throw new Error(`Payload inválido para ${type}: ${reason}`);
    }
    const normalizedPayload = validation.data;
  
    return this.pool.query(
      'INSERT INTO agent_tasks (type, payload, scheduled_for) VALUES ($1,$2,$3) RETURNING *',
      [type, normalizedPayload, when]
    ).then(r=>r.rows[0]);
  }
  
    // No-op here (migrated to async nextDue below)
  async nextDue(){
    // Busca e bloqueia o próximo job atômicamente para evitar race conditions entre workers
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const r = await client.query(
        `SELECT * FROM agent_tasks
         WHERE status='QUEUED' AND (locked_at IS NULL OR locked_at < NOW() - INTERVAL '5 minutes') AND (scheduled_for IS NULL OR scheduled_for <= now())
         ORDER BY created_at ASC LIMIT 1 FOR UPDATE SKIP LOCKED`
        , []
      );
      const job = r.rows[0];
      if (!job) {
        await client.query('COMMIT');
        return null;
      }
      // Marca um lease temporário na fila para impedir que outro worker pegue o mesmo job
      await client.query('UPDATE agent_tasks SET locked_at = now() WHERE id = $1', [job.id]);
      await client.query('COMMIT');
      return job;
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  }
  listAll(){ return this.pool.query('SELECT * FROM agent_tasks ORDER BY created_at DESC LIMIT 100').then(r=>r.rows); }
  markRunning(id:string){ return this.pool.query('UPDATE agent_tasks SET status=$1, attempts = attempts + 1, updated_at=now() WHERE id=$2',['RUNNING',id]); }
  markDone(id:string, result: any){ 
    return this.pool.query(
        'UPDATE agent_tasks SET status=$1, result=$2, last_error=NULL, updated_at=now(), locked_at=NULL WHERE id=$3',
        ['DONE', result ? JSON.stringify(result) : null, id]
    );
  }
  markFailed(id:string, err:string, attempts:number, nextStatus: 'QUEUED' | 'FAILED' = 'FAILED', backoffMs?: number){
      const nextScheduledFor = backoffMs ? new Date(Date.now() + backoffMs) : null;
      return this.pool.query(
          `UPDATE agent_tasks 
           SET status=$1, last_error=$2, attempts=$3, scheduled_for=$4, updated_at=now(), locked_at=NULL 
           WHERE id=$5`,
          [nextStatus, err, attempts, nextScheduledFor, id]
      );
  }
  lock(id: string) {
    log.info({ taskId: id }, "Locking task for human editing.");
    return this.pool.query("UPDATE agent_tasks SET locked_at = now() WHERE id = $1", [id]);
  }
  unlock(id: string) {
    log.info({ taskId: id }, "Unlocking task after human editing.");
    return this.pool.query("UPDATE agent_tasks SET locked_at = NULL WHERE id = $1", [id]);
  }
  updatePayload(id: string, payload: any) {
    log.info({ taskId: id }, "Updating task payload with human edits.");
    return this.pool.query("UPDATE agent_tasks SET payload = $1, updated_at=now() WHERE id = $2", [payload, id]);
  }
  async resetStuckRunning() {
    const res = await this.pool.query(
      `UPDATE agent_tasks SET status = 'QUEUED', last_error = 'Reset from stuck RUNNING state', locked_at = NULL
       WHERE status = 'RUNNING' AND updated_at < now() - interval '5 minutes'`
    );
    if (res.rowCount && res.rowCount > 0) {
      log.warn({ count: res.rowCount }, "Reset stuck RUNNING tasks to QUEUED.");
    }
  }
}

export class EventBus {
  constructor(private pool:Pool, private ws: typeof webSocketService){}
  emit(e:{level:string, code:string, message:string, data?:any, goalId?:string, stepId?:string, taskId?:string}){
    // Persist to DB
    this.pool.query(
      'INSERT INTO agent_events (goal_id, step_id, task_id, level, code, message, data) VALUES ($1,$2,$3,$4,$5,$6,$7)',
      [e.goalId || null, e.stepId || null, e.taskId || null, e.level, e.code, e.message, e.data || null]
    );
    // Broadcast to frontend clients via WebSocket
    this.ws.broadcast('agent_event', e);
  }
}

// Export singleton instance
export const taskRepo = new TaskRepo(pool);
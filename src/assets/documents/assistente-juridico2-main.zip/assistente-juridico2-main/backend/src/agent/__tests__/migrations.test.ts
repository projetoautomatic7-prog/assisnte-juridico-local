import { jest, describe, it, expect, beforeEach, afterEach } from '@jest/globals';

// We'll spy on pool.connect within the tests for more predictable typing and control

import { initializeDatabase } from '../migrations';
import { pool } from '../../services/db';

describe('initializeDatabase', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should call client.query for each migration SQL', async () => {
    const mockClient: any = { query: jest.fn(), release: jest.fn() };
    jest.spyOn(pool as any, 'connect').mockResolvedValue(mockClient);
    (mockClient.query as any).mockResolvedValue({} as any);

    await initializeDatabase();

    // Expect the create tables to be executed at least once
    expect(mockClient.query).toHaveBeenCalled();

    // Ensure agent_tasks_dlq is part of the executed SQL
    const calledWith = (mockClient.query as jest.Mock).mock.calls.map((c: any) => c[0]).join('\n');
    expect(calledWith).toMatch(/CREATE TABLE IF NOT EXISTS agent_tasks_dlq/);

    // release should be called
    expect(mockClient.release).toHaveBeenCalled();
  });

  it('should throw if a query fails and rollback', async () => {
    const mockClient: any = { query: jest.fn(), release: jest.fn() };
    jest.spyOn(pool as any, 'connect').mockResolvedValue(mockClient);

    (mockClient.query as any).mockImplementation((sql: string) => {
      if (/CREATE TABLE IF NOT EXISTS agent_goals/.test(sql)) {
        return Promise.reject(new Error('fail create table'));
      }
      return Promise.resolve({} as any);
    });

    await expect(initializeDatabase()).rejects.toThrow('fail create table');

    expect(mockClient.release).toHaveBeenCalled();
  });
});

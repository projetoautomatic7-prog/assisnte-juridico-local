import pino from 'pino';

import { GoalRepo, StepRepo, TaskRepo, EventBus } from './repos';
import { ToolRegistry } from './tools';

const log = pino({ name: 'AgentKernel' });

export class AgentKernel {
    constructor(
        private goalRepo: GoalRepo,
        private stepRepo: StepRepo,
        private taskRepo: TaskRepo,
        private tools: ToolRegistry,
        private eventBus: EventBus
    ) {}

    async createGoal(goalData: any, ctx: any) {
        log.info({ goalData }, 'Creating new goal');
        const goal = await this.goalRepo.create(goalData);
        await this.eventBus.emit({
            level: 'INFO',
            code: 'GOAL.CREATED',
            message: `Goal created: ${goal.title}`,
            goalId: goal.id
        });
        return goal;
    }

    async planAndRunGoal(goalId: string, ctx: any) {
        try {
            log.info({ goalId }, 'Planning and running goal');
            
            // Update goal status to planning
            await this.goalRepo.updateStatus(goalId, 'PLANNING');
            
            await this.eventBus.emit({
                level: 'INFO',
                code: 'GOAL.PLANNING',
                message: 'Starting goal planning',
                goalId
            });

            // Get the goal details
            const goal = await this.goalRepo.get(goalId);
            if (!goal) {
                throw new Error('Goal not found');
            }

            // Create a task for the goal
            await this.taskRepo.queue('EXECUTE_GOAL', {
                goalId,
                description: goal.description
            });

            // Update goal status to running
            await this.goalRepo.updateStatus(goalId, 'RUNNING');

            await this.eventBus.emit({
                level: 'INFO',
                code: 'GOAL.RUNNING',
                message: 'Goal execution started',
                goalId
            });

        } catch (error: any) {
            log.error({ goalId, error: error.message }, 'Error planning/running goal');
            await this.goalRepo.updateStatus(goalId, 'FAILED');
            await this.eventBus.emit({
                level: 'ERROR',
                code: 'GOAL.ERROR',
                message: `Goal execution failed: ${error.message}`,
                goalId
            });
        }
    }
}

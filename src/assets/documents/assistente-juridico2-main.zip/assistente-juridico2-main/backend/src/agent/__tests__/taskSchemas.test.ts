import { describe, it, expect } from '@jest/globals';
import { validateTaskPayload, schemas } from '../taskSchemas';

describe('taskSchemas validation', () => {
  it('validates EXECUTE_GOAL with correct payload', () => {
    const payload = { goalId: '550e8400-e29b-41d4-a716-446655440000', description: 'Run a short goal' };
    const res = validateTaskPayload('EXECUTE_GOAL', payload);
    expect(res.success).toBe(true);
    expect(res.data.goalId).toBe(payload.goalId);
  });

  it('rejects EXECUTE_GOAL with invalid goalId', () => {
    const payload = { goalId: 'not-uuid' };
    const res = validateTaskPayload('EXECUTE_GOAL', payload);
    expect(res.success).toBe(false);
    if (!res.success) {
      const err = res.error!;
      expect(err.issues?.[0]?.message).toBeDefined();
    }
  });

  it('validates ANALISE_DJEN with required fields', () => {
    const payload = { date: '2025-11-15', tribunals: ['TJMG'], terms: ['prazo'] };
    const res = validateTaskPayload('ANALISE_DJEN', payload);
    expect(res.success).toBe(true);
  });

  it('rejects ANALISE_DJEN missing terms', () => {
    const payload = { date: '2025-11-15', tribunals: ['TJMG'] } as any;
    const res = validateTaskPayload('ANALISE_DJEN', payload);
    expect(res.success).toBe(false);
    if (!res.success) {
      const err = res.error!;
      // assert that there's at least one validation issue (message text can vary)
      expect(err.issues?.length).toBeGreaterThan(0);
    }
  });

  it('passes unknown type without schema', () => {
    const payload = { arbitrary: 'value' };
    const res = validateTaskPayload('UNKNOWN_TYPE', payload);
    expect(res.success).toBe(true);
  });
});

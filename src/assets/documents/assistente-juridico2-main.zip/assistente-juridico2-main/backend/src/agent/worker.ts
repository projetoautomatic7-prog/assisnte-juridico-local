import pino from 'pino';

import { CircuitBreaker } from './circuitBreaker';
import { DeadLetterQueue } from './deadLetterQueue';
import { TaskRepo, EventBus } from './repos';
import { ToolRegistry } from './tools';


const log = pino({ name:'AgentWorker' });

const TASK_TIMEOUT_MS = 30000; // 30 segundos - Timeout Global
const CIRCUIT_BREAKER_THRESHOLD = 5; // Falhas antes de abrir
const CIRCUIT_BREAKER_TIMEOUT_MS = 60000; // 1 minuto para tentar reset

export async function startWorkerLoop(taskRepo: TaskRepo, tools: ToolRegistry, events: EventBus, ctx: any, dlq?: DeadLetterQueue) {
  const BACKOFFS = [1000, 5000, 15000, 30000]; // ms
  const circuitBreaker = new CircuitBreaker(CIRCUIT_BREAKER_THRESHOLD, CIRCUIT_BREAKER_TIMEOUT_MS, TASK_TIMEOUT_MS);
  
  async function processJob(job: any, toolName: string) {
    await events.emit({ level:'INFO', code:'TASK.START', message: `Iniciando tarefa: ${job.type}`, taskId: job.id });
    
    const tool = tools.get(toolName);
    if (!tool) {
        throw new Error(`Ferramenta não encontrada para a tarefa: ${toolName}`);
    }

    // ✅ SOLUÇÃO 1: Timeout Global (30s) com Promise.race()
    const result = await Promise.race([
      circuitBreaker.execute(
        () => tool.execute(job.payload, ctx),
        `tool-${toolName}`
      ),
      new Promise<never>((_, reject) =>
        setTimeout(
          () => reject(new Error(`Task timeout após ${TASK_TIMEOUT_MS}ms`)),
          TASK_TIMEOUT_MS
        )
      ),
    ]);

    await taskRepo.markDone(job.id, result);
    await events.emit({ level:'INFO', code:'TASK.DONE', message: `Tarefa '${job.type}' concluída.`, taskId: job.id, data: { result } });
  }

  async function once() {
    const job = await taskRepo.nextDue();
    if (!job) return; // Fila vazia, espera para a próxima verificação

    await taskRepo.markRunning(job.id);
    
    let toolName: string | null = null;
    try {
      // Mapear tipo de tarefa para nome da ferramenta
      switch(job.type) {
          case 'HEALTH_CHECK':
              toolName = 'it.healthCheck';
              break;
          case 'DAILY_EXECUTIVE_SUMMARY':
              toolName = 'management.dailySummary';
              break;
          case 'DAILY_CHECK_EXPEDIENTES':
              toolName = 'robot.pjeConsultar';
              break;
          case 'LEGAL_DRAFT_FROM_EXPEDIENTE':
              toolName = 'legal.draftFromExpediente';
              break;
          case 'ANALISE_DJEN':
              toolName = 'djen.analyze';
              break;
          default:
              throw new Error(`Tipo de tarefa desconhecido: ${job.type}`);
      }

      await processJob(job, toolName);
    } catch (e:any) {
      const attempts = (job.attempts ?? 0) + 1;
      const willRetry = attempts < BACKOFFS.length;
      const backoff = BACKOFFS[attempts - 1];
      const errorMessage = e?.message || String(e);

      log.error({ 
        taskId: job.id, 
        type: job.type, 
        tool: toolName,
        error: errorMessage, 
        attempts,
        circuitBreakerStatus: toolName ? circuitBreaker.getStatus(`tool-${toolName}`) : 'N/A'
      }, 'Task execution failed');

      if (willRetry) {
        // ✅ RETRY: Marca como QUEUED para próxima tentativa
        const status = 'QUEUED';
        await taskRepo.markFailed(job.id, errorMessage, attempts, status, backoff);
        log.info({ taskId: job.id, type: job.type, nextAttempt: attempts + 1, backoffMs: backoff }, 'Task queued for retry');
      } else {
        // ✅ SOLUÇÃO 2: Dead Letter Queue (DLQ) para falhas permanentes
        const status = 'FAILED';
        await taskRepo.markFailed(job.id, errorMessage, attempts, status);
        
        if (dlq) {
          await dlq.send(job.id, job.type, job.payload, `Max retries exceeded: ${errorMessage}`, attempts, errorMessage);
          log.warn({ taskId: job.id, type: job.type, attempts }, 'Task sent to Dead Letter Queue');
        }
      }

      await events.emit({ 
        level:'ERROR', 
        code:'TASK.ERROR', 
        message: `Erro na tarefa '${job.type}': ${errorMessage}${willRetry ? ` (tentativa ${attempts}/${BACKOFFS.length})` : ' (FALHA PERMANENTE)'}`, 
        taskId: job.id, 
        data: { error: errorMessage, attempts, willRetry } 
      });
    }
  }
  
  // Reset de tarefas que estavam RUNNING em crash anterior
  try {
      await taskRepo.resetStuckRunning?.();
  } catch (e) {
      log.warn({ err: (e as Error).message }, 'Falha ao resetar tarefas RUNNING antigas');
  }

  // ✅ SOLUÇÃO 3: Circuit Breaker Status Log (para monitoramento)
  setInterval(() => {
    const tools_list = ['it.healthCheck', 'management.dailySummary', 'robot.pjeConsultar', 'legal.draftFromExpediente', 'djen.analyze'];
    const statuses = tools_list.map(tool => ({
      tool,
      status: circuitBreaker.getStatus(`tool-${tool}`)
    }));
    log.debug({ circuitBreakerStatuses: statuses }, 'Circuit Breaker health check');
  }, 60000); // A cada 1 minuto

  // Inicia o loop do worker
  log.info(`Worker iniciado com timeout=${TASK_TIMEOUT_MS}ms, CB_threshold=${CIRCUIT_BREAKER_THRESHOLD}, DLQ=${dlq ? 'enabled' : 'disabled'}`);
  setInterval(once, 3000); // Verifica a fila a cada 3 segundos
}
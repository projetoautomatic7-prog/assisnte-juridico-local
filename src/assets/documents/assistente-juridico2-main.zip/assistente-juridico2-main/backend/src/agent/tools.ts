import { Type } from '@google/genai';
import { z } from 'zod';

import { runAnaliseDjen } from '../agents/analise-djen';
import { pool } from '../services/db';
import { geminiService } from '../services/geminiService';
import { vectorStoreService } from '../services/vectorStoreService';
import { Expediente } from '../types';

import { GoalRepo } from './repos';

export interface AgentTool {
    name: string;
    description: string;
    inputSchema: z.ZodObject<any>;
    execute: (input: any, context: any) => Promise<any>;
}

export class ToolRegistry {
    private tools: Map<string, AgentTool> = new Map();
    register(tool: AgentTool) {
        this.tools.set(tool.name, tool);
    }
    get(name: string): AgentTool | undefined {
        return this.tools.get(name);
    }
    list(): AgentTool[] {
        return Array.from(this.tools.values());
    }
}

export const itHealthCheck: AgentTool = {
    name: 'it.healthCheck',
    description: 'Verifica a saúde dos sistemas de TI.',
    inputSchema: z.object({}),
    execute: async () => ({ status: 'ok', services: ['pje', 'gemini', 'db'] }),
};

export const driveOrganizeProcessFolder: AgentTool = {
    name: 'drive.organizeProcessFolder',
    description: 'Organiza a pasta de um processo no Google Drive.',
    inputSchema: z.object({ cnj: z.string() }),
    execute: async () => ({ success: true, folderId: 'mock-folder-id' }),
};

export const robotPjeConsultar: AgentTool = {
    name: 'robot.pjeConsultar',
    description: 'Consulta o PJe para novos expedientes.',
    inputSchema: z.object({}),
    execute: async () => ({ new_expedientes: 2 }),
};

export const financeCobrarWhats: AgentTool = {
    name: 'finance.cobrarWhats',
    description: 'Envia uma cobrança via WhatsApp.',
    inputSchema: z.object({ cnj: z.string(), valor: z.number() }),
    execute: async () => ({ success: true, messageId: 'mock-msg-id' }),
};

export const prazoDetect: AgentTool = {
    name: 'prazo.detect',
    description: 'Detecta prazos em um texto de expediente.',
    inputSchema: z.object({ texto: z.string() }),
    execute: async () => ({ prazo_dias: 15, tipo: 'úteis' }),
};

export const memorySearchKnowledgeBase: AgentTool = {
    name: 'memory.searchKnowledgeBase',
    description: 'Busca na base de conhecimento.',
    inputSchema: z.object({ query: z.string() }),
    execute: async (input) => ({ results: await vectorStoreService.search(input.query, 3) }),
};

export const managementDailySummary: AgentTool = {
    name: 'management.dailySummary',
    description: 'Gera um resumo executivo diário.',
    inputSchema: z.object({ date: z.string().optional() }),
    execute: async () => {
        const events = await new GoalRepo(pool).getRecentEvents(24);
        const prompt = `Gere um resumo executivo para o gestor com base nos seguintes eventos do agente de IA das últimas 24 horas:\n${JSON.stringify(events, null, 2)}`;
        const summary = await geminiService.generateText(prompt);
        return { summary };
    },
};

const LegalAnalysisSchema = z.object({
    prazo: z.string(),
    resumo: z.string(),
    classificacao_acao: z.enum(['SIMPLE_REPLY', 'DRAFT_RESPONSE', 'HUMAN_REVIEW']),
    documentos_necessarios: z.array(z.string()).default([]),
});

export const legalDraftFromExpediente: AgentTool = {
    name: 'legal.draftFromExpediente',
    description: 'Analisa um expediente do PJe, classifica a ação e redige uma minuta se necessário.',
    inputSchema: z.object({
        notification: z.any(),
        human_draft: z.string().optional(),
    }),
    execute: async (input) => {
        const { notification, human_draft } = input;
        const prompt = `Você é um assistente jurídico sênior especialista em PJe. Analise o expediente abaixo.
        1. Extraia o prazo em dias e o tipo (ex: "15 dias úteis"). Se não houver, retorne "N/A".
        2. Crie um resumo jurídico de uma frase.
        3. Determine a próxima ação e classifique-a como: 'SIMPLE_REPLY', 'DRAFT_RESPONSE', ou 'HUMAN_REVIEW'.
        4. Identifique se algum documento é necessário. Se sim, liste-os.
        Expediente: "${notification.originalContent}"`;

        const legalAnalysisJsonSchema = {
            type: Type.OBJECT,
            properties: {
                prazo: { type: Type.STRING },
                resumo: { type: Type.STRING },
                classificacao_acao: { type: Type.STRING },
                documentos_necessarios: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["prazo", "resumo", "classificacao_acao"]
        };
        const analysisJsonString = await geminiService.generateJson(prompt, legalAnalysisJsonSchema);
        if (!analysisJsonString) {
            throw new Error('Failed to generate analysis JSON');
        }
        const analysisResult = LegalAnalysisSchema.safeParse(JSON.parse(analysisJsonString));

        if (!analysisResult.success || !analysisResult.data) {
            throw new Error(`Falha na análise da IA: ${analysisResult.error?.issues.map(i => i.message).join(', ')}`);
        }
        const analysis = analysisResult.data;

        let finalDraft: string | null = null;
        let finalStatus: Expediente['status'] = 'human_review';

        if (analysis.classificacao_acao === 'DRAFT_RESPONSE') {
            const draftPrompt = human_draft
                ? `Continue o rascunho a seguir: "${human_draft}". Expediente original: "${notification.originalContent}"`
                : `Com base no expediente "${notification.originalContent}", redija uma minuta de petição para a seguinte ação: ${analysis.resumo}. Seja técnico e objetivo.`;
            const draftResult = await geminiService.generateText(draftPrompt);
            finalDraft = draftResult || null;
            finalStatus = 'human_review';
        } else {
            finalStatus = analysis.classificacao_acao === 'SIMPLE_REPLY' ? 'no_action_needed' : 'human_review';
        }
        
        if (analysis.documentos_necessarios.length > 0) {
            finalStatus = 'awaiting_documents';
        }

        const ai_completed_tasks_list = ["Análise inicial do expediente", "Classificação da ação"];
        if (finalDraft) ai_completed_tasks_list.push("Geração da minuta");
        
        const human_tasks_list = analysis.documentos_necessarios.map(doc => `Anexar: ${doc}`);
        if (finalStatus === 'human_review' && finalDraft) human_tasks_list.push("Revisar e aprovar a minuta.");
        
        return {
            ...notification,
            ai_summary: analysis.resumo,
            prazo_dias: analysis.prazo,
            status: finalStatus,
            required_documents: analysis.documentos_necessarios,
            ai_drafted_document: finalDraft ? { name: `Minuta - ${notification.cnj}.txt`, content: finalDraft } : undefined,
            tasks_total: ai_completed_tasks_list.length + human_tasks_list.length,
            tasks_completed_by_ai: ai_completed_tasks_list.length,
            tasks_pending_human: human_tasks_list.length,
            ai_completed_tasks_list,
            human_tasks_list,
        };
    },
};

export const djenAnalyze: AgentTool = {
    name: 'djen.analyze',
    description: 'Analisa publicações do DJEN para uma data, tribunais e termos, gerando um resumo com IA.',
    inputSchema: z.object({
        date: z.string(),
        tribunals: z.array(z.string()),
        terms: z.array(z.string())
    }),
    execute: async (input) => {
        const result = await runAnaliseDjen({ params: input });
        if (!result.ok) throw new Error(result.error || 'Erro no agente AnaliseDjen');
        return result.data;
    },
};
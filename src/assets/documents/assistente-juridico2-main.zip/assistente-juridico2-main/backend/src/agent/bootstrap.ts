import { ToolRegistry } from './tools';
import { driveOrganizeProcessFolder, robotPjeConsultar, financeCobrarWhats, prazoDetect, itHealthCheck, memorySearchKnowledgeBase, managementDailySummary, legalDraftFromExpediente, djenAnalyze } from './tools';

export function buildToolRegistry() {
  const reg = new ToolRegistry();
  
  // Register initial tools
  reg.register(itHealthCheck);
  reg.register(driveOrganizeProcessFolder);
  reg.register(robotPjeConsultar);
  reg.register(financeCobrarWhats);
  reg.register(prazoDetect);
  reg.register(memorySearchKnowledgeBase); // Register the new memory tool
  reg.register(managementDailySummary); // Register the new daily summary tool
  reg.register(legalDraftFromExpediente); // Register the new drafting tool
  reg.register(djenAnalyze); // Register the new DJEN analysis tool

  // ... adicione outras ferramentas de TI, RH, Marketing etc. aqui
  return reg;
}

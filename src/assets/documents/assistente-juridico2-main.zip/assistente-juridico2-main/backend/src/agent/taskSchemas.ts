import { z } from 'zod';

/**
 * Schemas por tipo de task. Validação executada em TaskRepo.queue antes de enfileirar.
 * Adicione novos schemas conforme necessário para garantir integridade dos payloads.
 */
export const schemas: Record<string, z.ZodSchema<any>> = {
  EXECUTE_GOAL: z.object({
    goalId: z.string().uuid(),
    description: z.string().optional(),
    user: z.object({ id: z.string().optional() }).optional(),
  }),
  
  ANALISE_DJEN: z.object({
    date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    tribunals: z.array(z.string()).min(1),
    terms: z.array(z.string()).min(1),
  }),
  
  FINANCE_COBRAR_WHATS: z.object({
    cnj: z.string(),
    valor: z.number().positive(),
  }),

  HEALTH_CHECK: z.object({}),
  
  DAILY_EXECUTIVE_SUMMARY: z.object({
    date: z.string().optional(),
  }),

  LEGAL_DRAFT_FROM_EXPEDIENTE: z.object({
    notification: z.any(),
    human_draft: z.string().optional(),
  }),
};

/**
 * Helper para validar payload de task usando Zod schemas.
 * Retorna { success: true, data } se válido ou { success: false, error } se inválido.
 */
export function validateTaskPayload(type: string, payload: any) {
  const schema = schemas[type];
  if (!schema) return { success: true, data: payload };
  
  const result = schema.safeParse(payload);
  if (result.success) return { success: true, data: result.data };
  
  return { success: false, error: result.error };
}

// Alias compatível com imports existentes
export { schemas as taskSchemas };
export interface DeadLetterTask {
  id: string;
  task_id: string;
  type: string;
  payload: any;
  reason: string;
  attempts: number;
  created_at: Date;
  retry_count: number;
  last_error: string;
}

export class DeadLetterQueue {
  constructor(private pool: any) {}

  async create(tables: any) {
    await this.pool.query(`
      CREATE TABLE IF NOT EXISTS agent_tasks_dlq (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        task_id UUID NOT NULL UNIQUE REFERENCES agent_tasks(id) ON DELETE CASCADE,
        type VARCHAR(255) NOT NULL,
        payload JSONB NOT NULL,
        reason TEXT NOT NULL,
        attempts INT DEFAULT 0,
        created_at TIMESTAMPTZ DEFAULT NOW(),
        retry_count INT DEFAULT 0,
        last_error TEXT,
        created_at_original TIMESTAMPTZ
      );
      
      CREATE INDEX IF NOT EXISTS idx_dlq_created_at ON agent_tasks_dlq(created_at DESC);
      CREATE INDEX IF NOT EXISTS idx_dlq_type ON agent_tasks_dlq(type);
      CREATE INDEX IF NOT EXISTS idx_dlq_retry_count ON agent_tasks_dlq(retry_count);
    `);
  }

  async send(
    taskId: string,
    type: string,
    payload: any,
    reason: string,
    attempts: number,
    lastError: string
  ): Promise<void> {
    await this.pool.query(
      `INSERT INTO agent_tasks_dlq (task_id, type, payload, reason, attempts, last_error)
       VALUES ($1, $2, $3, $4, $5, $6)
       ON CONFLICT (task_id) DO UPDATE SET
         retry_count = agent_tasks_dlq.retry_count + 1,
         last_error = $6`,
      [taskId, type, payload, reason, attempts, lastError]
    );
  }

  async listUnprocessed(limit: number = 100): Promise<DeadLetterTask[]> {
    const result = await this.pool.query(
      `SELECT * FROM agent_tasks_dlq
       WHERE retry_count = 0
       ORDER BY created_at ASC
       LIMIT $1`,
      [limit]
    );
    return result.rows;
  }

  async listAll(limit: number = 100): Promise<DeadLetterTask[]> {
    const result = await this.pool.query(
      `SELECT * FROM agent_tasks_dlq
       ORDER BY created_at DESC
       LIMIT $1`,
      [limit]
    );
    return result.rows;
  }

  async requeue(dlqId: string): Promise<void> {
    await this.pool.query(
      `UPDATE agent_tasks_dlq
       SET retry_count = retry_count + 1
       WHERE id = $1`,
      [dlqId]
    );
  }

  async delete(dlqId: string): Promise<void> {
    await this.pool.query(
      `DELETE FROM agent_tasks_dlq WHERE id = $1`,
      [dlqId]
    );
  }

  async getStats(): Promise<{ total: number; unprocessed: number; retried: number }> {
    const result = await this.pool.query(
      `SELECT
        COUNT(*) as total,
        COUNT(CASE WHEN retry_count = 0 THEN 1 END) as unprocessed,
        COUNT(CASE WHEN retry_count > 0 THEN 1 END) as retried
       FROM agent_tasks_dlq`
    );
    return result.rows[0];
  }

  async cleanup(olderThanDays: number = 30): Promise<number> {
    const result = await this.pool.query(
      `DELETE FROM agent_tasks_dlq
       WHERE created_at < NOW() - INTERVAL '${olderThanDays} days'`,
    );
    return result.rowCount || 0;
  }
}

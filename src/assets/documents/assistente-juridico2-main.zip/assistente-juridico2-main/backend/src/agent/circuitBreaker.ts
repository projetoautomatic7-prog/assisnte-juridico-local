import { Pool } from 'pg';

export class CircuitBreaker {
  private failureCount: Map<string, number> = new Map();
  private lastFailureTime: Map<string, number> = new Map();
  private state: Map<string, 'CLOSED' | 'OPEN' | 'HALF_OPEN'> = new Map();

  constructor(
    private readonly threshold: number = 5, // Falhas antes de abrir
    private readonly timeout: number = 60000, // Tempo para tentar reset (ms)
    private readonly resetTimeout: number = 30000 // Timeout da tarefa
  ) {}

  async execute<T>(
    fn: () => Promise<T>,
    key: string
  ): Promise<T> {
    const state = this.state.get(key) || 'CLOSED';
    const failures = this.failureCount.get(key) || 0;
    const lastFailure = this.lastFailureTime.get(key) || 0;
    const now = Date.now();

    // Se OPEN e tempo expirou, tentar HALF_OPEN
    if (state === 'OPEN' && now - lastFailure > this.timeout) {
      this.state.set(key, 'HALF_OPEN');
    }

    // Se OPEN (e tempo não expirou), rejeitar
    if (this.state.get(key) === 'OPEN') {
      throw new Error(`Circuit breaker OPEN for ${key}. Service temporarily unavailable.`);
    }

    // Executar com timeout
    try {
      const result = await Promise.race([
        fn(),
        new Promise<never>((_, reject) =>
          setTimeout(
            () => reject(new Error(`Timeout (${this.resetTimeout}ms)`)),
            this.resetTimeout
          )
        ),
      ]);

      // Sucesso: resetar contadores
      this.failureCount.set(key, 0);
      this.lastFailureTime.set(key, 0);
      this.state.set(key, 'CLOSED');

      return result;
    } catch (error) {
      // Incrementar falhas
      const newFailures = failures + 1;
      this.failureCount.set(key, newFailures);
      this.lastFailureTime.set(key, now);

      // Se atingiu limiar, abrir circuito
      if (newFailures >= this.threshold) {
        this.state.set(key, 'OPEN');
      }

      throw error;
    }
  }

  getStatus(key: string): { state: string; failures: number } {
    return {
      state: this.state.get(key) || 'CLOSED',
      failures: this.failureCount.get(key) || 0,
    };
  }

  reset(key: string): void {
    this.failureCount.delete(key);
    this.lastFailureTime.delete(key);
    this.state.delete(key);
  }

  resetAll(): void {
    this.failureCount.clear();
    this.lastFailureTime.clear();
    this.state.clear();
  }
}

export const circuitBreaker = new CircuitBreaker();

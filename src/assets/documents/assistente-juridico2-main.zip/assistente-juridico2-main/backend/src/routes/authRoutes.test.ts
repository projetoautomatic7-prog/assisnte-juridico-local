import express from 'express';
import request from 'supertest';

import authRoutes from './authRoutes';

// Create a minimal express app for testing
const app = express();
app.use(express.json());
app.use('/api/auth', authRoutes);

// Mock environment variables
const originalEnv = process.env;

describe('POST /api/auth/login', () => {
    beforeEach(() => {
        jest.resetModules();
        process.env = { ...originalEnv };
        process.env.JWT_SECRET = 'test-jwt-secret';
    });

    afterAll(() => {
        process.env = originalEnv;
    });

    it('should login with default credentials when env vars are not set', async () => {
        delete process.env.ADMIN_USERNAME;
        delete process.env.ADMIN_PASSWORD;
        delete process.env.ADMIN_PASSWORD_HASH;

        const response = await request(app)
            .post('/api/auth/login')
            .send({ username: 'admin', password: 'admin123' });

        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('token');
    });

    it('should login with environment variable credentials (plain password)', async () => {
        process.env.ADMIN_USERNAME = 'testuser';
        process.env.ADMIN_PASSWORD = 'testpass';
        delete process.env.ADMIN_PASSWORD_HASH;

        const response = await request(app)
            .post('/api/auth/login')
            .send({ username: 'testuser', password: 'testpass' });

        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('token');
    });

    it('should login with environment variable credentials (bcrypt hash)', async () => {
        process.env.ADMIN_USERNAME = 'admin';
        // Generate a valid bcrypt hash for 'admin123'
        const bcryptModule = await import('bcrypt');
        const bcrypt = (bcryptModule as any).default ?? bcryptModule;
        const validHash = await bcrypt.hash('admin123', 12);
        process.env.ADMIN_PASSWORD_HASH = validHash;

        const response = await request(app)
            .post('/api/auth/login')
            .send({ username: 'admin', password: 'admin123' });

        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('token');
    });

    it('should reject invalid username', async () => {
        process.env.ADMIN_USERNAME = 'admin';
        process.env.ADMIN_PASSWORD = 'admin123';

        const response = await request(app)
            .post('/api/auth/login')
            .send({ username: 'wronguser', password: 'admin123' });

        expect(response.status).toBe(401);
        expect(response.body.message).toBe('Usuário ou senha inválidos.');
    });

    it('should reject invalid password with plain password comparison', async () => {
        process.env.ADMIN_USERNAME = 'admin';
        process.env.ADMIN_PASSWORD = 'admin123';
        delete process.env.ADMIN_PASSWORD_HASH;

        const response = await request(app)
            .post('/api/auth/login')
            .send({ username: 'admin', password: 'wrongpass' });

        expect(response.status).toBe(401);
        expect(response.body.message).toBe('Usuário ou senha inválidos.');
    });

    it('should reject invalid password with bcrypt hash', async () => {
        process.env.ADMIN_USERNAME = 'admin';
        // Generate a valid bcrypt hash for 'admin123'
        const bcryptModule2 = await import('bcrypt');
        const bcrypt2 = (bcryptModule2 as any).default ?? bcryptModule2;
        const validHash = await bcrypt2.hash('admin123', 12);
        process.env.ADMIN_PASSWORD_HASH = validHash;

        const response = await request(app)
            .post('/api/auth/login')
            .send({ username: 'admin', password: 'wrongpass' });

        expect(response.status).toBe(401);
        expect(response.body.message).toBe('Usuário ou senha inválidos.');
    });

    it('should return 500 if JWT_SECRET is not set', async () => {
        delete process.env.JWT_SECRET;
        process.env.ADMIN_USERNAME = 'admin';
        process.env.ADMIN_PASSWORD = 'admin123';

        const response = await request(app)
            .post('/api/auth/login')
            .send({ username: 'admin', password: 'admin123' });

        expect(response.status).toBe(500);
        expect(response.body.message).toBe('Erro de configuração interna do servidor.');
    });
});

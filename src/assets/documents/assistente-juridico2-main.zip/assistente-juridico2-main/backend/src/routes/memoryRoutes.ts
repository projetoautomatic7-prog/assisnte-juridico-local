import express, { Request, Response } from 'express';

import { geminiService } from '../services/geminiService';
import { indexingService } from '../services/indexingService';
import { vectorStoreService } from '../services/vectorStoreService';

const router = express.Router();

router.post('/index', async (req: Request, res: Response) => {
    const { text, metadata } = req.body;
    if (!text) {
        return res.status(400).json({ message: 'O campo "text" é obrigatório.' });
    }
    try {
        const chunks = await indexingService.processAndChunkText(text);
        
        await vectorStoreService.addDocuments(chunks.map(chunk => ({
            pageContent: chunk,
            metadata: { ...metadata, source: 'text_input' }
        })));
        
        res.status(200).json({ message: `Texto indexado com sucesso em ${chunks.length} partes.` });

    } catch (error) {
        console.error('Erro ao indexar texto:', error);
        res.status(500).json({ message: (error as Error).message });
    }
});

// New endpoint for RAG-based search
router.post('/search', async (req: Request, res: Response) => {
    const { query } = req.body;
    if (!query) {
        return res.status(400).json({ message: 'O campo "query" é obrigatório.'});
    }

    try {
        // 1. Search for relevant context in the vector store
        const contextDocs = await vectorStoreService.search(query, 5); // Get top 5 results

        // 2. Build an enriched prompt for the generative model
        const contextText = contextDocs.map(doc => `- ${doc.pageContent}`).join('\n');
        const prompt = `Com base no seguinte contexto extraído da minha base de conhecimento, responda à pergunta do usuário. Seja direto e baseie sua resposta apenas no contexto fornecido. Se o contexto não for suficiente, diga que não encontrou a informação.\n\nContexto:\n${contextText}\n\nPergunta do usuário: ${query}`;

        // 3. Call the generative model with the context
        const answer = await geminiService.generateText(prompt);

        res.status(200).json({
            answer,
            sources: contextDocs.map(doc => doc.metadata)
        });

    } catch (error) {
        console.error('Erro na busca RAG:', error);
        res.status(500).json({ message: (error as Error).message });
    }
});

export default router;
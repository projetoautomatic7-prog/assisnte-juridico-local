import express, { Request, Response } from 'express';

import { pool } from '../services/db';

const router = express.Router();

// Armazena uma nova assinatura de notificação push
router.post('/subscribe', async (req: Request, res: Response) => {
    const subscription = req.body;
    // const userId = (req as any).user.sub; // Assumindo que o ID do usuário está no token JWT

    if (!subscription || !subscription.endpoint) {
        return res.status(400).json({ message: 'Objeto de assinatura inválido.' });
    }

    try {
        // Em um app real, você associaria a assinatura ao ID do usuário
        await pool.query(
            'INSERT INTO push_subscriptions (subscription, user_id) VALUES ($1, $2)',
            [subscription, 'mock_user_id']
        );
        console.log('Nova assinatura de notificação push salva:', subscription.endpoint);
        res.status(201).json({ message: 'Assinatura salva com sucesso.' });
    } catch (error) {
        console.error('Erro ao salvar assinatura de notificação:', error);
        res.status(500).json({ message: 'Não foi possível salvar a assinatura.' });
    }
});

export default router;
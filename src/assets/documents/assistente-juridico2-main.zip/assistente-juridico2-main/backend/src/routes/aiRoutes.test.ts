import { describe, it, expect, jest } from '@jest/globals';
import jwt from 'jsonwebtoken';
import request from 'supertest';

import { authMiddleware } from '../middleware/authMiddleware';
import app from '../server'; // Import the app instance
import { geminiService } from '../services/geminiService';

// Mock the auth middleware to bypass authentication for these tests
jest.mock('../middleware/authMiddleware', () => ({ authMiddleware: (req: any, res: any, next: any) => next() }));

// Mock the entire geminiService to prevent actual API calls during tests
jest.mock('../services/geminiService');

// Create a typed mock to allow for type-safe mocking of methods
const mockedGeminiService = geminiService as jest.Mocked<typeof geminiService>;

describe('AI Routes (/api/ai)', () => {

  describe('POST /api/ai/text', () => {
    it('should return 200 and generated text for a valid request', async () => {
      mockedGeminiService.generateText.mockResolvedValue('This is a test summary.');
      
      const response = await request(app)
        .post('/api/ai/text')
        .send({ prompt: 'Summarize this' });

      expect(response.status).toBe(200);
      expect(response.body).toEqual({ text: 'This is a test summary.' });
      expect(mockedGeminiService.generateText).toHaveBeenCalledWith('Summarize this', undefined);
    });

    it('should return 400 if prompt is missing', async () => {
      const response = await request(app)
        .post('/api/ai/text')
        .send({}); // No prompt

      expect(response.status).toBe(400);
      expect(response.body.message).toContain('O prompt é obrigatório.');
    });

    it('should return 500 if geminiService throws an error', async () => {
      mockedGeminiService.generateText.mockRejectedValue(new Error('Gemini API error'));

      const response = await request(app)
        .post('/api/ai/text')
        .send({ prompt: 'This will fail' });

      expect(response.status).toBe(500);
      expect(response.body.message).toBe('Gemini API error');
    });
  });

  describe('POST /api/ai/image/generate', () => {
    it('should return 200 and a base64 image string', async () => {
      mockedGeminiService.generateImage.mockResolvedValue('base64string');
      
      const response = await request(app)
        .post('/api/ai/image/generate')
        .send({ prompt: 'A cat' });

      expect(response.status).toBe(200);
      expect(response.body).toEqual({ image: 'base64string' });
      expect(mockedGeminiService.generateImage).toHaveBeenCalledWith('A cat');
    });

    it('should return 400 if prompt is missing', async () => {
       const response = await request(app)
        .post('/api/ai/image/generate')
        .send({});

      expect(response.status).toBe(400);
      expect(response.body.message).toContain('O prompt é obrigatório.');
    });

    it('should return 500 on service failure', async () => {
      mockedGeminiService.generateImage.mockRejectedValue(new Error('Image generation failed'));

      const response = await request(app)
        .post('/api/ai/image/generate')
        .send({ prompt: 'A failing cat' });

      expect(response.status).toBe(500);
      expect(response.body.message).toBe('Image generation failed');
    });
  });

  describe('POST /api/ai/image/edit', () => {
    const validBody = {
      prompt: 'Make it blue',
      image: { data: 'base64data', mimeType: 'image/png' },
    };

    it('should return 200 and the edited image', async () => {
      mockedGeminiService.editImage.mockResolvedValue('editedbase64string');

      const response = await request(app)
        .post('/api/ai/image/edit')
        .send(validBody);

      expect(response.status).toBe(200);
      expect(response.body).toEqual({ image: 'editedbase64string' });
      expect(mockedGeminiService.editImage).toHaveBeenCalledWith(validBody.prompt, validBody.image);
    });

    it('should return 400 if image data is missing', async () => {
       const response = await request(app)
        .post('/api/ai/image/edit')
        .send({ prompt: 'Make it blue' }); // Missing image

      expect(response.status).toBe(400);
      expect(response.body.message).toContain('O prompt e a imagem (base64 com mimeType) são obrigatórios.');
    });

    it('should return 500 on service failure', async () => {
      mockedGeminiService.editImage.mockRejectedValue(new Error('Image editing failed'));

      const response = await request(app)
        .post('/api/ai/image/edit')
        .send(validBody);

      expect(response.status).toBe(500);
      expect(response.body.message).toBe('Image editing failed');
    });
  });
  
  describe('POST /api/ai/transcribe', () => {
    const validBody = {
      file: { data: 'base64audio', mimeType: 'audio/mp3' },
    };

    it('should return 200 with the transcription text', async () => {
      mockedGeminiService.transcribeAudio.mockResolvedValue('This is the transcription.');

      const response = await request(app)
        .post('/api/ai/transcribe')
        .send(validBody);

      expect(response.status).toBe(200);
      expect(response.body).toEqual({ transcription: 'This is the transcription.' });
      expect(mockedGeminiService.transcribeAudio).toHaveBeenCalledWith(validBody.file);
    });

    it('should return 400 if file data is missing', async () => {
      const response = await request(app)
        .post('/api/ai/transcribe')
        .send({}); // Missing file

      expect(response.status).toBe(400);
      expect(response.body.message).toContain('O arquivo (base64 com mimeType) é obrigatório.');
    });

    it('should return 500 on service failure', async () => {
      mockedGeminiService.transcribeAudio.mockRejectedValue(new Error('Transcription failed'));

      const response = await request(app)
        .post('/api/ai/transcribe')
        .send(validBody);
        
      expect(response.status).toBe(500);
      expect(response.body.message).toBe('Transcription failed');
    });
  });

});
import express, { Request, Response } from 'express';

import { taskRepo } from '../agent/repos';
import { datajudService } from '../services/datajudService';
import { djenService } from '../services/djenService';
import { geminiService } from '../services/geminiService';
import { pjeService } from '../services/pjeService';
import { DjenPublication } from '../types';

const router = express.Router();

router.get('/acervo', async (req: Request, res: Response) => {
    try {
        const processos = await pjeService.getAcervo();
        res.status(200).json(processos);
    } catch (error) {
        const message = (error as Error).message || 'Erro desconhecido ao buscar acervo.';
        res.status(500).json({ message });
    }
});

router.get('/expedientes', async (req: Request, res: Response) => {
    try {
        // Agora busca o estado real das tarefas de processamento de expediente
        const tasks = await taskRepo.listAll();
        const expedienteTasks = tasks.filter(t => t.type === 'LEGAL_DRAFT_FROM_EXPEDIENTE');

        const expedientes = expedienteTasks.map(task => {
            const initialData = task.payload.notification || {};
            // Result might be a stringified JSON, so we parse it.
            const resultData = typeof task.result === 'string' ? JSON.parse(task.result) : task.result || {};
            
            const merged = { ...initialData, ...resultData, agentTaskId: task.id };

            // Map the agent task's lifecycle status to a user-facing Expediente status
            if (task.status === 'QUEUED' || task.status === 'RUNNING') {
                merged.status = 'drafting';
            } else if (task.status === 'FAILED') {
                merged.status = 'human_review'; // Mark for human review on failure
                merged.ai_summary = `Falha do agente: ${task.last_error}. ${merged.ai_summary || ''}`;
            }
            // For 'DONE', the status from the tool's result is already in `merged`.
            
            // Fallback status if none is set after merging and status mapping
            if (!merged.status) {
                merged.status = 'human_review';
            }

            return merged;
        });


        res.status(200).json(expedientes);
    } catch (error) {
        const message = (error as Error).message || 'Erro desconhecido ao buscar expedientes.';
        res.status(500).json({ message });
    }
});

router.get('/audiencias', async (req: Request, res: Response) => {
    try {
        const audiencias = await pjeService.getAudiencias();
        res.status(200).json(audiencias);
    } catch (error) {
        const message = (error as Error).message || 'Erro desconhecido ao buscar audiências.';
        res.status(500).json({ message });
    }
});

router.post('/sync-calendar', async (req: Request, res: Response) => {
    try {
        const audiencias = await pjeService.syncAudienciasToCalendar();
        res.status(200).json(audiencias);
    } catch (error) {
        const message = (error as Error).message || 'Erro desconhecido ao sincronizar com a agenda.';
        res.status(500).json({ message });
    }
});

router.post('/premonicao', async (req: Request, res: Response) => {
    const { cnj } = req.body;
    if (!cnj) {
        return res.status(400).json({ message: 'O número do processo (CNJ) é obrigatório.' });
    }
    try {
        const premonicao = await pjeService.getPremonicaoJuridica(cnj);
        res.status(200).json(premonicao);
    } catch (error) {
        const message = (error as Error).message || 'Erro desconhecido ao gerar Premonição Jurídica.';
        res.status(500).json({ message });
    }
});


router.post('/connect', (req: Request, res: Response) => {
    const { login, password } = req.body;
    if (!login || !password) {
        return res.status(400).json({ message: 'Login e senha são obrigatórios.' });
    }
    pjeService.setCredentials(login, password);
    pjeService.connect();
    res.status(200).json({ message: 'Comando para conectar ao PJe recebido.' });
});

router.post('/start', (req: Request, res: Response) => {
    pjeService.startMonitoring();
    res.status(200).json({ message: 'Comando para iniciar o monitoramento recebido.' });
});

router.post('/stop', (req: Request, res: Response) => {
    pjeService.stopMonitoring();
    res.status(200).json({ message: 'Comando para parar o monitoramento recebido.' });
});

router.post('/disconnect', async (req: Request, res: Response) => {
    await pjeService.disconnect();
    res.status(200).json({ message: 'Comando para desconectar recebido.' });
});

router.post('/submit-2fa', async (req: Request, res: Response) => {
    const { code } = req.body;
    if (!code) {
        return res.status(400).json({ message: 'O código 2FA é obrigatório.' });
    }
    try {
        await pjeService.submit2FA(code);
        res.status(200).json({ message: 'Código 2FA submetido com sucesso.' });
    } catch (error) {
        res.status(401).json({ message: (error as Error).message });
    }
});


router.post('/diagnostics', async (req: Request, res: Response) => {
    const { step } = req.body;
    try {
        switch (step) {
            case 'backend':
                return res.status(200).json({ success: true, message: 'Servidor backend está online e respondendo.' });
            case 'gemini': {
                const geminiOk = await geminiService.checkHealth();
                if (geminiOk) {
                    return res.status(200).json({ success: true, message: 'API do Gemini acessível e chave válida.' });
                } else {
                    return res.status(503).json({ success: false, message: 'Falha ao comunicar com a API do Gemini. Verifique a API_KEY e a conectividade de rede.' });
                }
            }
            case 'puppeteer': {
                const puppeteerOk = await pjeService.checkBrowserHealth();
                if (puppeteerOk) {
                    return res.status(200).json({ success: true, message: 'Navegador de automação (Puppeteer) iniciado com sucesso.' });
                } else {
                    return res.status(503).json({ success: false, message: 'Falha ao iniciar o navegador. Verifique as dependências do Puppeteer no servidor (ex: apt-get install chromium-browser).' });
                }
            }
            case 'google': {
                // Simulate checking for required env vars for Google API
                if (process.env.GOOGLE_API_KEY && process.env.GOOGLE_CLIENT_ID) {
                    return res.status(200).json({ success: true, message: 'Credenciais da API do Google encontradas no servidor.' });
                } else {
                    return res.status(503).json({ success: false, message: 'Credenciais GOOGLE_API_KEY e/ou GOOGLE_CLIENT_ID não encontradas nas variáveis de ambiente do servidor.' });
                }
                break;
            }
            default:
                return res.status(400).json({ success: false, message: 'Etapa de diagnóstico desconhecida.' });
        }
    } catch (error) {
         console.error(`Diagnostic error on step ${step}:`, error);
         return res.status(500).json({ success: false, message: `Erro interno no servidor durante o diagnóstico: ${(error as Error).message}` });
    }
});

// Datajud route using datajudService
router.post('/datajud-search', async (req: Request, res: Response) => {
    const { cnj, tribunal } = req.body;
    if (!tribunal) {
        return res.status(400).json({ message: 'O tribunal é obrigatório.' });
    }
    if (!cnj) {
        return res.status(400).json({ message: 'O número do processo (CNJ) é obrigatório.' });
    }

    try {
        const numeroProcessoLimpo = cnj.replace(/\D/g, '');
        const processo = await datajudService.searchByCNJ(numeroProcessoLimpo, tribunal);
        
        if (processo) {
            // Reconstruct the elasticsearch-like response that the frontend expects
            res.status(200).json({
                hits: {
                    hits: [{
                        _source: processo.bruto
                    }]
                }
            });
        } else {
            // Return empty hits if not found, as expected by the frontend
            res.status(200).json({ hits: { hits: [] } });
        }
    } catch (error) {
        console.error('Erro interno ao buscar no Datajud:', error);
        res.status(500).json({ message: `Erro interno do servidor: ${(error as Error).message}` });
    }
});

// DJEN Search route using djenService
router.post('/djen-search', async (req: Request, res: Response) => {
    const { date, tribunals, name, oab } = req.body;

    if (!date || !tribunals || !Array.isArray(tribunals) || tribunals.length === 0) {
        return res.status(400).json({ message: 'Data e uma lista de tribunais são obrigatórios.' });
    }
    if (!name && !oab) {
        return res.status(400).json({ message: 'Nome ou OAB devem ser fornecidos para a busca.' });
    }

    const searchTerms: string[] = [];
    
    if (name && name.trim()) {
        const nameParts = name.trim().split(/[\s,]+/);
        searchTerms.push(...nameParts.filter((p: string) => p.length > 0));
    }
    
    if (oab && oab.trim()) {
        const oabNumbers = oab.match(/\d{3,7}/g);
        if (oabNumbers) {
            searchTerms.push(...oabNumbers);
        }
        // Accept formats like 'SP 123456', '123456/SP', or simply the UF two letters
        const oabUF = oab.match(/(?:([A-Z]{2})(?:\s|\/))|\b([A-Z]{2})\b/i);
        if (oabUF) {
            const uf = oabUF[1] || oabUF[2];
            if (uf && uf.length === 2) searchTerms.push(uf);
        }
    }

    const uniqueTerms = [...new Set(searchTerms)];

    try {
        console.log(`[DJEN] Buscando: date=${date}, tribunals=${tribunals.join(',')}, terms=${uniqueTerms.join(',')}`);
        const results = await djenService.search(date, tribunals, uniqueTerms);
        res.status(200).json(results);
    } catch (error) {
        console.error('Erro inesperado na busca do DJEN:', error);
        res.status(500).json({ message: 'Um erro interno ocorreu no servidor.' });
    }
});

router.post('/set-human-activity', (req: Request, res: Response) => {
    const { active } = req.body;
    if (typeof active !== 'boolean') {
        return res.status(400).json({ message: 'O campo "active" (booleano) é obrigatório.' });
    }
    try {
        pjeService.setHumanActivity(active);
        res.status(200).json({ message: `Atividade humana definida como: ${active}` });
    } catch (error) {
        res.status(500).json({ message: (error as Error).message });
    }
});

// ✅ SOLUÇÃO 2: Dead Letter Queue Endpoints
router.get('/dlq/stats', async (req: Request, res: Response) => {
    try {
        const { DeadLetterQueue } = await import('../agent/deadLetterQueue');
        const { pool } = await import('../services/db');
        const dlq = new DeadLetterQueue(pool);
        const stats = await dlq.getStats();
        res.status(200).json(stats);
    } catch (error) {
        res.status(500).json({ message: (error as Error).message });
    }
});

router.get('/dlq/list', async (req: Request, res: Response) => {
    try {
        const { DeadLetterQueue } = await import('../agent/deadLetterQueue');
        const { pool } = await import('../services/db');
        const dlq = new DeadLetterQueue(pool);
        const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
        const tasks = await dlq.listAll(limit);
        res.status(200).json(tasks);
    } catch (error) {
        res.status(500).json({ message: (error as Error).message });
    }
});

router.post('/dlq/requeue/:id', async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const { DeadLetterQueue } = await import('../agent/deadLetterQueue');
        const { pool } = await import('../services/db');
        const dlq = new DeadLetterQueue(pool);
        await dlq.requeue(id);
        res.status(200).json({ message: 'Task requeued successfully' });
    } catch (error) {
        res.status(500).json({ message: (error as Error).message });
    }
});

router.delete('/dlq/:id', async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const { DeadLetterQueue } = await import('../agent/deadLetterQueue');
        const { pool } = await import('../services/db');
        const dlq = new DeadLetterQueue(pool);
        await dlq.delete(id);
        res.status(200).json({ message: 'Task deleted from DLQ' });
    } catch (error) {
        res.status(500).json({ message: (error as Error).message });
    }
});

export default router;
import express, { Router } from 'express';

import { authMiddleware } from '../middleware/authMiddleware';
import { crmService } from '../services/crmService';
import { metricsService } from '../services/metricsService';

const router: Router = express.Router();

// Middleware: requer autenticação
router.use(authMiddleware);

/**
 * GET /api/crm/cards - Listar cards com filtros
 */
router.get('/cards', async (req, res) => {
  try {
    const { cnj, fase, status, responsavel, limit } = req.query;

    const filtros = {
      cnj: cnj as string,
      fase: fase as any,
      status: status as any,
      responsavel: responsavel as string,
      limit: limit ? parseInt(limit as string) : 50,
    };

    const cards = await crmService.searchCards(filtros);
    res.status(200).json({ data: cards });
  } catch (error) {
    res.status(500).json({ message: (error as Error).message });
  }
});

/**
 * GET /api/crm/cards/:cardId - Obter um card específico
 */
router.get('/cards/:cardId', async (req, res) => {
  try {
    const { cardId } = req.params;
    const card = await crmService.getCardById(cardId);

    if (!card) {
      return res.status(404).json({ message: 'Card não encontrado' });
    }

    res.status(200).json({ data: card });
  } catch (error) {
    res.status(500).json({ message: (error as Error).message });
  }
});

/**
 * POST /api/crm/cards - Criar novo card
 */
router.post('/cards', async (req, res) => {
  try {
    const start = Date.now();
    const card = await crmService.createOrUpdateCard(req.body);
    metricsService.recordRequest('crm.card.create', Date.now() - start);
    res.status(201).json({ data: card });
  } catch (error) {
    metricsService.recordError('crm.card.create');
    res.status(500).json({ message: (error as Error).message });
  }
});

/**
 * PUT /api/crm/cards/:cardId - Atualizar card
 */
router.put('/cards/:cardId', async (req, res) => {
  try {
    const { cardId } = req.params;
    const card = await crmService.createOrUpdateCard({ ...req.body, id: cardId });
    res.status(200).json({ data: card });
  } catch (error) {
    res.status(500).json({ message: (error as Error).message });
  }
});

/**
 * PATCH /api/crm/cards/:cardId/status - Atualizar status do card
 */
router.patch('/cards/:cardId/status', async (req, res) => {
  try {
    const { cardId } = req.params;
    const { status } = req.body;

    if (!status) {
      return res.status(400).json({ message: 'Status é obrigatório' });
    }

    const card = await crmService.updateCardStatus(cardId, status);
    res.status(200).json({ data: card });
  } catch (error) {
    res.status(500).json({ message: (error as Error).message });
  }
});

/**
 * PATCH /api/crm/cards/:cardId/move - Mover card para outro estágio/fase
 */
router.patch('/cards/:cardId/move', async (req, res) => {
  try {
    const { cardId } = req.params;
    const { novaFase, novoEstagio } = req.body;

    if (!novaFase || !novoEstagio) {
      return res.status(400).json({ message: 'novaFase e novoEstagio são obrigatórios' });
    }

    const card = await crmService.moveCard(cardId, novaFase, novoEstagio);
    res.status(200).json({ data: card });
  } catch (error) {
    res.status(500).json({ message: (error as Error).message });
  }
});

/**
 * POST /api/crm/cards/:cardId/annotate - Adicionar anotação
 */
router.post('/cards/:cardId/annotate', async (req, res) => {
  try {
    const { cardId } = req.params;
    const { anotacao } = req.body;

    if (!anotacao) {
      return res.status(400).json({ message: 'Anotação é obrigatória' });
    }

    const card = await crmService.addAnnotation(cardId, anotacao);
    res.status(200).json({ data: card });
  } catch (error) {
    res.status(500).json({ message: (error as Error).message });
  }
});

/**
 * POST /api/crm/cards/:cardId/minuta - Adicionar minuta
 */
router.post('/cards/:cardId/minuta', async (req, res) => {
  try {
    const { cardId } = req.params;
    const { minutaUrl } = req.body;

    if (!minutaUrl) {
      return res.status(400).json({ message: 'minutaUrl é obrigatória' });
    }

    const card = await crmService.addMinuta(cardId, minutaUrl);
    res.status(200).json({ data: card });
  } catch (error) {
    res.status(500).json({ message: (error as Error).message });
  }
});

/**
 * POST /api/crm/cards/:cardId/archive - Arquivar card
 */
router.post('/cards/:cardId/archive', async (req, res) => {
  try {
    const { cardId } = req.params;
    const card = await crmService.archiveCard(cardId);
    res.status(200).json({ data: card });
  } catch (error) {
    res.status(500).json({ message: (error as Error).message });
  }
});

/**
 * DELETE /api/crm/cards/:cardId - Deletar card
 */
router.delete('/cards/:cardId', async (req, res) => {
  try {
    const { cardId } = req.params;
    await crmService.deleteCard(cardId);
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ message: (error as Error).message });
  }
});

/**
 * GET /api/crm/phase/:phase - Listar todos os cards de uma fase
 */
router.get('/phase/:phase', async (req, res) => {
  try {
    const { phase } = req.params;
    const cards = await crmService.getCardsByPhase(phase as any);
    res.status(200).json({ data: cards });
  } catch (error) {
    res.status(500).json({ message: (error as Error).message });
  }
});

/**
 * POST /api/crm/pipeline - Criar pipeline
 */
router.post('/pipeline', async (req, res) => {
  try {
    const pipeline = await crmService.createOrUpdatePipeline(req.body);
    res.status(201).json({ data: pipeline });
  } catch (error) {
    res.status(500).json({ message: (error as Error).message });
  }
});

/**
 * GET /api/crm/pipeline/:id - Obter pipeline
 */
router.get('/pipeline/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const pipeline = await crmService.getPipeline(id);

    if (!pipeline) {
      return res.status(404).json({ message: 'Pipeline não encontrado' });
    }

    res.status(200).json({ data: pipeline });
  } catch (error) {
    res.status(500).json({ message: (error as Error).message });
  }
});

export default router;

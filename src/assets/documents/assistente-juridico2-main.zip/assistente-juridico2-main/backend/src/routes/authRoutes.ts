import bcrypt from 'bcrypt';
import express, { Request, Response } from 'express';
import { OAuth2Client } from 'google-auth-library';
import jwt from 'jsonwebtoken';

const router = express.Router();
const client = new OAuth2Client();

router.post('/login', async (req: Request, res: Response) => {
    const { username, password } = req.body;

    // Get admin credentials from environment variables
    const adminUsername = process.env.ADMIN_USERNAME || 'admin';
    const adminPassword = process.env.ADMIN_PASSWORD || 'admin123';
    const adminPasswordHash = process.env.ADMIN_PASSWORD_HASH;

    // Enhanced logging for debugging (without exposing sensitive data)
    console.log(`[Login Attempt] Username: "${username}" | Expected: "${adminUsername}" | Using hash: ${!!adminPasswordHash}`);

    // Validate username
    if (username !== adminUsername) {
        console.log(`[Login Failed] Username mismatch: received "${username}", expected "${adminUsername}"`);
        return res.status(401).json({ message: 'Usuário ou senha inválidos.' });
    }

    // Validate password - check hash first, then fallback to plain password
    let isPasswordValid = false;
    
    try {
        if (adminPasswordHash) {
            // Use bcrypt to compare with hash
            isPasswordValid = await bcrypt.compare(password, adminPasswordHash);
        } else {
            // Fallback to plain password comparison
            isPasswordValid = password === adminPassword;
        }
    } catch (error) {
        console.error('Error validating password:', error);
        return res.status(500).json({ message: 'Erro ao validar credenciais.' });
    }

    if (!isPasswordValid) {
        console.log(`[Login Failed] Password validation failed for user "${username}"`);
        return res.status(401).json({ message: 'Usuário ou senha inválidos.' });
    }

    const jwtSecret = process.env.JWT_SECRET;
    if (!jwtSecret) {
        console.error("JWT_SECRET não está definido. Não é possível gerar token.");
        return res.status(500).json({ message: 'Erro de configuração interna do servidor.' });
    }

    // Payload do token pode incluir ID do usuário, roles, etc.
    const payload = {
        sub: username, // 'subject'
        // Adicione outras informações que você queira no token
    };

    // Gera o token com validade de 24 horas
    const token = jwt.sign(payload, jwtSecret, { expiresIn: '24h' });

    console.log(`[Login Success] User "${username}" logged in successfully`);
    res.status(200).json({ token });
});

// New route for Google Login
router.post('/google', async (req: Request, res: Response) => {
    const { idToken } = req.body;
    const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
    const JWT_SECRET = process.env.JWT_SECRET;
    const ALLOWED_DOMAIN = process.env.GOOGLE_ALLOWED_DOMAIN;

    if (!GOOGLE_CLIENT_ID || !JWT_SECRET) {
        console.error("GOOGLE_CLIENT_ID ou JWT_SECRET não estão definidos.");
        return res.status(500).json({ message: 'Erro de configuração do servidor.' });
    }

    try {
        const ticket = await client.verifyIdToken({
            idToken,
            audience: GOOGLE_CLIENT_ID,
        });

        const payload = ticket.getPayload();
        if (!payload || !payload.email) {
            return res.status(401).json({ message: 'Token do Google inválido.' });
        }
        
        // Optional: Restrict login to a specific domain
        if (ALLOWED_DOMAIN && payload.hd !== ALLOWED_DOMAIN) {
             return res.status(403).json({ message: `Acesso negado. Apenas e-mails do domínio ${ALLOWED_DOMAIN} são permitidos.` });
        }

        // User is authenticated with Google. Now, create our own app token.
        const appPayload = {
            sub: payload.sub,
            email: payload.email,
            name: payload.name,
        };

        const token = jwt.sign(appPayload, JWT_SECRET, { expiresIn: '24h' });

        res.status(200).json({ token });

    } catch (error) {
        console.error('Erro na verificação do token do Google:', error);
        res.status(401).json({ message: 'Falha na autenticação com o Google.' });
    }
});

// Diagnostic endpoint to verify auth configuration (without exposing sensitive data)
router.get('/config-check', (req: Request, res: Response) => {
    const config = {
        adminUsernameConfigured: !!process.env.ADMIN_USERNAME,
        adminUsernameValue: process.env.ADMIN_USERNAME || 'admin (default)',
        adminPasswordConfigured: !!process.env.ADMIN_PASSWORD,
        adminPasswordHashConfigured: !!process.env.ADMIN_PASSWORD_HASH,
        usingHashAuth: !!process.env.ADMIN_PASSWORD_HASH,
        jwtSecretConfigured: !!process.env.JWT_SECRET,
        timestamp: new Date().toISOString()
    };
    
    console.log('[Auth Config Check]', config);
    res.status(200).json(config);
});

export default router;
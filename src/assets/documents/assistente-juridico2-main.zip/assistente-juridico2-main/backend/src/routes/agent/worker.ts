// This file is obsolete and can be deleted.
// The agent worker logic has been moved to `backend/src/agent/worker.ts`.

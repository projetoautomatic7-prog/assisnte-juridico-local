// This file is obsolete and can be deleted.
// The agent bootstrapping logic has been moved to `backend/src/agent/bootstrap.ts`.

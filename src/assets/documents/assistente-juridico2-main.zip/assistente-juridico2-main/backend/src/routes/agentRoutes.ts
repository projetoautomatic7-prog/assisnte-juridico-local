import express, { Request, Response } from 'express';

import { AgentKernel } from '../agent/agentKernel';
import { buildToolRegistry } from '../agent/bootstrap';
import { GoalRepo, StepRepo, TaskRepo, EventBus } from '../agent/repos';
import { pool } from '../services/db';
import { webSocketService } from '../websocketService';

const router = express.Router();

// Setup Agent Kernel
const tools = buildToolRegistry();
const eventBus = new EventBus(pool, webSocketService);
const goalRepo = new GoalRepo(pool);
const stepRepo = new StepRepo(pool);
const taskRepo = new TaskRepo(pool);
const kernel = new AgentKernel(goalRepo, stepRepo, taskRepo, tools, eventBus);

// Cria e executa um objetivo
router.post('/goal', async (req: Request, res: Response)=>{
  try {
    const ctx = { requestId: (req as any).id, policies: {} }; // Carrega policies do DB se preferir
    const goal = await kernel.createGoal(req.body, ctx);
    
    // Dispara o planejamento e a execução em background, sem bloquear a resposta
    kernel.planAndRunGoal(goal.id, ctx);
    
    res.status(202).json({ goal }); // 202 Accepted
  } catch(e) {
    res.status(500).json({ message: (e as Error).message });
  }
});

// Lista todos os objetivos
router.get('/goals', async (req: Request, res: Response) => {
    try {
        const goals = await goalRepo.listAll();
        res.status(200).json(goals);
    } catch(e) {
        res.status(500).json({ message: (e as Error).message });
    }
});

// Pega detalhes de um objetivo (plano e eventos)
router.get('/goals/:id', async (req: Request, res: Response) => {
    try {
        const goal = await goalRepo.get(req.params.id);
        if (!goal) return res.status(404).json({ message: 'Objetivo não encontrado.' });
        
        const steps = await stepRepo.listByGoal(req.params.id);
        const events = await pool.query('SELECT * FROM agent_events WHERE goal_id=$1 ORDER BY created_at ASC', [req.params.id]).then(r => r.rows);

        res.status(200).json({ goal, steps, events });
    } catch(e) {
        res.status(500).json({ message: (e as Error).message });
    }
});

// Lista todas as tarefas
router.get('/tasks', async (req: Request, res: Response) => {
    try {
        const tasks = await taskRepo.listAll();
        res.status(200).json(tasks);
    } catch(e) {
        res.status(500).json({ message: (e as Error).message });
    }
});

// Bloqueia uma tarefa para edição humana
router.post('/tasks/:id/lock', async (req: Request, res: Response) => {
    try {
        await taskRepo.lock(req.params.id);
        res.status(200).json({ message: 'Tarefa bloqueada com sucesso.' });
    } catch (e) {
        res.status(500).json({ message: (e as Error).message });
    }
});

// Desbloqueia uma tarefa
router.post('/tasks/:id/unlock', async (req: Request, res: Response) => {
    try {
        await taskRepo.unlock(req.params.id);
        res.status(200).json({ message: 'Tarefa desbloqueada com sucesso.' });
    } catch (e) {
        res.status(500).json({ message: (e as Error).message });
    }
});

// Atualiza o payload de uma tarefa (ex: com um rascunho editado por humano)
router.patch('/tasks/:id/payload', async (req: Request, res: Response) => {
    try {
        await taskRepo.updatePayload(req.params.id, req.body);
        res.status(200).json({ message: 'Payload da tarefa atualizado.' });
    } catch (e) {
        res.status(500).json({ message: (e as Error).message });
    }
});

// Webhooks de fontes (GAS, TJMG/Recorte, Evolution)
router.post('/webhooks/:source', async (req: Request, res: Response)=>{
  // valide HMAC/X-Signature aqui (conferindo ts + body)
  // cria task com payload
  const task = await taskRepo.queue('INBOUND_EVENT', { source:req.params.source, body:req.body });
  res.status(202).json({ ok:true, queued:task.id });
});

export default router;
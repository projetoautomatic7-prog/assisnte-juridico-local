// This file is obsolete and can be deleted.
// The agent tools have been moved to `backend/src/agent/tools.ts`.

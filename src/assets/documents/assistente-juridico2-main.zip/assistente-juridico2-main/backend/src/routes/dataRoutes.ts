import express, { Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';

import { pool } from '../services/db';
import { Processo, Transaction, Pessoa, OriginData } from '../types';

const router = express.Router();

// Processos (Acervo)
router.get('/processos', async (req: Request, res: Response) => {
    try {
        const result = await pool.query('SELECT * FROM processos ORDER BY updated_at DESC');
        res.status(200).json(result.rows);
    } catch (error) {
        res.status(500).json({ message: (error as Error).message });
    }
});

router.patch('/processos/:id/stage', async (req: Request, res: Response) => {
    const { id } = req.params;
    const { stage, phase } = req.body;
    if (!stage || !phase) {
        return res.status(400).json({ message: 'Stage e Phase são obrigatórios.' });
    }
    try {
        const result = await pool.query(
            'UPDATE processos SET stage = $1, phase = $2, updated_at = now() WHERE id = $3 OR numero_cnj = $3 RETURNING *',
            [stage, phase, id]
        );
        if (result.rowCount === 0) {
            return res.status(404).json({ message: 'Processo não encontrado.' });
        }
        res.status(200).json(result.rows[0]);
    } catch (error) {
        res.status(500).json({ message: (error as Error).message });
    }
});


// Pessoas
router.get('/pessoas', async (req: Request, res: Response) => {
    try {
        const listRes = await pool.query('SELECT * FROM pessoas ORDER BY name');
        const pessoas: Pessoa[] = listRes.rows;

        // Calculate stats and charts from the data
        const total = pessoas.length;
        const withProcess = Math.floor(total * 0.6); 
        const withoutProcess = total - withProcess;

        const originsCount = pessoas.reduce((acc, p) => {
            if (p.origin) {
                acc[p.origin] = (acc[p.origin] || 0) + 1;
            }
            return acc;
        }, {} as Record<string, number>);

        // Fix: Explicitly cast `value` to number, as Object.entries may infer it as `unknown`.
        const originsChartData: OriginData[] = Object.entries(originsCount)
            .map(([name, value]) => ({ name, value: value as number }))
            .sort((a, b) => b.value - a.value)
            .slice(0, 5);

        const ageGroups: Record<string, number> = { '25-34': 0, '35-44': 0, '45-54': 0, '55+': 0 };
        let dominantAgeGroup = '25-34';
        let maxAgeCount = 0;
        
        pessoas.forEach(p => {
            if (p.age >= 25 && p.age <= 34) ageGroups['25-34']++;
            else if (p.age >= 35 && p.age <= 44) ageGroups['35-44']++;
            else if (p.age >= 45 && p.age <= 54) ageGroups['45-54']++;
            else if (p.age >= 55) ageGroups['55+']++;
        });

        // Fix: Cast `count` to number before comparison and assignment to fix type errors.
        Object.entries(ageGroups).forEach(([group, count]) => {
            if ((count as number) > maxAgeCount) {
                maxAgeCount = count as number;
                dominantAgeGroup = group;
            }
        });

        const ageChartPercentage = total > 0 ? (maxAgeCount / total) * 100 : 0;
        
        let dominantProfession = 'Outros';
        let maxProfessionCount = 0;
        const professionsCount = pessoas.reduce((acc, p) => {
            if (p.profession) {
                acc[p.profession] = (acc[p.profession] || 0) + 1;
            }
            return acc;
        }, {} as Record<string, number>);

        Object.entries(professionsCount).forEach(([prof, count]) => {
            if ((count as number) > maxProfessionCount) {
                maxProfessionCount = count as number;
                dominantProfession = prof;
            }
        });

        const professionChartPercentage = total > 0 ? (maxProfessionCount / total) * 100 : 0;

        res.status(200).json({
            list: pessoas,
            stats: { total, withProcess, withoutProcess },
            charts: { 
                origins: originsChartData, 
                age: { percentage: ageChartPercentage, label: dominantAgeGroup },
                professions: { percentage: professionChartPercentage, label: dominantProfession },
            }
        });
    } catch (error) {
        res.status(500).json({ message: (error as Error).message });
    }
});

// Atividades
router.get('/atividades', async (req: Request, res: Response) => {
    try {
        const result = await pool.query('SELECT * FROM atividades ORDER BY data_compromisso DESC');
        res.status(200).json(result.rows);
    } catch (error) {
        res.status(500).json({ message: (error as Error).message });
    }
});

// Estatísticas de Atividades
router.get('/atividades/stats', async (req: Request, res: Response) => {
    try {
        // Contar atividades pendentes
        const pendentesRes = await pool.query(`
            SELECT COUNT(*) as count FROM atividades 
            WHERE status = 'pendente'
        `);
        
        // Contar atividades atrasadas
        const atrasadasRes = await pool.query(`
            SELECT COUNT(*) as count FROM atividades 
            WHERE status = 'atrasada' AND data_compromisso < NOW()
        `);
        
        // Contar atividades resolvidas neste mês
        const resolvidasRes = await pool.query(`
            SELECT COUNT(*) as count FROM atividades 
            WHERE status = 'resolvida' 
            AND EXTRACT(MONTH FROM data_compromisso) = EXTRACT(MONTH FROM NOW())
            AND EXTRACT(YEAR FROM data_compromisso) = EXTRACT(YEAR FROM NOW())
        `);
        
        // Contar tarefas pendentes
        const tarefasPendentesRes = await pool.query(`
            SELECT COUNT(*) as count FROM atividades 
            WHERE status IN ('pendente', 'atrasada')
        `);

        res.status(200).json({
            atividades: parseInt(pendentesRes.rows[0].count),
            pendentes: parseInt(pendentesRes.rows[0].count),
            atrasadas: parseInt(atrasadasRes.rows[0].count),
            resolvidasNoMes: parseInt(resolvidasRes.rows[0].count),
            produtividade: parseInt(tarefasPendentesRes.rows[0].count),
            publicacoesPendentes: 0 // Será preenchido quando houver integração com DJEN
        });
    } catch (error) {
        res.status(500).json({ message: (error as Error).message });
    }
});

// Modelos
router.get('/modelos', async (req: Request, res: Response) => {
    try {
        const result = await pool.query('SELECT * FROM modelos ORDER BY nome');
        res.status(200).json(result.rows);
    } catch (error) {
        res.status(500).json({ message: (error as Error).message });
    }
});

// Dashboard Home
router.get('/dashboard-home', async (req: Request, res: Response) => {
     try {
        const compromissosRes = await pool.query('SELECT * FROM compromissos ORDER BY is_urgent DESC, relative_date');
        const audienciasRes = await pool.query('SELECT * FROM audiencias WHERE data_hora >= now() ORDER BY data_hora ASC LIMIT 3');
        // Mocked stats
        res.status(200).json({
            compromissos: compromissosRes.rows,
            audiencias: audienciasRes.rows,
            stats: { tarefasFinalizadas: 0, tarefasPendentes: 0, pontosAcumulados: 0 }
        });
    } catch (error) {
        res.status(500).json({ message: (error as Error).message });
    }
});

// Gestao BI
router.get('/gestao-bi', async (req: Request, res: Response) => {
    try {
        // Mocked for now
        res.status(200).json({
             reports: [],
             charts: { bar: [], line: [], donut: 0 }
        });
    } catch (error) {
        res.status(500).json({ message: (error as Error).message });
    }
});

// New endpoint for Rede
router.get('/rede', async (req: Request, res: Response) => {
    try {
        // Mock data for demonstration purposes. Replace with a real database query.
        const mockContacts = [
            { id: '1', name: 'Dr. Carlos Andrade', role: 'Perito Contábil', location: 'Belo Horizonte, MG', expertise: ['Cálculos Judiciais', 'Avaliação de Empresas'] },
            { id: '2', name: 'Dra. Beatriz Costa', role: 'Advogada Trabalhista', location: 'São Paulo, SP', expertise: ['Direito Trabalhista', 'Acordos Coletivos'] },
            { id: '3', name: 'Dr. Fernando Guimarães', role: 'Médico Perito', location: 'Curitiba, PR', expertise: ['Perícia Médica', 'Medicina do Trabalho'] },
            { id: '4', name: 'Dra. Lúcia Martins', role: 'Advogada Previdenciarista', location: 'Porto Alegre, RS', expertise: ['Direito Previdenciário', 'Aposentadoria Especial'] },
            { id: '5', name: 'Dr. Roberto Neves', role: 'Especialista em TI', location: 'Recife, PE', expertise: ['Direito Digital', 'LGPD'] },
        ];
        res.status(200).json(mockContacts);
    } catch (error) {
        res.status(500).json({ message: (error as Error).message });
    }
});


// --- CRUD for Financial Transactions ---
router.get('/financeiro', async (req: Request, res: Response) => {
    try {
        const result = await pool.query('SELECT * FROM transacoes ORDER BY date DESC');
        res.status(200).json(result.rows);
    } catch (error) {
        res.status(500).json({ message: (error as Error).message });
    }
});

router.post('/financeiro', async (req: Request, res: Response) => {
    const { date, processo_cnj, description, amount, type, status, attachment } = req.body;
    try {
        const result = await pool.query(
            'INSERT INTO transacoes (id, date, processo_cnj, description, amount, type, status, attachment, created_at, updated_at) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, now(), now()) RETURNING *',
            [uuidv4(), date, processo_cnj, description, amount, type, status, attachment || null]
        );
        res.status(201).json(result.rows[0]);
    } catch (error) {
        res.status(500).json({ message: (error as Error).message });
    }
});

router.put('/financeiro/:id', async (req: Request, res: Response) => {
    const { id } = req.params;
    const { date, processo_cnj, description, amount, type, status, attachment } = req.body;
    try {
        const result = await pool.query(
            'UPDATE transacoes SET date=$1, processo_cnj=$2, description=$3, amount=$4, type=$5, status=$6, attachment=$7, updated_at=now() WHERE id=$8 RETURNING *',
            [date, processo_cnj, description, amount, type, status, attachment || null, id]
        );
        if (result.rowCount === 0) {
            return res.status(404).json({ message: 'Transação não encontrada.' });
        }
        res.status(200).json(result.rows[0]);
    } catch (error) {
        res.status(500).json({ message: (error as Error).message });
    }
});

router.delete('/financeiro/:id', async (req: Request, res: Response) => {
    const { id } = req.params;
    try {
        const result = await pool.query('DELETE FROM transacoes WHERE id=$1', [id]);
        if (result.rowCount === 0) {
            return res.status(404).json({ message: 'Transação não encontrada.' });
        }
        res.status(204).send();
    } catch (error) {
        res.status(500).json({ message: (error as Error).message });
    }
});

export default router;
import { describe, it, expect, jest, beforeAll } from '@jest/globals';
import jwt from 'jsonwebtoken';
import request from 'supertest';

import app from '../server'; // Importa a instância do app Express
import { pjeService } from '../services/pjeService';

// Mock do pjeService para evitar chamadas reais ao Puppeteer
jest.mock('../services/pjeService');
const mockedPjeService = pjeService as jest.Mocked<typeof pjeService>;

describe('Robot Routes (/api/robot)', () => {
    let token: string;

    beforeAll(() => {
        // Gera um token JWT válido para os testes
        const jwtSecret = process.env.JWT_SECRET || 'test-secret';
        if (process.env.JWT_SECRET === undefined) {
          process.env.JWT_SECRET = jwtSecret;
        }
        token = jwt.sign({ sub: 'testuser' }, jwtSecret, { expiresIn: '1h' });
    });

    describe('Authentication', () => {
        it('should return 401 Unauthorized if no token is provided', async () => {
            const response = await request(app).get('/api/robot/acervo');
            expect(response.status).toBe(401);
            expect(response.body.message).toContain('Nenhum token fornecido');
        });

        it('should return 401 Unauthorized if an invalid token is provided', async () => {
            const response = await request(app)
                .get('/api/robot/acervo')
                .set('Authorization', 'Bearer invalidtoken');
            expect(response.status).toBe(401);
            expect(response.body.message).toContain('Token inválido ou expirado');
        });
    });

    describe('GET /api/robot/acervo', () => {
        it('should return 200 and a list of processos when authenticated', async () => {
            const mockProcessos = [{ id: '1', numero_cnj: '123' }];
            mockedPjeService.getAcervo.mockResolvedValue(mockProcessos as any);

            const response = await request(app)
                .get('/api/robot/acervo')
                .set('Authorization', `Bearer ${token}`);

            expect(response.status).toBe(200);
            expect(response.body).toEqual(mockProcessos);
            expect(pjeService.getAcervo).toHaveBeenCalledTimes(1);
        });

        it('should return 500 if the service throws an error', async () => {
            mockedPjeService.getAcervo.mockRejectedValue(new Error('PJe is down'));

            const response = await request(app)
                .get('/api/robot/acervo')
                .set('Authorization', `Bearer ${token}`);

            expect(response.status).toBe(500);
            expect(response.body.message).toBe('PJe is down');
        });
    });
});
import express, { Request, Response } from 'express';

import { User } from '../types';

const router = express.Router();

// Mock Data
const mockUsers: User[] = [
  { id: '1', name: 'Dr. Thiago Bodevan', email: 'thiago@bodevan.com', role: 'Administrador', status: 'Ativo', lastLogin: '2024-07-25T10:00:00Z' },
  { id: '2', name: 'Dra. Julia Santana', email: 'julia@bodevan.com', role: 'Advogado', status: 'Ativo', lastLogin: '2024-07-25T09:30:00Z' },
  { id: '3', name: 'Arthur dos Santos', email: 'arthur@bodevan.com', role: 'Advogado', status: 'Ativo', lastLogin: '2024-07-24T15:00:00Z' },
  { id: '4', name: 'Ian Nour', email: 'ian.convidado@email.com', role: 'Estagiário', status: 'Pendente', lastLogin: 'Nunca' },
];

router.get('/users', (req: Request, res: Response) => {
  res.status(200).json(mockUsers);
});

router.post('/users/invite', (req: Request, res: Response) => {
  const { email, role } = req.body;
  if (!email || !role) {
    return res.status(400).json({ message: 'Email e cargo são obrigatórios.' });
  }
  
  if (mockUsers.some(u => u.email === email)) {
      return res.status(409).json({ message: 'Um usuário com este email já existe.' });
  }
  
  // In a real app, you would send an email invite here.
  console.log(`Simulando envio de convite para ${email} com o cargo ${role}`);
  
  res.status(200).json({ message: 'Convite enviado com sucesso!' });
});

// New endpoint to update user's own account info
router.patch('/users/account', (req: Request, res: Response) => {
    const { name, newPassword } = req.body;
    // In a real app, you'd get the user ID from the JWT token (req.user.sub)
    // and update the corresponding user in the database.
    console.log(`Simulando atualização de conta: Nome=${name}, Nova Senha=${newPassword ? 'Sim' : 'Não'}`);

    if (!name && !newPassword) {
        return res.status(400).json({ message: 'Nenhum dado para atualizar foi fornecido.' });
    }
    
    // Here would be the database logic, e.g.:
    // await pool.query('UPDATE users SET name = $1, password = $2 WHERE id = $3', [name, hashedPassword, userId]);

    res.status(200).json({ message: 'Sua conta foi atualizada com sucesso!' });
});

export default router;
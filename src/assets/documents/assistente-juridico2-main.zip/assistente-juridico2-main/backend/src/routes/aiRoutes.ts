import express, { Request, Response } from 'express';

import { geminiService } from '../services/geminiService';

const router = express.Router();

// Generic text generation route
router.post('/text', async (req: Request, res: Response) => {
    const { prompt, model, schema } = req.body;
    if (!prompt) {
        return res.status(400).json({ message: 'O prompt é obrigatório.' });
    }
    try {
        let text;
        if(schema) {
            text = await geminiService.generateJson(prompt, schema, model);
        } else {
            text = await geminiService.generateText(prompt, model);
        }
        res.status(200).json({ text });
    } catch (error) {
        console.error('AI text generation error:', error);
        res.status(500).json({ message: (error as Error).message });
    }
});

// New route for conversational chat
router.post('/chat', async (req: Request, res: Response) => {
    const { history, message } = req.body;
    if (!message) {
        return res.status(400).json({ message: 'A mensagem do usuário é obrigatória.' });
    }
    try {
        const text = await geminiService.continueConversation(history || [], message);
        res.status(200).json({ text });
    } catch (error) {
        console.error('AI chat error:', error);
        res.status(500).json({ message: (error as Error).message });
    }
});

// Image generation route
router.post('/image/generate', async (req: Request, res: Response) => {
    const { prompt } = req.body;
    if (!prompt) {
        return res.status(400).json({ message: 'O prompt é obrigatório.' });
    }
    try {
        const base64Image = await geminiService.generateImage(prompt);
        res.status(200).json({ image: base64Image });
    } catch (error) {
        console.error('AI image generation error:', error);
        res.status(500).json({ message: (error as Error).message });
    }
});

// Image editing route
router.post('/image/edit', async (req: Request, res: Response) => {
    const { prompt, image } = req.body; // image should be { data: base64, mimeType: 'image/...' }
    if (!prompt || !image || !image.data || !image.mimeType) {
        return res.status(400).json({ message: 'O prompt e a imagem (base64 com mimeType) são obrigatórios.' });
    }
    try {
        const base64Image = await geminiService.editImage(prompt, image);
        res.status(200).json({ image: base64Image });
    } catch (error) {
        console.error('AI image editing error:', error);
        res.status(500).json({ message: (error as Error).message });
    }
});

// Audio/Video transcription route
router.post('/transcribe', async (req: Request, res: Response) => {
    const { file } = req.body; // file should be { data: base64, mimeType: 'audio/...' or 'video/...' }
    if (!file || !file.data || !file.mimeType) {
        return res.status(400).json({ message: 'O arquivo (base64 com mimeType) é obrigatório.' });
    }
    try {
        const transcription = await geminiService.transcribeAudio(file);
        res.status(200).json({ transcription });
    } catch (error) {
        console.error('AI audio transcription error:', error);
        res.status(500).json({ message: (error as Error).message });
    }
});

// New route for financial data extraction from documents
router.post('/extract-financial', async (req: Request, res: Response) => {
    const { file } = req.body;
    if (!file || !file.data || !file.mimeType) {
        return res.status(400).json({ message: 'O arquivo (base64 com mimeType) é obrigatório.' });
    }

    try {
        const data = await geminiService.extractFinancialDataFromFile(file);
        res.status(200).json(data);
    } catch (error) {
        console.error('AI financial extraction error:', error);
        res.status(500).json({ message: (error as Error).message });
    }
});

export default router;
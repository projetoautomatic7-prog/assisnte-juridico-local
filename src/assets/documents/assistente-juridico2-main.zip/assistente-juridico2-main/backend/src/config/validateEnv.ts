import 'dotenv/config';

const REQUIRED_VARS = ['API_KEY','JWT_SECRET','DATABASE_URL','FRONTEND_ORIGIN','PJE_LOGIN_URL','DATAJUD_API_KEY'] as const;
const RECOMMENDED_VARS = ['PJE_LOGIN_USER','PJE_LOGIN_PASS','CHROMA_URL','DATAJUD_BASE_URL','DJEN_BASE_URL','DJEN_REQUEST_INTERVAL_MS','DATAJUD_CACHE_TTL_MS','DJEN_CACHE_TTL_MS','ADMIN_USERNAME','ADMIN_PASSWORD','ADMIN_PASSWORD_HASH','GOOGLE_CLIENT_ID','GOOGLE_ALLOWED_DOMAIN'];

export function validateEnv() {
  if (process.env.NODE_ENV === 'test') {
    return; // Em testes usamos mocks/dummies
  }
  const missing = REQUIRED_VARS.filter(k => !process.env[k]);
  if (missing.length) {
    console.error('❌ Variáveis obrigatórias ausentes:', missing.join(', '));
    console.error('');
    console.error('🔧 Como resolver:');
    if (missing.includes('DATABASE_URL')) {
      console.error('  - DATABASE_URL: Configure no Render Dashboard → Seu Banco de Dados → Info → Internal Connection String');
    }
    if (missing.includes('API_KEY')) {
      console.error('  - API_KEY: Obtenha sua chave em https://aistudio.google.com/app/apikey');
    }
    if (missing.includes('JWT_SECRET')) {
      console.error('  - JWT_SECRET: Gere uma string aleatória longa e segura');
    }
    if (missing.includes('FRONTEND_ORIGIN')) {
      console.error('  - FRONTEND_ORIGIN: URL do seu frontend (ex: https://seu-app.vercel.app)');
    }
    if (missing.includes('DATAJUD_API_KEY')) {
      console.error('  - DATAJUD_API_KEY: Obtenha em https://datajud.cnj.jus.br/');
    }
    console.error('');
    throw new Error('Configuração incompleta de ambiente. Defina as variáveis listadas.');
  }
  const missingRecommended = RECOMMENDED_VARS.filter(k => !process.env[k]);
  if (missingRecommended.length) {
    console.warn('⚠️ Variáveis recomendadas não definidas (funcionalidades degradadas ou fallback manual exigido):', missingRecommended.join(', '));
  }
  console.log('✅ Variáveis obrigatórias presentes.');
}

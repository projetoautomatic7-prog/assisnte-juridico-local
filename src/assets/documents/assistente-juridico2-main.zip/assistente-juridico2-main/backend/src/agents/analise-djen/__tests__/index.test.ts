import { describe, it, expect, jest, beforeEach } from '@jest/globals';

import { djenService } from '../../../services/djenService';
import { geminiService } from '../../../services/geminiService';
import { runAnaliseDjen } from '../index';

// Mock services
jest.mock('../../../services/djenService');
jest.mock('../../../services/geminiService');

const mockedDjenService = djenService as jest.Mocked<typeof djenService>;
const mockedGeminiService = geminiService as jest.Mocked<typeof geminiService>;

describe('Agent: AnaliseDjen', () => {

    beforeEach(() => {
        jest.clearAllMocks();
    });

    it('should return success and summaries for found publications', async () => {
        const input = {
            params: {
                date: '2024-07-26',
                tribunals: ['TJMG'],
                terms: ['Advogado Teste']
            }
        };

        const mockPublications = [
            { tribunal: 'TJMG', dataPublicacao: '2024-07-26', tipo: 'Intimação', conteudo: 'Conteúdo da publicação 1' },
        ];

        mockedDjenService.search.mockResolvedValue(mockPublications as any);
        mockedGeminiService.generateText.mockResolvedValue('Resumo da publicação 1');

        const result = await runAnaliseDjen(input);

        expect(result.ok).toBe(true);
        expect((result.data as any).summaries).toHaveLength(1);
        expect((result.data as any).summaries[0].resumo).toBe('Resumo da publicação 1');
        expect(mockedDjenService.search).toHaveBeenCalledWith('2024-07-26', ['TJMG'], ['Advogado Teste']);
        expect(mockedGeminiService.generateText).toHaveBeenCalledWith('Resuma a seguinte publicação do Diário de Justiça em uma frase: "Conteúdo da publicação 1"');
    });

    it('should return success with a message when no publications are found', async () => {
        const input = {
            params: {
                date: '2024-07-26',
                tribunals: ['TJMG'],
                terms: ['Advogado Inexistente']
            }
        };

        mockedDjenService.search.mockResolvedValue([]);

        const result = await runAnaliseDjen(input);

        expect(result.ok).toBe(true);
        expect((result.data as any).message).toBe("Nenhuma publicação encontrada.");
        expect(mockedGeminiService.generateText).not.toHaveBeenCalled();
    });

    it('should return an error if required parameters are missing', async () => {
        const input = { params: {} }; // Missing params

        const result = await runAnaliseDjen(input);

        expect(result.ok).toBe(false);
        expect(result.error).toBe("Parâmetros 'date', 'tribunals' e 'terms' são obrigatórios.");
    });
});
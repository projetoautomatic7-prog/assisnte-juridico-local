// Auto-gerado por scaffold. Ajuste conforme necessário.
// Agente: AnaliseDjen
// Descrição: Analisa publicações DJEN e gera resumo

import type { Request, Response } from 'express';

import { djenService } from '../../services/djenService';
import { geminiService } from '../../services/geminiService';

// Contrato mínimo esperado pelo worker/tools atuais
export type AgentRunInput = {
  params?: Record<string, unknown>;
};

export type AgentRunOutput = {
  ok: boolean;
  ms: number;
  data?: any;
  error?: string;
};

export const AnaliseDjenConfig = {
  "name": "AnaliseDjen",
  "description": "Analisa publicações DJEN e gera resumo",
  "enabled": true,
  "cron": "15 2 * * *",
  "timezone": "America/Sao_Paulo",
  "tools": [
    "djen.analyze",
    "gemini"
  ],
  "tags": [],
  "concurrency": 1,
  "timeoutMs": 60000,
  "params": {}
} as const;

export async function runAnaliseDjen(input: AgentRunInput): Promise<AgentRunOutput> {
  const started = Date.now();
  try {
    const { date, tribunals, terms } = (input.params || {}) as { date: string, tribunals: string[], terms: string[] };
    if (!date || !tribunals || !terms) {
      throw new Error("Parâmetros 'date', 'tribunals' e 'terms' são obrigatórios.");
    }

    const publications = await djenService.search(date, tribunals, terms);
    if (publications.length === 0) {
      return { ok: true, ms: Date.now() - started, data: { message: "Nenhuma publicação encontrada." } };
    }

    const summaries = await Promise.all(
        publications.map(async (pub) => {
            const prompt = `Resuma a seguinte publicação do Diário de Justiça em uma frase: "${pub.conteudo}"`;
            const summary = await geminiService.generateText(prompt);
            return {
                tribunal: pub.tribunal,
                data: pub.dataPublicacao,
                resumo: summary,
                original: pub.conteudo
            };
        })
    );
    
    return { ok: true, ms: Date.now() - started, data: { summaries } };
  } catch (e) {
    const err = e as Error;
    return { ok: false, ms: Date.now() - started, error: err.message };
  }
}

// Exemplo opcional de rota HTTP (se quiser expor):
// Integre no router existente e proteja com JWT + zod.
export function mountAnaliseDjenRoutes(app: import('express').Express) {
  app.post('/api/agent/analise-djen/run', async (req: Request, res: Response) => {
    const out = await runAnaliseDjen({ params: req.body });
    res.json(out);
  });
}
# AnaliseDjen

Analisa publicações DJEN e gera resumo

## Execução

- Cron: 15 2 * * * (America/Sao_Paulo)
- Ferramentas: djen.analyze, gemini
- Timeout: 60000 ms | Concorrência: 1

## Como registrar

1. Adicione a função run no mapeamento do worker (task type → função).
2. Registre o agente em tools.ts, se for expor como ferramenta.
3. (Opcional) Monte as rotas com mount*Routes no router protegido por JWT.

## Testes

Crie testes em __tests__/ para validar o happy path e um edge case.

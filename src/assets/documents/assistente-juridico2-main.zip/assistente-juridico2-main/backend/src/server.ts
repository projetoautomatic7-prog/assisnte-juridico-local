import http from 'http';

import cors from 'cors';
import express, { Request, Response, NextFunction, RequestHandler } from 'express';

import 'dotenv/config';
import { URL } from 'url';

import cron from 'node-cron';

import process from 'process';
import path from 'path';

import { buildToolRegistry } from './agent/bootstrap';
import { initializeDatabase } from './agent/migrations';
import { EventBus, TaskRepo, taskRepo as taskRepoSingleton } from './agent/repos';
import { startWorkerLoop } from './agent/worker';
import { validateEnv } from './config/validateEnv';
import { authMiddleware } from './middleware/authMiddleware';
import agentRoutes from './routes/agentRoutes';
import aiRoutes from './routes/aiRoutes';
import authRoutes from './routes/authRoutes';
import dataRoutes from './routes/dataRoutes';
import memoryRoutes from './routes/memoryRoutes';
import notificationRoutes from './routes/notificationRoutes'; // Rota para notificações
import robotRoutes from './routes/robotRoutes';
import settingsRoutes from './routes/settingsRoutes';
import { seedAgentGoals } from './seeds/agent-goals';
import { seedAtividades } from './seeds/atividades-seed';
import { audioProxyService } from './services/audioProxyService';
import { pool } from './services/db';
import { webSocketService } from './websocketService';

validateEnv();

const app = express();
const server = http.createServer(app);

const frontendOrigins = process.env.FRONTEND_ORIGIN?.split(',').map(origin => origin.trim()) || [];
const staticAllowedOrigins = [
        ...new Set([
                ...frontendOrigins,
                'http://localhost:3000',
                'http://127.0.0.1:3000',
                'http://localhost:5173',
                'http://127.0.0.1:5173'
        ])
];

function isVercelOrigin(origin?: string): boolean {
    if (!origin) return false;
    try {
        const url = new URL(origin);
        const host = url.hostname.toLowerCase();
        return host === 'vercel.app' || host.endsWith('.vercel.app');
    } catch {
        return false;
    }
}

app.use(cors({
    origin: (origin, callback) => {
        if (
            !origin ||
            staticAllowedOrigins.includes(origin) ||
            /\.scf\.usercontent\.goog$/.test(origin) ||
            isVercelOrigin(origin)
        ) {
            return callback(null, true);
        }
        return callback(new Error('Not allowed by CORS'));
    },
    credentials: true
}));

app.use(express.json({ limit: '10mb' }));

app.get(['/health', '/saude', '/saúde'], (req: Request, res: Response) => {
    res.status(200).json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Serve static test page for login diagnostics
app.use('/test', express.static(path.join(__dirname, 'public')));

// Rotas da API
app.use('/api/auth', authRoutes);
app.use('/api/robot', authMiddleware as RequestHandler, robotRoutes);
app.use('/api/ai', authMiddleware as RequestHandler, aiRoutes);
app.use('/api/agent', authMiddleware as RequestHandler, agentRoutes);
app.use('/api/memory', authMiddleware as RequestHandler, memoryRoutes);
app.use('/api/data', authMiddleware as RequestHandler, dataRoutes);
app.use('/api/settings', authMiddleware as RequestHandler, settingsRoutes);
app.use('/api/notifications', authMiddleware as RequestHandler, notificationRoutes); // Nova rota

// Initialize WebSocket Services
webSocketService.initialize();
audioProxyService.initialize();

server.on('upgrade', (request, socket, head) => {
  const pathname = new URL(request.url || '', `http://${request.headers.host}`).pathname;

  if (pathname === '/api/ai/live-audio') {
    audioProxyService.getWss().handleUpgrade(request, socket, head, (ws) => {
      audioProxyService.getWss().emit('connection', ws, request);
    });
  } else {
    webSocketService.getWss().handleUpgrade(request, socket, head, (ws) => {
      webSocketService.getWss().emit('connection', ws, request);
    });
  }
});

const initializeApp = async () => {
    await initializeDatabase();
    console.log('🏛️  Banco de dados verificado e pronto.');

    // Seed agentes de teste em desenvolvimento
    if (process.env.NODE_ENV !== 'production') {
        await seedAgentGoals();
        await seedAtividades(pool);
    }

    // ✅ SOLUÇÃO 2: Inicializar Dead Letter Queue
    const { DeadLetterQueue } = await import('./agent/deadLetterQueue');
    const dlq = new DeadLetterQueue(pool);
    try {
        await dlq.create({});
        console.log('✅ Dead Letter Queue inicializada.');
    } catch (e) {
        console.warn('⚠️  DLQ já existe ou erro na criação:', (e as Error).message);
    }

    const toolRegistry = buildToolRegistry();
    const eventBus = new EventBus(pool, webSocketService);
    // Use the singleton taskRepo instance
    const agentContext = { requestId: 'SYSTEM', policies: {} };

    // ✅ SOLUÇÃO 1 + 3: Passar DLQ para Worker com Timeout Global e Circuit Breaker
    startWorkerLoop(taskRepoSingleton, toolRegistry, eventBus, agentContext, dlq);
    console.log('🤖 Worker do Agente iniciado (Timeout=30s, CircuitBreaker=ON, DLQ=ON).');

    cron.schedule('*/5 * * * *', () => {
        console.log('🗓️  Agendando tarefa recorrente: HEALTH_CHECK');
        taskRepoSingleton.queue('HEALTH_CHECK', { reason: 'Recurring schedule' });
    });
    
    cron.schedule('0 8 * * *', () => {
        console.log('🗓️  Agendando tarefa diária: Resumo Executivo');
        taskRepoSingleton.queue('DAILY_EXECUTIVE_SUMMARY', { date: new Date().toISOString() });
    }, {
        timezone: "America/Sao_Paulo"
    });

    // Novo cron job para o agente AnaliseDjen
    cron.schedule('15 2 * * *', () => {
        console.log('🗓️  Agendando tarefa diária: Análise de Publicações DJEN');
        // Parâmetros podem vir de uma tabela de configuração no futuro
        taskRepoSingleton.queue('ANALISE_DJEN', { 
            date: new Date().toISOString().split('T')[0],
            tribunals: ['TJMG', 'TRT3', 'TST'], // Tribunais padrão para monitorar
            terms: ['Thiago Bodevan Advocacia', '184404'] // Termos padrão (ex: nome, OAB)
        });
    }, {
        timezone: "America/Sao_Paulo"
    });

    console.log('🗓️  Scheduler de tarefas ativado.');
};

if (process.env.NODE_ENV !== 'test') {
    initializeApp().then(() => {
        const PORT = process.env.PORT || 3001;
        server.listen(PORT, () => {
            console.log(`🚀 Servidor backend rodando na porta ${PORT}`);
        });
    }).catch(err => {
        console.error("❌ Falha ao iniciar o servidor:", err);
        process.exit(1);
    });
}

export default app;
import 'dotenv/config';
import { pool } from './db';
import { metricsService } from './metricsService';

export type ProcessPhase = 'Marketing' | 'Negociação' | 'Consultoria' | 'Administrativo' | 'Judicial' | 'Recursal' | 'Execução' | 'Financeiro' | 'Arquivamento';

export interface CRMCard {
  id: string;
  processoId: string;
  cnj?: string;
  titulo: string;
  partes: { polo_ativo: string[]; polo_passivo: string[] };
  fase: ProcessPhase;
  estagio: string;
  prazos: {
    fatal: string | null;
    resposta: string | null;
  };
  status: 'novo' | 'em_progresso' | 'aguardando' | 'completado' | 'arquivado';
  valor?: number;
  minutas?: string[];
  anotacoes: string;
  dataUltimaAtualizacao: string;
  responsavel?: string;
  autoAtomacoes?: {
    sugestaoAcoes: string[];
    statusIA: string;
    ultimaAnalise: string;
  };
}

export interface CRMPipeline {
  id: string;
  nome: string;
  fases: Array<{
    id: ProcessPhase;
    label: string;
    estagios: string[];
    cards: CRMCard[];
  }>;
  configuracao?: {
    responsavelPadrao?: string;
    automacaoativada: boolean;
    frequenciaAtualizacao: 'hourly' | 'daily' | 'on-demand';
  };
}

class CRMService {
  /**
   * Cria ou atualiza um card no CRM
   */
  async createOrUpdateCard(card: Partial<CRMCard>): Promise<CRMCard> {
    try {
      const {
        id = `card_${Date.now()}`,
        processoId,
        cnj,
        titulo,
        partes,
        fase,
        estagio,
        prazos,
        status = 'novo',
        valor,
        anotacoes = '',
        responsavel,
      } = card;

      const query = `
        INSERT INTO crm_cards (
          id, processo_id, cnj, titulo, partes, fase, estagio, 
          prazos, status, valor, anotacoes, responsavel, data_criacao
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, NOW())
        ON CONFLICT (id) DO UPDATE SET
          titulo = EXCLUDED.titulo,
          fase = EXCLUDED.fase,
          estagio = EXCLUDED.estagio,
          prazos = EXCLUDED.prazos,
          status = EXCLUDED.status,
          valor = EXCLUDED.valor,
          anotacoes = EXCLUDED.anotacoes,
          data_ultima_atualizacao = NOW()
        RETURNING *;
      `;

      const result = await pool.query(query, [
        id,
        processoId,
        cnj,
        titulo,
        JSON.stringify(partes),
        fase,
        estagio,
        JSON.stringify(prazos),
        status,
        valor || 0,
        anotacoes,
        responsavel,
      ]);

      metricsService.recordRequest('crm.card.create', 0);
      return this.mapCardRow(result.rows[0]);
    } catch (error) {
      metricsService.recordError('crm.card.create');
      throw new Error(`Erro ao criar card CRM: ${(error as Error).message}`);
    }
  }

  /**
   * Move um card entre estagio/fase
   */
  async moveCard(cardId: string, novaFase: ProcessPhase, novoEstagio: string): Promise<CRMCard> {
    try {
      const query = `
        UPDATE crm_cards 
        SET fase = $2, estagio = $3, data_ultima_atualizacao = NOW()
        WHERE id = $1
        RETURNING *;
      `;

      const result = await pool.query(query, [cardId, novaFase, novoEstagio]);

      if (result.rows.length === 0) {
        throw new Error(`Card com ID ${cardId} não encontrado.`);
      }

      metricsService.recordRequest('crm.card.move', 0);
      return this.mapCardRow(result.rows[0]);
    } catch (error) {
      metricsService.recordError('crm.card.move');
      throw new Error(`Erro ao mover card: ${(error as Error).message}`);
    }
  }

  /**
   * Atualiza status do card (novo, em_progresso, aguardando, completado, arquivado)
   */
  async updateCardStatus(cardId: string, novoStatus: CRMCard['status']): Promise<CRMCard> {
    try {
      const query = `
        UPDATE crm_cards 
        SET status = $2, data_ultima_atualizacao = NOW()
        WHERE id = $1
        RETURNING *;
      `;

      const result = await pool.query(query, [cardId, novoStatus]);

      if (result.rows.length === 0) {
        throw new Error(`Card com ID ${cardId} não encontrado.`);
      }

      metricsService.recordRequest('crm.card.updateStatus', 0);
      return this.mapCardRow(result.rows[0]);
    } catch (error) {
      metricsService.recordError('crm.card.updateStatus');
      throw new Error(`Erro ao atualizar status: ${(error as Error).message}`);
    }
  }

  /**
   * Arquiva um card (move para fase Arquivamento)
   */
  async archiveCard(cardId: string): Promise<CRMCard> {
    try {
      const query = `
        UPDATE crm_cards 
        SET fase = 'Arquivamento', estagio = 'Arquivado Definitivamente', 
            status = 'arquivado', data_ultima_atualizacao = NOW()
        WHERE id = $1
        RETURNING *;
      `;

      const result = await pool.query(query, [cardId]);

      if (result.rows.length === 0) {
        throw new Error(`Card com ID ${cardId} não encontrado.`);
      }

      metricsService.recordRequest('crm.card.archive', 0);
      return this.mapCardRow(result.rows[0]);
    } catch (error) {
      metricsService.recordError('crm.card.archive');
      throw new Error(`Erro ao arquivar card: ${(error as Error).message}`);
    }
  }

  /**
   * Obtém todos os cards de uma fase
   */
  async getCardsByPhase(fase: ProcessPhase): Promise<CRMCard[]> {
    try {
      const query = `
        SELECT * FROM crm_cards 
        WHERE fase = $1 AND status != 'arquivado'
        ORDER BY data_ultima_atualizacao DESC;
      `;

      const result = await pool.query(query, [fase]);
      return result.rows.map((row) => this.mapCardRow(row));
    } catch (error) {
      throw new Error(`Erro ao buscar cards: ${(error as Error).message}`);
    }
  }

  /**
   * Obtém cards por filtro avançado
   */
  async searchCards(filtros: {
    cnj?: string;
    fase?: ProcessPhase;
    status?: CRMCard['status'];
    responsavel?: string;
    limit?: number;
  }): Promise<CRMCard[]> {
    try {
      let query = 'SELECT * FROM crm_cards WHERE 1=1';
      const params: any[] = [];

      if (filtros.cnj) {
        query += ` AND cnj = $${params.length + 1}`;
        params.push(filtros.cnj);
      }

      if (filtros.fase) {
        query += ` AND fase = $${params.length + 1}`;
        params.push(filtros.fase);
      }

      if (filtros.status) {
        query += ` AND status = $${params.length + 1}`;
        params.push(filtros.status);
      }

      if (filtros.responsavel) {
        query += ` AND responsavel = $${params.length + 1}`;
        params.push(filtros.responsavel);
      }

      query += ' ORDER BY data_ultima_atualizacao DESC';

      if (filtros.limit) {
        query += ` LIMIT $${params.length + 1}`;
        params.push(filtros.limit);
      }

      const result = await pool.query(query, params);
      return result.rows.map((row) => this.mapCardRow(row));
    } catch (error) {
      throw new Error(`Erro ao pesquisar cards: ${(error as Error).message}`);
    }
  }

    /**
     * Busca um card por ID (query mais eficiente que buscar todos e filtrar)
     */
    async getCardById(cardId: string): Promise<CRMCard | null> {
      try {
        const query = 'SELECT * FROM crm_cards WHERE id = $1';
        const result = await pool.query(query, [cardId]);
        if (result.rows.length === 0) return null;
        return this.mapCardRow(result.rows[0]);
      } catch (error) {
        throw new Error(`Erro ao buscar card por ID: ${(error as Error).message}`);
      }
    }

  /**
   * Adiciona anotação a um card
   */
  async addAnnotation(cardId: string, anotacao: string): Promise<CRMCard> {
    try {
      const query = `
        UPDATE crm_cards 
        SET anotacoes = anotacoes || chr(10) || $2,
            data_ultima_atualizacao = NOW()
        WHERE id = $1
        RETURNING *;
      `;

      const result = await pool.query(query, [cardId, anotacao]);

      if (result.rows.length === 0) {
        throw new Error(`Card com ID ${cardId} não encontrado.`);
      }

      return this.mapCardRow(result.rows[0]);
    } catch (error) {
      throw new Error(`Erro ao adicionar anotação: ${(error as Error).message}`);
    }
  }

  /**
   * Adiciona minuta/documento a um card
   */
  async addMinuta(cardId: string, minutaUrl: string): Promise<CRMCard> {
    try {
      const query = `
        UPDATE crm_cards 
        SET minutas = array_append(minutas, $2),
            data_ultima_atualizacao = NOW()
        WHERE id = $1
        RETURNING *;
      `;

      const result = await pool.query(query, [cardId, minutaUrl]);

      if (result.rows.length === 0) {
        throw new Error(`Card com ID ${cardId} não encontrado.`);
      }

      return this.mapCardRow(result.rows[0]);
    } catch (error) {
      throw new Error(`Erro ao adicionar minuta: ${(error as Error).message}`);
    }
  }

  /**
   * Deleta um card
   */
  async deleteCard(cardId: string): Promise<void> {
    try {
      const query = 'DELETE FROM crm_cards WHERE id = $1;';
      await pool.query(query, [cardId]);
      metricsService.recordRequest('crm.card.delete', 0);
    } catch (error) {
      metricsService.recordError('crm.card.delete');
      throw new Error(`Erro ao deletar card: ${(error as Error).message}`);
    }
  }

  /**
   * Obtém pipeline completo
   */
  async getPipeline(pipelineId: string): Promise<CRMPipeline | null> {
    try {
      const query = 'SELECT * FROM crm_pipelines WHERE id = $1;';
      const result = await pool.query(query, [pipelineId]);

      if (result.rows.length === 0) return null;

      return this.mapPipelineRow(result.rows[0]);
    } catch (error) {
      throw new Error(`Erro ao buscar pipeline: ${(error as Error).message}`);
    }
  }

  /**
   * Cria ou atualiza pipeline
   */
  async createOrUpdatePipeline(pipeline: Partial<CRMPipeline>): Promise<CRMPipeline> {
    try {
      const {
        id = `pipeline_${Date.now()}`,
        nome,
        configuracao,
      } = pipeline;

      const query = `
        INSERT INTO crm_pipelines (id, nome, configuracao, data_criacao)
        VALUES ($1, $2, $3, NOW())
        ON CONFLICT (id) DO UPDATE SET
          nome = EXCLUDED.nome,
          configuracao = EXCLUDED.configuracao
        RETURNING *;
      `;

      const result = await pool.query(query, [
        id,
        nome,
        JSON.stringify(configuracao || {}),
      ]);

      return this.mapPipelineRow(result.rows[0]);
    } catch (error) {
      throw new Error(`Erro ao criar/atualizar pipeline: ${(error as Error).message}`);
    }
  }

  /**
   * Mapeia linha do DB para objeto CRMCard
   */
  private mapCardRow(row: any): CRMCard {
    return {
      id: row.id,
      processoId: row.processo_id,
      cnj: row.cnj,
      titulo: row.titulo,
      partes: typeof row.partes === 'string' ? JSON.parse(row.partes) : row.partes,
      fase: row.fase as ProcessPhase,
      estagio: row.estagio,
      prazos: typeof row.prazos === 'string' ? JSON.parse(row.prazos) : row.prazos,
      status: row.status as CRMCard['status'],
      valor: row.valor,
      minutas: row.minutas || [],
      anotacoes: row.anotacoes,
      dataUltimaAtualizacao: row.data_ultima_atualizacao,
      responsavel: row.responsavel,
      autoAtomacoes: row.auto_automacoes ? JSON.parse(row.auto_automacoes) : undefined,
    };
  }

  private mapPipelineRow(row: any): CRMPipeline {
    return {
      id: row.id,
      nome: row.nome,
      fases: [],
      configuracao: typeof row.configuracao === 'string' ? JSON.parse(row.configuracao) : row.configuracao,
    };
  }
}

export const crmService = new CRMService();

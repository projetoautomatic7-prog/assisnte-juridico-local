import 'dotenv/config';
import { DjenPublication } from '../types';

import { fetchWithRetry } from './httpClient';
import { metricsService } from './metricsService';

class DjenService {
  private baseUrl: string;
  private intervalMs: number;
  private cache: Map<string, { data: DjenPublication[]; expires: number }>; 
  private ttlMs: number;

  constructor() {
    this.baseUrl = process.env.DJEN_BASE_URL || 'https://comunicaapi.pje.jus.br/api/v1';
    this.intervalMs = parseInt(process.env.DJEN_REQUEST_INTERVAL_MS || '1000', 10);
    this.ttlMs = parseInt(process.env.DJEN_CACHE_TTL_MS || '900000', 10); // default 15m
    this.cache = new Map();
  }

  private sleep(ms: number) { return new Promise(r => setTimeout(r, ms)); }

  private extractEntities(text: string): { advogados: string[]; oabs: Array<{ uf?: string; numero: string }> } {
    const advogados: Set<string> = new Set();
    const oabs: Map<string, { uf?: string; numero: string }> = new Map();

    if (!text) return { advogados: [], oabs: [] };
    // Normalizamos espaços múltiplos
    const normalized = text.replace(/\s+/g, ' ');

  // Captura nomes após "Advogado" ou "Advogada" (permitindo conectores como de/da/do/dos/das/e)
  const ADV_REGEX = /Advogad[oa]\s+([A-ZÁÉÍÓÚÃÕÂÊÔ][\wÁÉÍÓÚÃÕÂÊÔçãõâêôüïëÿ'`-]+(?:\s+(?:[dD]e|[dD]a|[dD]o|[dD]as|[dD]os|e)\s+[A-ZÁÉÍÓÚÃÕÂÊÔ][\wÁÉÍÓÚÃÕÂÊÔçãõâêôüïëÿ'`-]+|\s+[A-ZÁÉÍÓÚÃÕÂÊÔ][\wÁÉÍÓÚÃÕÂÊÔçãõâêôüïëÿ'`-]+){0,5})/g;
    let advMatch: RegExpExecArray | null;
    while ((advMatch = ADV_REGEX.exec(normalized)) !== null) {
      let nome = advMatch[1].trim();
      // Remove qualquer sufixo iniciando em OAB para evitar captura de registro
      nome = nome.replace(/\s+OAB.*$/i, '').trim();
      if (nome.length > 2) advogados.add(nome);
    }

    // Captura padrões de OAB: OAB/MG 184404, OAB MG 184404, OAB/SP123456
    const OAB_REGEX = /OAB\s*(?:\/?\s*([A-Z]{2}))?\s*([A-Z]{2})?\s*(\d{3,7})/g;
    let oabMatch: RegExpExecArray | null;
    while ((oabMatch = OAB_REGEX.exec(normalized)) !== null) {
      // Grupos possíveis: 1 ou 2 podem ser UF; prioriza último não numérico de 2 letras
      const g1 = oabMatch[1];
      const g2 = oabMatch[2];
      const numero = oabMatch[3];
      let uf: string | undefined = undefined;
      if (g2 && /^[A-Z]{2}$/.test(g2)) uf = g2; else if (g1 && /^[A-Z]{2}$/.test(g1)) uf = g1;
      const key = (uf ? uf + '-' : '') + numero;
      if (!oabs.has(key)) oabs.set(key, { uf, numero });
    }

    return { advogados: Array.from(advogados), oabs: Array.from(oabs.values()) };
  }

  async search(date: string, tribunals: string[], terms: string[]): Promise<DjenPublication[]> {
    const cacheKey = `${date}|${tribunals.sort().join(',')}|${terms.sort().join(',')}`;
    const cached = this.cache.get(cacheKey);
    const now = Date.now();
    if (cached && cached.expires > now) {
      metricsService.hitCache('djen');
      console.debug(`[DJEN] date=${date} tribunals=${tribunals.join(',')} terms=${terms.join(',')} cache=true`);
      return cached.data;
    }
    metricsService.missCache('djen');
    const results: DjenPublication[] = [];
    
    const searchTerms = terms.map(t => t.trim().toLowerCase()).filter(t => t.length > 0);
    if (searchTerms.length === 0) {
      console.warn('[DJEN] Nenhum termo de busca fornecido');
      return results;
    }
    
    for (const tribunal of tribunals) {
      const url = `${this.baseUrl}/caderno/${tribunal}/${date}`;
      try {
        const started = Date.now();
        const resp = await fetchWithRetry(url, { headers: { 'Accept': 'application/json', 'User-Agent': 'PJe-Assistant/1.0' } }, { retries: 3, baseDelayMs: 300, factor: 2, timeoutMs: 60000 });
        if (!resp.ok) {
          console.warn(`DJEN ${tribunal} ${date} => ${resp.status}`);
          metricsService.recordError('djen');
          continue;
        }
        const data = await resp.json() as any;
        const publications = Array.isArray(data) ? data : data.documentos || [];
        const elapsed = Date.now() - started;
        metricsService.recordRequest('djen', elapsed);
        console.debug(`[DJEN] tribunal=${tribunal} date=${date} ms=${elapsed} docs=${publications.length} cache=false`);
        
        if (Array.isArray(publications)) {
          for (const pub of publications) {
            const conteudo = pub.inteiro_teor || pub.ementa || pub.descricao || '';
            if (!conteudo) continue;
            
            const extracted = this.extractEntities(conteudo);
            const contentLower = conteudo.toLowerCase();
            
            const hasSearchTerm = searchTerms.some(term => {
              if (extracted.advogados.some(adv => adv.toLowerCase().includes(term))) return true;
              if (extracted.oabs.some(oab => oab.numero.includes(term.replace(/\D/g, '')))) return true;
              return contentLower.includes(term);
            });
            
            if (hasSearchTerm) {
              results.push({
                tribunal,
                dataPublicacao: pub.data_disponibilizacao || pub.dataPublicacao || date,
                tipo: pub.tipo_comunicacao || pub.tipo || 'Publicação',
                conteudo,
                advogados: extracted.advogados,
                oabs: extracted.oabs
              });
            }
          }
        }
      } catch (e) {
        console.error(`Erro DJEN tribunal=${tribunal}:`, (e as Error).message);
        metricsService.recordError('djen');
      }
      await this.sleep(this.intervalMs);
    }
    this.cache.set(cacheKey, { data: results, expires: Date.now() + this.ttlMs });
    return results;
  }
}

export const djenService = new DjenService();
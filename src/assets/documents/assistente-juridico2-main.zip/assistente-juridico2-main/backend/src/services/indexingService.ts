import { execSync } from 'child_process';

// Avoid top-level import from @xenova to keep Jest happy (ESM vs CJS)

// Configure transformers.js to not attempt to download models from the internet in production environments
// and to use local models. This is handled lazily in the constructor to avoid Jest ESM issues.

interface GPUInfo {
  available: boolean;
  type: 'cuda' | 'cudnn' | 'wsl2-cuda' | 'metal' | 'vulkan' | 'none';
  details: string;
}

class IndexingService {
    private gpuInfo: GPUInfo | null = null;
    
    constructor() {
        this.detectGPU();
        // Lazy-set env configuration for transformers
        (async () => {
            try {
                const { env } = await import('@xenova/transformers');
                env.allowLocalModels = true;
                env.allowRemoteModels = process.env.NODE_ENV === 'development';
            } catch (e) {
                // If import fails (tests), just ignore the configuration
                console.warn('⚠️  Não foi possível importar @xenova/transformers durante a inicialização: ', e instanceof Error ? e.message : e);
            }
        })();
    }

    /**
     * Detecta disponibilidade de GPU para aceleração de embeddings
     * Suporta: CUDA, cuDNN, WSL2+CUDA, Metal (Mac), Vulkan
     */
    private detectGPU(): void {
        try {
            console.log('🔍 Detectando suporte a GPU...');

            // 1. Verificar CUDA (Linux/Windows)
            try {
                const nvidiaSmi = execSync('nvidia-smi --query-gpu=compute_cap --format=csv,noheader', { encoding: 'utf-8' }).trim();
                if (nvidiaSmi) {
                    this.gpuInfo = {
                        available: true,
                        type: 'cuda',
                        details: `NVIDIA CUDA disponível - Compute Capability: ${nvidiaSmi}`
                    };
                    console.log('✅ GPU CUDA detectada:', nvidiaSmi);
                    return;
                }
            } catch (e) {
                // nvidia-smi não encontrada
            }

            // 2. Verificar WSL2 + CUDA
            try {
                const wslCheck = execSync('grep -i wsl /proc/version', { encoding: 'utf-8', stdio: ['pipe', 'pipe', 'ignore'] }).trim();
                if (wslCheck) {
                    try {
                        const cudaCheck = execSync('nvidia-smi --list-gpus', { encoding: 'utf-8' }).trim();
                        if (cudaCheck) {
                            this.gpuInfo = {
                                available: true,
                                type: 'wsl2-cuda',
                                details: `WSL2 com CUDA - ${cudaCheck}`
                            };
                            console.log('✅ GPU WSL2+CUDA detectada:', cudaCheck);
                            return;
                        }
                    } catch (e) {
                        // CUDA não disponível em WSL2
                    }
                }
            } catch (e) {
                // Não é WSL2
            }

            // 3. Verificar Metal (macOS)
            try {
                const metalCheck = execSync('system_profiler SPDisplaysDataType | grep Metal', { encoding: 'utf-8', stdio: ['pipe', 'pipe', 'ignore'] }).trim();
                if (metalCheck) {
                    this.gpuInfo = {
                        available: true,
                        type: 'metal',
                        details: 'Metal GPU disponível (macOS)'
                    };
                    console.log('✅ GPU Metal detectada (macOS)');
                    return;
                }
            } catch (e) {
                // Não é macOS ou Metal não disponível
            }

            // 4. Fallback: Sem GPU
            this.gpuInfo = {
                available: false,
                type: 'none',
                details: 'GPU não detectada - usando CPU para embeddings'
            };
            console.log('⚠️  GPU não detectada - modo CPU');
        } catch (error) {
            console.warn('⚠️  Erro ao detectar GPU:', error instanceof Error ? error.message : error);
            this.gpuInfo = {
                available: false,
                type: 'none',
                details: 'Erro na detecção - modo CPU'
            };
        }
    }

    /**
     * Obtém informações sobre GPU
     */
    public getGPUInfo(): GPUInfo {
        return this.gpuInfo || { available: false, type: 'none', details: 'Não inicializado' };
    }

    /**
     * Chunking de texto com suporte a parametrização
     */
    public async processAndChunkText(text: string, chunkSize = 500, overlap = 50): Promise<string[]> {
        const chunks: string[] = [];
        for (let i = 0; i < text.length; i += chunkSize - overlap) {
            chunks.push(text.substring(i, i + chunkSize));
        }
        return chunks;
    }

    /**
     * Gera embeddings com suporte a GPU
     * Processa em lotes se muitos documentos (optimização para GPU)
     */
    public async generateEmbeddings(texts: string[], batchSize = 32): Promise<number[][]> {
        try {
            const gpuInfo = this.getGPUInfo();
            console.log(`📊 Gerando embeddings (${texts.length} textos) - GPU: ${gpuInfo.type}`);

            // 'pipeline' will create an instance of the feature-extraction pipeline
            // The model 'Xenova/all-MiniLM-L6-v2' é bom para similaridade semântica
            // Será baixado na primeira execução se não estiver disponível localmente
            // Lazily import to avoid Jest ESM parsing issues and to allow mocking
            const { pipeline } = await import('@xenova/transformers');
            const extractor = await pipeline('feature-extraction', 'Xenova/all-MiniLM-L6-v2');
            
            const embeddings: number[][] = [];
            
            // Processar em lotes para otimizar memória em GPUs
            for (let i = 0; i < texts.length; i += batchSize) {
                const batch = texts.slice(i, i + batchSize);
                const batchEmbeddings = await Promise.all(
                    batch.map(async (text): Promise<number[]> => {
                        const result = await extractor(text, { pooling: 'mean', normalize: true });
                        return Array.from(result.data as any);
                    })
                );
                embeddings.push(...batchEmbeddings);
                
                // Log de progresso para lotes grandes
                if (texts.length > batchSize) {
                    console.log(`  ↳ Processados ${Math.min(i + batchSize, texts.length)}/${texts.length} textos`);
                }
            }
            
            console.log(`✅ Embeddings gerados com sucesso (${embeddings.length} vetores)`);
            return embeddings;

        } catch (error) {
            console.error("❌ Falha ao gerar embeddings:", error);
            throw new Error(
                "Não foi possível carregar o modelo de IA para processamento de texto. " +
                "Verifique a conexão com a internet ou os modelos locais."
            );
        }
    }
}

export const indexingService = new IndexingService();
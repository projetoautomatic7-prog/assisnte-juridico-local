// Do not import vectorStoreService at top-level because it triggers
// the lazy initialization of `indexingService` which imports ESM modules.
// Each test will import the module dynamically after applying mocks.

// Explicitly require the manual mock via path to avoid ESM/CJS resolution issues
jest.mock('chromadb-client');
// Mock indexingService with the expected named export shape
jest.mock('../indexingService', () => ({
  indexingService: {
    generateEmbeddings: jest.fn(async (texts: string[]) => texts.map(() => [0.123, 0.456]))
  }
}));

describe('VectorStoreService', () => {
  beforeEach(async () => {
    // reset modules to ensure mock state is clean
    jest.resetModules();
  });

  it('should add documents to the collection when CHROMA_URL is set', async () => {
    process.env.CHROMA_URL = 'http://mock';

    // Re-import after setting env
    const { vectorStoreService } = await import('../vectorStoreService');
    // Access the manual mock via jest.requireMock so we can inspect lastAdd
    const chroma = jest.requireMock('chromadb-client');

    await vectorStoreService.addDocuments([
      { pageContent: 'doc1', metadata: { id: 'a' } },
      { pageContent: 'doc2', metadata: { id: 'b' } },
    ]);

    // __mocks__/chromadb-client.js exports lastAdd (node caches), so import again
    const { state } = chroma;
    const lastAdd = state.lastAdd;
    expect(lastAdd).not.toBeNull();
    expect(lastAdd.documents.length).toBe(2);
  });

  it('should return search results when collection query returns results', async () => {
    process.env.CHROMA_URL = 'http://mock';
    const { vectorStoreService } = await import('../vectorStoreService');

    const results = await vectorStoreService.search('hello', 2);
    expect(Array.isArray(results)).toBe(true);
    // our mock returns 2 documents
    expect(results.length).toBe(2);
    expect(results[0]).toHaveProperty('pageContent');
    expect(results[0]).toHaveProperty('metadata');
  });
});

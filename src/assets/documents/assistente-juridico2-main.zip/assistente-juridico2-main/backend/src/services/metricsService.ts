class MetricsService {
    hitCache(serviceName: string) {
        console.log(`[Metrics] Cache HIT for ${serviceName}`);
    }

    missCache(serviceName: string) {
        console.log(`[Metrics] Cache MISS for ${serviceName}`);
    }

    recordError(serviceName: string) {
        console.log(`[Metrics] Error recorded for ${serviceName}`);
    }

    recordRequest(serviceName: string, durationMs: number) {
        console.log(`[Metrics] Request for ${serviceName} took ${durationMs}ms`);
    }
}

export const metricsService = new MetricsService();

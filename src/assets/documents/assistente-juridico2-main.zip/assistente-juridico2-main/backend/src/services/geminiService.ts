import { GoogleGenAI, Type, Modality } from "@google/genai";
import 'dotenv/config';

class GeminiService {
    private ai?: GoogleGenAI;

    constructor() {
        const apiKey = process.env.API_KEY;
        if (!apiKey) {
            // Do not throw during module import – tests may mock this service.
            console.warn("API_KEY do Gemini não encontrada nas variáveis de ambiente. GeminiService estará desativado para testes.");
            this.ai = undefined;
            return;
        }
        this.ai = new GoogleGenAI({ apiKey });
    }

    public async analyzeNotificationContent(content: string) {
        const analysisPrompt = `Você é um assistente jurídico sênior especialista em PJe. Analise o expediente abaixo.
        1. Extraia o prazo em dias e o tipo (ex: "15 dias úteis"). Se não houver, retorne "N/A".
        2. Crie um resumo jurídico de uma frase.
        3. Determine a próxima ação necessária e classifique-a como: 'SIMPLE_REPLY', 'DRAFT_RESPONSE', ou 'HUMAN_REVIEW'.
        4. Identifique se algum documento essencial para a próxima ação parece estar faltando (ex: procuração, comprovante de pagamento, contrato). Se sim, liste os documentos necessários. Se não, retorne um array vazio.
        Responda em JSON.
        Expediente: "${content}"`;
        
        if (!this.ai) throw new Error('Gemini API não configurada (API_KEY faltando)');
        if (!this.ai) throw new Error('Gemini API não configurada (API_KEY faltando)');
        const response = await this.ai.models.generateContent({
            model: 'gemini-2.5-pro',
            contents: analysisPrompt,
            config: { 
                responseMimeType: 'application/json', 
                responseSchema: { 
                    type: Type.OBJECT, 
                    properties: { 
                        prazo: { type: Type.STRING }, 
                        resumo: { type: Type.STRING }, 
                        classificacao_acao: { type: Type.STRING },
                        documentos_necessarios: { 
                            type: Type.ARRAY, 
                            items: { type: Type.STRING },
                            description: "Lista de documentos que precisam ser providenciados."
                        }
                    },
                    required: ["prazo", "resumo", "classificacao_acao", "documentos_necessarios"]
                } 
            }
        });

        const text = response.text;
        if (!text || text.trim() === '') {
            throw new Error("A resposta da IA estava vazia ou inválida.");
        }

        try {
            const parsed = JSON.parse(text);
            return {
                deadline: parsed.prazo,
                summary: parsed.resumo,
                actionClassification: parsed.classificacao_acao,
                requiredDocuments: parsed.documentos_necessarios || [],
            };
        } catch (e) {
            console.error("Falha ao parsear JSON da IA:", text);
            throw new Error("A resposta da IA não estava no formato JSON esperado. Conteúdo recebido: " + text);
        }
    }

    public async draftLegalDocument(content: string, summary: string) {
         const draftPrompt = `Com base no expediente "${content}", redija uma minuta de petição profissional para a seguinte ação: ${summary}. Seja técnico e objetivo.`;
         if (!this.ai) throw new Error('Gemini API não configurada (API_KEY faltando)');
         if (!this.ai) throw new Error('Gemini API não configurada (API_KEY faltando)');
         const response = await this.ai.models.generateContent({ model: 'gemini-2.5-pro', contents: draftPrompt });
         return response.text;
    }

    public async checkHealth(): Promise<boolean> {
        try {
            if (!this.ai) return false;
            if (!this.ai) return false;
            const response = await this.ai.models.generateContent({ model: 'gemini-2.5-flash', contents: "Health check" });
            return !!response.text;
        } catch (error) {
            console.error("Gemini health check failed:", error);
            return false;
        }
    }
    
    public async generateText(prompt: string, model: string = 'gemini-2.5-flash') {
         try {
             if (!this.ai) throw new Error('Gemini API não configurada (API_KEY faltando)');
             if (!this.ai) throw new Error('Gemini API não configurada (API_KEY faltando)');
             const response = await this.ai.models.generateContent({ model, contents: prompt });
             if (!response?.text) throw new Error('Resposta vazia do Gemini');
             return response.text;
         } catch (error) {
             console.error('Gemini generateText failed:', error);
             throw new Error('Erro ao gerar texto com Gemini: ' + (error as Error).message);
         }
    }

    public async generateJson(prompt: string, schema: any, model: string = 'gemini-2.5-pro') {
        try {
            if (!this.ai) throw new Error('Gemini API não configurada (API_KEY faltando)');
            if (!this.ai) throw new Error('Gemini API não configurada (API_KEY faltando)');
            const response = await this.ai.models.generateContent({
            model,
            contents: prompt,
            config: {
                responseMimeType: 'application/json',
                responseSchema: schema
            }
        });
            if (!response?.text) throw new Error('Resposta vazia do Gemini');
            return response.text;
        } catch (error) {
            console.error('Gemini generateJson failed:', error);
            throw new Error('Erro ao gerar JSON com Gemini: ' + (error as Error).message);
        }
    }

    public async continueConversation(history: any[], message: string) {
        if (!this.ai) throw new Error('Gemini API não configurada (API_KEY faltando)');
        const chat = this.ai.chats.create({ model: 'gemini-2.5-flash', history });
        const response = await chat.sendMessage({ message });
        return response.text;
    }

    public async generateImage(prompt: string) {
        if (!this.ai) throw new Error('Gemini API não configurada (API_KEY faltando)');
        const response = await this.ai.models.generateImages({
            model: 'imagen-4.0-generate-001',
            prompt: prompt,
            config: {
                numberOfImages: 1,
                outputMimeType: 'image/png',
            },
        });
        if (!response.generatedImages || !response.generatedImages[0]?.image?.imageBytes) {
            throw new Error('No image generated');
        }
        return response.generatedImages[0].image.imageBytes;
    }

    public async editImage(prompt: string, image: { data: string, mimeType: string }) {
        const imagePart = {
            inlineData: {
                data: image.data,
                mimeType: image.mimeType,
            },
        };
        const textPart = { text: prompt };
        if (!this.ai) throw new Error('Gemini API não configurada (API_KEY faltando)');
        if (!this.ai) throw new Error('Gemini API não configurada (API_KEY faltando)');
        const response = await this.ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: { parts: [imagePart, textPart] },
            config: {
                responseModalities: [Modality.IMAGE],
            },
        });
        const part = response.candidates?.[0]?.content?.parts?.[0];
        if (part && part.inlineData) {
            return part.inlineData.data;
        }
        throw new Error('Não foi possível editar a imagem.');
    }

    public async transcribeAudio(file: { data: string, mimeType: string }): Promise<string> {
        const audioPart = {
            inlineData: {
                data: file.data,
                mimeType: file.mimeType,
            },
        };
        const textPart = { text: "Transcribe this audio file." };
        if (!this.ai) throw new Error('Gemini API não configurada (API_KEY faltando)');
        if (!this.ai) throw new Error('Gemini API não configurada (API_KEY faltando)');
        if (!this.ai) throw new Error('Gemini API não configurada (API_KEY faltando)');
        const response = await this.ai.models.generateContent({
            model: 'gemini-2.5-pro',
            contents: { parts: [audioPart, textPart] },
        });

        const text = response.text;
        if (!text) {
            throw new Error('Failed to get transcription from Gemini response.');
        }
        return text;
    }

    public async analyzePjeErrorScreen(screenshotBase64: string, pageText: string): Promise<{ status: string, recommendation: string }> {
        const imagePart = { inlineData: { mimeType: 'image/png', data: screenshotBase64 } };
        const textPart = { text: `Analyze this PJe error screen. The page text is: "${pageText}". What is the likely problem and what should the user do next? Respond in JSON with 'status' and 'recommendation' fields.`};
        
        if (!this.ai) throw new Error('Gemini API não configurada (API_KEY faltando)');
        const response = await this.ai.models.generateContent({
            model: 'gemini-2.5-pro',
            contents: { parts: [imagePart, textPart] },
            config: {
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        status: { type: Type.STRING },
                        recommendation: { type: Type.STRING }
                    }
                }
            }
        });
        if (!response.text) {
            throw new Error('No text response from Gemini');
        }
        return JSON.parse(response.text);
    }

    public async extractFinancialDataFromFile(file: { data: string, mimeType: string }): Promise<any> {
        const filePart = { inlineData: { data: file.data, mimeType: file.mimeType } };
        const prompt = `Analyze this document (invoice, contract, receipt) and extract key financial information. Specifically, look for:
        - A brief description of the service or item.
        - The total amount.
        - Any associated lawsuit number (CNJ format).
        Respond ONLY with a JSON object containing 'description', 'amount', and 'processo_cnj'. If a field is not found, its value should be null.`;

        const schema = {
            type: Type.OBJECT,
            properties: {
                description: { type: Type.STRING },
                amount: { type: Type.NUMBER },
                processo_cnj: { type: Type.STRING },
            },
        };

        if (!this.ai) throw new Error('Gemini API não configurada (API_KEY faltando)');
        const response = await this.ai.models.generateContent({
            model: 'gemini-2.5-pro',
            contents: { parts: [filePart, { text: prompt }] },
            config: {
                responseMimeType: 'application/json',
                responseSchema: schema,
            },
        });

        const text = response.text;
        if (!text) {
            throw new Error('Could not extract financial data from the document.');
        }
        return JSON.parse(text);
    }
}

export const geminiService = new GeminiService();
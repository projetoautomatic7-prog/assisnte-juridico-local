import { Buffer } from 'buffer';
import { IncomingMessage } from 'http';

import { GoogleGenAI, Session, LiveServerMessage, Modality, Blob } from '@google/genai';
import { WebSocketServer, WebSocket } from 'ws';

class AudioProxyService {
    private wss!: WebSocketServer;
    private ai: GoogleGenAI;

    constructor() {
        // AI client is initialized here, but wss is initialized in the initialize method
        const apiKey = process.env.API_KEY;
        if (!apiKey) {
            throw new Error("API_KEY do Gemini não encontrada.");
        }
        this.ai = new GoogleGenAI({ apiKey });
    }
    
    public initialize() {
        this.wss = new WebSocketServer({ noServer: true });
        this.wss.on('connection', this.handleConnection.bind(this));
    }

    private async handleConnection(ws: WebSocket, request: IncomingMessage) {
        console.log('Cliente conectado ao proxy de áudio.');

        let geminiSession: Session | null = null;

        try {
            geminiSession = await this.ai.live.connect({
                model: 'gemini-2.5-flash-native-audio-preview-09-2025',
                config: {
                    responseModalities: [Modality.AUDIO], // Required by the API for transcription
                    inputAudioTranscription: {},
                },
                callbacks: {
                    onopen: () => console.log('Sessão Gemini Live aberta para um cliente.'),
                    onmessage: (message: LiveServerMessage) => {
                        if (ws.readyState === WebSocket.OPEN) {
                            ws.send(JSON.stringify({ type: 'gemini_message', payload: message }));
                        }
                    },
                    onerror: (e: any) => { // Use 'any' as ErrorEvent is not standard in Node
                        console.error('Erro na sessão Gemini Live:', e.message);
                        if (ws.readyState === WebSocket.OPEN) {
                            ws.send(JSON.stringify({ type: 'gemini_error', payload: { message: e.message } }));
                        }
                    },
                    onclose: () => {
                        console.log('Sessão Gemini Live fechada.');
                        if (ws.readyState === WebSocket.OPEN) {
                            ws.close();
                        }
                    },
                }
            });

            ws.on('message', (message: Buffer) => {
                try {
                    const parsedMessage = JSON.parse(message.toString());
                    if (parsedMessage.type === 'audio_chunk' && geminiSession) {
                        const pcmBlob: Blob = parsedMessage.payload;
                        geminiSession.sendRealtimeInput({ media: pcmBlob });
                    }
                } catch (e) {
                    console.error('Falha ao parsear mensagem do cliente de áudio:', e);
                }
            });

            ws.on('close', () => {
                console.log('Cliente de áudio desconectado. Fechando sessão Gemini.');
                geminiSession?.close();
            });

        } catch (error) {
            console.error('Falha ao estabelecer sessão Gemini Live:', error);
            ws.send(JSON.stringify({ type: 'error', payload: { message: 'Falha ao conectar ao serviço de IA.' } }));
            ws.close();
        }
    }
    
    public getWss(): WebSocketServer {
        return this.wss;
    }
}

export const audioProxyService = new AudioProxyService();
import { metricsService } from '../metricsService';

describe('metricsService', () => {
  const originalLog = console.log;
  let logs: string[];

  beforeEach(() => {
    logs = [];
    console.log = (msg?: any) => { logs.push(String(msg)); };
  });

  afterEach(() => {
    console.log = originalLog;
  });

  it('records cache hits and misses', () => {
    metricsService.hitCache('test-service');
    metricsService.missCache('test-service');
    expect(logs.some(l => l.includes('Cache HIT'))).toBe(true);
    expect(logs.some(l => l.includes('Cache MISS'))).toBe(true);
  });

  it('records errors and request timings', () => {
    metricsService.recordError('svc');
    metricsService.recordRequest('svc', 42);
    expect(logs.some(l => l.includes('Error recorded'))).toBe(true);
    expect(logs.some(l => l.includes('took 42ms'))).toBe(true);
  });
});

import 'dotenv/config';
import { fetchWithRetry, NodeFetchResponse } from './httpClient';
import { metricsService } from './metricsService';

export interface DatajudProcesso {
  numeroCNJ: string;
  tribunal: string;
  classe?: string;
  assunto?: string;
  partes?: Array<{ polo: 'ativo' | 'passivo' | string; nome: string }>;
  movimentos?: Array<{ data: string; descricao: string }>;
  bruto?: any;
}

class DatajudService {
  private baseUrl: string;
  private apiKey?: string;
  private cache: Map<string, { data: DatajudProcesso | null; expires: number }>; 
  private ttlMs: number;

  constructor() {
    this.baseUrl = process.env.DATAJUD_BASE_URL || 'https://api-publica.datajud.cnj.jus.br';
    this.apiKey = process.env.DATAJUD_API_KEY;
    this.ttlMs = parseInt(process.env.DATAJUD_CACHE_TTL_MS || '300000', 10); // default 5m
    this.cache = new Map();
  }

  private buildHeaders() {
    if (!this.apiKey) throw new Error('DATAJUD_API_KEY não configurada no ambiente.');
    const headers: Record<string, string> = {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Authorization': `APIKey ${this.apiKey}`,
      'User-Agent': 'PJe-Assistant/1.0'
    };
    return headers;
  }

  private tribunalAlias(tribunal: string) {
    const norm = (tribunal || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    return `api_publica_${norm}`; // ex: trf1 -> api_publica_trf1, tjmg -> api_publica_tjmg
  }

  async searchByCNJ(cnj: string, tribunal: string) : Promise<DatajudProcesso | null> {
    const key = `${cnj}|${tribunal}`.toLowerCase();
    const now = Date.now();
    const cached = this.cache.get(key);
    if (cached && cached.expires > now) {
      metricsService.hitCache('datajud');
      return cached.data ? { ...cached.data } : null;
    }
    metricsService.missCache('datajud');
    if (!this.apiKey) {
      throw new Error('DATAJUD_API_KEY não configurada no ambiente.');
    }
    const alias = this.tribunalAlias(tribunal);
    const url = `${this.baseUrl}/${alias}/_search`;
    const body = {
      query: { match: { numeroProcesso: cnj } },
      size: 1
    };
    const started = Date.now();
    let resp: NodeFetchResponse;
    try {
      resp = await fetchWithRetry(url, { method: 'POST', headers: this.buildHeaders(), body: JSON.stringify(body) }, { retries: 3, baseDelayMs: 300, factor: 2, timeoutMs: 60000 });
    } catch (e) {
      metricsService.recordError('datajud');
      throw e;
    }
    if (!resp.ok) {
      if (resp.status === 404) return null;
      metricsService.recordError('datajud');
      throw new Error(`Falha ao consultar DataJud: ${resp.status} ${resp.statusText}`);
    }
    const elapsed = Date.now() - started;
    metricsService.recordRequest('datajud', elapsed);
    console.debug(`[DataJud] ${cnj} tribunal=${tribunal} ms=${elapsed} cache=false`);
    const json: any = await resp.json();
    // Suporta formato Elasticsearch (hits.hits) ou fallback (dados[])
    let item: any = null;
    if (json?.hits?.hits && Array.isArray(json.hits.hits) && json.hits.hits.length) {
      item = json.hits.hits[0]._source || json.hits.hits[0];
    } else if (Array.isArray(json?.dados) && json.dados.length) {
      item = json.dados[0];
    }
    if (!item) {
      this.cache.set(key, { data: null, expires: now + this.ttlMs });
      return null;
    }
    const mapped: DatajudProcesso = {
      numeroCNJ: cnj,
      tribunal,
      classe: item?.classe?.nome || item?.classe || item?.classeProcessual || undefined,
      assunto: Array.isArray(item?.assuntos) ? item.assuntos.map((a: any) => a?.nome).filter(Boolean).join(', ') : (item?.assunto || undefined),
      movimentos: item?.movimentos || [],
      bruto: item
    };
    this.cache.set(key, { data: mapped, expires: now + this.ttlMs });
    return { ...mapped };
  }
}

export const datajudService = new DatajudService();
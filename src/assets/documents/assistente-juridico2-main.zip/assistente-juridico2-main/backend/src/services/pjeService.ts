import chromium from '@sparticuz/chromium';
import puppeteer, { Browser, Page } from 'puppeteer-core';

import 'dotenv/config';
import { taskRepo } from '../agent/repos';
import { ProcessedNotification, Processo, Expediente, Audiencia, PremonicaoJuridica } from '../types';
import { webSocketService } from '../websocketService';

import { pool } from './db';
import { geminiService } from './geminiService';


const SELECTORS = {
    loginField: '#username',
    passwordField: '#password',
    loginButton: 'button[type="submit"]',
    twoFactorCodeInput: '#token',
    twoFactorSubmitButton: 'button[type="submit"]',
    deviceNameInput: 'input[placeholder*="dispositivo"], input[placeholder*="device"], input[name*="device"]',
    configureDeviceButton: 'button:has-text("Configurar"), button:has-text("Configure")',
    dashboardElement: '#painel-advogado', 
    notificationsPanel: '#div-avisos-geral', 
    notificationItems: '.item-aviso-geral',
    notificationContent: '.rich-messages-label',
    notificationCnj: 'a[id*="numeroProcesso"]',
};

class PjeService {
    private browser: Browser | null = null;
    private page: Page | null = null;
    private robotStatus: 'inactive' | 'running' | 'connecting' | 'error' | 'paused' = 'inactive';
    private monitoringTimeout: ReturnType<typeof setTimeout> | null = null;
    private processedIds = new Set<string>();
    private humanIsActive = false;
    private isPausedByHuman = false;
    
    private pjeLogin = '';
    private pjePassword = '';

    public setCredentials(login: string, password: string) {
        this.pjeLogin = login;
        this.pjePassword = password;
    }

    public setHumanActivity(isActive: boolean) {
        this.humanIsActive = isActive;
        if (isActive) {
            this.pauseMonitoring();
        } else {
            this.resumeMonitoring();
        }
    }

    private pauseMonitoring() {
        if (this.robotStatus !== 'running') return;
        this.isPausedByHuman = true;
        this.robotStatus = 'paused';
        if (this.monitoringTimeout) {
            clearTimeout(this.monitoringTimeout);
            this.monitoringTimeout = null;
        }
        this.log('Monitoramento pausado devido à atividade do usuário.', 'warn');
        webSocketService.broadcast('status', { robotStatus: 'paused' });
    }

    private resumeMonitoring() {
        if (this.robotStatus !== 'paused' || !this.isPausedByHuman) return;
        this.isPausedByHuman = false;
        this.robotStatus = 'running';
        this.log('Usuário inativo. Retomando monitoramento automático.', 'info');
        webSocketService.broadcast('status', { robotStatus: 'running' });
        this.monitoringLoop();
    }

    public async connect() {
        if (this.robotStatus === 'connecting' || this.robotStatus === 'running') {
            this.log('Robô já está conectado ou em execução.', 'warn');
            return;
        }
        
        try {
            this.robotStatus = 'connecting';
            webSocketService.broadcast('status', { robotStatus: 'connecting', sessionStatus: 'connecting' });
            this.log('Iniciando navegador...', 'info', 'LAUNCHING_BROWSER');
            this.browser = await puppeteer.launch({
                args: chromium.args,
                executablePath: await chromium.executablePath(),
            });
            this.page = await this.browser.newPage();
            await this.page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36');
            
            const loginStatus = await this.login();
            
            if (loginStatus === 'success') {
                this.robotStatus = 'inactive';
                webSocketService.broadcast('status', { robotStatus: 'inactive', sessionStatus: 'active' });
            }
        } catch (error) {
            console.error('Falha ao conectar:', error);
            this.log(`Erro ao conectar: ${(error as Error).message}`, 'fatal');
            webSocketService.broadcast('status', { robotStatus: 'error', sessionStatus: 'disconnected' });
            await this.disconnect();
        }
    }

    public startMonitoring() {
        if (this.robotStatus !== 'inactive' || !this.page) {
            this.log('Robô precisa estar conectado e inativo para iniciar.', 'warn');
            return;
        }
        if (this.humanIsActive) {
            this.robotStatus = 'paused';
            this.isPausedByHuman = true;
            webSocketService.broadcast('status', { robotStatus: 'paused' });
            this.log('Usuário está ativo. Robô iniciará em modo pausado.', 'warn');
            return;
        }
        this.robotStatus = 'running';
        webSocketService.broadcast('status', { robotStatus: 'running' });
        this.log('Monitoramento 24/7 iniciado.', 'success');
        this.monitoringLoop();
    }
    
    public stopMonitoring() {
        this.isPausedByHuman = false;
        if (this.robotStatus !== 'running' && this.robotStatus !== 'paused') return;
        const wasPaused = this.robotStatus === 'paused';
        this.robotStatus = 'inactive';
        if (this.monitoringTimeout) clearTimeout(this.monitoringTimeout);
        this.monitoringTimeout = null;
        webSocketService.broadcast('status', { robotStatus: 'inactive' });
        if (!wasPaused) this.log('Monitoramento parado pelo usuário.', 'warn');
    }

    public async disconnect() {
        this.stopMonitoring();
        this.log('Desconectando...', 'info');
        await this.browser?.close();
        this.browser = null;
        this.page = null;
        this.robotStatus = 'inactive';
        this.processedIds.clear();
        webSocketService.broadcast('status', { robotStatus: 'inactive', sessionStatus: 'disconnected' });
        this.log('Robô desconectado com segurança.', 'info');
    }
    
    public async submit2FA(code: string) {
        if (!this.page || this.robotStatus !== 'connecting') throw new Error('Estado inválido do robô para 2FA.');
        try {
            this.log('Recebido código 2FA. Processando...', 'info');
            
            // Verifica se ainda está na tela de "Configurar novo dispositivo"
            const configDeviceHeader = await this.page.$('h2:has-text("Configurar novo dispositivo"), h2:has-text("Configure Device")');
            if (configDeviceHeader) {
                this.log('Ainda está na tela de configuração. Completando...', 'info');
                await this.handleConfigureNewDevice();
                await new Promise(resolve => setTimeout(resolve, 1500));
            }
            
            // Aguarda e preenche o código 2FA
            this.log('Aguardando campo de código 2FA...', 'info');
            await this.page.waitForSelector(SELECTORS.twoFactorCodeInput, { visible: true, timeout: 10000 });
            await this.page.type(SELECTORS.twoFactorCodeInput, code);
            
            this.log('Submetendo código 2FA...', 'info');
            await Promise.all([
                this.page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 60000 }),
                this.page.click(SELECTORS.twoFactorSubmitButton)
            ]);
            
            this.log('Aguardando dashboard do painel...', 'info');
            await this.page.waitForSelector(SELECTORS.dashboardElement, { timeout: 15000 });
            this.log('Código 2FA aceito. Login completo!', 'success', 'LOGIN_SUCCESS');
            this.robotStatus = 'inactive';
            webSocketService.broadcast('status', { robotStatus: 'inactive', sessionStatus: 'active' });
            webSocketService.broadcast('auth_success', {});
        } catch (error) {
            console.error('Falha ao submeter 2FA:', error);
            this.log(`Erro no 2FA: ${(error as Error).message}`, 'fatal');
            webSocketService.broadcast('log', { message: 'Código inválido, expirado ou erro na autenticação. Por favor, tente novamente.', level: 'warn' });
            throw new Error('Código 2FA inválido ou expirado.');
        }
    }
    
    public async getAcervo(): Promise<Processo[]> {
        const result = await pool.query('SELECT * FROM processos');
        return result.rows;
    }
    
    public async getAudiencias(): Promise<Audiencia[]> {
        const result = await pool.query('SELECT * FROM audiencias WHERE data_hora >= now() ORDER BY data_hora ASC');
        return result.rows;
    }
    
    // FIX: Implement missing syncAudienciasToCalendar method.
    public async syncAudienciasToCalendar(): Promise<Audiencia[]> {
        this.log('Sincronizando audiências com o Google Calendar...', 'info');
        const audiencias = await this.getAudiencias();
        // In a real implementation, you would loop through audiencias and use Google Calendar API.
        // For now, we simulate success by updating the status in our local representation.
        
        // Here you could also update the database if persistence is needed:
        for (const aud of audiencias) {
            await pool.query("UPDATE audiencias SET google_calendar_status = 'synced' WHERE id = $1", [aud.id]);
        }
        
        const updatedAudiencias = audiencias.map(aud => ({ ...aud, google_calendar_status: 'synced' as const }));

        this.log(`${audiencias.length} audiências foram marcadas como sincronizadas.`, 'success');
        return updatedAudiencias;
    }


    public async getPremonicaoJuridica(cnj: string): Promise<PremonicaoJuridica> {
      return {} as PremonicaoJuridica;
    }

    public async checkBrowserHealth(): Promise<boolean> {
        let browser = null;
        try {
            browser = await puppeteer.launch({
                args: chromium.args,
                executablePath: await chromium.executablePath(),
            });
            await browser.close();
            return true;
        } catch (error) {
            console.error("Puppeteer health check failed:", error);
            if (browser) await browser.close();
            return false;
        }
    }

    private async monitoringLoop() {
      if (this.robotStatus !== 'running') return;
      await this.checkForNotifications();
      if (this.robotStatus === 'running') {
          this.monitoringTimeout = setTimeout(() => this.monitoringLoop(), 60000);
      }
    }

    private log(message: string, level: 'info' | 'success' | 'error' | 'warn' | 'fatal', code?: string) {
      webSocketService.broadcast('log', { message, level, code });
    }

    private async login(): Promise<'success' | '2fa_required'> {
        if (!this.page) throw new Error("Página não inicializada.");
        this.log('Navegando para a página de login do PJe...', 'info', 'NAVIGATING_TO_PJE');
        await this.page.goto(process.env.PJE_LOGIN_URL!, { waitUntil: 'networkidle2', timeout: 60000 });
        this.log('Aguardando pelo campo de login...', 'info');
        await this.page.waitForSelector(SELECTORS.loginField, { visible: true, timeout: 60000 });
        this.log('Preenchendo credenciais...', 'info', 'FILLING_CREDENTIALS');
        await this.page.type(SELECTORS.loginField, this.pjeLogin);
        await this.page.type(SELECTORS.passwordField, this.pjePassword);
        this.log('Enviando formulário de login...', 'info', 'SUBMITTING_LOGIN');
        await this.page.click(SELECTORS.loginButton);
        this.log('Aguardando resultado do login (Painel, 2FA ou Configurar Dispositivo)...', 'info', 'WAITING_FOR_RESULT');
        try {
            // Aguarda por um dos três possíveis estados
            await Promise.race([
                this.page.waitForSelector(SELECTORS.dashboardElement, { visible: true, timeout: 60000 }),
                this.page.waitForSelector(SELECTORS.twoFactorCodeInput, { visible: true, timeout: 60000 }),
                this.page.waitForSelector('h2:has-text("Configurar novo dispositivo"), h2:has-text("Configure Device")', { visible: true, timeout: 60000 })
            ]);
            
            // Verifica se precisa configurar novo dispositivo
            const configDeviceHeader = await this.page.$('h2:has-text("Configurar novo dispositivo"), h2:has-text("Configure Device")');
            if (configDeviceHeader) {
                this.log('Página de configuração de novo dispositivo detectada.', 'warn');
                await this.handleConfigureNewDevice();
                return '2fa_required';
            }
            
            // Verifica se precisa de 2FA
            const twoFactorInput = await this.page.$(SELECTORS.twoFactorCodeInput);
            if (twoFactorInput) {
                this.log('Página de autenticação de dois fatores detectada.', 'warn');
                webSocketService.broadcast('2fa_required', {});
                return '2fa_required';
            }
            
            // Caso contrário, login foi bem-sucedido
            this.log('Login realizado com sucesso!', 'success', 'LOGIN_SUCCESS');
            webSocketService.broadcast('auth_success', {});
            return 'success';
        } catch (error) {
            console.error('Falha no login:', error);
            let analysisMessage = 'Causa desconhecida.';
            if (this.page) {
                try {
                    const screenshot = await this.page.screenshot({ encoding: 'base64' });
                    const pageText = await this.page.evaluate(() => document.body.innerText);
                    const analysis = await geminiService.analyzePjeErrorScreen(screenshot, pageText);
                    analysisMessage = `Análise da IA: ${analysis.status} - ${analysis.recommendation}`;
                } catch (analysisError) {
                    analysisMessage = 'Não foi possível analisar a tela de erro.';
                }
            }
            const errorMessage = (error as Error).message.includes('Timeout') ? 'Tempo esgotado ao aguardar. O PJe pode estar lento.' : 'Credenciais inválidas ou elemento não encontrado.';
            this.log(`Falha no login: ${errorMessage}. ${analysisMessage}`, 'fatal');
            webSocketService.broadcast('status', { sessionStatus: 'error' });
            await this.disconnect();
            throw new Error(`${errorMessage}. ${analysisMessage}`);
        }
    }

    private async handleConfigureNewDevice() {
        if (!this.page) throw new Error("Página não inicializada.");
        try {
            this.log('Processando tela "Configurar novo dispositivo"...', 'info');
            
            // Tenta preencher campo de nome do dispositivo (se existir)
            const deviceNameInput = await this.page.$(SELECTORS.deviceNameInput);
            if (deviceNameInput) {
                this.log('Preenchendo nome do dispositivo...', 'info');
                await this.page.type(SELECTORS.deviceNameInput, 'Assistant-Robot-PJe');
            }
            
            // Tenta clicar em "Configurar" ou similar
            const configButton = await this.page.$('button:has-text("Configurar"), button:has-text("Continuar"), button:has-text("Configure")');
            if (configButton) {
                this.log('Clicando em "Configurar"...', 'info');
                await Promise.all([
                    this.page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 30000 }).catch(() => {}),
                    this.page.click('button:has-text("Configurar"), button:has-text("Continuar"), button:has-text("Configure")')
                ]);
                await new Promise(resolve => setTimeout(resolve, 2000)); // Aguarda carregamento
            }
            
            this.log('Tela de configuração de dispositivo processada.', 'info');
            webSocketService.broadcast('2fa_required', {});
        } catch (error) {
            console.error('Erro ao processar "Configurar novo dispositivo":', error);
            this.log(`Erro ao processar configuração de dispositivo: ${(error as Error).message}`, 'warn');
            webSocketService.broadcast('2fa_required', {});
        }
    }

    private async checkForNotifications() {
        if (!this.page || this.robotStatus !== 'running') return;
        this.log('Verificando novos expedientes...', 'info');
        try {
            await this.page.waitForSelector(SELECTORS.notificationsPanel, { timeout: 15000 });
            const notifications = await this.page.$$(SELECTORS.notificationItems);
            if (notifications.length === 0) {
                this.log('Nenhum novo expediente encontrado.', 'info');
                return;
            }
            this.log(`Encontrados ${notifications.length} expedientes. Processando...`, 'info');
            for (const notification of notifications) {
                const id = await notification.evaluate(el => el.getAttribute('id'));
                if (!id || this.processedIds.has(id)) continue;
                this.processedIds.add(id);

                const content = await notification.$eval(SELECTORS.notificationContent, el => el.textContent?.trim() || '');
                const cnj = await notification.$eval(SELECTORS.notificationCnj, el => el.textContent?.trim() || 'N/A');
                if (!content) continue;

                // Garante que o processo exista no CRM
                await this.ensureProcessoExists(cnj);
                
                // Verifica se é uma audiência e salva
                if (content.toLowerCase().includes('audiência de conciliação')) {
                    await this.saveAudienciaFromNotification(cnj, content);
                }

                const notificationData: Partial<ProcessedNotification> = { id, cnj, client: 'Cliente Exemplo', originalContent: content };
                await taskRepo.queue('LEGAL_DRAFT_FROM_EXPEDIENTE', { notification: notificationData });
                this.log(`Tarefa criada para processar o expediente do processo ${cnj}.`, 'info');
            }
        } catch (error) {
            this.log(`Erro ao verificar expedientes: ${(error as Error).message}`, 'error');
            await this.validateSession();
        }
    }

    private async ensureProcessoExists(cnj: string) {
        const { rows } = await pool.query('SELECT id FROM processos WHERE numero_cnj = $1', [cnj]);
        if (rows.length === 0) {
            this.log(`Processo ${cnj} não encontrado no CRM. Cadastrando...`, 'info');
            await pool.query(
                `INSERT INTO processos (numero_cnj, phase, stage, partes) VALUES ($1, $2, $3, $4)`,
                [cnj, 'Judicial', 'Aguarda Manifestação', JSON.stringify({ polo_ativo: ['A Definir'], polo_passivo: ['A Definir'] })]
            );
        }
    }

    private async saveAudienciaFromNotification(cnj: string, content: string) {
        // Lógica simples para extrair data/hora. Uma implementação real usaria IA ou regex mais robustos.
        const dataMatch = content.match(/(\d{2}\/\d{2}\/\d{4})\s*às\s*(\d{2}:\d{2})/);
        if (dataMatch) {
            const [_, data, hora] = dataMatch;
            const [dia, mes, ano] = data.split('/');
            const dataHora = new Date(`${ano}-${mes}-${dia}T${hora}:00`);
            
            this.log(`Audiência detectada para o processo ${cnj}. Salvando no banco de dados.`, 'success');
            await pool.query(
                `INSERT INTO audiencias (processo_cnj, data_hora, tipo, status, partes)
                 VALUES ($1, $2, $3, $4, $5) ON CONFLICT (processo_cnj, data_hora) DO NOTHING`,
                [cnj, dataHora, 'Audiência de Conciliação', 'Agendada', { polo_ativo: 'A Definir', polo_passivo: 'A Definir' }]
            );
        }
    }
    
    private async isSessionValid(): Promise<boolean> {
        if (!this.page) return false;
        try {
            return !!(await this.page.$(SELECTORS.dashboardElement));
        } catch { return false; }
    }

    private async validateSession() {
        if (!this.page) return;
        try {
            await this.page.waitForSelector(SELECTORS.dashboardElement, { visible: true, timeout: 5000 });
        } catch (error) {
            this.log('Sessão PJe expirou. Notificando para reconexão.', 'warn');
            webSocketService.broadcast('pje_session_expired', {});
            webSocketService.broadcast('status', { sessionStatus: 'disconnected' });
            await this.disconnect();
        }
    }
}

export const pjeService = new PjeService();
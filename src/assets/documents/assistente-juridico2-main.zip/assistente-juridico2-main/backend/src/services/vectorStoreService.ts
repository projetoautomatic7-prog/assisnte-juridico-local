import { ChromaClient, Collection } from 'chromadb-client';

import { indexingService } from './indexingService';

class VectorStoreService {
    private client: ChromaClient | null = null;
    private collectionName = 'juridico_geral';
    private collection: Collection | null = null;
    private isAvailable: boolean = false;
    private initializationAttempted: boolean = false;

    constructor() {
        // Don't initialize in constructor to prevent startup crashes
        // Lazy initialization will happen on first use
    }

    private async initialize() {
        if (this.initializationAttempted) {
            return;
        }
        this.initializationAttempted = true;

        try {
            const chromaUrl = process.env.CHROMA_URL;
            if (!chromaUrl) {
                console.warn('⚠️  CHROMA_URL não definida. VectorStoreService desabilitado.');
                return;
            }

            this.client = new ChromaClient({ path: chromaUrl });
            this.collection = await this.client.getOrCreateCollection({ name: this.collectionName });
            this.isAvailable = true;
            console.log(`🏛️  Coleção "${this.collectionName}" no ChromaDB está pronta.`);
        } catch (error) {
            console.warn('⚠️  ChromaDB não disponível. VectorStoreService funcionará em modo degradado:', error instanceof Error ? error.message : error);
            this.isAvailable = false;
        }
    }

    private async ensureInitialized() {
        if (!this.initializationAttempted) {
            await this.initialize();
        }
    }

    public async addDocuments(documents: { pageContent: string; metadata: Record<string, any> }[]) {
        await this.ensureInitialized();

        if (!this.isAvailable || !this.collection) {
            console.warn('⚠️  ChromaDB não disponível. Documentos não foram indexados.');
            return;
        }

        try {
            const contents = documents.map(doc => doc.pageContent);
            const embeddings = await indexingService.generateEmbeddings(contents);
            
            await this.collection.add({
                ids: Array.from({ length: documents.length }, () => Math.random().toString(36).substring(2)),
                embeddings: embeddings,
                metadatas: documents.map(doc => doc.metadata),
                documents: contents,
            });

            console.log(`✅ ${documents.length} documentos adicionados à coleção "${this.collectionName}".`);
        } catch (error) {
            console.error('❌ Erro ao adicionar documentos ao ChromaDB:', error instanceof Error ? error.message : error);
            throw error;
        }
    }
    
    public async search(query: string, k: number = 3): Promise<{ pageContent: string; metadata: any }[]> {
        await this.ensureInitialized();

        if (!this.isAvailable || !this.collection) {
            console.warn('⚠️  ChromaDB não disponível. Retornando resultados vazios.');
            return [];
        }

        try {
            const queryEmbedding = await indexingService.generateEmbeddings([query]);
            
            const results = await this.collection.query({
                queryEmbeddings: queryEmbedding,
                nResults: k,
            });

            if (!results.documents || results.documents.length === 0) {
                return [];
            }

            // The structure from chromadb-client is results.documents[0], results.metadatas[0], etc.
            const searchResults = results.documents[0].map((doc: any, i: any) => ({
                pageContent: doc,
                metadata: results.metadatas[0][i],
            }));

            return searchResults;
        } catch (error) {
            console.error('❌ Erro ao buscar no ChromaDB:', error instanceof Error ? error.message : error);
            return [];
        }
    }

    public getAvailability(): boolean {
        return this.isAvailable;
    }
}

export const vectorStoreService = new VectorStoreService();
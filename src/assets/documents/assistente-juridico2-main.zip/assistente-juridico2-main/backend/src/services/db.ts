import { Pool } from 'pg';

import 'dotenv/config';
import process from 'process';

const createPool = () => {
  try {
    const databaseUrl = process.env.DATABASE_URL;
    if (!databaseUrl) {
      throw new Error('DATABASE_URL environment variable is not set');
    }

    // Validate that DATABASE_URL is not a placeholder
    if (databaseUrl.includes('HOST') || databaseUrl.includes('USER') || databaseUrl.includes('PASSWORD')) {
      throw new Error('DATABASE_URL contains placeholder values. Please configure with actual database credentials.');
    }

    // Additional validation: check for common invalid patterns
    const urlPattern = /^postgres(?:ql)?:\/\/([^:@]+):([^@]+)@([^:/]+)(?::(\d+))?\/(.+)$/;
    const match = databaseUrl.match(urlPattern);
    
    if (!match) {
      throw new Error(
        'DATABASE_URL format is invalid. Expected format: postgresql://USER:PASSWORD@HOST:PORT/DATABASE\n' +
        `Received: ${databaseUrl.substring(0, 30)}...`
      );
    }

    const [, user, password, host, port, database] = match;

    // Check for suspicious or incomplete values
    const suspiciousPatterns = ['localhost', 'base', 'host', 'server', 'db', 'database'];
    if (suspiciousPatterns.includes(host.toLowerCase()) && process.env.NODE_ENV === 'production') {
      console.warn(
        `⚠️ DATABASE_URL hostname '${host}' looks suspicious for production environment.\n` +
        'Make sure you have configured the DATABASE_URL in your Render dashboard with the actual database connection string.\n' +
        'You can find it in: Render Dashboard → Your Database → Connection → Internal Connection String'
      );
    }

    if (!user || !password || !host || !database) {
      throw new Error(
        'DATABASE_URL is missing required components (user, password, host, or database name).\n' +
        'Expected format: postgresql://USER:PASSWORD@HOST:PORT/DATABASE'
      );
    }

    console.log(`🔌 Connecting to PostgreSQL at ${host}:${port || 5432}/${database} as ${user}`);

    return new Pool({
      connectionString: databaseUrl,
      ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: false } : false,
    });
  } catch (error) {
    console.error('❌ Erro ao configurar pool de conexão do banco de dados:', error instanceof Error ? error.message : error);
    throw error;
  }
};

export const pool = createPool();

pool.on('connect', () => {
    console.log('🔌 Conectado ao banco de dados PostgreSQL.');
});

pool.on('error', (err) => {
    console.error('❌ Erro inesperado na conexão com o banco de dados.', err);
    process.exit(-1);
});
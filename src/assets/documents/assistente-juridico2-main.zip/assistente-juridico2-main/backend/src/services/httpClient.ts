import type { RequestInfo, RequestInit } from 'node-fetch';
import type { Response as NodeFetchResponse } from 'node-fetch';

export type { NodeFetchResponse };

async function loadNodeFetch() {
    // Lazy-load node-fetch to avoid Jest / ESM parsing issues when running tests
    const m = await import('node-fetch');
    // node-fetch v3 exports default in ESM; for compatibility support both
    return (m as any).default ? (m as any).default : m;
}

interface RetryOptions {
    retries?: number;
    baseDelayMs?: number;
    factor?: number;
    timeoutMs?: number;
}

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export async function fetchWithRetry(
    url: RequestInfo,
    init?: RequestInit,
    retryOptions: RetryOptions = {}
): Promise<NodeFetchResponse> {
    const { retries = 3, baseDelayMs = 200, factor = 2, timeoutMs = 30000 } = retryOptions;

    for (let i = 0; i < retries; i++) {
        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
            
            const fetch = await loadNodeFetch();
            const response = await fetch(url, {
                ...init,
                signal: controller.signal as any, // node-fetch supports AbortSignal
            });

            clearTimeout(timeoutId);

            if (response.ok || (response.status >= 400 && response.status < 500)) {
                return response;
            }

            // Retry on server errors (5xx)
            console.warn(`[fetchWithRetry] Attempt ${i + 1} failed for ${url} with status ${response.status}. Retrying...`);
        } catch (error) {
            if (i === retries - 1) {
                console.error(`[fetchWithRetry] Final attempt failed for ${url}.`, error);
                throw error;
            }
            console.warn(`[fetchWithRetry] Attempt ${i + 1} failed for ${url} with error. Retrying...`, error);
        }
        
        await sleep(baseDelayMs * Math.pow(factor, i));
    }
    
    throw new Error(`[fetchWithRetry] All ${retries} attempts failed for ${url}.`);
}
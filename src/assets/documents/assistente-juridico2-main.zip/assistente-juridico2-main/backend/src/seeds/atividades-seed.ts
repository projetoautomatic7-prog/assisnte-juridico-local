import { Pool } from 'pg';

export async function seedAtividades(pool: Pool) {
  try {
    // Verificar se já existem dados
    const countResult = await pool.query('SELECT COUNT(*) FROM atividades');
    if (parseInt(countResult.rows[0].count) > 0) {
      console.log('Atividades já populadas, pulando seed.');
      return;
    }

    const hoje = new Date();
    const ontem = new Date(hoje);
    ontem.setDate(ontem.getDate() - 1);
    const amanha = new Date(hoje);
    amanha.setDate(amanha.getDate() + 1);
    const semanaPassada = new Date(hoje);
    semanaPassada.setDate(semanaPassada.getDate() - 7);
    const proximaSemana = new Date(hoje);
    proximaSemana.setDate(proximaSemana.getDate() + 7);

    const atividades = [
      // Pendentes (5 atividades)
      {
        tarefa: 'Preparar parecer jurídico para processo #12345',
        partes: 'Thiago Bodevan',
        dataCompromisso: hoje.toISOString(),
        prazoFatal: amanha.toISOString(),
        isUrgent: true,
        status: 'pendente'
      },
      {
        tarefa: 'Revisar documentação de defesa',
        partes: 'Thiago Bodevan',
        dataCompromisso: amanha.toISOString(),
        prazoFatal: proximaSemana.toISOString(),
        isUrgent: false,
        status: 'pendente'
      },
      {
        tarefa: 'Protocolar petição inicial',
        partes: 'Thiago Bodevan',
        dataCompromisso: amanha.toISOString(),
        prazoFatal: null,
        isUrgent: false,
        status: 'pendente'
      },
      {
        tarefa: 'Comparecer em audiência conciliação',
        partes: 'Thiago Bodevan',
        dataCompromisso: proximaSemana.toISOString(),
        prazoFatal: proximaSemana.toISOString(),
        isUrgent: true,
        status: 'pendente'
      },
      {
        tarefa: 'Elaborar minuta de contrato',
        partes: 'Thiago Bodevan',
        dataCompromisso: proximaSemana.toISOString(),
        prazoFatal: null,
        isUrgent: false,
        status: 'pendente'
      },
      {
        tarefa: 'Responder intimação do tribunal',
        partes: 'Thiago Bodevan',
        dataCompromisso: ontem.toISOString(),
        prazoFatal: hoje.toISOString(),
        isUrgent: true,
        status: 'pendente'
      },
      {
        tarefa: 'Enviar documentos para perícia',
        partes: 'Thiago Bodevan',
        dataCompromisso: hoje.toISOString(),
        prazoFatal: amanha.toISOString(),
        isUrgent: true,
        status: 'pendente'
      },
      {
        tarefa: 'Agendar reunião com cliente',
        partes: 'Thiago Bodevan',
        dataCompromisso: amanha.toISOString(),
        prazoFatal: null,
        isUrgent: false,
        status: 'pendente'
      },
      // Atrasadas (3 atividades)
      {
        tarefa: 'Entregar análise de risco do negócio',
        partes: 'Thiago Bodevan',
        dataCompromisso: semanaPassada.toISOString(),
        prazoFatal: ontem.toISOString(),
        isUrgent: true,
        status: 'atrasada'
      },
      {
        tarefa: 'Revisar contrato com fornecedor',
        partes: 'Thiago Bodevan',
        dataCompromisso: semanaPassada.toISOString(),
        prazoFatal: semanaPassada.toISOString(),
        isUrgent: true,
        status: 'atrasada'
      },
      {
        tarefa: 'Enviar parecer para cliente',
        partes: 'Thiago Bodevan',
        dataCompromisso: ontem.toISOString(),
        prazoFatal: hoje.toISOString(),
        isUrgent: true,
        status: 'atrasada'
      },
      // Resolvidas no mês (10 atividades)
      {
        tarefa: 'Protocolar ação de cobrança',
        partes: 'Thiago Bodevan',
        dataCompromisso: new Date(hoje.getFullYear(), hoje.getMonth(), 1).toISOString(),
        prazoFatal: null,
        isUrgent: false,
        status: 'resolvida'
      },
      {
        tarefa: 'Comparecimento em audiência',
        partes: 'Thiago Bodevan',
        dataCompromisso: new Date(hoje.getFullYear(), hoje.getMonth(), 2).toISOString(),
        prazoFatal: null,
        isUrgent: false,
        status: 'resolvida'
      },
      {
        tarefa: 'Expedição de certidão',
        partes: 'Thiago Bodevan',
        dataCompromisso: new Date(hoje.getFullYear(), hoje.getMonth(), 3).toISOString(),
        prazoFatal: null,
        isUrgent: false,
        status: 'resolvida'
      },
      {
        tarefa: 'Análise de jurisprudência',
        partes: 'Thiago Bodevan',
        dataCompromisso: new Date(hoje.getFullYear(), hoje.getMonth(), 5).toISOString(),
        prazoFatal: null,
        isUrgent: false,
        status: 'resolvida'
      },
      {
        tarefa: 'Parecer sobre constitucionalidade',
        partes: 'Thiago Bodevan',
        dataCompromisso: new Date(hoje.getFullYear(), hoje.getMonth(), 7).toISOString(),
        prazoFatal: null,
        isUrgent: false,
        status: 'resolvida'
      },
      {
        tarefa: 'Publicação em DJEN',
        partes: 'Thiago Bodevan',
        dataCompromisso: new Date(hoje.getFullYear(), hoje.getMonth(), 8).toISOString(),
        prazoFatal: null,
        isUrgent: false,
        status: 'resolvida'
      },
      {
        tarefa: 'Assinatura de termo de transação',
        partes: 'Thiago Bodevan',
        dataCompromisso: new Date(hoje.getFullYear(), hoje.getMonth(), 10).toISOString(),
        prazoFatal: null,
        isUrgent: false,
        status: 'resolvida'
      },
      {
        tarefa: 'Depósito judicial realizado',
        partes: 'Thiago Bodevan',
        dataCompromisso: new Date(hoje.getFullYear(), hoje.getMonth(), 11).toISOString(),
        prazoFatal: null,
        isUrgent: false,
        status: 'resolvida'
      },
      {
        tarefa: 'Sentença favorável proferida',
        partes: 'Thiago Bodevan',
        dataCompromisso: new Date(hoje.getFullYear(), hoje.getMonth(), 12).toISOString(),
        prazoFatal: null,
        isUrgent: false,
        status: 'resolvida'
      },
      {
        tarefa: 'Recurso preparado e enviado',
        partes: 'Thiago Bodevan',
        dataCompromisso: new Date(hoje.getFullYear(), hoje.getMonth(), 14).toISOString(),
        prazoFatal: null,
        isUrgent: false,
        status: 'resolvida'
      }
    ];

    // Inserir dados com ON CONFLICT para evitar duplicatas
    for (const ativ of atividades) {
      await pool.query(
        `INSERT INTO atividades (tarefa, partes, data_compromisso, prazo_fatal, is_urgent, status)
         VALUES ($1, $2, $3, $4, $5, $6)
         ON CONFLICT (tarefa, partes) DO NOTHING`,
        [
          ativ.tarefa,
          ativ.partes,
          ativ.dataCompromisso,
          ativ.prazoFatal,
          ativ.isUrgent,
          ativ.status
        ]
      );
    }

    console.log(`✅ Seed de Atividades: ${atividades.length} atividades inseridas`);
  } catch (error) {
    console.error('❌ Erro ao seedar atividades:', (error as Error).message);
    throw error;
  }
}

import { pool } from '../services/db';

export async function seedAgentGoals() {
  try {
    const agentGoals = [
      {
        title: 'Monitoramento PJe Automático',
        description: 'Monitorar portal PJe para novos expedientes e processar automaticamente',
        department: 'Robótica',
        priority: 1,
        status: 'RUNNING'
      },
      {
        title: 'Análise de Documentos com Gemini',
        description: 'Extrair informações de documentos jurídicos usando IA',
        department: 'IA',
        priority: 2,
        status: 'RUNNING'
      },
      {
        title: 'Geração de Minutas',
        description: 'Gerar automaticamente minutas e rascunhos de petições',
        department: 'IA',
        priority: 1,
        status: 'PENDING'
      },
      {
        title: 'Verificação de Prazos',
        description: 'Detector automático de prazos e alertas jurídicos',
        department: 'Automação',
        priority: 1,
        status: 'DONE'
      },
      {
        title: 'Sincronização DataJud',
        description: 'Buscar dados de processos no DataJud e sincronizar com base local',
        department: 'Integração',
        priority: 2,
        status: 'FAILED'
      }
    ];

    let inserted = 0;
    for (const goal of agentGoals) {
      const result = await pool.query(
        `INSERT INTO agent_goals (title, description, department, priority, status)
         VALUES ($1, $2, $3, $4, $5)
         ON CONFLICT(title) DO NOTHING
         RETURNING id`,
        [goal.title, goal.description, goal.department, goal.priority, goal.status]
      );
      if (result.rows.length > 0) {
        inserted++;
      }
    }

    console.log(`✅ ${inserted} agentes de teste adicionados ao dashboard`);
    return true;
  } catch (err) {
    console.error('❌ Erro ao adicionar agentes de teste:', err);
    return false;
  }
}

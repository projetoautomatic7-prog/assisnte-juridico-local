#!/usr/bin/env node
/**
 * Utility script to generate bcrypt hash for admin password
 * Usage: node generatePasswordHash.js <password>
 */

/* eslint-env node */
/* eslint-disable no-undef, no-restricted-syntax */
const bcrypt = require('bcrypt');

const password = process.argv[2];

if (!password) {
    console.error('Usage: node generatePasswordHash.js <password>');
    process.exit(1);
}

bcrypt.hash(password, 12).then(hash => {
    console.log('\nGenerated bcrypt hash:');
    console.log(hash);
    console.log('\nSet this value as ADMIN_PASSWORD_HASH environment variable');
}).catch(err => {
    console.error('Error generating hash:', err);
    process.exit(1);
});

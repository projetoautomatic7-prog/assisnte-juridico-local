module.exports = {
  preset: 'ts-jest',
  testEnvironment: 'node',
  clearMocks: true,
  testMatch: [
    "**/__tests__/**/*.test.ts",
    "**/?(*.)+(spec|test).ts"
  ],
  transform: {
    '^.+\\.tsx?$': ['ts-jest', {
      useESM: true,
      tsconfig: {
        esModuleInterop: true,
        allowSyntheticDefaultImports: true
      }
    }]
  },
  collectCoverageFrom: [
    'src/**/*.{ts,tsx}',
    '!src/**/*.d.ts',
    '!src/**/index.ts'
  ],
  coverageThreshold: {
    global: {
      branches: 10,
      functions: 15,
      lines: 25,
      statements: 25
    }
  },
  transformIgnorePatterns: [
    'node_modules/(?!(node-fetch|@xenova|uuid)/)',
    '^.+\\.module\\.(css|sass|scss)$'
  ],
  moduleNameMapper: {
    '^(\\.{1,2}/.*)\\.js$': '$1',
    '^@/(.*)$': '<rootDir>/src/$1',
    '^@xenova/transformers$': '<rootDir>/__mocks__/@xenova/transformers.js',
    // Mapear chromadb-client para utilizar o mock manual durante testes
    '^chromadb-client$': '<rootDir>/__mocks__/chromadb-client.js',
    // Garantir que imports com subpath também sejam mapeados
    '^chromadb-client/(.*)$': '<rootDir>/__mocks__/chromadb-client.js',
    // Force uuid to use mock (CJS) to avoid ESM parse errors
    '^uuid$': '<rootDir>/__mocks__/uuid.js'
  },
  // Map @xenova/transformers to our mock implementation to avoid ESM issues during tests
  // Jest will look for the mock at backend/__mocks__/@xenova/transformers.js
  testTimeout: 30000
  ,
  setupFiles: ['<rootDir>/jest.setup.ts']
};
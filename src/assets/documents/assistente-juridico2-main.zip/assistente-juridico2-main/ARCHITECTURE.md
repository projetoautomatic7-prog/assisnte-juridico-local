# 🏗️ ARQUITETURA DO SISTEMA - Assistente Jurídico PJe

**Versão**: 1.0  
**Data**: 15 de novembro de 2025  
**Status**: Documentação Técnica Oficial

---

## 📐 VISÃO GERAL DA ARQUITETURA

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         CAMADA DE APRESENTAÇÃO                          │
│                              (Frontend)                                 │
│                                                                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌────────────┐ │
│  │  Dashboard   │  │  Expedientes │  │  CRM Kanban  │  │   Agenda   │ │
│  │   (Métricas) │  │  (Intimações)│  │  (Processos) │  │(Calendário)│ │
│  └──────────────┘  └──────────────┘  └──────────────┘  └────────────┘ │
│                                                                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌────────────┐ │
│  │     DJEN     │  │   DataJud    │  │  Transcrição │  │   Prazos   │ │
│  │   (Busca)    │  │   (CNJ)      │  │    (Áudio)   │  │ (Calculado)│ │
│  └──────────────┘  └──────────────┘  └──────────────┘  └────────────┘ │
│                                                                         │
│                    React 19 + TypeScript + Vite                        │
│                    Tailwind CSS + Zustand                              │
└─────────────────────────────────────────────────────────────────────────┘
                                    ↕
                          WebSocket + REST API
                          (Tempo Real + CRUD)
                                    ↕
┌─────────────────────────────────────────────────────────────────────────┐
│                          CAMADA DE NEGÓCIO                              │
│                             (Backend)                                   │
│                                                                         │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                     AGENT KERNEL (Orquestrador)                   │ │
│  │                                                                   │ │
│  │  ┌─────────────────────────────────────────────────────────────┐ │ │
│  │  │              WORKER LOOP (Polling 3s)                       │ │ │
│  │  │                                                             │ │ │
│  │  │  while(true) {                                              │ │ │
│  │  │    task = taskRepo.getNext()                                │ │ │
│  │  │    if (!task) { await sleep(3000); continue; }              │ │ │
│  │  │                                                             │ │ │
│  │  │    tool = toolRegistry.get(task.type)                       │ │ │
│  │  │    try {                                                    │ │ │
│  │  │      result = await circuitBreaker.execute(                 │ │ │
│  │  │        withTimeout(tool.execute(task.payload), 30000)       │ │ │
│  │  │      )                                                      │ │ │
│  │  │      await taskRepo.markCompleted(task.id, result)          │ │ │
│  │  │    } catch (error) {                                        │ │ │
│  │  │      await taskRepo.retry(task.id, error, backoff)          │ │ │
│  │  │    }                                                        │ │ │
│  │  │  }                                                          │ │ │
│  │  └─────────────────────────────────────────────────────────────┘ │ │
│  │                                                                   │ │
│  │  ┌─────────────────────────────────────────────────────────────┐ │ │
│  │  │             TOOL REGISTRY (7 Ferramentas)                   │ │ │
│  │  │                                                             │ │ │
│  │  │  1. legal.draftFromExpediente                               │ │ │
│  │  │     - Analisa expediente com Gemini 2.5-pro                 │ │ │
│  │  │     - Classifica ação: SIMPLE_REPLY | DRAFT_RESPONSE        │ │ │
│  │  │     - Gera minuta se necessário                             │ │ │
│  │  │                                                             │ │ │
│  │  │  2. djen.analyze                                            │ │ │
│  │  │     - Busca publicações DJEN por OAB/nome                   │ │ │
│  │  │     - Extrai CNJ numbers e prazos                           │ │ │
│  │  │                                                             │ │ │
│  │  │  3. robot.pjeConsultar                                      │ │ │
│  │  │     - Puppeteer automation do PJe                           │ │ │
│  │  │     - Busca novos expedientes                               │ │ │
│  │  │                                                             │ │ │
│  │  │  4. memory.searchKnowledgeBase                              │ │ │
│  │  │     - RAG search em ChromaDB                                │ │ │
│  │  │     - Embeddings com @xenova/transformers                   │ │ │
│  │  │                                                             │ │ │
│  │  │  5. management.dailySummary                                 │ │ │
│  │  │     - Resumo executivo diário                               │ │ │
│  │  │     - Análise de eventos das últimas 24h                    │ │ │
│  │  │                                                             │ │ │
│  │  │  6. prazo.detect                                            │ │ │
│  │  │     - Detecta prazos em texto jurídico                      │ │ │
│  │  │                                                             │ │ │
│  │  │  7. it.healthCheck                                          │ │ │
│  │  │     - Verifica saúde dos serviços                           │ │ │
│  │  └─────────────────────────────────────────────────────────────┘ │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                    EXPRESS ROUTES (API REST)                      │ │
│  │                                                                   │ │
│  │  /api/auth      - Login, JWT, rate limiting                      │ │
│  │  /api/robot     - PJe Robot control (connect, pause, status)     │ │
│  │  /api/ai        - Gemini services (analyze, draft, transcribe)   │ │
│  │  /api/agent     - Agent tasks (queue, status, events)            │ │
│  │  /api/memory    - Knowledge base (search, index)                 │ │
│  │  /api/data      - CRUD processos, pessoas, atividades            │ │
│  │  /api/settings  - User settings                                  │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│                   Node.js + Express + TypeScript                       │
└─────────────────────────────────────────────────────────────────────────┘
                                    ↕
                        Integrações Externas
                                    ↕
┌─────────────────────────────────────────────────────────────────────────┐
│                        CAMADA DE SERVIÇOS                               │
│                                                                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌────────────┐ │
│  │    Gemini    │  │      PJe     │  │     DJEN     │  │  DataJud   │ │
│  │     API      │  │  (Puppeteer) │  │     API      │  │    API     │ │
│  │              │  │              │  │              │  │   (CNJ)    │ │
│  │  2.5-pro     │  │  Login 2FA   │  │  TRT1-24     │  │  Base      │ │
│  │  2.5-flash   │  │  Expedientes │  │  Parsing     │  │  Nacional  │ │
│  │  audio       │  │  Intimações  │  │  Extração    │  │            │ │
│  └──────────────┘  └──────────────┘  └──────────────┘  └────────────┘ │
│                                                                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐                 │
│  │   ChromaDB   │  │  PostgreSQL  │  │   WebSocket  │                 │
│  │ Vector Store │  │   Database   │  │  Real-time   │                 │
│  │              │  │              │  │              │                 │
│  │  Embeddings  │  │  14 Tables   │  │  Broadcast   │                 │
│  │  RAG Search  │  │  Migrations  │  │  Events      │                 │
│  │              │  │  Pool        │  │              │                 │
│  └──────────────┘  └──────────────┘  └──────────────┘                 │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 🗄️ SCHEMA DO BANCO DE DADOS

### Tabelas de Agentes (4)

```sql
┌─────────────────────────────────────────────────────────────────┐
│                        agent_goals                              │
├─────────────────────────────────────────────────────────────────┤
│ id              UUID PRIMARY KEY                                │
│ title           VARCHAR(255)    "Analisar expediente #12345"    │
│ description     TEXT            "Expediente urgente TRT..."     │
│ department      VARCHAR(100)    "LEGAL" | "FINANCE" | "IT"      │
│ priority        SMALLINT         1 (alta) a 5 (baixa)           │
│ status          VARCHAR(50)     "PENDING" | "RUNNING" | ...     │
│ created_at      TIMESTAMPTZ                                     │
│ updated_at      TIMESTAMPTZ                                     │
└─────────────────────────────────────────────────────────────────┘
                             ↓ 1:N
┌─────────────────────────────────────────────────────────────────┐
│                       agent_steps                               │
├─────────────────────────────────────────────────────────────────┤
│ id              UUID PRIMARY KEY                                │
│ goal_id         UUID → agent_goals(id)                          │
│ idx             SMALLINT         Ordem do step (0, 1, 2...)     │
│ tool            VARCHAR(100)    "legal.draftFromExpediente"     │
│ input           JSONB           {"notification": {...}}         │
│ result          JSONB           {"draft": "...", "status": ...} │
│ error           TEXT            Mensagem de erro                │
│ status          VARCHAR(50)    "PENDING" | "COMPLETED" | ...    │
│ created_at      TIMESTAMPTZ                                     │
│ updated_at      TIMESTAMPTZ                                     │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                       agent_tasks                               │
├─────────────────────────────────────────────────────────────────┤
│ id              UUID PRIMARY KEY                                │
│ type            VARCHAR(100)    "EXECUTE_GOAL" | "DJEN_SEARCH"  │
│ payload         JSONB           {"goalId": "...", ...}          │
│ result          JSONB           Resultado da execução           │
│ status          VARCHAR(50)    "QUEUED" | "RUNNING" | ...       │
│ attempts        SMALLINT        0, 1, 2, 3, 4                   │
│ last_error      TEXT            Última mensagem de erro         │
│ locked_at       TIMESTAMPTZ     Lock para evitar race condition │
│ scheduled_for   TIMESTAMPTZ     Agendamento futuro              │
│ created_at      TIMESTAMPTZ                                     │
│ updated_at      TIMESTAMPTZ                                     │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                      agent_events                               │
├─────────────────────────────────────────────────────────────────┤
│ id              SERIAL PRIMARY KEY                              │
│ goal_id         UUID → agent_goals(id)                          │
│ step_id         UUID → agent_steps(id)                          │
│ task_id         UUID → agent_tasks(id)                          │
│ level           VARCHAR(20)    "INFO" | "WARN" | "ERROR"        │
│ code            VARCHAR(50)    "GOAL.CREATED" | "TASK.ERROR"    │
│ message         TEXT            "Task failed: timeout"          │
│ data            JSONB           {"error": "...", "attempts": 3} │
│ created_at      TIMESTAMPTZ                                     │
└─────────────────────────────────────────────────────────────────┘
```

### Tabelas da Aplicação (10)

```sql
┌─────────────────────────────────────────────────────────────────┐
│                         processos                               │
├─────────────────────────────────────────────────────────────────┤
│ id                UUID PRIMARY KEY                              │
│ numero_cnj        VARCHAR(255) UNIQUE "1234567-89.2024.5.01..."│
│ classe_judicial   VARCHAR(255)    "Reclamação Trabalhista"      │
│ assunto           TEXT            "Horas extras não pagas"      │
│ partes            JSONB           {"reclamante": ..., ...}      │
│ orgao_julgador    VARCHAR(255)    "1ª Vara do Trabalho"         │
│ distribuicao_data TIMESTAMPTZ                                   │
│ ultimo_movimento  JSONB           {"tipo": "Sentença", ...}     │
│ phase             VARCHAR(100)    "Conhecimento" | "Execução"   │
│ stage             VARCHAR(100)    "Lead" | "Negociação" | ...   │
│ value             NUMERIC(15,2)   Valor da causa                │
│ probability       VARCHAR(50)     "High" | "Medium" | "Low"     │
│ responsible       VARCHAR(255)    "Dr. João Silva"              │
│ is_overdue        BOOLEAN          Prazo vencido?               │
│ overdue_tasks     INT              Quantidade de tarefas atrasadas│
│ has_open_tasks    BOOLEAN          Tem tarefas pendentes?       │
│ timeline_events   JSONB           [{"date": ..., "event": ...}] │
│ created_at        TIMESTAMPTZ                                   │
│ updated_at        TIMESTAMPTZ                                   │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                        atividades                               │
├─────────────────────────────────────────────────────────────────┤
│ id                UUID PRIMARY KEY                              │
│ is_urgent         BOOLEAN         Tarefa urgente?               │
│ tarefa            TEXT            "Apresentar contestação"      │
│ partes            TEXT            "João vs. Empresa XYZ"        │
│ data_compromisso  DATE            Data do compromisso           │
│ prazo_fatal       DATE            Prazo fatal (deadline)        │
│ status            VARCHAR(50)    "Pendente" | "Concluído"       │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                        audiencias                               │
├─────────────────────────────────────────────────────────────────┤
│ id                    UUID PRIMARY KEY                          │
│ processo_cnj          VARCHAR(255) → processos                  │
│ data_hora             TIMESTAMPTZ                               │
│ local                 TEXT        "Sala 301, TRT1"              │
│ tipo                  VARCHAR(255) "Inicial" | "Instrução"      │
│ partes                JSONB                                     │
│ status                VARCHAR(50) "Agendada" | "Realizada"      │
│ google_calendar_status VARCHAR(50) "pending" | "synced"         │
│ classe_judicial       VARCHAR(255)                              │
│ orgao_julgador        VARCHAR(255)                              │
│ advogado_responsavel  VARCHAR(255)                              │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                       transacoes                                │
├─────────────────────────────────────────────────────────────────┤
│ id              UUID PRIMARY KEY                                │
│ date            DATE            Data da transação               │
│ processo_cnj    VARCHAR(255)   CNJ do processo relacionado      │
│ description     TEXT            "Honorários caso #12345"        │
│ amount          NUMERIC(15,2)   R$ 5.000,00                     │
│ type            VARCHAR(20)    "income" | "expense"             │
│ status          VARCHAR(50)    "paid" | "pending" | "overdue"   │
│ attachment      JSONB           {"url": "...", "name": "..."}   │
│ created_at      TIMESTAMPTZ                                     │
│ updated_at      TIMESTAMPTZ                                     │
└─────────────────────────────────────────────────────────────────┘

-- Outras tabelas: pessoas, modelos, compromissos, push_subscriptions
```

---

## 🔄 FLUXO DE EXECUÇÃO DO AGENTE

### 1. Criação de Goal

```
User Action (Frontend)
        ↓
POST /api/agent/goals
        ↓
agentKernel.createGoal()
        ↓
INSERT INTO agent_goals (title, description, status='PENDING')
        ↓
eventBus.emit('GOAL.CREATED')
        ↓
WebSocket broadcast → Frontend atualiza Dashboard
```

### 2. Planejamento e Execução

```
agentKernel.planAndRunGoal(goalId)
        ↓
UPDATE agent_goals SET status='PLANNING'
        ↓
taskRepo.queue('EXECUTE_GOAL', {goalId, description})
        ↓
INSERT INTO agent_tasks (type='EXECUTE_GOAL', status='QUEUED')
        ↓
UPDATE agent_goals SET status='RUNNING'
```

### 3. Worker Loop Processa Tarefa

```
Worker Loop (polling 3s)
        ↓
SELECT * FROM agent_tasks 
WHERE status='QUEUED' 
  AND (locked_at IS NULL OR locked_at < NOW() - INTERVAL '5 min')
ORDER BY created_at 
LIMIT 1 
FOR UPDATE SKIP LOCKED
        ↓
UPDATE agent_tasks SET status='RUNNING', locked_at=NOW()
        ↓
toolName = mapTaskTypeToTool(task.type)  // 'EXECUTE_GOAL' → 'legal.draftFromExpediente'
        ↓
tool = toolRegistry.get(toolName)
        ↓
circuitBreaker = getCircuitBreaker(toolName)
        ↓
try {
    result = circuitBreaker.execute(() => 
        withTimeout(tool.execute(task.payload), 30000)
    )
    ↓
    UPDATE agent_tasks 
    SET status='COMPLETED', result=... 
    WHERE id=task.id
    ↓
    eventBus.emit('TASK.COMPLETED')
    ↓
    WebSocket broadcast → Frontend mostra "Tarefa concluída"
    
} catch (error) {
    ↓
    attempts++
    backoff = BACKOFFS[attempts] // 1s, 5s, 15s, 30s
    ↓
    if (attempts >= 4) {
        UPDATE agent_tasks 
        SET status='FAILED', last_error=... 
        WHERE id=task.id
        ↓
        eventBus.emit('TASK.FAILED')
    } else {
        UPDATE agent_tasks 
        SET status='QUEUED', 
            attempts=..., 
            last_error=...,
            scheduled_for=NOW() + backoff 
        WHERE id=task.id
        ↓
        eventBus.emit('TASK.RETRYING')
    }
}
```

### 4. Ferramenta Executa (Exemplo: legal.draftFromExpediente)

```
legal.draftFromExpediente.execute({notification: {...}})
        ↓
prompt = `Analise o expediente: "${notification.originalContent}"...`
        ↓
geminiService.generateJson(prompt, LegalAnalysisSchema)
        ↓
Google Gemini API (2.5-pro) [5-10s]
        ↓
{
    "prazo": "15 dias úteis",
    "resumo": "Apresentar contestação à reclamação trabalhista",
    "classificacao_acao": "DRAFT_RESPONSE",
    "documentos_necessarios": ["Procuração", "Contrato de Trabalho"]
}
        ↓
if (classificacao_acao === 'DRAFT_RESPONSE') {
    draftPrompt = `Redija uma minuta de contestação...`
    ↓
    draft = geminiService.generateText(draftPrompt, 'gemini-2.5-pro')
    ↓
    Google Gemini API (2.5-pro) [5-10s]
}
        ↓
return {
    analysis: {...},
    draft: "...",
    ai_completed_tasks: ["Análise", "Classificação", "Geração da minuta"],
    human_tasks: ["Revisar minuta", "Anexar procuração", "Anexar contrato"]
}
        ↓
Worker recebe result e salva em agent_tasks.result
        ↓
Frontend busca result via GET /api/agent/tasks/:id
        ↓
User visualiza minuta gerada e tarefas humanas pendentes
```

---

## 🔐 FLUXO DE AUTENTICAÇÃO

```
User insere username + password no Login.tsx
        ↓
POST /api/auth/login
        ↓
loginLimiter verifica: IP fez < 5 tentativas em 15 min?
        ↓ SIM
authRoutes.ts: SELECT * FROM users WHERE username=...
        ↓
bcrypt.compare(password, user.password_hash)
        ↓ VÁLIDO
jwt.sign({userId: user.id}, JWT_SECRET, {expiresIn: '7d'})
        ↓
res.json({token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."})
        ↓
Frontend armazena token em localStorage
        ↓
Toda requisição subsequente inclui:
Header: Authorization: Bearer <token>
        ↓
authMiddleware verifica JWT em cada rota /api/*
        ↓
jwt.verify(token, JWT_SECRET)
        ↓ VÁLIDO
req.user = {userId: ...}
        ↓
Rota executa lógica de negócio
```

---

## 🤖 FLUXO DO ROBÔ PJE

```
User clica "Conectar" em PjeRobot.tsx
        ↓
POST /api/robot/connect
        ↓
pjeService.connect()
        ↓
puppeteer.launch({executablePath: chromium})
        ↓
browser.newPage()
        ↓
page.goto(PJE_LOGIN_URL)
        ↓
page.type('#username', pjeLogin)
page.type('#password', pjePassword)
page.click('button[type="submit"]')
        ↓
await page.waitForNavigation()
        ↓
Se tela de 2FA:
    webSocket.send('2FA_REQUIRED')
    ↓
    Frontend mostra input para código
    ↓
    User digita código → Frontend envia via WebSocket
    ↓
    page.type('#token', code)
    page.click('button[type="submit"]')
    ↓
    await page.waitForNavigation()
        ↓
Se tela de configurar dispositivo:
    page.type('input[placeholder*="dispositivo"]', 'Robot-PJe')
    page.click('button:has-text("Configurar")')
    ↓
    await page.waitForNavigation()
        ↓
Verificar se login bem-sucedido:
await page.waitForSelector('#painel-advogado')
        ↓ SIM
robotStatus = 'inactive'
webSocket.send('SESSION_ACTIVE')
        ↓
Frontend mostra botão "Iniciar Monitoramento"
        ↓
User clica "Iniciar Monitoramento"
        ↓
POST /api/robot/start-monitoring
        ↓
pjeService.startMonitoring()
        ↓
robotStatus = 'running'
setInterval(() => {
    const newExpedientes = await scrapeExpedientes()
    ↓
    for (expediente of newExpedientes) {
        if (!processedIds.has(expediente.id)) {
            processedIds.add(expediente.id)
            ↓
            // Enfileirar para análise IA
            taskRepo.queue('ANALYZE_EXPEDIENTE', {expediente})
            ↓
            webSocket.send('NEW_EXPEDIENTE', expediente)
        }
    }
}, 60000) // A cada 60 segundos
```

---

## 📊 MÉTRICAS E MONITORAMENTO

### Health Checks

```
GET /health
        ↓
{
    "status": "ok",
    "timestamp": "2025-11-15T01:00:00.000Z"
}

GET /api/agent/health (requer auth)
        ↓
{
    "worker": "running",
    "database": "connected",
    "gemini": "healthy",
    "pje_robot": "active",
    "tasks_queued": 5,
    "tasks_running": 2,
    "circuit_breakers": {
        "legal.draftFromExpediente": "CLOSED",
        "djen.analyze": "CLOSED"
    }
}
```

### Logs Estruturados (Pino)

```javascript
log.info({taskId: '123', type: 'EXECUTE_GOAL'}, 'Task started');
log.warn({queueSize: 50}, 'Queue growing');
log.error({error: 'Timeout', attempts: 3}, 'Task failed');

// Output:
{
    "level": 30,
    "time": 1700000000000,
    "taskId": "123",
    "type": "EXECUTE_GOAL",
    "msg": "Task started"
}
```

---

## 🚀 DEPLOY E INFRAESTRUTURA

### Ambientes

```
┌─────────────────────────────────────────────────────────┐
│                  PRODUÇÃO                               │
│                                                         │
│  Frontend: Vercel (CDN Global)                          │
│  Backend:  Render.com (US East)                         │
│  Database: Render PostgreSQL 15                         │
│  ChromaDB: Render Web Service                           │
│                                                         │
│  Domínio: https://assistente-juridico.vercel.app       │
│  API:     https://assistente-juridico-backend.onrender.com
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│                DESENVOLVIMENTO                          │
│                                                         │
│  Frontend: Vite dev server (localhost:5173)             │
│  Backend:  ts-node (localhost:3001)                     │
│  Database: Docker PostgreSQL (localhost:5432)           │
│  ChromaDB: Docker (localhost:8000)                      │
└─────────────────────────────────────────────────────────┘
```

### CI/CD Pipeline (Proposto)

```
git push origin main
        ↓
GitHub Actions
        ↓
┌─────────────────────────────────────────┐
│         Build & Test                    │
│  - npm install                          │
│  - npm run build                        │
│  - npm test                             │
│  - npm audit                            │
└─────────────────────────────────────────┘
        ↓ SUCCESS
┌─────────────────────────────────────────┐
│         Deploy Staging                  │
│  - Vercel: staging.assistente.app      │
│  - Render: staging backend              │
└─────────────────────────────────────────┘
        ↓ MANUAL APPROVAL
┌─────────────────────────────────────────┐
│         Deploy Production               │
│  - Vercel: assistente-juridico.app     │
│  - Render: production backend           │
│  - Database migration                   │
└─────────────────────────────────────────┘
```

---

## 📚 REFERÊNCIAS

- **Documentação Completa**: `ANALISE_TECNICA_COMPLETA.md`
- **Resumo Executivo**: `EXECUTIVE_SUMMARY.md`
- **Guia de Implementação**: `IMPLEMENTATION_GUIDE.md`
- **Código Fonte**: https://github.com/thiagobodevan/assistente-juridico

---

**Última atualização**: 15 de novembro de 2025  
**Versão do Sistema**: 1.0  
**Mantenedor**: Thiago Bodevan Advocacia

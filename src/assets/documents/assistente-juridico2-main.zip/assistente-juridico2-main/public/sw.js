const CACHE_NAME = 'pje-assistente-cache-v5';
const urlsToCache = [
  '/',
  '/index.html',
  '/icon.svg',
  '/manifest.json',
  // URLs from importmap
  "https://aistudiocdn.com/react@^19.2.0",
  "https://aistudiocdn.com/react-dom@^19.2.0/",
  "https://aistudiocdn.com/@google/genai@^1.29.0"
];

// Install event: open cache and add all URLs to it
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Opened cache');
        return cache.addAll(urlsToCache).catch(err => {
          console.error('Failed to cache files during install:', err);
        });
      })
  );
});

// Fetch event: serve from cache first, then network
self.addEventListener('fetch', (event) => {
  // We only want to cache GET requests.
  if (event.request.method !== 'GET') {
    return;
  }
  
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        // If we have a cached response, check if it's valid
        if (response) {
          // Don't serve cached 401 responses - always try network
          if (response.status === 401) {
            console.log('Cached 401 found, fetching from network instead:', event.request.url);
            // Delete the bad cached response and then fetch from network
            return caches.open(CACHE_NAME)
              .then(cache => cache.delete(event.request))
              .then(() => fetch(event.request)
                .then((response) => {
                  // Don't cache error responses (401, 403, 404, 500, etc.)
                  if (!response || response.status < 200 || response.status >= 400) {
                    console.log('Not caching error response:', response?.status, event.request.url);
                    return response;
                  }

                  // Only cache successful responses (200-399)
                  // Opaque responses are for cross-origin resources (like CDNs). We can't see their status but can cache them.
                  if (response.type === 'basic' || response.type === 'opaque') {
                      const responseToCache = response.clone();
                      caches.open(CACHE_NAME)
                        .then((cache) => {
                          cache.put(event.request, responseToCache);
                        });
                  }

                  return response;
                })
                .catch(error => {
                  console.error('Fetch failed:', error, event.request.url);
                  // Try to return cached response even if it's old
                  return caches.match(event.request).then(cachedResponse => {
                    return cachedResponse || new Response('Network error occurred', {
                      status: 503,
                      statusText: 'Service Unavailable',
                      headers: new Headers({ 'Content-Type': 'text/plain' })
                    });
                  });
                })
              );
          } else {
            return response; // Return valid cached response
          }
        }
        
        // Not in cache, fetch from network
        return fetch(event.request).then(
          (response) => {
            // Don't cache error responses (401, 403, 404, 500, etc.)
            if (!response || response.status < 200 || response.status >= 400) {
              console.log('Not caching error response:', response?.status, event.request.url);
              return response;
            }

            // Only cache successful responses (200-399)
            // Opaque responses are for cross-origin resources (like CDNs). We can't see their status but can cache them.
            if (response.type === 'basic' || response.type === 'opaque') {
                const responseToCache = response.clone();
                caches.open(CACHE_NAME)
                  .then((cache) => {
                    cache.put(event.request, responseToCache);
                  });
            }

            return response;
          }
        ).catch(error => {
          console.error('Fetch failed:', error, event.request.url);
          // Try to return cached response even if it's old
          return caches.match(event.request).then(cachedResponse => {
            return cachedResponse || new Response('Network error occurred', {
              status: 503,
              statusText: 'Service Unavailable',
              headers: new Headers({ 'Content-Type': 'text/plain' })
            });
          });
        });
      })
  );
});


// Activate event: clean up old caches
self.addEventListener('activate', (event) => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// Push Notification event listener
self.addEventListener('push', (event) => {
  let data = { title: 'Nova Notificação', body: 'Você tem uma nova mensagem.', data: { url: '/' } };
  try {
    if (event.data) {
      data = event.data.json();
    }
  } catch (e) {
    console.error('Error parsing push data:', e);
    data.body = event.data ? event.data.text() : 'Não foi possível ler o conteúdo.';
  }

  const options = {
    body: data.body,
    icon: '/icon.svg',
    badge: '/icon.svg', // Icon for Android notifications bar
    data: data.data || { url: '/' }
  };

  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

// Notification Click event listener
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  const urlToOpen = new URL(event.notification.data.url || '/', self.location.origin).href;

  event.waitUntil(
    clients.matchAll({
      type: 'window',
      includeUncontrolled: true
    }).then((clientList) => {
      // If a window for the app is already open, focus it.
      for (const client of clientList) {
        if (client.url === urlToOpen && 'focus' in client) {
          return client.focus();
        }
      }
      // Otherwise, open a new window.
      if (clients.openWindow) {
        return clients.openWindow(urlToOpen);
      }
    })
  );
});
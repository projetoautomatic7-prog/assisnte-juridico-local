# Solução de Problemas: DATABASE_URL

## ❌ Erro: `getaddrinfo ENOTFOUND base`

Se você está vendo este erro nos logs do Render:

```
❌ Falha ao iniciar o servidor: Error: getaddrinfo ENOTFOUND base
    at /opt/render/project/src/backend/node_modules/pg-pool/index.js:45:11
    at process.processTicksAndRejections (node:internal/process/task_queues:95:5) {
  errno: -3008,
  code: 'ENOTFOUND',
  syscall: 'getaddrinfo',
  hostname: 'base'
}
```

### Causa

Isso significa que a variável de ambiente `DATABASE_URL` está **incorretamente configurada** no Render. O hostname do banco de dados está definido como 'base' ao invés do hostname real do seu banco de dados PostgreSQL.

### Como Resolver

#### Passo 1: Obter a Connection String Correta

1. Acesse seu **Dashboard da Render**
2. Vá para seu **Banco de Dados PostgreSQL** (não confunda com o serviço web!)
3. Clique na aba **Info** ou **Connect**
4. Copie a **Internal Connection String**
   - Ela deve ter este formato: `postgres://usuario:senha@hostname.region.render.com:5432/nome_do_banco`
   - Exemplo: `postgres://pje_user:ABC123xyz@dpg-abc123xyz-a.oregon-postgres.render.com:5432/pje_robot_db`

#### Passo 2: Configurar no Serviço Web

1. Ainda no Dashboard da Render, vá para seu **serviço web** (pje-robot-backend)
2. Clique na aba **Environment**
3. Encontre a variável `DATABASE_URL` ou adicione-a se não existir
4. Cole a **Internal Connection String** completa que você copiou
5. Clique em **Save Changes**

#### Passo 3: Verificar

O Render fará um novo deploy automaticamente. Aguarde e verifique os logs:

✅ **Sucesso:** Você deve ver mensagens como:
```
✅ Variáveis obrigatórias presentes.
🔌 Connecting to PostgreSQL at dpg-abc123xyz-a.oregon-postgres.render.com:5432/pje_robot_db as pje_user
🔌 Conectado ao banco de dados PostgreSQL.
🏛️  Banco de dados verificado e pronto.
🤖 Worker do Agente iniciado.
🚀 Servidor backend rodando na porta 10000
```

❌ **Ainda com erro?** Verifique:
- A Connection String foi copiada completamente (sem espaços extras no início/fim)
- Você está usando a **Internal** Connection String, não a External
- O banco de dados PostgreSQL está rodando (verifique na página do banco no Render)

## ⚠️ Erros Comuns

### 1. Usar External Connection String

❌ **ERRADO:** `postgres://usuario:senha@dpg-abc-external:5432/db`

✅ **CORRETO:** `postgres://usuario:senha@dpg-abc-a.oregon-postgres.render.com:5432/db`

### 2. Usar placeholder ou valores incompletos

❌ **ERRADO:** `postgres://USER:PASSWORD@HOST:5432/DATABASE`

❌ **ERRADO:** `postgres://user:pass@base:5432/db`

✅ **CORRETO:** Use a connection string real fornecida pelo Render

### 3. Esquecer de salvar as alterações

Sempre clique em **Save Changes** após editar as variáveis de ambiente no Render.

### 4. Não aguardar o redeploy

Após salvar as variáveis, o Render precisa fazer um novo deploy. Isso leva alguns minutos. Não force o deploy enquanto outro está em andamento.

## 📋 Formato da DATABASE_URL

A `DATABASE_URL` deve seguir este formato:

```
postgresql://[USUÁRIO]:[SENHA]@[HOST]:[PORTA]/[NOME_DO_BANCO]
```

Componentes:
- **USUÁRIO:** Nome do usuário do banco (ex: `pje_user`)
- **SENHA:** Senha do usuário (ex: `ABC123xyz`)
- **HOST:** Hostname completo do servidor PostgreSQL no Render (ex: `dpg-abc123xyz-a.oregon-postgres.render.com`)
- **PORTA:** Geralmente `5432` para PostgreSQL
- **NOME_DO_BANCO:** Nome do banco de dados (ex: `pje_robot_db`)

## 🔧 Desenvolvimento Local

Para desenvolvimento local, use:

```env
DATABASE_URL=postgres://postgres:postgres@localhost:5432/assistente_juridico
```

Se estiver usando Docker com o `docker-compose.yml` incluído no projeto:

```bash
docker compose up -d
```

Isso criará o banco automaticamente com as credenciais padrão.

## 📞 Ainda Precisa de Ajuda?

Se após seguir todos esses passos o problema persistir:

1. Verifique os logs completos do deploy no Render
2. Confirme que o banco de dados PostgreSQL está "Available" no dashboard da Render
3. Tente se conectar ao banco usando um cliente PostgreSQL (como DBeaver ou pgAdmin) usando a External Connection String para confirmar que o banco está acessível
4. Verifique se não há problemas de rede ou firewall bloqueando a conexão

## ✅ Checklist de Verificação

- [ ] Copiei a **Internal Connection String** do meu banco PostgreSQL no Render
- [ ] Colei a connection string completa na variável `DATABASE_URL` do meu serviço web
- [ ] Cliquei em **Save Changes** no Render
- [ ] Aguardei o redeploy completar
- [ ] Verifiquei os logs e vi a mensagem "Conectado ao banco de dados PostgreSQL"
